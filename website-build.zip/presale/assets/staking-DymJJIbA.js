import {
    f as e,
    _ as a
} from "./index-BPv_7EZ9.js";
import {
    _ as t
} from "./line-circ-y8Xq16cD.js";
import {
    m as l,
    Y as s,
    G as o,
    y as i,
    I as n,
    h as d,
    o as r,
    j as c,
    l as u,
    ck as m,
    p,
    t as v,
    X as g,
    v as h,
    w as f,
    q as x,
    n as y,
    s as k,
    u as b,
    dm as w,
    a as S,
    K as P,
    dn as T,
    P as j,
    cB as _,
    k as D,
    N as O,
    du as z,
    B as L,
    i as B
} from "./index-CQfCy4Xm.js";
import "./index-DZwhim7i.js";
import {
    E as A
} from "./index-DWyf7GKU.js";
import {
    E as I
} from "./index-CteOOV_f.js";
import {
    _ as C
} from "./_plugin-vue_export-helper-BCo6x5W8.js";
import {
    _ as V
} from "./ButtonGR-CCzD27Qk.js";
import {
    _ as F
} from "./Title-B_xB6icS.js";
import {
    _ as M
} from "./VPlaceload-DcvQMSN9.js";
import {
    _ as Z
} from "./Subtitle-C6oUzL5I.js";
import {
    _ as H
} from "./Navbar2-Cx1AKm6v.js";
import {
    F as E
} from "./browser-Cv63Auap.js";
import {
    m as W
} from "./index-CiVKPdRb.js";
import {
    r as R
} from "./calcs-C2mNVRpW.js";
import {
    E as N
} from "./index-5N62XIoj.js";
import {
    E as U
} from "./index-BaPl-dvV.js";
import {
    E as Y
} from "./index-DxHJyswS.js";
import {
    M as K
} from "./vue3-markdown-it.umd.min-h-q_g2pl.js";
import {
    m as G
} from "./vue3-apexcharts-DWxdUF6r.js";
import {
    _ as $
} from "./opz-B6gfBROM.js";
import {
    C as q,
    P as X,
    S as J
} from "./carousel.es-BlHzsVLl.js";
import {
    _ as Q
} from "./lodash-Bm6t9hsB.js";
import {
    u as ee
} from "./useSeoMeta-DJrBtPw8.js";
import {
    a as ae,
    E as te
} from "./index-D21_sbBM.js";
import {
    E as le,
    a as se
} from "./index-HXOjRM0c.js";
import {
    E as oe,
    a as ie
} from "./index-CBmmRNm0.js";
import {
    E as ne
} from "./index-CwZ3pmKF.js";
import {
    E as de,
    a as re
} from "./index-BUqPiGKl.js";
import {
    E as ce
} from "./index-CRtkyuT7.js";
import {
    E as ue
} from "./index-DhHA3mFI.js";
import {
    B as me
} from "./provider-browser-D4UahRA7.js";
import "./AppPop-DXr7YMXx.js";
import "./index-DPTDKB4o.js";
import "./index-wV0BwLDn.js";
import "./index-CB5HUA9W.js";
import "./google-play-0W6tGWt8.js";
import "./Button-C_PMcYdl.js";
import "./AvatarSimple-DIs6U3iF.js";
import "./via-placeholder-csI6CdwS.js";
import "./user-qMNVzsWD.js";
import "./sett-Dbwu6PJ1.js";
import "./avatarSettings-C1kj7zSJ.js";
import "./vue3-avataaars-DO56oOZp.js";
import "./index-38aUouWI.js";
import "./logo-DqlCWKKL.js";
import "./index-DYh1qtlV.js";
import "./index-CreMjc0E.js";
import "./use-dialog-CC6CVfkB.js";
import "./use-global-config-CYuHb1FB.js";
import "./index-BR6qnryQ.js";
import "./typescript-CRqm1_SZ.js";
import "./vue.runtime.esm-bundler-BbVV3g-V.js";
import "./vue.8fc199ce-DBDcZ0BB.js";
import "./aria-C-hsWcn7.js";
import "./index-Czea63rc.js";
import "./dayjs.min-CoMKM3gL.js";
import "./index-CIJievV_.js";
import "./_initCloneObject-DqrhPNyg.js";
import "./isPlainObject-BkooXA2Q.js";
import "./sha256-o0pdH_sn.js";
import "./secp256k1-LeYlzbB0.js";
const pe = {
        class: "cardV2-header"
    },
    ve = {
        class: "cardV2-btn-text"
    },
    ge = {
        class: "cardV2-top-btn-left pr-3 py-2 pl-2"
    },
    he = {
        class: "imgParent"
    },
    fe = ["src"],
    xe = {
        style: {
            float: "left"
        },
        class: "text-bold text-gray5"
    },
    ye = {
        class: "cardV2-top-btn"
    },
    ke = {
        class: "cardV2-body"
    },
    be = {
        class: "cardV2-body-top"
    },
    we = {
        width: "0"
    },
    Se = {
        class: "flex items-center justify-between mt-3",
        style: {
            width: "100%",
            "align-items": "start",
            "text-align": "start",
            "padding-right": "12px",
            "padding-left": "24px"
        }
    },
    Pe = {
        class: "flex items-center"
    },
    Te = {
        class: "flex items-center justify-between mt-1",
        style: {
            width: "100%",
            "align-items": "start",
            "text-align": "start",
            "padding-right": "12px",
            "padding-left": "24px"
        }
    },
    je = {
        style: {
            "font-size": "12px"
        }
    },
    _e = {
        class: "cardV2-body-bottom"
    },
    De = {
        class: "cardV2-body-bottom-r"
    },
    Oe = {
        class: "cardV2-body-bottom-t"
    },
    ze = {
        class: "cardV2-body-bottom-t1"
    },
    Le = {
        class: "cardV2-body-bottom-t2"
    },
    Be = C(l({
        __name: "CardV4",
        props: {
            card: {},
            isMobileWidth: {
                type: Boolean
            }
        },
        emits: ["stake"],
        setup(e, {
            emit: a
        }) {
            const {
                t: l
            } = s(), b = o(), w = e, S = a, P = () => {
                S("stake", w.card)
            }, T = i(!1);
            n((() => {
                w.isMobileWidth && setTimeout((() => {
                    T.value = !0
                }), 3e3)
            }));
            const j = () => {
                    T.value = !0
                },
                _ = () => {
                    w.isMobileWidth || (T.value = !1)
                },
                D = d((() => parseFloat((w.card.amountPurchased / w.card.maxAvailable * 100).toFixed(2)))),
                O = d((() => {
                    const e = w.card.amountPurchased / w.card.maxAvailable;
                    return e <= .1 ? "Basic" : e <= .2 ? "Moderate" : e <= .4 ? "Enhanced" : e <= .6 ? "High" : e <= .8 ? "Very High" : "Maximum"
                }));
            return (e, a) => {
                var s, o;
                return r(), c("div", {
                    class: "cardV2",
                    style: m(w.card.expired && "opacity:0.8;"),
                    onMouseover: j,
                    onMouseleave: _,
                    onFocus: j,
                    onFocusout: _
                }, [u("div", null, [u("div", pe, [u("div", {
                    class: "cardV2-header-bg",
                    style: m("background-image: url(/assets/illustrations/" + ("ETH" === w.card.aiCoin ? "img-eth" : "img-btc") + ".jpg)")
                }, a[1] || (a[1] = [u("img", {
                    class: "cardV2-header-rd",
                    alt: "",
                    src: t
                }, null, -1)]), 4), u("div", {
                    class: p(["cardV2-btn", T.value && "isHover"])
                }, [a[2] || (a[2] = u("div", {
                    class: "cardV2-btn-icon"
                }, [u("span", {
                    class: "cardv2-bt-text"
                })], -1)), u("a", {
                    onClick: P
                }, [u("div", ve, [u("span", null, v(g(l)("stk.stake-now")), 1)])])], 2), u("div", ge, [u("div", {
                    class: "flex items-center cursor-pointer",
                    onClick: a[0] || (a[0] = e => g(b).push({
                        name: "trade-slug",
                        params: {
                            slug: w.card.aiCoin + "-USDT"
                        }
                    }))
                }, [u("span", he, [u("img", {
                    class: "imgSelect",
                    src: "/images/coinsnew/" + (null == (s = w.card.aiCoin) ? void 0 : s.toString().toLowerCase()) + ".png"
                }, null, 8, fe)]), u("span", xe, v(w.card.aiCoin) + "/USDT", 1), a[3] || (a[3] = u("i", {
                    class: "iconify ml-1",
                    "data-icon": "feather:external-link",
                    "data-inline": "false"
                }, null, -1))])]), u("div", ye, [h(g(A), {
                    effect: "customized",
                    content: w.card.running ? "Expired" : w.card.amountPurchased == w.card.maxAvailable ? "Finished" : "Active",
                    placement: "top"
                }, {
                    default: f((() => [u("div", {
                        class: p(w.card.running ? "expired-circle" : w.card.amountPurchased == w.card.maxAvailable ? "completed-circle" : "cardV2-top-btn-circle pulsate")
                    }, null, 2)])),
                    _: 1
                }, 8, ["content"])])])]), u("div", ke, [u("div", be, [u("span", we, [u("span", null, [u("span", null, v(w.card.title) + " " + v(w.card.periodDays >= 365 ? (o = w.card.periodDays, o >= 365 && o < 730 ? "1Y" : o >= 730 && o < 1095 ? "2Y" : o >= 1095 && o < 1460 ? "3Y" : o >= 1460 && o < 1825 ? "4Y" : o >= 1825 ? Math.floor(o / 365) + "Y" : o + "D") : ""), 1)])])]), u("div", Se, [u("div", Pe, [u("p", null, v(g(l)("stk.est-apy")), 1)]), u("span", {
                    class: p(w.card.annualInterestRate > 0 ? "text-green-500" : w.card.annualInterestRate < 0 ? "text-red-500" : "")
                }, v((w.card.annualInterestRate > 0 ? "+" : "") + (100 * w.card.annualInterestRate).toFixed(2)) + "% ", 3)]), h(g(A), {
                    effect: "customized",
                    placement: "top"
                }, {
                    content: f((() => [u("p", null, [x(" Your stake directly fuels " + v(w.card.aiCoin) + "-GPT Processing Power, ", 1), a[4] || (a[4] = u("br", null, null, -1)), a[5] || (a[5] = x(" allowing it to make smart trading decisions. "))])])),
                    default: f((() => [u("div", Te, [a[6] || (a[6] = u("div", {
                        class: "flex items-center",
                        style: {
                            "font-size": "12px"
                        }
                    }, [u("p", null, "Processing Power")], -1)), u("span", je, v(O.value), 1)])])),
                    _: 1
                }), 0 != w.card.maxprogress ? (r(), y(g(A), {
                    key: 0,
                    effect: "customized",
                    content: w.card.amountPurchased + "/" + w.card.maxAvailable + " OPZ (" + D.value + "%)",
                    placement: "top"
                }, {
                    default: f((() => [u("div", _e, [u("div", De, [h(g(I), {
                        percentage: 0 == D.value ? 50 : D.value,
                        indeterminate: 0 == D.value,
                        "stroke-width": 21,
                        striped: "",
                        "striped-flow": "",
                        "text-inside": !0,
                        duration: 10
                    }, {
                        default: f((({
                            percentage: e
                        }) => [u("span", {
                            class: p(["percentage-value", e < 18 && "bld"])
                        }, v(0 == D.value ? "0" : e) + "%", 3)])),
                        _: 1
                    }, 8, ["percentage", "indeterminate"])]), u("div", Oe, [u("div", ze, v(w.card.amountPurchased) + " OPZ", 1), u("div", Le, v(w.card.maxAvailable) + " OPZ", 1)])])])),
                    _: 1
                }, 8, ["content"])) : k("", !0)])], 36)
            }
        }
    }), [
        ["__scopeId", "data-v-bc56fb54"]
    ]),
    Ae = {
        class: "imgParent"
    },
    Ie = ["src"],
    Ce = {
        class: "flex flex-col"
    },
    Ve = {
        class: "title-header text-gray3"
    },
    Fe = {
        class: "text-gray5"
    },
    Me = {
        class: "text-gray3 mr-1"
    },
    Ze = {
        class: "flex justify-between mb-0 mx-1",
        style: {
            "margin-top": "1px"
        }
    },
    He = {
        class: "help text-gray2"
    },
    Ee = {
        key: 0,
        class: "help text-medium flex"
    },
    We = {
        key: 1,
        class: "help text-medium flex"
    },
    Re = {
        class: "ml-1 text-gray3"
    },
    Ne = {
        key: 0,
        class: "mt-1 flex justify-between mt-0 mb-0 mx-1"
    },
    Ue = {
        class: "help text-medium flex"
    },
    Ye = {
        class: "ml-1 text-gray3"
    },
    Ke = {
        key: 1,
        class: "flex justify-between mt-0 mb-0 mx-1"
    },
    Ge = {
        class: "help text-gray2"
    },
    $e = {
        class: "help text-medium flex"
    },
    qe = {
        class: "ml-1 text-gray3"
    },
    Xe = {
        key: 2,
        class: "flex justify-between mt-2 mb-1 mx-1"
    },
    Je = {
        class: "text-12 text-gray2"
    },
    Qe = {
        class: "text-12 text-medium flex"
    },
    ea = {
        class: "ml-1 text-gray3"
    },
    aa = {
        key: 3,
        class: "flex justify-between mt-2 mb-1 mx-1"
    },
    ta = {
        class: "text-12 text-medium flex"
    },
    la = {
        class: "ml-1 text-gray3"
    },
    sa = {
        key: 4,
        class: "flex justify-between mt-2 mb-1 mx-1"
    },
    oa = {
        class: "text-12 text-gray2"
    },
    ia = {
        class: "text-12 text-medium flex"
    },
    na = {
        class: "ml-1 text-gray3"
    },
    da = {
        key: 5,
        class: "flex justify-between mt-2 mb-1 mx-1"
    },
    ra = {
        class: "text-12 text-gray2"
    },
    ca = {
        class: "text-12 text-medium flex"
    },
    ua = {
        class: "ml-1 text-gray3"
    },
    ma = {
        key: 6,
        class: "flex justify-between mt-2 mb-1 mx-1"
    },
    pa = {
        class: "text-12 text-gray2"
    },
    va = {
        class: "text-12 text-medium"
    },
    ga = {
        class: "flex justify-between mt-1 mx-1"
    },
    ha = {
        class: "text-medium text-gray5"
    },
    fa = {
        class: "text-bold text-green-500"
    },
    xa = {
        key: 7,
        class: "flex justify-between mt-1 mx-1"
    },
    ya = {
        class: "text-medium text-gray5"
    },
    ka = {
        class: "text-bold"
    },
    ba = {
        class: "dialog-footer"
    },
    wa = {
        class: "flex",
        style: {
            display: "flex",
            width: "100%"
        }
    },
    Sa = C(l({
        __name: "Staking",
        props: {
            btn: {
                type: Boolean,
                default: !1
            },
            modelValue: {
                type: Boolean,
                default: !0
            },
            selectedStake: {
                default: void 0
            },
            wallet: {
                default: void 0
            },
            openHistory: {
                default: void 0
            },
            balanceAllocation: {
                default: 0
            },
            allOnlyBlockWallet: {
                default: void 0
            }
        },
        emits: ["update:modelValue", "close", "addBlockBalance", "refreshAdd"],
        setup(e, {
            emit: a
        }) {
            const t = o(),
                l = b(),
                {
                    t: n
                } = s(),
                {
                    Api: m
                } = w();
            i();
            const p = S(),
                _ = P({
                    amount: "",
                    region: "",
                    date1: "",
                    date2: "",
                    delivery: !1,
                    wallet: [
                        []
                    ],
                    resource: "",
                    desc: ""
                }),
                D = a,
                O = e,
                z = d({
                    get: () => O.modelValue,
                    set: e => D("update:modelValue", e)
                });
            P({
                allCards: []
            }), T();
            const L = e => {
                    for (var a = e.toLowerCase().split(" "), t = 0; t < a.length; t++) a[t] = a[t].charAt(0).toUpperCase() + a[t].substring(1);
                    return a.join(" ")
                },
                B = () => {
                    D("update:modelValue", !0)
                },
                I = () => {
                    _.amount = "", D("update:modelValue", !1)
                },
                C = () => {
                    z.value = !1, D("addBlockBalance"), D("update:modelValue", !1)
                },
                F = () => {
                    if ("" == _.amount || "0" == _.amount) return void p.error(n("inx.please-input-correct-amount"));
                    if (!(Number(_.amount) > 0)) return void p.error(n("inx.please-input-correct-amount"));
                    if (null == O.selectedStake) return void p.error(n("stk.please-try-again"));
                    if (Number(_.amount) < O.selectedStake.minBuyAmount) return void p.error(n("stk.min-amount") + ": " + O.selectedStake.minBuyAmount + " " + O.selectedStake.coin);
                    const e = new E;
                    e.append("amount", _.amount), e.append("stakingId", O.selectedStake.id), m.addStaking(e).then((e => {
                        const a = e.data;
                        0 == a.code ? (z.value = !1, p.success(n("inx.submitted-successfully")), D("refreshAdd", _.amount)) : p.error(a.message)
                    }))
                },
                M = d((() => {
                    const e = O.selectedStake.periodDays;
                    let a = !1,
                        t = "";
                    return 365 === e ? (a = !0, t = "1 Year " + n("stk.locked-staking")) : 1460 === e ? (a = !0, t = "4 Year " + n("stk.locked-staking")) : t = e < 7 ? n("stk.locked-staking") : e + " " + n("stk.days") + " " + n("stk.locked-staking"), {
                        text: t,
                        isLongTerm: a
                    }
                })),
                Z = () => {
                    var e, a, t;
                    const l = (null == (a = null == (e = O.wallet) ? void 0 : e.filter((e => e.coin === O.selectedStake.coin))[0]) ? void 0 : a.balance) ? ? 0;
                    null == (t = O.openHistory) || t.filter((e => e.stakingId === O.selectedStake.id)).reduce(((e, a) => e + a.amount), 0).toFixed(0), M.value.isLongTerm ? _.amount = O.balanceAllocation.toFixed(0) : _.amount = l >= O.selectedStake.maxBuyAmount2 ? O.selectedStake.maxBuyAmount2 : l
                },
                H = d((() => {
                    const e = O.selectedStake.periodDays,
                        a = new Date,
                        t = new Date(a.setDate(a.getDate() + e));
                    return W(t).format("D MMM YYYY")
                }));
            return (e, a) => {
                const s = V;
                return r(), c(j, null, [O.btn ? (r(), y(s, {
                    key: 0,
                    class: "btn-buy-card",
                    onClick: a[0] || (a[0] = e => B())
                }, {
                    default: f((() => a[7] || (a[7] = [x("Order")]))),
                    _: 1
                })) : k("", !0), h(g(N), {
                    class: "dialogStaking",
                    modelValue: z.value,
                    "onUpdate:modelValue": a[5] || (a[5] = e => z.value = e),
                    "append-to-body": "",
                    "destroy-on-close": "",
                    onClose: I,
                    onOpen: a[6] || (a[6] = e => B())
                }, {
                    header: f((() => {
                        var e, a;
                        return [u("span", Ae, [u("img", {
                            width: "35",
                            height: "35",
                            src: "/images/icons/coin/" + (null == (e = O.selectedStake.coin) ? void 0 : e.toLowerCase()) + ".svg"
                        }, null, 8, Ie)]), u("div", Ce, [u("span", Ve, v(O.selectedStake.coin), 1), u("span", Fe, v(null == (a = M.value) ? void 0 : a.text), 1)])]
                    })),
                    footer: f((() => {
                        var a;
                        return [u("span", ba, [u("div", wa, [g(l).isLoggedIn && (null == (a = e.allOnlyBlockWallet) ? void 0 : a.totalAmount) > 0 ? (r(), y(s, {
                            key: 0,
                            size: "small",
                            style: {
                                "flex-grow": "1",
                                "margin-right": "10px"
                            },
                            onClick: C
                        }, {
                            default: f((() => [x(v(g(n)("dash.add")), 1)])),
                            _: 1
                        })) : k("", !0), h(s, {
                            size: "small",
                            style: {
                                "flex-grow": "1"
                            },
                            onClick: F,
                            disabled: "" == _.amount || Number(_.amount) <= 0
                        }, {
                            default: f((() => [x(v(g(n)("stk.stake-now")), 1)])),
                            _: 1
                        }, 8, ["disabled"])])])]
                    })),
                    default: f((() => {
                        var s, o, i, d, m, p, y, b, w, S;
                        return [h(g(U), {
                            modelValue: _.amount,
                            "onUpdate:modelValue": a[2] || (a[2] = e => _.amount = e),
                            autocomplete: "off",
                            onKeydown: a[3] || (a[3] = e => (e => {
                                const a = e.keyCode;
                                190 != a && 110 != a || (_.amount.indexOf(".") > 0 && e.preventDefault(), "" == _.amount && e.preventDefault()), a >= 48 && a <= 57 || a >= 96 && a <= 105 || [8, 37, 39, 46, 190, 110].includes(a) || e.preventDefault()
                            })(e))
                        }, {
                            suffix: f((() => [u("p", Me, v(O.selectedStake.coin), 1), a[8] || (a[8] = x(" | ")), u("span", {
                                class: "max-add",
                                onClick: a[1] || (a[1] = (...e) => Z && Z(...e))
                            }, v(g(n)("inx.max")), 1)])),
                            _: 1
                        }, 8, ["modelValue"]), u("div", Ze, [u("p", He, v((null == (s = M.value) ? void 0 : s.isLongTerm) ? "Available Allocation" : g(n)("dash.available-balance")), 1), g(l).isLoggedIn ? (r(), c("span", We, [x(v(g(R)((null == (o = M.value) ? void 0 : o.isLongTerm) ? O.balanceAllocation : null == (d = null == (i = e.wallet) ? void 0 : i.filter((e => e.coin == O.selectedStake.coin))[0]) ? void 0 : d.balance, 8)) + " ", 1), u("p", Re, v(O.selectedStake.coin), 1)])) : (r(), c("p", Ee, [h(g(Y), {
                            onClick: a[4] || (a[4] = e => g(t).push({
                                name: "auth",
                                query: {
                                    redirect: "/staking"
                                }
                            }))
                        }, {
                            default: f((() => [x(v(g(n)("inx.please-login")), 1)])),
                            _: 1
                        })]))]), g(l).isLoggedIn && (null == (m = e.allOnlyBlockWallet) ? void 0 : m.totalAmount) > 0 ? (r(), c("div", Ne, [a[9] || (a[9] = u("p", {
                            class: "help text-gray2"
                        }, v("Unavailable Balance"), -1)), u("span", Ue, [x(v(g(R)((null == (p = e.allOnlyBlockWallet) ? void 0 : p.totalAmount) || 0, 8)) + " ", 1), u("p", Ye, v(O.selectedStake.coin), 1), h(g(Y), {
                            style: {
                                "margin-left": "6px",
                                position: "relative",
                                top: "-4px",
                                "font-size": "1rem",
                                "line-height": "1.5"
                            },
                            onClick: C
                        }, {
                            default: f((() => [x(v(g(n)("dash.add")), 1)])),
                            _: 1
                        })])])) : k("", !0), (null == (y = e.allOnlyBlockWallet) ? void 0 : y.totalAmount) && 0 != (null == (b = e.allOnlyBlockWallet) ? void 0 : b.totalAmount) || 0 == O.openHistory.length || !O.openHistory.some((e => e.stakingId == O.selectedStake.id && 0 == e.redeemed)) ? k("", !0) : (r(), c("div", Ke, [u("p", Ge, v(g(n)("stk.locked-staking")), 1), u("span", $e, [x(v(O.openHistory.filter((e => e.stakingId == O.selectedStake.id && 0 == e.redeemed)).reduce(((e, a) => e + a.amount), 0).toFixed(0)) + " ", 1), u("p", qe, v(O.selectedStake.coin), 1)])])), a[15] || (a[15] = u("hr", {
                            class: "mt-4 mb-0 line-hz"
                        }, null, -1)), "OPZ" != O.selectedStake.coin ? (r(), c("div", Xe, [u("p", Je, v(L(g(n)("stk.maximum-amount"))) + ":", 1), u("span", Qe, [x(v(O.selectedStake.maxBuyAmount2.toFixed(5)) + " ", 1), u("p", ea, v(O.selectedStake.coin), 1)])])) : k("", !0), "OPZ" == O.selectedStake.coin && 999999999 != O.selectedStake.maxBuyAmount ? (r(), c("div", aa, [a[10] || (a[10] = u("p", {
                            class: "text-12 text-gray2"
                        }, v("Max Buy Amount") + ": ", -1)), u("span", ta, [x(v(O.selectedStake.maxBuyAmount.toLocaleString(void 0, {
                            maximumFractionDigits: 0
                        })) + " ", 1), u("p", la, v(O.selectedStake.coin), 1)])])) : k("", !0), "OPZ" == O.selectedStake.coin ? (r(), c("div", sa, [u("p", oa, v(L(g(n)("stk.total-staked-amount"))) + ": ", 1), u("span", ia, [x(v(O.selectedStake.amountPurchased.toLocaleString(void 0, {
                            maximumFractionDigits: 0
                        })) + " ", 1), u("p", na, v(O.selectedStake.coin), 1)])])) : k("", !0), "OPZ" == O.selectedStake.coin ? (r(), c("div", da, [u("p", ra, v(L(g(n)("dash.max-supply"))) + ": ", 1), u("span", ca, [x(v(O.selectedStake.maxAvailable.toLocaleString(void 0, {
                            maximumFractionDigits: 0
                        })) + " ", 1), u("p", ua, v(O.selectedStake.coin), 1)])])) : k("", !0), 9999999999999 != O.selectedStake.startTime && (null == (w = M.value) ? void 0 : w.isLongTerm) ? (r(), c("div", ma, [u("p", pa, v(L(g(n)("stk.redeem-date"))) + ":", 1), u("p", va, v(H.value), 1)])) : k("", !0), a[16] || (a[16] = u("hr", {
                            class: "mt-2 mb-2 line-hz"
                        }, null, -1)), u("div", ga, [u("p", ha, v(g(n)("stk.est-apy")) + ":", 1), u("p", fa, v((100 * O.selectedStake.annualInterestRate).toFixed(2)) + "% ", 1)]), (null == (S = M.value) ? void 0 : S.isLongTerm) ? (r(), c("div", xa, [u("p", ya, [a[13] || (a[13] = x(v("Factor"))), h(g(A), {
                            effect: "customized",
                            width: "300px",
                            placement: "top"
                        }, {
                            content: f((() => a[11] || (a[11] = [u("p", null, [x(" The ratio factor between the amount of OPZ locked and the "), u("br"), x(" final OPZ amount. Extend your lock duration to increase "), u("br"), x(" the ratio factor. ")], -1)]))),
                            default: f((() => [a[12] || (a[12] = u("i", {
                                class: "fas fa-info-circle text-gray1 ml-1",
                                style: {
                                    "font-size": "12px"
                                }
                            }, null, -1))])),
                            _: 1
                        }), a[14] || (a[14] = x(":"))]), u("p", ka, v((O.selectedStake.annualInterestRate / 365 * O.selectedStake.periodDays).toFixed(2)) + "x ", 1)])) : k("", !0)]
                    })),
                    _: 1
                }, 8, ["modelValue"])], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-b8ccd1c8"]
    ]),
    Pa = {
        class: "staking-dash"
    },
    Ta = {
        class: "staking-dash-body"
    },
    ja = {
        class: "staking-dash-top"
    },
    _a = {
        role: "toolbar",
        "aria-orientation": "horizontal",
        dir: "ltr",
        class: "sdash-btn-i sdash-21",
        layout: "row",
        tabindex: "-1",
        "data-orientation": "horizontal",
        style: {
            outline: "none"
        }
    },
    Da = {
        class: "sdash-7562 sdash-75242"
    },
    Oa = {
        class: "stdash-62165"
    },
    za = {
        key: 0,
        class: "sdash-b13s stdash-21314"
    },
    La = ["title"],
    Ba = {
        class: "text-gray1 mr-2"
    },
    Aa = {
        class: "stdash-bottom"
    },
    Ia = {
        class: "sdash-4252"
    },
    Ca = {
        class: "stads-4342 stadsg-4325"
    },
    Va = {
        class: "stdasdh-3242"
    },
    Fa = {
        class: "stdash-img-s21"
    },
    Ma = {
        key: 0,
        class: "sdash-b13s stdash-21314"
    },
    Za = ["title"],
    Ha = {
        class: "stdasdh-3242"
    },
    Ea = {
        key: 0,
        class: "sdash-b13s stdash-21314"
    },
    Wa = {
        key: 1,
        title: "0",
        class: "sdash-b13s stdash-21314"
    },
    Ra = C(l({
        __name: "StakingDash",
        props: {
            opzBalance: {
                default: 0
            },
            loading: {
                type: Boolean,
                default: !1
            },
            totalStakedOPZ: {
                default: 0
            },
            allTimeProfit: {
                default: 0
            }
        },
        setup(e) {
            const a = e,
                {
                    t: t
                } = s(),
                l = P({
                    feeGrade: {}
                }),
                d = b(),
                {
                    Api: m
                } = w();
            d.isLoggedIn && m.getUserFeeLvl().then((e => {
                const a = e.data;
                0 == a.code && (l.feeGrade = a.data)
            })), o();
            const p = T();
            return i(p.isAppOn), n((() => {})), (e, l) => {
                const s = M;
                return r(), c("section", Pa, [u("div", Ta, [u("div", ja, [l[1] || (l[1] = u("h3", {
                    class: "sdash-im"
                }, [u("img", {
                    src: $,
                    class: "sdash-title",
                    alt: "OPZ"
                }), x("OPZ ")], -1)), u("div", _a, [u("dl", Da, [u("div", Oa, [u("dd", null, [e.loading ? (r(), c("div", za, [h(s, {
                    height: "17.9px",
                    width: "75px",
                    style: {
                        "background-color": "rgba(255, 255, 255, 0.33)"
                    }
                })])) : (r(), c("output", {
                    key: 1,
                    title: a.opzBalance || "0.00",
                    class: "sdash-b13s stdash-21314"
                }, [u("span", Ba, v(g(t)("exh.total")) + ":", 1), x(" " + v((a.opzBalance + a.allTimeProfit).toFixed(2) || "0.00"), 1), l[0] || (l[0] = u("span", {
                    class: "stadsh-312 stads-131"
                }, "OPZ", -1))], 8, La))])])])])]), u("div", Aa, [u("div", Ia, [u("dl", Ca, [u("div", Va, [u("dt", null, [u("div", Fa, [u("h4", null, v(g(t)("dash.allocation")), 1), l[2] || (l[2] = u("div", {
                    class: "stdash-if2"
                }, [u("i", {
                    class: "fas fa-wallet sdash-img"
                })], -1))])]), u("dd", null, [e.loading ? (r(), c("div", Ma, [h(s, {
                    height: "25.6px",
                    width: "60px",
                    style: {
                        "background-color": "rgba(255, 255, 255, 0.33)"
                    }
                })])) : (r(), c("output", {
                    key: 1,
                    title: a.opzBalance || "0.00",
                    class: "sdash-b13s stdash-21314"
                }, v(a.opzBalance || "0.00"), 9, Za))])]), u("div", Ha, [l[3] || (l[3] = u("dt", null, [u("div", {
                    class: "stdash-img-s21"
                }, [u("h4", null, " Allocation at TGE Price "), u("div", {
                    class: "stdash-if2"
                }, [u("i", {
                    class: "fas fa-lock sdash-img"
                })])])], -1)), u("dd", null, [e.loading ? (r(), c("div", Ea, [h(s, {
                    height: "25.6px",
                    width: "75px",
                    style: {
                        "background-color": "rgba(255, 255, 255, 0.33)"
                    }
                })])) : (r(), c("output", Wa, v("$" + (a.opzBalance ? (.1 * a.opzBalance).toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }) : "0.00")), 1))])])])])])])])
            }
        }
    }), [
        ["__scopeId", "data-v-6c228efe"]
    ]),
    Na = {
        class: "flex"
    },
    Ua = {
        class: "card reffbox reffbox-bordered",
        style: {
            width: "100%"
        }
    },
    Ya = {
        class: "nk-refwg"
    },
    Ka = {
        class: "nk-refwg-invite reffbox-inner",
        style: {
            padding: "0"
        }
    },
    Ga = {
        class: "nk-refwg-stats reffbox-inner bg-lighter"
    },
    $a = {
        class: ""
    },
    qa = {
        class: ""
    },
    Xa = {
        class: "flex fw-bold small"
    },
    Ja = {
        class: "flex-grow-1 text-medium"
    },
    Qa = {
        class: "row align-items-center mb-4 pt-2"
    },
    et = {
        class: "col-7"
    },
    at = {
        key: 1,
        class: "mb-0 font-big-1"
    },
    tt = {
        class: "col-5"
    },
    lt = {
        class: "mt-n3"
    },
    st = {
        class: "small text-white text-opacity-50 text-truncate"
    },
    ot = {
        class: "flex mt-3"
    },
    it = C(l({
        __name: "OPZDash",
        props: {
            opzBalance: {
                default: 0
            },
            loading: {
                type: Boolean,
                default: !1
            },
            totalStakedOPZ: {
                default: 0
            },
            allTimeProfit: {
                default: 0
            },
            todayProfit: {
                default: 0
            },
            last7DaysProfit: {
                default: []
            }
        },
        setup(e) {
            const a = e,
                t = b(),
                {
                    t: l
                } = s(),
                o = i(t.isLoggedIn ? t.userData.promotionCode : "");
            i(t.isLoggedIn ? l("ctm.refurl") + String(o.value) : l("inx.please-login")), S();
            const n = () => {
                var e, t;
                const s = [];
                for (let a = 6; a >= 0; a--) {
                    const e = new Date;
                    e.setDate(e.getDate() - a), s.push(e)
                }
                const o = s.map(((e, a) => 6 === a ? l("dash.today") : 5 === a ? l("dash.yesterday") : `${e.getDate().toString().padStart(2,"0")}/${(e.getMonth()+1).toString().padStart(2,"0")}/${e.getFullYear()}`));
                return [{
                    title: l("stk.total-interest-earned"),
                    total: a.allTimeProfit,
                    info: [{
                        icon: "fa fa-calendar-week fa-fw me-1",
                        text: "*" + l("pga.commission") + " (" + l("dash.today") + "):* " + a.todayProfit.toFixed(3) + " **OPZ**"
                    }, {
                        icon: "fa fa-calendar-alt fa-fw me-1",
                        text: "*" + l("pga.commission") + " (" + l("dash.yesterday") + "):* " + Number(null == (e = null == a ? void 0 : a.last7DaysProfit) ? void 0 : e[5].toString()).toFixed(3) + " **OPZ**"
                    }, {
                        icon: "fa fa-calendar-alt fa-fw me-1",
                        text: "*" + l("pga.commission") + " (" + l("dash.all") + "):* " + (null == (t = null == a ? void 0 : a.allTimeProfit) ? void 0 : t.toFixed(3)) + " **OPZ**"
                    }],
                    chart: {
                        height: 36,
                        options: {
                            chart: {
                                type: "bar",
                                sparkline: {
                                    enabled: !0
                                }
                            },
                            colors: ["rgba(115,3,252, 1)"],
                            plotOptions: {
                                bar: {
                                    horizontal: !1,
                                    columnWidth: "65%",
                                    endingShape: "rounded"
                                }
                            },
                            labels: o,
                            tooltip: {
                                enabled: a.allTimeProfit,
                                theme: "dark",
                                style: {
                                    fontSize: "12px",
                                    fontFamily: "DINPRO-Medium"
                                }
                            }
                        },
                        series: [{
                            name: "OPZ",
                            data: a.allTimeProfit ? a.last7DaysProfit : [1, 2, 3, 4, 5, 6, 7, 8]
                        }]
                    }
                }]
            };
            return (e, t) => {
                const l = M;
                return r(), c("div", Na, [u("div", Ua, [u("div", Ya, [u("div", Ka, [h(Ra, {
                    opzBalance: a.opzBalance,
                    "onUpdate:opzBalance": t[0] || (t[0] = e => a.opzBalance = e),
                    allTimeProfit: a.allTimeProfit,
                    totalStakedOPZ: e.totalStakedOPZ,
                    loading: e.loading
                }, null, 8, ["opzBalance", "allTimeProfit", "totalStakedOPZ", "loading"])]), u("div", Ga, [(r(!0), c(j, null, _(n(), (a => (r(), c("div", null, [u("div", $a, [u("div", qa, [u("div", Xa, [u("span", Ja, v(a.title), 1)]), u("div", Qa, [u("div", et, [e.loading ? (r(), y(l, {
                    key: 0,
                    height: "25px",
                    width: "52px",
                    style: {
                        "background-color": "rgba(255, 255, 255, 0.33)"
                    }
                })) : (r(), c("h3", at, v(a.total.toFixed(3)), 1))]), u("div", tt, [u("div", lt, [h(g(G), {
                    height: a.chart.height,
                    options: a.chart.options,
                    series: a.chart.series
                }, null, 8, ["height", "options", "series"])])])]), u("div", st, [(r(!0), c(j, null, _(a.info, (e => (r(), c("div", ot, [u("i", {
                    class: p(e.icon)
                }, null, 2), h(g(K), {
                    source: e.text,
                    class: "mk-earnings",
                    breaks: !0
                }, null, 8, ["source"])])))), 256))])])])])))), 256))])]), t[1] || (t[1] = D('<div class="card-arrow" data-v-ccda2d99><div class="card-arrow-top-left" data-v-ccda2d99></div><div class="card-arrow-top-right" data-v-ccda2d99></div><div class="card-arrow-bottom-left" data-v-ccda2d99></div><div class="card-arrow-bottom-right" data-v-ccda2d99></div></div>', 1))])])
            }
        }
    }), [
        ["__scopeId", "data-v-ccda2d99"]
    ]),
    nt = {
        class: "staking-head"
    },
    dt = {
        class: "staking-top"
    },
    rt = {
        class: "staking-top-body",
        style: {
            width: "100%",
            "max-width": "inherit",
            "justify-content": "center"
        }
    },
    ct = {
        class: "staking-top-middle",
        style: {
            "max-width": "1200px"
        }
    },
    ut = {
        class: "staking-top-bar"
    },
    mt = {
        class: "staking-bar-body"
    },
    pt = {
        class: "staking-body"
    },
    vt = {
        key: 0,
        class: "content-stake"
    },
    gt = {
        class: ""
    },
    ht = {
        class: "has-text-centered flex justify-center items-center flex-col mb-3"
    },
    ft = {
        key: 0
    },
    xt = {
        key: 1
    },
    yt = {
        key: 0
    },
    kt = {
        key: 1
    },
    bt = {
        class: "userRankContainer"
    },
    wt = {
        class: "rankInfo"
    },
    St = ["src", "alt"],
    Pt = {
        class: "rankDetails"
    },
    Tt = {
        key: 0,
        class: "bonus-amount"
    },
    jt = {
        className: "index-section flex flex-row"
    },
    _t = {
        class: "data-index"
    },
    Dt = {
        class: "rankProgress"
    },
    Ot = {
        class: "progressBar"
    },
    zt = {
        class: "flex justify-between",
        style: {
            width: "100%"
        }
    },
    Lt = {
        class: "mr-2 text-bold",
        style: {
            "font-size": "15px"
        }
    },
    Bt = {
        class: "rankInfo reverseOrder"
    },
    At = ["src", "alt"],
    It = {
        key: 0,
        className: "index-section flex flex-row",
        style: {
            order: "1"
        }
    },
    Ct = {
        class: "data-index"
    },
    Vt = {
        class: "rankDetails"
    },
    Ft = {
        key: 0
    },
    Mt = {
        key: 1
    },
    Zt = {
        key: 2,
        class: "bonus-amount"
    },
    Ht = {
        class: "mob-table mt-3"
    },
    Et = {
        class: "mob-table-header"
    },
    Wt = {
        class: "mob-t-text-end flex items-center"
    },
    Rt = {
        class: "flex items-center claim-opz"
    },
    Nt = {
        class: "flex flex-col",
        style: {
            "min-width": "0px",
            width: "100%",
            position: "relative"
        }
    },
    Ut = {
        class: "flex flex-row"
    },
    Yt = {
        class: "cardV2-top-btn top-circle"
    },
    Kt = {
        class: "sc-x4ybvz-4 juixKb",
        style: {
            "scroll-behavior": "smooth",
            padding: "1rem 16px",
            height: "100%",
            isolation: "isolate",
            position: "relative",
            overflow: "auto"
        }
    },
    Gt = {
        class: "text-gray1"
    },
    $t = {
        class: "claim-opz-avail"
    },
    qt = {
        style: {
            flex: "1 1 0%"
        }
    },
    Xt = {
        key: 1,
        title: "0",
        class: "text-bold flex",
        style: {
            "font-size": "26px",
            "line-height": "30px",
            "-webkit-box-align": "center",
            "align-items": "center",
            "min-width": "max-content",
            gap: "0px"
        }
    },
    Jt = {
        id: "mob-table-0",
        class: "mob-table-body pt-0"
    },
    Qt = {
        "aria-hidden": "true",
        class: "mob-data-bottom"
    },
    el = {
        class: "mob-data-bottom2"
    },
    al = {
        class: "mob-data-top"
    },
    tl = {
        class: "mob-data-top-right"
    },
    ll = {
        class: "mob-data-top"
    },
    sl = {
        class: "mob-data-top-right"
    },
    ol = {
        class: "mob-data-top"
    },
    il = {
        class: "mob-data-top-left"
    },
    nl = {
        class: "mob-data-top"
    },
    dl = {
        class: "mob-data-top-left"
    },
    rl = {
        class: "view-more"
    },
    cl = {
        key: 1,
        class: "content-history"
    },
    ul = {
        class: "filter-items"
    },
    ml = {
        key: 0
    },
    pl = {
        key: 1,
        class: "center-login"
    },
    vl = {
        class: "mx-1"
    },
    gl = {
        key: 1,
        class: "imgParent"
    },
    hl = ["src"],
    fl = {
        key: 1,
        class: "imgParent"
    },
    xl = ["src"],
    yl = {
        class: "mt-1"
    },
    kl = {
        class: "mob-table mt-5"
    },
    bl = {
        class: "mob-table-header"
    },
    wl = {
        class: "mob-t-text-end flex items-center"
    },
    Sl = {
        class: "flex items-center claim-opz"
    },
    Pl = {
        class: "flex flex-col",
        style: {
            "min-width": "0px",
            width: "100%",
            position: "relative"
        }
    },
    Tl = {
        class: "flex flex-row"
    },
    jl = {
        class: "cardV2-top-btn top-circle"
    },
    _l = {
        class: "sc-x4ybvz-4 juixKb",
        style: {
            "scroll-behavior": "smooth",
            padding: "1rem 16px",
            height: "100%",
            isolation: "isolate",
            position: "relative",
            overflow: "auto"
        }
    },
    Dl = {
        class: "text-gray1"
    },
    Ol = {
        class: "claim-opz-avail"
    },
    zl = {
        style: {
            flex: "1 1 0%"
        }
    },
    Ll = {
        key: 1,
        title: "0",
        class: "text-bold flex",
        style: {
            "font-size": "26px",
            "line-height": "30px",
            "-webkit-box-align": "center",
            "align-items": "center",
            "min-width": "max-content",
            gap: "0px"
        }
    },
    Bl = {
        id: "mob-table-0",
        class: "mob-table-body pt-0"
    },
    Al = {
        "aria-hidden": "true",
        class: "mob-data-bottom"
    },
    Il = {
        class: "mob-data-bottom2"
    },
    Cl = {
        class: "mob-data-top"
    },
    Vl = {
        class: "mob-data-top-left"
    },
    Fl = {
        class: "mob-data-top-right"
    },
    Ml = {
        class: "mob-data-top"
    },
    Zl = {
        class: "mob-data-top-left"
    },
    Hl = {
        class: "mob-data-top"
    },
    El = {
        class: "mob-data-top-left"
    },
    Wl = {
        class: "mob-data-top"
    },
    Rl = {
        class: "mob-data-top-left"
    },
    Nl = {
        class: "mob-data-top-right"
    },
    Ul = {
        class: "mob-data-top"
    },
    Yl = {
        class: "mob-data-top-left"
    },
    Kl = {
        class: "mob-data-top"
    },
    Gl = {
        class: "mob-data-top-left"
    },
    $l = {
        class: "mob-data-top-right"
    },
    ql = {
        class: "view-more"
    },
    Xl = C(l({
        __name: "staking",
        setup(t) {
            const {
                Api: l
            } = w(), {
                t: D
            } = s();
            ee(D("stk.start-staking"), " Earn Staking Rewards with OPZ's Staking Program");
            const C = {
                    0: {
                        itemsToShow: 1,
                        snapAlign: "center"
                    },
                    700: {
                        itemsToShow: 2,
                        snapAlign: "center"
                    },
                    1024: {
                        itemsToShow: 3,
                        snapAlign: "center-even"
                    }
                },
                W = T(),
                R = i(""),
                N = i(""),
                U = i(""),
                K = i(""),
                G = i(window.innerWidth <= 767);
            let $;
            const pe = o(),
                ve = S(),
                ge = b(),
                he = i("1"),
                fe = i([]),
                xe = i(1),
                ye = P({
                    availableStaking: [{}],
                    allStaking: [],
                    allHistory: {
                        pageSize: 10,
                        total: 1,
                        page: 1,
                        rows: []
                    },
                    totalEarned: 0,
                    currentAmountStaked: 0,
                    openHistory: [],
                    last7DaysProfit: Array(7).fill(0),
                    thumbPrices: [],
                    todayProfit: 0,
                    allTimeProfit: 0,
                    allTimeProfitLong: 0,
                    allTimeProfitShort: 0,
                    stakedLongTerm: 0,
                    allOnlyBlockWallet: []
                }),
                ke = i(!0),
                be = () => {
                    l.getStakingAvailable().then((e => {
                        const a = e.data;
                        if (a.data) {
                            let e = a.data.reduce((function(e, a) {
                                return e[a.coin] = e[a.coin] || [], e[a.coin].push(a), e
                            }), Object.create(null));
                            null != a.data && a.data.length > 0 && null != e && (ye.allStaking = a.data, ye.availableStaking = Object.keys(e).map((a => [String(a), e[a]])), ye.availableStaking.forEach((e => {
                                e[1].sort(((e, a) => e.periodDays - a.periodDays))
                            })))
                        }
                        ke.value = !1
                    }))
                },
                we = [{
                    text: D("pga.last-7-days"),
                    value: () => {
                        const e = new Date,
                            a = new Date;
                        return a.setTime(a.getTime() - 6048e5), [a, e]
                    }
                }, {
                    text: D("pga.last-30-days"),
                    value: () => {
                        const e = new Date,
                            a = new Date;
                        return a.setTime(a.getTime() - 2592e6), [a, e]
                    }
                }, {
                    text: D("pga.last-90-days"),
                    value: () => {
                        const e = new Date,
                            a = new Date;
                        return a.setTime(a.getTime() - 7776e6), [a, e]
                    }
                }],
                Se = e => {
                    var a, t, l;
                    if (ge.isLoggedIn && "2" == he.value) {
                        const o = new Date((new Date).setHours(0, 0, 0, 0));
                        switch (U.value = o.getTime(), e) {
                            case "":
                                N.value = "", U.value = "";
                                break;
                            case "yesterday":
                                N.value = o.getTime() - 864e5;
                                break;
                            case "thisweek":
                                N.value = (a = o, t = (a = new Date(a)).getDay(), l = a.getDate() - t + (0 == t ? -6 : 1), new Date(a.setDate(l)).getTime()), U.value = (new Date).getTime();
                                break;
                            case "thismonth":
                                var s = new Date(o.getFullYear(), o.getMonth(), 1);
                                N.value = s.getTime(), U.value = (new Date).getTime();
                                break;
                            default:
                                return
                        }
                        Ze()
                    }
                },
                Pe = e => {
                    ge.isLoggedIn && "2" == he.value && (e && e[0] && e[1] ? (R.value = "null", N.value = e[0], U.value = e[1], Ze()) : (N.value = "", U.value = ""))
                };
            i("1");
            const Te = i(),
                je = e => {
                    fe.value.some((a => a.coin == e)) && l.getWallet(e).then((a => {
                        const t = a.data;
                        t.data && t.data.balance && (fe.value.find((a => a.coin == e)).balance = t.data.balance)
                    }))
                },
                _e = (e, a, t) => t * e * (a / 31536e6),
                De = () => {
                    const e = new Date,
                        a = new Date(e.getFullYear(), e.getMonth(), e.getDate()).getTime();
                    let t = 0,
                        l = 0,
                        s = 0,
                        o = Array(7).fill(0),
                        i = 0,
                        n = 0,
                        d = 0,
                        r = 0;
                    ye.openHistory.forEach((c => {
                        var u, m;
                        const p = (e => {
                            const a = (Math.min(ia, e.endTime) - e.createTime) / 31536e6;
                            return e.amount * e.annualInterestRate * a
                        })(c);
                        d += p;
                        const v = Math.max(c.createTime, a),
                            g = Math.min(c.endTime, e.getTime());
                        t += _e(c.annualInterestRate, g - v, c.amount), t < 0 && (t = 0), (null == (u = ye.allHistory) ? void 0 : u.rows) && (null == (m = ye.allHistory) ? void 0 : m.rows.length) > 0 && (ye.allHistory.rows.find((e => e.id == c.id)).allTimeProfit = p), console.log(ye.availableStaking[0][1]);
                        ye.availableStaking[0][1].find((e => e.id == c.stakingId)).periodDays >= 365 ? (n += p, r += c.amount, l += t, l < 0 && (l = 0)) : (i += p, s += t, s < 0 && (s = 0));
                        for (let a = 0; a < 7; a++) {
                            const t = new Date(e.getFullYear(), e.getMonth(), e.getDate() - a).getTime(),
                                l = t + 864e5,
                                s = Math.max(c.createTime, t);
                            if (l >= c.endTime && l - 864e5 >= c.endTime) o[6 - a] = 0;
                            else if (s < l) {
                                const e = Math.min(l, g) - s;
                                o[6 - a] += _e(c.annualInterestRate, e, c.amount)
                            }
                        }
                    })), ye.stakedLongTerm = r, ye.last7DaysProfit = o.map((e => e.toFixed(6))), ye.todayProfit = t, ye.allTimeProfit = t > d ? t : d < 0 ? 0 : d, ye.allTimeProfitLong = l > n ? l : n < 0 ? 0 : n, ye.allTimeProfitShort = s > i ? s : i < 0 ? 0 : i
                };
            De();
            const Oe = d((() => {
                    var e, a;
                    const t = (null == (a = null == (e = fe.value) ? void 0 : e.filter((e => "OPZ" === e.coin))[0]) ? void 0 : a.balance) ? ? 0,
                        l = ea.value - ye.stakedLongTerm - ye.allOnlyBlockWallet.totalAmount;
                    return t < l ? t : l
                })),
                ze = i(0),
                Le = () => {
                    l.stakingOpen().then((e => {
                        const a = e.data;
                        if (a.data && a.data.length > 0) {
                            a.data.forEach(((e, a) => {
                                var t;
                                e.isLongTerm || (e.endTime = null == (t = ye.allStaking.find((a => a.id === e.stakingId))) ? void 0 : t.endTime), ia > e.endTime && !e.canceled && (e.completed = !0)
                            })), ye.openHistory = a.data, De();
                            const e = a.data.reduce(((e, a) => "OPZ" === a.coin ? e + a.amount : e), 0);
                            ze.value = e
                        }
                    }))
                },
                Ae = async () => {
                    var e;
                    if (Ne.value && Ne.value.provider) {
                        const a = new me(Ne.value.provider, "any"),
                            t = await a.getSigner(),
                            s = await t.signMessage("OPZ Staking"),
                            o = new E;
                        o.append("allHashes", null == (e = null == ye ? void 0 : ye.allOnlyBlockWallet) ? void 0 : e.hashes), o.append("signature", s), l.checkWeb3(o).then((e => {
                            0 === e.data.code ? (je("OPZ"), la(sa.value, !1), ve.success(D("sett.successfully-added"))) : ve.error(e.message)
                        }))
                    }
                },
                Ie = e => {
                    Le(), Ze(), be()
                },
                Ce = (e, a, t) => {
                    const s = new E;
                    s.append("stakingId", e), l.stakingCancel(s).then((l => {
                        const s = l.data;
                        0 == s.code ? (ve.success(D("hiss.canceled")), ((e, a, t) => {
                            fe.value.some((e => e.coin == a)) && (fe.value.find((e => e.coin == a)).balance += Number(t)), ye.openHistory.some((a => a.stakingId == e)) && (ye.openHistory.find((a => a.stakingId == e)).amount -= Number(t)), ye.allHistory.rows != [] && Ze()
                        })(e, a, t)) : ve.error(s.message)
                    }))
                },
                Ve = e => {
                    const a = document.getElementById(e);
                    if (null != a) {
                        const e = document.getElementsByClassName("enabled-dc");
                        if (a.classList.toString().includes("enabled-dc")) return void a.classList.remove("enabled-dc");
                        null != e && null != e[0] && e[0].classList.remove("enabled-dc"), a.classList.add("enabled-dc")
                    }
                };
            i(!1);
            const Fe = e => {
                    var a;
                    const t = e;
                    var s;
                    ge.isLoggedIn ? (s = t.coin, fe.value.filter((e => e.coin == s))[0] || l.getWallet(s).then((e => {
                        const a = e.data;
                        a.data && a.data.balance ? fe.value.push({
                            coin: s,
                            balance: a.data.balance
                        }) : fe.value.push({
                            coin: s,
                            balance: 0
                        })
                    }))) : (ye.openHistory = [], fe.value.push({
                        coin: t.coin,
                        balance: 0
                    })), ye.openHistory.length > 0 && ye.openHistory.some((e => e.stakingId == t.id)) ? t.maxBuyAmount2 = t.maxBuyAmount - (null == (a = ye.openHistory.filter((e => e.stakingId == t.id))[0]) ? void 0 : a.amount) : t.maxBuyAmount2 = t.maxBuyAmount, Te.value = t, Me.value = !0
                },
                Me = i(!1),
                Ze = () => {
                    ye.allHistory.rows = [];
                    const e = new E;
                    e.append("pageNo", String(xe.value)), e.append("pageSize", String(ye.allHistory.pageSize)), N.value && e.append("startTime", N.value), U.value && e.append("endTime", U.value), l.StakingHistory(e).then((e => {
                        const a = e.data;
                        a.content && a.content.length > 0 && (a.content.forEach(((e, a) => {
                            var t;
                            e.isLongTerm || (e.endTime = null == (t = ye.allStaking.find((a => a.id === e.stakingId))) ? void 0 : t.endTime), ia > e.endTime && !e.canceled && (e.completed = !0)
                        })), ye.allHistory.total = a.totalElements, ye.allHistory.page = a.number, ye.allHistory.rows = a.content, De())
                    }))
                },
                He = e => {
                    he.value = e, "2" == e && 0 == ye.allHistory.rows.length ? ge.isLoggedIn && Ze() : "2" != e || ge.isLoggedIn || pe.push({
                        name: "auth",
                        query: {
                            redirect: "/staking"
                        }
                    })
                };
            n((async () => {
                $ = Q.throttle((() => {
                    G.value = window.innerWidth <= 767
                }), 100), window.addEventListener("resize", $), be(), ge.isLoggedIn && (l.stakingEarnings().then((e => {
                    const a = e.data;
                    a.data ? ye.totalEarned = a.data : ye.totalEarned = 0
                })), Le())
            })), O((() => {
                window.removeEventListener("resize", $)
            }));
            const Ee = e => {
                    for (var a = e.toLowerCase().split(" "), t = 0; t < a.length; t++) a[t] = a[t].charAt(0).toUpperCase() + a[t].substring(1);
                    return a.join(" ")
                },
                {
                    wallets: We,
                    connectWallet: Re,
                    connectedWallet: Ne,
                    setChain: Ue,
                    connectedChain: Ye,
                    alreadyConnectedWallets: Ke
                } = z(),
                Ge = i(!1);
            n((async () => {
                !Ne.value && Ke.value && Ke.value[0] ? await Re({
                    autoSelect: {
                        label: Ke.value[0],
                        disableModals: !0
                    }
                }) : Ne.value && Ne.value.accounts[0] ? (oa.value = Ne.value.accounts[0].address, la(oa.value, !0)) : ge.isLoggedIn ? l.getWalletMPCAddress().then((({
                    data: e
                }) => {
                    0 == e.code && e.data && (sa.value = e.data), la(sa.value, !0)
                })) : ta.value = !1, Ge.value = !0
            }));
            const $e = async () => {
                    Ne.value || await Re()
                },
                qe = [{
                    id: "1",
                    name: "Fish",
                    threshold: 0,
                    nextRank: "Lobster",
                    bonus: 0,
                    img: "fish"
                }, {
                    id: "2",
                    name: "Lobster",
                    threshold: 15e3,
                    nextRank: "Octopus",
                    bonus: 2,
                    img: "lobster"
                }, {
                    id: "3",
                    name: "Octopus",
                    threshold: 5e4,
                    nextRank: "Shark",
                    bonus: 5,
                    img: "octopus"
                }, {
                    id: "4",
                    name: "Shark",
                    threshold: 25e4,
                    nextRank: "Whale",
                    bonus: 8,
                    img: "shark"
                }, {
                    id: "5",
                    name: "Whale",
                    threshold: 1e6,
                    nextRank: null,
                    bonus: 10,
                    img: "whale"
                }],
                Xe = i(qe[0]),
                Je = i(qe[1]),
                Qe = i(0),
                ea = i(0),
                aa = i(qe[1].threshold),
                ta = i(!0),
                la = (e, a) => {
                    if (Ne.value || a) {
                        const a = new E;
                        e && a.append("address", e), ge.isLoggedIn && a.append("memberId", ge.userData.id), l.getCoinOrderHistory(a).then((({
                            data: e
                        }) => {
                            if (0 != e.code) return ta.value = !1, ea.value = 0, Xe.value = qe[0], aa.value = qe[1].threshold, Je.value = qe[1], void(Qe.value = 0); {
                                const a = e.data,
                                    t = a.reduce(((e, a) => 1 === a.status && null !== a.amountToken ? e + Number(a.amountToken) : e), 0);
                                ea.value = t, (e => {
                                    for (let a = 0; a < qe.length && e >= qe[a].threshold; a++) Xe.value = qe[a], Je.value = qe[a + 1] || {
                                        name: "Max Rank",
                                        threshold: 0,
                                        bonus: 10,
                                        img: "whale"
                                    };
                                    aa.value = Je.value.threshold - e, Qe.value = Je.value.threshold ? Math.min(e / Je.value.threshold * 100, 100).toFixed(2) : 100
                                })(ea.value);
                                const l = [];
                                let s = 0;
                                a.filter((e => null === e.memberId || "" === e.memberId)).forEach((e => {
                                    1 === e.status && null !== e.amountToken && (s += Number(e.amountToken), l.push(e.hash))
                                })), ye.allOnlyBlockWallet = {
                                    totalAmount: s,
                                    hashes: l
                                }
                            }
                            ta.value = !1
                        })).catch((e => {
                            ta.value = !1, console.log(e)
                        }))
                    } else ta.value = !1, ea.value = 0, Xe.value = qe[0], aa.value = qe[1].threshold, Je.value = qe[1], Qe.value = 0
                },
                sa = i(""),
                oa = i("");
            L(Ne, (e => {
                console.log("newWallet", e), e ? e && e.accounts && e.accounts[0] && e.accounts[0].address && (e.accounts[0].address !== oa.value && (oa.value = e.accounts[0].address, la(e.accounts[0].address)), oa.value = e.accounts[0].address) : ge.isLoggedIn ? la() : (ta.value = !1, ea.value = 0, Xe.value = qe[0], aa.value = qe[1].threshold, Je.value = qe[1], Qe.value = 0)
            }), {
                deep: !0
            });
            const ia = (new Date).getTime(),
                na = e => {
                    const {
                        columns: a,
                        data: t
                    } = e, l = [];
                    return a.forEach(((e, a) => {
                        if (0 === a) return void(l[a] = B("div", {
                            style: {
                                textDecoration: "underline"
                            }
                        }, ["Total"]));
                        const s = t.map((a => Number(a[e.property])));
                        s.every((e => Number.isNaN(e))) ? l[a] = "" : l[a] = `${s.reduce(((e,a)=>{const t=Number(a);return Number.isNaN(t)?e:e+a}),0).toFixed(0)} OPZ`
                    })), l
                };
            return (t, s) => {
                var o;
                const i = H,
                    n = Z,
                    d = M,
                    b = F,
                    w = V,
                    S = Be,
                    P = a;
                return r(), c(j, null, [h(i), u("div", {
                    class: p(["staking stake-dash", g(W).isAppOn && "mobile"])
                }, [u("div", nt, [u("div", dt, [u("div", rt, [u("div", ct, [h(it, {
                    opzBalance: ea.value,
                    "onUpdate:opzBalance": s[0] || (s[0] = e => ea.value = e),
                    totalStakedOPZ: ze.value,
                    allTimeProfit: ye.allTimeProfit,
                    todayProfit: ye.todayProfit,
                    last7DaysProfit: ye.last7DaysProfit,
                    loading: ke.value && g(ge).isLoggedIn
                }, null, 8, ["opzBalance", "totalStakedOPZ", "allTimeProfit", "todayProfit", "last7DaysProfit", "loading"])])])]), u("div", ut, [u("div", mt, [h(g(ae), {
                    "default-active": he.value,
                    class: "el-menu-demo",
                    style: {
                        "min-width": "400px",
                        "margin-bottom": "1px"
                    },
                    mode: "horizontal",
                    "text-color": "white",
                    onSelect: He
                }, {
                    default: f((() => [h(g(te), {
                        index: "1",
                        style: {
                            color: "white !important"
                        }
                    }, {
                        default: f((() => s[14] || (s[14] = [x("Token Dashboard")]))),
                        _: 1
                    }), h(g(te), {
                        index: "2",
                        style: {
                            color: "white !important"
                        }
                    }, {
                        default: f((() => [x(v(g(D)("stk.staking-history")), 1)])),
                        _: 1
                    })])),
                    _: 1
                }, 8, ["default-active"])])])]), u("div", pt, ["1" == he.value ? (r(), c("div", vt, [u("div", gt, [u("div", ht, [h(n, {
                    tag: "h3",
                    size: 5,
                    weight: "bold",
                    class: "text-gradient"
                }, {
                    default: f((() => [Je.value.threshold ? (r(), c("span", ft, " To increase your rank ")) : (r(), c("span", xt, " MAX RANK "))])),
                    _: 1
                }), ta.value ? (r(), y(d, {
                    key: 0,
                    width: "329px",
                    height: "31px",
                    light: "",
                    style: {
                        "border-radius": "15px",
                        position: "relative",
                        top: "-10px"
                    }
                })) : (r(), y(b, {
                    key: 1,
                    tag: "h2",
                    size: 3,
                    class: "rankTitle",
                    weight: "bold",
                    style: {
                        color: "var(--gray-dark-05)",
                        "padding-top": "0"
                    }
                }, {
                    default: f((() => {
                        return [Je.value.threshold ? (r(), c("span", yt, " Purchase " + v((e = aa.value, e ? e < 1e3 ? null == e ? void 0 : e.toString() : e >= 1e3 && e < 1e6 ? +(e / 1e3).toFixed(2) + "K" : e >= 1e6 && e < 1e9 ? +(e / 1e6).toFixed(2) + "M" : e >= 1e9 && e < 1e12 ? +(e / 1e9).toFixed(2) + "B" : e >= 1e12 ? +(e / 1e12).toFixed(2) + "T" : null == e ? void 0 : e.toString() : "0")) + " OPZ Tokens ", 1)) : (r(), c("span", kt, " Congratulations on reaching Max Rank! "))];
                        var e
                    })),
                    _: 1
                }))]), u("div", bt, [u("div", wt, [u("img", {
                    src: `/assets/ranks/${Xe.value.img}.svg`,
                    alt: Xe.value.name,
                    loading: "lazy",
                    width: "50",
                    height: "50",
                    decoding: "async",
                    class: "rankImage"
                }, null, 8, St), u("div", Pt, [u("h5", null, v(Xe.value.name), 1), s[15] || (s[15] = u("p", null, "Current Rank", -1)), Xe.value.bonus ? (r(), c("p", Tt, " Presale Bonus " + v(Xe.value.bonus) + "% ", 1)) : k("", !0)]), u("div", jt, [u("div", _t, v(Xe.value.id), 1)])]), u("div", Dt, [u("div", Ot, [h(g(I), {
                    class: "rankBar",
                    "text-inside": !0,
                    percentage: Qe.value,
                    striped: "",
                    "striped-flow": "",
                    duration: 10
                }, {
                    default: f((() => [u("div", zt, [u("span", Lt, v(Qe.value) + "%", 1)])])),
                    _: 1
                }, 8, ["percentage"])])]), u("div", Bt, [u("img", {
                    src: Je.value ? `/assets/ranks/${Je.value.img}.svg` : "/assets/ranks/whale.svg",
                    alt: (null == (o = Je.value) ? void 0 : o.name) || "Max Rank Achieved",
                    loading: "lazy",
                    width: "48",
                    height: "48",
                    decoding: "async",
                    class: "rankImage"
                }, null, 8, At), Je.value.id ? (r(), c("div", It, [u("div", Ct, v(Je.value.id), 1)])) : k("", !0), u("div", Vt, [u("h5", null, v(Je.value.name), 1), Je.value.threshold ? (r(), c("p", Ft, "Next Rank")) : (r(), c("p", Mt, "Max Rank")), Je.value.bonus ? (r(), c("p", Zt, " Presale Bonus " + v(Je.value.bonus) + "% ", 1)) : k("", !0)])])])]), u("div", Ht, [u("div", Et, [s[16] || (s[16] = u("div", {
                    class: "mob-t-img",
                    style: "background-image: url(/images/icons/coin/opz.svg"
                }, null, -1)), s[17] || (s[17] = u("div", {
                    class: "mob-t-text"
                }, v("Presale Allocation"), -1)), u("div", Wt, [!g(Ne) && Ge.value ? (r(), c("a", {
                    key: 0,
                    "data-v-ea142894": "",
                    onClick: s[1] || (s[1] = () => {
                        $e()
                    }),
                    class: "w-full rounded border-purple-darken text-10 block text-center text-bold btn-connect-wal"
                }, v(g(D)("dash.connect-wallet")), 1)) : k("", !0)])]), u("section", Rt, [u("div", Nt, [u("div", Ut, [s[19] || (s[19] = u("h3", {
                    style: {
                        padding: "1.25rem 6px 0 16px",
                        "margin-bottom": "-0.5rem",
                        "font-size": "16px"
                    },
                    class: "text-medium"
                }, " OPZ Presale ", -1)), u("div", Yt, [h(g(A), {
                    effect: "customized",
                    content: g(D)("subb.active"),
                    placement: "top"
                }, {
                    default: f((() => s[18] || (s[18] = [u("div", {
                        class: "cardV2-top-btn-circle pulsate"
                    }, null, -1)]))),
                    _: 1
                }, 8, ["content"])])]), u("div", Kt, [u("div", Gt, [s[21] || (s[21] = u("span", {
                    class: "flex"
                }, "Our Presale is Live now! Secure your OPZ tokens from our presale:", -1)), h(g(Y), {
                    type: "primary",
                    onClick: s[2] || (s[2] = e => g(pe).push({
                        name: "presale"
                    }))
                }, {
                    default: f((() => s[20] || (s[20] = [x("Learn More...")]))),
                    _: 1
                })])])]), u("div", $t, [u("div", qt, [s[23] || (s[23] = u("div", {
                    class: "text-medium text-gray1",
                    style: {
                        "font-size": "16px"
                    }
                }, " Claimable Allocation ", -1)), ke.value ? (r(), y(d, {
                    key: 0,
                    width: "100px",
                    height: "30px"
                })) : (r(), c("output", Xt, s[22] || (s[22] = [x(" 0.00 "), u("span", {
                    class: "opz-text"
                }, "OPZ", -1)])))]), h(w, {
                    disabled: "",
                    size: "medium",
                    style: {
                        flex: "1 1 0%"
                    }
                }, {
                    default: f((() => [x(v(g(D)("inx.claim")), 1)])),
                    _: 1
                })])]), u("div", Jt, [u("div", Qt, [u("div", el, [u("div", al, [s[25] || (s[25] = u("div", {
                    class: "mob-data-top-left"
                }, [u("span", null, v("Total Presale Allocation"))], -1)), u("div", tl, [x(v(ea.value) + " ", 1), s[24] || (s[24] = u("span", {
                    class: "text-gray1"
                }, "OPZ", -1))])]), u("div", ll, [s[27] || (s[27] = u("div", {
                    class: "mob-data-top-left"
                }, [u("span", null, v("Allocated for Staking"))], -1)), u("div", sl, [x(v(ye.stakedLongTerm) + " ", 1), s[26] || (s[26] = u("span", {
                    class: "text-gray1"
                }, "OPZ", -1))])]), u("div", ol, [u("div", il, [u("span", null, v(g(D)("dash.claimed")), 1)]), s[28] || (s[28] = u("div", {
                    class: "mob-data-top-right"
                }, [x(" 0 "), u("span", {
                    class: "text-gray1"
                }, "OPZ")], -1))]), u("div", nl, [u("div", dl, [u("span", null, v("Allocation " + g(D)("sett.unlock-period")), 1)]), s[29] || (s[29] = u("div", {
                    class: "mob-data-top-right"
                }, " 12.5% TGE + 4 Months Cliff, Linear Unlock 12 Months ", -1))])])]), u("div", {
                    class: "more-info",
                    onClick: s[3] || (s[3] = e => Ve("mob-table-0"))
                }, [u("span", rl, v(g(D)("wall.view-more")), 1), s[30] || (s[30] = u("span", {
                    class: "view-less"
                }, v("View Less"), -1)), s[31] || (s[31] = u("button", {
                    class: "btn-more"
                }, null, -1))])])]), s[32] || (s[32] = u("div", {
                    class: "flex t-dapp mt-0 justify-between"
                }, [u("div", {
                    class: "flex"
                }, [u("div", {
                    class: "block-title"
                }), u("div", {
                    class: "title-dark"
                }, "Staking")])], -1)), G.value ? (r(), y(g(le), {
                    key: 0,
                    arrow: "always",
                    type: "card",
                    height: "279px",
                    autoplay: !1,
                    "motion-blur": ""
                }, {
                    default: f((() => {
                        var e;
                        return [(r(!0), c(j, null, _(null == (e = ye.allStaking) ? void 0 : e.filter(((e, a) => 0 !== a && 3 !== a && 4 !== a && 5 !== a && 2 !== a)), ((e, a) => (r(), y(g(se), {
                            key: a
                        }, {
                            default: f((() => [h(S, {
                                card: e,
                                onStake: Fe,
                                isMobileWidth: G.value
                            }, null, 8, ["card", "isMobileWidth"])])),
                            _: 2
                        }, 1024)))), 128))]
                    })),
                    _: 1
                })) : (r(), y(g(q), {
                    key: 1,
                    breakpoints: C,
                    class: "bg-drop-lin"
                }, {
                    addons: f((() => [h(g(X))])),
                    default: f((() => {
                        var e;
                        return [(r(!0), c(j, null, _(null == (e = ye.allStaking) ? void 0 : e.filter(((e, a) => 0 !== a && 3 !== a && 4 !== a && 5 !== a && 2 !== a)), ((e, a) => (r(), y(g(J), {
                            key: a
                        }, {
                            default: f((() => [h(S, {
                                card: e,
                                onStake: Fe,
                                isMobileWidth: G.value
                            }, null, 8, ["card", "isMobileWidth"])])),
                            _: 2
                        }, 1024)))), 128))]
                    })),
                    _: 1
                }))])) : k("", !0), "2" == he.value ? (r(), c("div", cl, [u("div", ul, [h(g(oe), {
                    id: "scrollRight",
                    modelValue: R.value,
                    "onUpdate:modelValue": s[4] || (s[4] = e => R.value = e),
                    onChange: Se,
                    class: "text-medium light-radio-group"
                }, {
                    default: f((() => [h(g(ie), {
                        value: ""
                    }, {
                        default: f((() => [x(v(g(D)("dash.all")), 1)])),
                        _: 1
                    }), h(g(ie), {
                        value: "yesterday"
                    }, {
                        default: f((() => [x(v(g(D)("pga.yesterday")), 1)])),
                        _: 1
                    }), h(g(ie), {
                        value: "thisweek"
                    }, {
                        default: f((() => [x(v(g(D)("pga.this-week")), 1)])),
                        _: 1
                    }), h(g(ie), {
                        value: "thismonth"
                    }, {
                        default: f((() => [x(v(g(D)("pga.this-month")), 1)])),
                        _: 1
                    })])),
                    _: 1
                }, 8, ["modelValue"]), h(g(ne), {
                    modelValue: K.value,
                    "onUpdate:modelValue": s[5] || (s[5] = e => K.value = e),
                    type: "daterange",
                    "unlink-panels": "",
                    class: "datepick datepick-small",
                    style: m("null" == R.value && "border: 1px solid var(--el-border-color-hover);"),
                    "range-separator": g(D)("wall.to"),
                    "start-placeholder": g(D)("wall.start-date"),
                    "end-placeholder": g(D)("wall.end-date"),
                    shortcuts: we,
                    "value-format": "x",
                    onChange: Pe
                }, null, 8, ["modelValue", "style", "range-separator", "start-placeholder", "end-placeholder"])]), h(g(de), {
                    data: ye.allHistory.rows,
                    class: "slim-table white-theme his-staking",
                    "table-layout": "fixed",
                    style: {
                        width: "100%"
                    },
                    "show-summary": !0,
                    "summary-method": na
                }, {
                    empty: f((() => [g(ge).isLoggedIn ? (r(), c("div", ml, v(g(D)("exh.no-records-found")), 1)) : (r(), c("div", pl, [h(g(Y), {
                        type: "primary",
                        class: "text-green-darken",
                        onClick: s[6] || (s[6] = e => g(pe).push({
                            name: "auth",
                            query: {
                                redirect: "/staking"
                            }
                        }))
                    }, {
                        default: f((() => [x(v(g(D)("auth.log-in")), 1)])),
                        _: 1
                    }), u("span", vl, v(g(D)("exh.or")), 1), h(g(Y), {
                        type: "primary",
                        class: "text-green-darken",
                        onClick: s[7] || (s[7] = e => g(pe).push({
                            name: "register",
                            query: {
                                redirect: "/staking"
                            }
                        }))
                    }, {
                        default: f((() => [x(v(g(D)("auth.register-now")), 1)])),
                        _: 1
                    })]))])),
                    default: f((() => [h(g(re), {
                        label: g(D)("depwi.coin")
                    }, {
                        default: f((e => {
                            var a;
                            return [e.row.coin ? (r(), c("span", gl, [u("img", {
                                class: "imgSelect",
                                src: "/images/icons/coin/" + (null == (a = e.row.coin) ? void 0 : a.toLowerCase()) + ".svg"
                            }, null, 8, hl)])) : (r(), y(d, {
                                key: 0,
                                width: "21px",
                                height: "21px"
                            })), x(" " + v(e.row.coin), 1)]
                        })),
                        _: 1
                    }, 8, ["label"]), h(g(re), {
                        label: "GPT"
                    }, {
                        default: f((e => {
                            var a, t, l;
                            return [e.row.coin ? (r(), c("span", fl, [u("img", {
                                class: "imgSelect",
                                src: "/images/icons/coin/" + (null == (t = null == (a = ye.allStaking.find((a => a.id === e.row.stakingId))) ? void 0 : a.aiCoin) ? void 0 : t.toLowerCase()) + ".svg"
                            }, null, 8, xl)])) : (r(), y(d, {
                                key: 0,
                                width: "21px",
                                height: "21px"
                            })), x(" " + v(null == (l = ye.allStaking.find((a => a.id === e.row.stakingId))) ? void 0 : l.aiCoin) + "-GPT ", 1)]
                        })),
                        _: 1
                    }), h(g(re), {
                        label: g(D)("stk.stake-date"),
                        "class-name": "timeColumn",
                        width: "152"
                    }, {
                        default: f((e => [x(v(new Date(e.row.createTime).toLocaleDateString("en-UK") + " " + new Date(e.row.createTime).toLocaleTimeString("en-UK")), 1)])),
                        _: 1
                    }, 8, ["label"]), h(g(re), {
                        label: Ee(g(D)("wall.end-date")),
                        "class-name": "timeColumn",
                        width: "152"
                    }, {
                        default: f((e => {
                            var a, t, l;
                            return [x(v((null == (a = ye.allStaking.find((a => a.id === e.row.stakingId))) ? void 0 : a.periodDays) >= 365 ? new Date(e.row.endTime).toLocaleDateString("en-UK") + " " + new Date(e.row.endTime).toLocaleTimeString("en-UK") : new Date(null == (t = ye.allStaking.find((a => a.id === e.row.stakingId))) ? void 0 : t.endTime).toLocaleDateString("en-UK") + " " + new Date(null == (l = ye.allStaking.find((a => a.id === e.row.stakingId))) ? void 0 : l.endTime).toLocaleTimeString("en-UK")), 1)]
                        })),
                        _: 1
                    }, 8, ["label"]), h(g(re), {
                        label: g(D)("stk.est-apy")
                    }, {
                        default: f((e => [x(v((100 * e.row.annualInterestRate).toFixed(2)) + "% ", 1)])),
                        _: 1
                    }, 8, ["label"]), h(g(re), {
                        label: g(D)("exh.amount")
                    }, {
                        default: f((e => [x(v(e.row.amount.toFixed(0)), 1)])),
                        _: 1
                    }, 8, ["label"]), h(g(re), {
                        prop: "allTimeProfit",
                        label: g(D)("stk.you-earned")
                    }, {
                        default: f((e => {
                            var a, t;
                            return [x(v(null == (t = null == (a = e.row) ? void 0 : a.allTimeProfit) ? void 0 : t.toFixed(4)), 1)]
                        })),
                        _: 1
                    }, 8, ["label"]), h(g(re), {
                        label: "Total"
                    }, {
                        default: f((e => [x(v((e.row.amount + e.row.allTimeProfit).toFixed(4)), 1)])),
                        _: 1
                    }), h(g(re), {
                        label: g(D)("wall.status"),
                        align: "right"
                    }, {
                        default: f((e => [x(v(e.row.redeemed ? g(D)("stk.redeemed") : e.row.canceled ? g(D)("hiss.canceled") : e.row.completed ? g(D)("hiss.completed") : g(D)("subb.active")), 1)])),
                        _: 1
                    }, 8, ["label"]), h(g(re), {
                        align: "right",
                        width: "100",
                        "text-align": "right"
                    }, {
                        header: f((() => s[33] || (s[33] = []))),
                        default: f((e => [Date.now() < e.row.startTime && !e.row.running ? (r(), y(g(ue), {
                            key: 0,
                            color: "var(--primary)",
                            style: {
                                color: "white"
                            },
                            onClick: a => Ce(e.row.stakingId, e.row.coin, e.row.amount)
                        }, {
                            default: f((() => [x(v(g(D)("wall.cancel")), 1)])),
                            _: 2
                        }, 1032, ["onClick"])) : k("", !0), Date.now() > e.row.endTime && e.row.completed && !e.row.redeemed && !e.row.canceled ? (r(), y(g(ue), {
                            key: 1,
                            color: "var(--primary)",
                            style: {
                                color: "white"
                            },
                            onClick: a => ((e, a, t, s) => {
                                const o = new E;
                                o.append("stakingId", e), o.append("itemId", s), l.stakingRedeem(o).then((e => {
                                    const t = e.data;
                                    0 == t.code ? (ve.success(D("inx.succesfully-redeemed")), je(a), Ze()) : ve.error(t.message)
                                }))
                            })(e.row.stakingId, e.row.coin, e.row.amount, e.row.id)
                        }, {
                            default: f((() => [x(v(g(D)("stk.redeem")), 1)])),
                            _: 2
                        }, 1032, ["onClick"])) : k("", !0)])),
                        _: 1
                    })])),
                    _: 1
                }, 8, ["data"]), u("div", yl, [g(ge).isLoggedIn ? (r(), y(g(ce), {
                    key: 0,
                    currentPage: xe.value,
                    "onUpdate:currentPage": s[8] || (s[8] = e => xe.value = e),
                    background: "",
                    size: "small",
                    layout: "prev, pager, next, jumper",
                    total: ye.allHistory.total,
                    onCurrentChange: s[9] || (s[9] = e => Ze())
                }, null, 8, ["currentPage", "total"])) : k("", !0)]), u("div", kl, [u("div", bl, [s[34] || (s[34] = u("div", {
                    class: "mob-t-img",
                    style: "background-image: url(/images/icons/coin/opz.svg"
                }, null, -1)), s[35] || (s[35] = u("div", {
                    class: "mob-t-text"
                }, v("Staking Rewards"), -1)), u("div", wl, [!g(Ne) && Ge.value ? (r(), c("a", {
                    key: 0,
                    "data-v-ea142894": "",
                    onClick: s[10] || (s[10] = () => {
                        $e()
                    }),
                    class: "w-full rounded border-purple-darken text-10 block text-center text-bold btn-connect-wal"
                }, v(g(D)("dash.connect-wallet")), 1)) : k("", !0)])]), u("section", Sl, [u("div", Pl, [u("div", Tl, [s[37] || (s[37] = u("h3", {
                    style: {
                        padding: "1.25rem 6px 0 16px",
                        "margin-bottom": "-0.5rem",
                        "font-size": "16px"
                    },
                    class: "text-medium"
                }, " OPZ Presale ", -1)), u("div", jl, [h(g(A), {
                    effect: "customized",
                    content: g(D)("subb.active"),
                    placement: "top"
                }, {
                    default: f((() => s[36] || (s[36] = [u("div", {
                        class: "cardV2-top-btn-circle pulsate"
                    }, null, -1)]))),
                    _: 1
                }, 8, ["content"])])]), u("div", _l, [u("div", Dl, [s[39] || (s[39] = u("span", {
                    class: "flex"
                }, "Our Presale is Live now! Secure your OPZ tokens from our presale:", -1)), h(g(Y), {
                    type: "primary",
                    onClick: s[11] || (s[11] = e => g(pe).push({
                        name: "presale"
                    }))
                }, {
                    default: f((() => s[38] || (s[38] = [x("Learn More...")]))),
                    _: 1
                })])])]), u("div", Ol, [u("div", zl, [s[41] || (s[41] = u("div", {
                    class: "text-medium text-gray1",
                    style: {
                        "font-size": "16px"
                    }
                }, " Claimable Staking Rewards ", -1)), ke.value ? (r(), y(d, {
                    key: 0,
                    width: "100px",
                    height: "30px"
                })) : (r(), c("output", Ll, s[40] || (s[40] = [x(" 0.00 "), u("span", {
                    class: "opz-text"
                }, "OPZ", -1)])))]), h(w, {
                    disabled: "",
                    size: "medium",
                    style: {
                        flex: "1 1 0%"
                    }
                }, {
                    default: f((() => [x(v(g(D)("inx.claim")), 1)])),
                    _: 1
                })])]), u("div", Bl, [u("div", Al, [u("div", Il, [u("div", Cl, [u("div", Vl, [u("span", null, v("Short-Term " + g(D)("pga.rewards")), 1)]), u("div", Fl, [x(v(ye.allTimeProfitShort.toFixed(0)) + " ", 1), s[42] || (s[42] = u("span", {
                    class: "text-gray1"
                }, "OPZ", -1))])]), u("div", Ml, [u("div", Zl, [u("span", null, v("Short-Term " + g(D)("dash.claimed")), 1)]), s[43] || (s[43] = u("div", {
                    class: "mob-data-top-right"
                }, [x(" 0 "), u("span", {
                    class: "text-gray1"
                }, "OPZ")], -1))]), u("div", Hl, [u("div", El, [u("span", null, [x(v("Short-Term Staking " + g(D)("sett.unlock-period")) + " ", 1), h(g(A), {
                    effect: "customized",
                    width: "300px",
                    placement: "top"
                }, {
                    content: f((() => s[44] || (s[44] = [u("p", null, [x(" This refers to the staking during the presale, which will "), u("br"), x(" end and be fully released while still in the presale phase. "), u("br")], -1)]))),
                    default: f((() => [s[45] || (s[45] = u("i", {
                        class: "fas fa-info-circle text-gray1 ml-1",
                        style: {
                            "font-size": "12px"
                        }
                    }, null, -1))])),
                    _: 1
                })])]), s[46] || (s[46] = u("div", {
                    class: "mob-data-top-right"
                }, " 5% TGE + 6 Months Cliff, Linear Unlock 12 Months ", -1))]), s[54] || (s[54] = u("hr", {
                    style: {
                        "margin-top": "6px",
                        "margin-bottom": "6px"
                    }
                }, null, -1)), u("div", Wl, [u("div", Rl, [u("span", null, v("Long-Term " + g(D)("pga.rewards")), 1)]), u("div", Nl, [x(v(ye.allTimeProfitLong.toFixed(0)) + " ", 1), s[47] || (s[47] = u("span", {
                    class: "text-gray1"
                }, "OPZ", -1))])]), u("div", Ul, [u("div", Yl, [u("span", null, v("Long-Term " + g(D)("dash.claimed")), 1)]), s[48] || (s[48] = u("div", {
                    class: "mob-data-top-right"
                }, [x(" 0 "), u("span", {
                    class: "text-gray1"
                }, "OPZ")], -1))]), u("div", Kl, [u("div", Gl, [u("span", null, [x(v("Long-Term Staking " + g(D)("sett.unlock-period")) + " ", 1), h(g(A), {
                    effect: "customized",
                    width: "300px",
                    placement: "top"
                }, {
                    content: f((() => s[49] || (s[49] = [u("p", null, [x(" This refers to staking where earnings "), u("br"), x(" are claimable only after the presale ends. ")], -1)]))),
                    default: f((() => [s[50] || (s[50] = u("i", {
                        class: "fas fa-info-circle text-gray1 ml-1",
                        style: {
                            "font-size": "12px"
                        }
                    }, null, -1))])),
                    _: 1
                })])]), u("div", $l, [s[53] || (s[53] = x(" Unlock percentage will match the presale release ")), h(g(A), {
                    effect: "customized",
                    width: "300px",
                    placement: "top"
                }, {
                    content: f((() => s[51] || (s[51] = [u("p", null, [x(" Whatever percentage is released during the presale will be "), u("br"), x(" fully unlocked and available for claiming at the end of the "), u("br"), x(" staking period. This includes the staked amount along with "), u("br"), x(" the staking rewards. ")], -1)]))),
                    default: f((() => [s[52] || (s[52] = u("i", {
                        class: "fas fa-info-circle text-gray1 ml-1",
                        style: {
                            "font-size": "12px"
                        }
                    }, null, -1))])),
                    _: 1
                })])])])]), u("div", {
                    class: "more-info",
                    onClick: s[12] || (s[12] = e => Ve("mob-table-0"))
                }, [u("span", ql, v(g(D)("wall.view-more")), 1), s[55] || (s[55] = u("span", {
                    class: "view-less"
                }, v("View Less"), -1)), s[56] || (s[56] = u("button", {
                    class: "btn-more"
                }, null, -1))])])])])) : k("", !0)])], 2), h(Sa, {
                    modelValue: Me.value,
                    "onUpdate:modelValue": s[13] || (s[13] = e => Me.value = e),
                    btn: !1,
                    selectedStake: Te.value,
                    wallet: fe.value,
                    openHistory: ye.openHistory,
                    balanceAllocation: Oe.value,
                    allOnlyBlockWallet: ye.allOnlyBlockWallet,
                    onRefreshAdd: Ie,
                    onAddBlockBalance: Ae
                }, null, 8, ["modelValue", "selectedStake", "wallet", "openHistory", "balanceAllocation", "allOnlyBlockWallet"]), h(P, {
                    token: !0,
                    cta: !1,
                    content: g(e),
                    color: "dark"
                }, null, 8, ["content"])], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-f51624d4"]
    ]);
export {
    Xl as
    default
};