import {
    m as e,
    G as s,
    j as a,
    o as n
} from "./index-CQfCy4Xm.js";
const t = e({
    __name: "index",
    setup: e => (s().push({
        name: "help-desk-center"
    }), (e, s) => (n(), a("div")))
});
export {
    t as
    default
};