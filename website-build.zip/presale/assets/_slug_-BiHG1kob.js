import {
    m as e,
    j as t,
    r as n,
    p as r,
    o,
    l as i,
    q as a,
    dm as s,
    y as l,
    I as c,
    v as u,
    w as d,
    ck as p,
    t as f,
    X as m,
    n as h,
    s as y,
    bh as g,
    H as v,
    bb as b,
    dn as x,
    Y as w,
    B as k,
    dg as S,
    cB as C,
    P as _,
    K as T,
    h as A,
    N as D,
    cD as O,
    u as E,
    G as I,
    cC as j,
    d8 as L,
    a as P,
    z as M,
    d9 as N,
    dj as F,
    C as R,
    dp as W
} from "./index-CQfCy4Xm.js";
import {
    C as V,
    S as B,
    _ as H
} from "./sockjs.min-Cp7lQCtH.js";
import {
    _ as q
} from "./_plugin-vue_export-helper-BCo6x5W8.js";
import {
    k as U,
    c as z
} from "./index-DZwhim7i.js";
import {
    C as $,
    D as Z,
    T as G,
    N as Y
} from "./chatAi-C5hZwDRz.js";
import {
    E as J,
    a as K
} from "./index-Cqgn8wHL.js";
import {
    r as X
} from "./___vite-browser-external_commonjs-proxy-CX5ghsV-.js";
import {
    A as Q,
    W as ee,
    _ as te
} from "./Navbar2-Cx1AKm6v.js";
import {
    u as ne
} from "./vue.8fc199ce-DBDcZ0BB.js";
import {
    F as re
} from "./browser-Cv63Auap.js";
import {
    _ as oe
} from "./lodash-Bm6t9hsB.js";
import {
    m as ie
} from "./index-CiVKPdRb.js";
import {
    l as ae
} from "./loadingSvg-B2DNNGSL.js";
import {
    v as se,
    a as le,
    E as ce
} from "./directive-CUB6-Wra.js";
import {
    a as ue,
    E as de,
    b as pe
} from "./index-BUqPiGKl.js";
import {
    E as fe
} from "./index-CsseI5JE.js";
import {
    E as me
} from "./index-DhHA3mFI.js";
import {
    E as he
} from "./index-CRtkyuT7.js";
import {
    _ as ye
} from "./AvatarSimple-DIs6U3iF.js";
import {
    E as ge
} from "./index-BaPl-dvV.js";
import {
    a as ve,
    E as be
} from "./index-CBmmRNm0.js";
import {
    E as xe
} from "./index-2O69uWbI.js";
import {
    E as we
} from "./index-Q5e3bkYB.js";
import {
    _ as ke
} from "./ButtonGR-CCzD27Qk.js";
import {
    _ as Se
} from "./VPlaceload-DcvQMSN9.js";
import {
    V as Ce
} from "./vue3-lottie.es-CiYK4lOh.js";
import {
    E as _e
} from "./index-5N62XIoj.js";
import {
    E as Te
} from "./index-CB5HUA9W.js";
import {
    E as Ae
} from "./index-DWyf7GKU.js";
import {
    a as De,
    E as Oe
} from "./index-D45OIXsf.js";
import {
    E as Ee
} from "./index-DMxP6Huc.js";
import {
    E as Ie
} from "./index-DPclT-tF.js";
import {
    _ as je,
    a as Le
} from "./deposit.vue_vue_type_style_index_0_lang-BPShOGGL.js";
import {
    _ as Pe
} from "./transfersub.vue_vue_type_style_index_0_lang-CAgEAYMJ.js";
import {
    r as Me
} from "./calcs-C2mNVRpW.js";
import {
    D as Ne
} from "./DownloadApp-CvKNuiGj.js";
import {
    u as Fe
} from "./useNotyfLong-unFWQDox.js";
import {
    a as Re,
    E as We
} from "./index-38aUouWI.js";
import {
    E as Ve
} from "./index-DxHJyswS.js";
import "./_commonjs-dynamic-modules-BHR_E30J.js";
import "./vue.runtime.esm-bundler-BbVV3g-V.js";
import "./vue3-apexcharts-DWxdUF6r.js";
import "./index-CcBkONjK.js";
import "./typescript-CRqm1_SZ.js";
import "./index-Ccebcdf2.js";
import "./index-CteOOV_f.js";
import "./index-wV0BwLDn.js";
import "./viewWrapper-yhXGfwRy.js";
import "./VPageContent-BIuP73X_.js";
import "./dayjs.min-CoMKM3gL.js";
import "./index-BFnVcjcj.js";
import "./vue3-markdown-it.umd.min-h-q_g2pl.js";
import "./tiny-slider-CC0nyWcN.js";
import "./index-D21_sbBM.js";
import "./aria-C-hsWcn7.js";
import "./index-CreMjc0E.js";
import "./index-CIJievV_.js";
import "./AppPop-DXr7YMXx.js";
import "./index-DPTDKB4o.js";
import "./google-play-0W6tGWt8.js";
import "./Button-C_PMcYdl.js";
import "./user-qMNVzsWD.js";
import "./sett-Dbwu6PJ1.js";
import "./avatarSettings-C1kj7zSJ.js";
import "./vue3-avataaars-DO56oOZp.js";
import "./logo-DqlCWKKL.js";
import "./index-Czea63rc.js";
import "./use-global-config-CYuHb1FB.js";
import "./_initCloneObject-DqrhPNyg.js";
import "./isPlainObject-BkooXA2Q.js";
import "./via-placeholder-csI6CdwS.js";
import "./index-DYh1qtlV.js";
import "./use-dialog-CC6CVfkB.js";
import "./index-BR6qnryQ.js";
import "./_baseClone-CNNEnxsr.js";
import "./validator-Kt7cHrwc.js";
import "./doubleCheck.vue_vue_type_style_index_0_lang-CBr02gDU.js";
import "./Control-BAxR9hhH.js";
import "./vue3-otp-input-C7HeO7ob.js";
import "./index--1JsBO1r.js";
import "./index-DI0c3Das.js";
import "./vue-qrcode.esm-C-BWAPbN.js";
import "./browser-ZWSpNtBY.js";
const Be = e({
        __name: "LandingLayout",
        props: {
            theme: {
                default: "darker"
            }
        },
        setup(e) {
            const i = e;
            return (e, a) => (o(), t("div", {
                class: r(["minimal-wrapper", [i.theme]])
            }, [n(e.$slots, "default")], 2))
        }
    }),
    He = {
        class: "footer footer-left"
    },
    qe = {
        class: "container"
    },
    Ue = {
        class: "ft-body columns is-vcentered flex"
    },
    ze = {
        class: "column is-8"
    },
    $e = {
        class: "link-all is-flex is-align-items-center"
    },
    Ze = {
        class: "link-list"
    };
const Ge = q({}, [
        ["render", function(e, r) {
            return o(), t("footer", He, [i("div", qe, [i("div", Ue, [i("div", ze, [i("div", $e, [i("ul", Ze, [n(e.$slots, "links")])])]), r[0] || (r[0] = i("div", {
                class: "column is-4 has-text-centered"
            }, [i("p", {
                class: "footer-text medium:text-right is-6",
                "data-config-id": "copyright"
            }, [i("span", {
                role: "img",
                "aria-label": "copyright"
            }, "©"), a(" 2024 OPZ.COM. All rights reserved. ")])], -1))])])])
        }],
        ["__scopeId", "data-v-b8344fd1"]
    ]),
    Ye = {
        key: 0
    },
    Je = {
        class: "flex items-center justify-center mb-3"
    },
    Ke = {
        class: "flex flex-col items-center gap-2 p-2"
    },
    Xe = ["src"],
    Qe = {
        class: "mt-1"
    },
    et = {
        class: "container-inner no-padding"
    },
    tt = {
        class: "container-inner no-padding"
    },
    nt = {
        class: "container-inner no-padding"
    },
    rt = {
        class: "container-inner no-padding"
    },
    ot = q(e({
        __name: "AiTabs",
        props: {
            coin: {
                default: ""
            },
            isMobileWidth: {
                type: Boolean,
                default: !1
            }
        },
        setup(e) {
            s();
            const n = e,
                a = [{
                    icon: "/images/svg/aichatgray.svg",
                    value: 0,
                    label: "Chat"
                }, {
                    icon: "/images/svg/market-analysis.svg",
                    value: 1,
                    label: "Details"
                }, {
                    icon: "/images/svg/data-analysis.svg",
                    value: 2,
                    label: "Chart"
                }, {
                    icon: "/images/svg/newspaper.svg",
                    value: 3,
                    label: "News"
                }],
                g = l(0),
                v = l(!1),
                b = l(null);
            return c((() => {
                const e = new IntersectionObserver((t => {
                    const n = t[0];
                    n.isIntersecting && (v.value = !0, e.unobserve(n.target))
                }));
                b.value && e.observe(b.value)
            })), (e, s) => (o(), t("div", {
                class: r(["pricing-wrapper2 ai-trade", n.isMobileWidth && "mt-3"]),
                ref_key: "pricingWrapperRef",
                ref: b
            }, [v.value ? (o(), t("div", Ye, [i("div", Je, [u(m(J), {
                modelValue: g.value,
                "onUpdate:modelValue": s[0] || (s[0] = e => g.value = e),
                options: a,
                size: "large"
            }, {
                default: d((({
                    item: e
                }) => [i("div", Ke, [i("img", {
                    src: e.icon,
                    alt: "Pricing icon",
                    width: "20",
                    style: p({
                        filter: g.value === e.value ? "brightness(0) invert(1)" : "none"
                    })
                }, null, 12, Xe), i("div", Qe, f(e.label), 1)])])),
                _: 1
            }, 8, ["modelValue"])]), i("div", {
                class: r(["pricing-container mt-2", 0 === g.value && "is-active"])
            }, [i("div", et, [(o(), h($, {
                disableStaking: !0,
                coin: n.coin,
                key: `chat-ai-${n.coin}`
            }, null, 8, ["coin"]))])], 2), i("div", {
                class: r(["pricing-container", 1 === g.value && "is-active"])
            }, [i("div", tt, [u(Z, {
                coin: n.coin
            }, null, 8, ["coin"])])], 2), i("div", {
                class: r(["pricing-container", 2 === g.value && "is-active"])
            }, [i("div", nt, [u(G, {
                coin: n.coin,
                activeTab: g.value
            }, null, 8, ["coin", "activeTab"])])], 2), i("div", {
                class: r(["pricing-container", 3 === g.value && "is-active"])
            }, [i("div", rt, [u(Y, {
                coin: n.coin,
                activeTab: g.value
            }, null, 8, ["coin", "activeTab"])])], 2)])) : y("", !0)], 2))
        }
    }), [
        ["__scopeId", "data-v-8d7a419c"]
    ]);

function it(e, t) {
    const n = { ...e
    };
    for (const r in t) "object" != typeof e[r] || null === e[r] || Array.isArray(e[r]) ? void 0 !== t[r] && (n[r] = t[r]) : n[r] = it(e[r], t[r]);
    return n
}
const at = {
        mobile: {
            disabled_features: ["left_toolbar", "header_widget", "timeframes_toolbar", "edit_buttons_in_legend", "context_menus", "control_bar", "border_around_the_chart"],
            enabled_features: []
        }
    },
    st = {
        width: 800,
        height: 500,
        interval: "1D",
        timezone: "Etc/UTC",
        container: "",
        library_path: "",
        locale: "en",
        widgetbar: {
            details: !1,
            watchlist: !1,
            watchlist_settings: {
                default_symbols: []
            }
        },
        overrides: {
            "mainSeriesProperties.showCountdown": !1
        },
        studies_overrides: {},
        trading_customization: {
            position: {},
            order: {}
        },
        brokerConfig: {
            configFlags: {}
        },
        fullscreen: !1,
        autosize: !1,
        disabled_features: [],
        enabled_features: [],
        debug: !1,
        logo: {},
        time_frames: [{
            text: "5y",
            resolution: "1W"
        }, {
            text: "1y",
            resolution: "1W"
        }, {
            text: "6m",
            resolution: "120"
        }, {
            text: "3m",
            resolution: "60"
        }, {
            text: "1m",
            resolution: "30"
        }, {
            text: "5d",
            resolution: "5"
        }, {
            text: "1d",
            resolution: "1"
        }],
        client_id: "0",
        user_id: "0",
        charts_storage_api_version: "1.0",
        favorites: {
            intervals: [],
            chartTypes: []
        }
    };
let lt = !1;
const ct = class {
    constructor(e) {
        if (this._id = `tradingview_${(1048576*(1+Math.random())|0).toString(16).substring(1)}`, this._ready = !1, this._readyHandlers = [], this._onWindowResize = this._autoResizeChart.bind(this), !e.datafeed) throw new Error("Datafeed is not defined");
        if (this._options = it(st, e), e.preset) {
            const t = at[e.preset];
            t ? (void 0 !== this._options.disabled_features ? this._options.disabled_features = this._options.disabled_features.concat(t.disabled_features) : this._options.disabled_features = t.disabled_features, void 0 !== this._options.enabled_features ? this._options.enabled_features = this._options.enabled_features.concat(t.enabled_features) : this._options.enabled_features = t.enabled_features) : console.warn("Unknown preset: `" + e.preset + "`")
        }("Dark" === this._options.theme || "Classic" === this._options.theme) && void 0 === this._options.loading_screen && (this._options.loading_screen = {
            backgroundColor: "#131722"
        }), this._options.debug && (lt || (lt = !0, console.log("Using CL v22.032 (internal id e2a841ff @ 2022-07-06T11:53:07.702Z)"))), this._create()
    }
    onChartReady(e) {
        this._ready ? e.call(this) : this._readyHandlers.push(e)
    }
    headerReady() {
        return this._innerWindowLoaded.then((() => this._innerWindow().headerReady()))
    }
    onGrayedObjectClicked(e) {
        this._doWhenInnerApiLoaded((t => {
            t.onGrayedObjectClicked(e)
        }))
    }
    onShortcut(e, t) {
        this._doWhenInnerWindowLoaded((n => {
            n.createShortcutAction(e, t)
        }))
    }
    subscribe(e, t) {
        this._doWhenInnerApiLoaded((n => {
            n.subscribe(e, t)
        }))
    }
    unsubscribe(e, t) {
        this._doWhenInnerApiLoaded((n => {
            n.unsubscribe(e, t)
        }))
    }
    chart(e) {
        return this._innerAPI().chart(e)
    }
    getLanguage() {
        return this._options.locale
    }
    setSymbol(e, t, n) {
        this._innerAPI().changeSymbol(e, t, n)
    }
    remove() {
        window.removeEventListener("resize", this._onWindowResize), this._readyHandlers.splice(0, this._readyHandlers.length), delete window[this._id], this._iFrame.parentNode && this._iFrame.parentNode.removeChild(this._iFrame)
    }
    closePopupsAndDialogs() {
        this._doWhenInnerApiLoaded((e => {
            e.closePopupsAndDialogs()
        }))
    }
    selectLineTool(e) {
        this._innerAPI().selectLineTool(e)
    }
    selectedLineTool() {
        return this._innerAPI().selectedLineTool()
    }
    save(e) {
        this._innerAPI().saveChart(e)
    }
    load(e, t) {
        this._innerAPI().loadChart({
            json: e,
            extendedData: t
        })
    }
    getSavedCharts(e) {
        this._innerAPI().getSavedCharts(e)
    }
    loadChartFromServer(e) {
        this._innerAPI().loadChartFromServer(e)
    }
    saveChartToServer(e, t, n) {
        this._innerAPI().saveChartToServer(e, t, n)
    }
    removeChartFromServer(e, t) {
        this._innerAPI().removeChartFromServer(e, t)
    }
    onContextMenu(e) {
        this._doWhenInnerApiLoaded((t => {
            t.onContextMenu(e)
        }))
    }
    createButton(e) {
        return this._innerWindow().createButton(e)
    }
    createDropdown(e) {
        return this._innerWindow().createDropdown(e)
    }
    showNoticeDialog(e) {
        this._doWhenInnerApiLoaded((t => {
            t.showNoticeDialog(e)
        }))
    }
    showConfirmDialog(e) {
        this._doWhenInnerApiLoaded((t => {
            t.showConfirmDialog(e)
        }))
    }
    showLoadChartDialog() {
        this._innerAPI().showLoadChartDialog()
    }
    showSaveAsChartDialog() {
        this._innerAPI().showSaveAsChartDialog()
    }
    symbolInterval() {
        return this._innerAPI().getSymbolInterval()
    }
    mainSeriesPriceFormatter() {
        return this._innerAPI().mainSeriesPriceFormatter()
    }
    getIntervals() {
        return this._innerAPI().getIntervals()
    }
    getStudiesList() {
        return this._innerAPI().getStudiesList()
    }
    getStudyInputs(e) {
        return this._innerAPI().getStudyInputs(e)
    }
    addCustomCSSFile(e) {
        this._innerWindow().addCustomCSSFile(e)
    }
    applyOverrides(e) {
        this._options = it(this._options, {
            overrides: e
        }), this._doWhenInnerWindowLoaded((t => {
            t.applyOverrides(e)
        }))
    }
    applyStudiesOverrides(e) {
        this._doWhenInnerWindowLoaded((t => {
            t.applyStudiesOverrides(e)
        }))
    }
    watchList() {
        return this._innerAPI().watchlist()
    }
    news() {
        return this._innerAPI().news()
    }
    widgetbar() {
        return this._innerAPI().widgetbar()
    }
    activeChart() {
        return this._innerAPI().activeChart()
    }
    chartsCount() {
        return this._innerAPI().chartsCount()
    }
    layout() {
        return this._innerAPI().layout()
    }
    setLayout(e) {
        this._innerAPI().setLayout(e)
    }
    layoutName() {
        return this._innerAPI().layoutName()
    }
    changeTheme(e, t) {
        return this._innerWindow().changeTheme(e, t)
    }
    getTheme() {
        return this._innerWindow().getTheme()
    }
    takeScreenshot() {
        this._doWhenInnerApiLoaded((e => {
            e.takeScreenshot()
        }))
    }
    lockAllDrawingTools() {
        return this._innerAPI().lockAllDrawingTools()
    }
    hideAllDrawingTools() {
        return this._innerAPI().hideAllDrawingTools()
    }
    drawOnAllCharts(e) {
        this._innerAPI().drawOnAllCharts(e)
    }
    magnetEnabled() {
        return this._innerAPI().magnetEnabled()
    }
    magnetMode() {
        return this._innerAPI().magnetMode()
    }
    undoRedoState() {
        return this._innerAPI().undoRedoState()
    }
    setIntervalLinkingEnabled(e) {
        this._innerAPI().setIntervalLinkingEnabled(e)
    }
    setTimeFrame(e) {
        this._innerAPI().setTimeFrame(e)
    }
    symbolSync() {
        return this._innerAPI().symbolSync()
    }
    intervalSync() {
        return this._innerAPI().intervalSync()
    }
    crosshairSync() {
        return this._innerAPI().crosshairSync()
    }
    timeSync() {
        return this._innerAPI().timeSync()
    }
    getAllFeatures() {
        return this._innerWindow().getAllFeatures()
    }
    clearUndoHistory() {
        return this._innerAPI().clearUndoHistory()
    }
    undo() {
        return this._innerAPI().undo()
    }
    redo() {
        return this._innerAPI().redo()
    }
    startFullscreen() {
        this._innerAPI().startFullscreen()
    }
    exitFullscreen() {
        this._innerAPI().exitFullscreen()
    }
    takeClientScreenshot(e) {
        return this._innerAPI().takeClientScreenshot(e)
    }
    navigationButtonsVisibility() {
        return this._innerWindow().getNavigationButtonsVisibility()
    }
    paneButtonsVisibility() {
        return this._innerWindow().getPaneButtonsVisibility()
    }
    dateFormat() {
        return this._innerWindow().getDateFormat()
    }
    _innerAPI() {
        return this._innerWindow().tradingViewApi
    }
    _innerWindow() {
        return this._iFrame.contentWindow
    }
    _doWhenInnerWindowLoaded(e) {
        this._ready ? e(this._innerWindow()) : this._innerWindowLoaded.then((() => {
            e(this._innerWindow())
        }))
    }
    _doWhenInnerApiLoaded(e) {
        this._doWhenInnerWindowLoaded((t => {
            t.doWhenApiIsReady((() => e(this._innerAPI())))
        }))
    }
    _autoResizeChart() {
        this._options.fullscreen && (this._iFrame.style.height = window.innerHeight + "px")
    }
    _create() {
        const e = this._render();
        this._options.container_id && console.warn("`container_id` is now deprecated. Please use `container` instead to either still pass a string or an `HTMLElement`.");
        const t = this._options.container_id || this._options.container,
            n = "string" == typeof t ? document.getElementById(t) : t;
        if (null === n) throw new Error(`There is no such element - #${this._options.container}`);
        n.innerHTML = e, this._iFrame = n.querySelector(`#${this._id}`);
        const r = this._iFrame;
        (this._options.autosize || this._options.fullscreen) && (r.style.width = "100%", this._options.fullscreen || (r.style.height = "100%")), window.addEventListener("resize", this._onWindowResize), this._onWindowResize(), this._innerWindowLoaded = new Promise((e => {
            const t = () => {
                r.contentWindow && void 0 !== r.contentWindow.widgetReady ? e() : setTimeout(t, 100)
            };
            t()
        })), this._innerWindowLoaded.then((() => {
            this._innerWindow().widgetReady((() => {
                this._ready = !0;
                for (const t of this._readyHandlers) try {
                    t.call(this)
                } catch (e) {
                    console.error(e)
                }
                this._innerWindow().initializationFinished()
            }))
        }))
    }
    _render() {
        const e = window;
        if (e[this._id] = {
                datafeed: this._options.datafeed,
                customFormatters: this._options.custom_formatters || this._options.customFormatters,
                brokerFactory: this._options.broker_factory || this._options.brokerFactory,
                overrides: this._options.overrides,
                studiesOverrides: this._options.studies_overrides,
                tradingCustomization: this._options.trading_customization,
                disabledFeatures: this._options.disabled_features,
                enabledFeatures: this._options.enabled_features,
                brokerConfig: this._options.broker_config || this._options.brokerConfig,
                restConfig: this._options.restConfig,
                favorites: this._options.favorites,
                logo: this._options.logo,
                numeric_formatting: this._options.numeric_formatting,
                rss_news_feed: this._options.rss_news_feed,
                newsProvider: this._options.news_provider,
                loadLastChart: this._options.load_last_chart,
                saveLoadAdapter: this._options.save_load_adapter,
                loading_screen: this._options.loading_screen,
                settingsAdapter: this._options.settings_adapter,
                getCustomIndicators: this._options.custom_indicators_getter,
                additionalSymbolInfoFields: this._options.additional_symbol_info_fields,
                headerWidgetButtonsMode: this._options.header_widget_buttons_mode,
                customTranslateFunction: this._options.custom_translate_function,
                symbolSearchComplete: this._options.symbol_search_complete,
                contextMenu: this._options.context_menu,
                settingsOverrides: this._options.settings_overrides
            }, this._options.saved_data) e[this._id].chartContent = {
            json: this._options.saved_data
        }, this._options.saved_data_meta_info && (e[this._id].chartContentExtendedData = this._options.saved_data_meta_info);
        else if (!this._options.load_last_chart && !this._options.symbol) throw new Error("Symbol is not defined: either 'symbol' or 'load_last_chart' option must be set");
        const t = (this._options.library_path || "") + `${encodeURIComponent(this._options.locale)}-tv-chart.e2a841ff.html#symbol=` + encodeURIComponent(this._options.symbol || "") + "&interval=" + encodeURIComponent(this._options.interval) + (this._options.timeframe ? "&timeframe=" + encodeURIComponent(this._options.timeframe) : "") + (this._options.toolbar_bg ? "&toolbarbg=" + encodeURIComponent(this._options.toolbar_bg.replace("#", "")) : "") + (this._options.studies_access ? "&studiesAccess=" + encodeURIComponent(JSON.stringify(this._options.studies_access)) : "") + "&widgetbar=" + encodeURIComponent(JSON.stringify(this._options.widgetbar)) + (this._options.drawings_access ? "&drawingsAccess=" + encodeURIComponent(JSON.stringify(this._options.drawings_access)) : "") + "&timeFrames=" + encodeURIComponent(JSON.stringify(this._options.time_frames)) + "&locale=" + encodeURIComponent(this._options.locale) + "&uid=" + encodeURIComponent(this._id) + "&clientId=" + encodeURIComponent(String(this._options.client_id)) + "&userId=" + encodeURIComponent(String(this._options.user_id)) + (this._options.charts_storage_url ? "&chartsStorageUrl=" + encodeURIComponent(this._options.charts_storage_url) : "") + (this._options.charts_storage_api_version ? "&chartsStorageVer=" + encodeURIComponent(this._options.charts_storage_api_version) : "") + (this._options.custom_css_url ? "&customCSS=" + encodeURIComponent(this._options.custom_css_url) : "") + (this._options.custom_font_family ? "&customFontFamily=" + encodeURIComponent(this._options.custom_font_family) : "") + (this._options.auto_save_delay ? "&autoSaveDelay=" + encodeURIComponent(String(this._options.auto_save_delay)) : "") + "&debug=" + encodeURIComponent(String(this._options.debug)) + (this._options.snapshot_url ? "&snapshotUrl=" + encodeURIComponent(this._options.snapshot_url) : "") + (this._options.timezone ? "&timezone=" + encodeURIComponent(this._options.timezone) : "") + (this._options.study_count_limit ? "&studyCountLimit=" + encodeURIComponent(String(this._options.study_count_limit)) : "") + (this._options.symbol_search_request_delay ? "&ssreqdelay=" + encodeURIComponent(String(this._options.symbol_search_request_delay)) : "") + (this._options.compare_symbols ? "&compareSymbols=" + encodeURIComponent(JSON.stringify(this._options.compare_symbols)) : "") + (this._options.theme ? "&theme=" + encodeURIComponent(String(this._options.theme)) : "") + (this._options.header_widget_buttons_mode ? "&header_widget_buttons_mode=" + encodeURIComponent(String(this._options.header_widget_buttons_mode)) : "") + (this._options.time_scale ? "&time_scale=" + encodeURIComponent(JSON.stringify(this._options.time_scale)) : "");
        return '<iframe id="' + this._id + '" name="' + this._id + '"  src="' + t + '"' + (this._options.autosize || this._options.fullscreen ? "" : ' width="' + this._options.width + '" height="' + this._options.height + '"') + ' title="Financial Chart" frameborder="0" allowTransparency="true" scrolling="no" allowfullscreen style="display:block;"></iframe>'
    }
};
window.TradingView = window.TradingView || {}, window.TradingView.version = function() {
    return "CL v22.032 (internal id e2a841ff @ 2022-07-06T11:53:07.702Z)"
};
const ut = {
    "1min": "1",
    "5min": "5",
    "15min": "15",
    "30min": "30",
    "60min": "60",
    "1day": "1D",
    "1week": "1W",
    "1mon": "1M"
};
class dt extends Error {}
class pt extends dt {
    constructor(e) {
        super(`Invalid DateTime: ${e.toMessage()}`)
    }
}
class ft extends dt {
    constructor(e) {
        super(`Invalid Interval: ${e.toMessage()}`)
    }
}
class mt extends dt {
    constructor(e) {
        super(`Invalid Duration: ${e.toMessage()}`)
    }
}
class ht extends dt {}
class yt extends dt {
    constructor(e) {
        super(`Invalid unit ${e}`)
    }
}
class gt extends dt {}
class vt extends dt {
    constructor() {
        super("Zone is an abstract class")
    }
}
const bt = "numeric",
    xt = "short",
    wt = "long",
    kt = {
        year: bt,
        month: bt,
        day: bt
    },
    St = {
        year: bt,
        month: xt,
        day: bt
    },
    Ct = {
        year: bt,
        month: xt,
        day: bt,
        weekday: xt
    },
    _t = {
        year: bt,
        month: wt,
        day: bt
    },
    Tt = {
        year: bt,
        month: wt,
        day: bt,
        weekday: wt
    },
    At = {
        hour: bt,
        minute: bt
    },
    Dt = {
        hour: bt,
        minute: bt,
        second: bt
    },
    Ot = {
        hour: bt,
        minute: bt,
        second: bt,
        timeZoneName: xt
    },
    Et = {
        hour: bt,
        minute: bt,
        second: bt,
        timeZoneName: wt
    },
    It = {
        hour: bt,
        minute: bt,
        hourCycle: "h23"
    },
    jt = {
        hour: bt,
        minute: bt,
        second: bt,
        hourCycle: "h23"
    },
    Lt = {
        hour: bt,
        minute: bt,
        second: bt,
        hourCycle: "h23",
        timeZoneName: xt
    },
    Pt = {
        hour: bt,
        minute: bt,
        second: bt,
        hourCycle: "h23",
        timeZoneName: wt
    },
    Mt = {
        year: bt,
        month: bt,
        day: bt,
        hour: bt,
        minute: bt
    },
    Nt = {
        year: bt,
        month: bt,
        day: bt,
        hour: bt,
        minute: bt,
        second: bt
    },
    Ft = {
        year: bt,
        month: xt,
        day: bt,
        hour: bt,
        minute: bt
    },
    Rt = {
        year: bt,
        month: xt,
        day: bt,
        hour: bt,
        minute: bt,
        second: bt
    },
    Wt = {
        year: bt,
        month: xt,
        day: bt,
        weekday: xt,
        hour: bt,
        minute: bt
    },
    Vt = {
        year: bt,
        month: wt,
        day: bt,
        hour: bt,
        minute: bt,
        timeZoneName: xt
    },
    Bt = {
        year: bt,
        month: wt,
        day: bt,
        hour: bt,
        minute: bt,
        second: bt,
        timeZoneName: xt
    },
    Ht = {
        year: bt,
        month: wt,
        day: bt,
        weekday: wt,
        hour: bt,
        minute: bt,
        timeZoneName: wt
    },
    qt = {
        year: bt,
        month: wt,
        day: bt,
        weekday: wt,
        hour: bt,
        minute: bt,
        second: bt,
        timeZoneName: wt
    };
class Ut {
    get type() {
        throw new vt
    }
    get name() {
        throw new vt
    }
    get ianaName() {
        return this.name
    }
    get isUniversal() {
        throw new vt
    }
    offsetName(e, t) {
        throw new vt
    }
    formatOffset(e, t) {
        throw new vt
    }
    offset(e) {
        throw new vt
    }
    equals(e) {
        throw new vt
    }
    get isValid() {
        throw new vt
    }
}
let zt = null;
class $t extends Ut {
    static get instance() {
        return null === zt && (zt = new $t), zt
    }
    get type() {
        return "system"
    }
    get name() {
        return (new Intl.DateTimeFormat).resolvedOptions().timeZone
    }
    get isUniversal() {
        return !1
    }
    offsetName(e, {
        format: t,
        locale: n
    }) {
        return dr(e, t, n)
    }
    formatOffset(e, t) {
        return hr(this.offset(e), t)
    }
    offset(e) {
        return -new Date(e).getTimezoneOffset()
    }
    equals(e) {
        return "system" === e.type
    }
    get isValid() {
        return !0
    }
}
let Zt = {};
const Gt = {
    year: 0,
    month: 1,
    day: 2,
    era: 3,
    hour: 4,
    minute: 5,
    second: 6
};
let Yt = {};
class Jt extends Ut {
    static create(e) {
        return Yt[e] || (Yt[e] = new Jt(e)), Yt[e]
    }
    static resetCache() {
        Yt = {}, Zt = {}
    }
    static isValidSpecifier(e) {
        return this.isValidZone(e)
    }
    static isValidZone(e) {
        if (!e) return !1;
        try {
            return new Intl.DateTimeFormat("en-US", {
                timeZone: e
            }).format(), !0
        } catch (t) {
            return !1
        }
    }
    constructor(e) {
        super(), this.zoneName = e, this.valid = Jt.isValidZone(e)
    }
    get type() {
        return "iana"
    }
    get name() {
        return this.zoneName
    }
    get isUniversal() {
        return !1
    }
    offsetName(e, {
        format: t,
        locale: n
    }) {
        return dr(e, t, n, this.name)
    }
    formatOffset(e, t) {
        return hr(this.offset(e), t)
    }
    offset(e) {
        const t = new Date(e);
        if (isNaN(t)) return NaN;
        const n = (r = this.name, Zt[r] || (Zt[r] = new Intl.DateTimeFormat("en-US", {
            hour12: !1,
            timeZone: r,
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            era: "short"
        })), Zt[r]);
        var r;
        let [o, i, a, s, l, c, u] = n.formatToParts ? function(e, t) {
            const n = e.formatToParts(t),
                r = [];
            for (let o = 0; o < n.length; o++) {
                const {
                    type: e,
                    value: t
                } = n[o], i = Gt[e];
                "era" === e ? r[i] = t : Un(i) || (r[i] = parseInt(t, 10))
            }
            return r
        }(n, t) : function(e, t) {
            const n = e.format(t).replace(/\u200E/g, ""),
                r = /(\d+)\/(\d+)\/(\d+) (AD|BC),? (\d+):(\d+):(\d+)/.exec(n),
                [, o, i, a, s, l, c, u] = r;
            return [a, o, i, s, l, c, u]
        }(n, t);
        "BC" === s && (o = 1 - Math.abs(o));
        let d = +t;
        const p = d % 1e3;
        return d -= p >= 0 ? p : 1e3 + p, (sr({
            year: o,
            month: i,
            day: a,
            hour: 24 === l ? 0 : l,
            minute: c,
            second: u,
            millisecond: 0
        }) - d) / 6e4
    }
    equals(e) {
        return "iana" === e.type && e.name === this.name
    }
    get isValid() {
        return this.valid
    }
}
let Kt = {};
let Xt = {};

function Qt(e, t = {}) {
    const n = JSON.stringify([e, t]);
    let r = Xt[n];
    return r || (r = new Intl.DateTimeFormat(e, t), Xt[n] = r), r
}
let en = {};
let tn = {};
let nn = null;
let rn = {};

function on(e, t, n, r) {
    const o = e.listingMode();
    return "error" === o ? null : "en" === o ? n(t) : r(t)
}
class an {
    constructor(e, t, n) {
        this.padTo = n.padTo || 0, this.floor = n.floor || !1;
        const {
            padTo: r,
            floor: o,
            ...i
        } = n;
        if (!t || Object.keys(i).length > 0) {
            const t = {
                useGrouping: !1,
                ...n
            };
            n.padTo > 0 && (t.minimumIntegerDigits = n.padTo), this.inf = function(e, t = {}) {
                const n = JSON.stringify([e, t]);
                let r = en[n];
                return r || (r = new Intl.NumberFormat(e, t), en[n] = r), r
            }(e, t)
        }
    }
    format(e) {
        if (this.inf) {
            const t = this.floor ? Math.floor(e) : e;
            return this.inf.format(t)
        }
        return Qn(this.floor ? Math.floor(e) : rr(e, 3), this.padTo)
    }
}
class sn {
    constructor(e, t, n) {
        let r;
        if (this.opts = n, this.originalZone = void 0, this.opts.timeZone) this.dt = e;
        else if ("fixed" === e.zone.type) {
            const t = e.offset / 60 * -1,
                n = t >= 0 ? `Etc/GMT+${t}` : `Etc/GMT${t}`;
            0 !== e.offset && Jt.create(n).valid ? (r = n, this.dt = e) : (r = "UTC", this.dt = 0 === e.offset ? e : e.setZone("UTC").plus({
                minutes: e.offset
            }), this.originalZone = e.zone)
        } else "system" === e.zone.type ? this.dt = e : "iana" === e.zone.type ? (this.dt = e, r = e.zone.name) : (r = "UTC", this.dt = e.setZone("UTC").plus({
            minutes: e.offset
        }), this.originalZone = e.zone);
        const o = { ...this.opts
        };
        o.timeZone = o.timeZone || r, this.dtf = Qt(t, o)
    }
    format() {
        return this.originalZone ? this.formatToParts().map((({
            value: e
        }) => e)).join("") : this.dtf.format(this.dt.toJSDate())
    }
    formatToParts() {
        const e = this.dtf.formatToParts(this.dt.toJSDate());
        return this.originalZone ? e.map((e => {
            if ("timeZoneName" === e.type) {
                const t = this.originalZone.offsetName(this.dt.ts, {
                    locale: this.dt.locale,
                    format: this.opts.timeZoneName
                });
                return { ...e,
                    value: t
                }
            }
            return e
        })) : e
    }
    resolvedOptions() {
        return this.dtf.resolvedOptions()
    }
}
class ln {
    constructor(e, t, n) {
        this.opts = {
            style: "long",
            ...n
        }, !t && Zn() && (this.rtf = function(e, t = {}) {
            const {
                base: n,
                ...r
            } = t, o = JSON.stringify([e, r]);
            let i = tn[o];
            return i || (i = new Intl.RelativeTimeFormat(e, t), tn[o] = i), i
        }(e, n))
    }
    format(e, t) {
        return this.rtf ? this.rtf.format(e, t) : function(e, t, n = "always", r = !1) {
            const o = {
                    years: ["year", "yr."],
                    quarters: ["quarter", "qtr."],
                    months: ["month", "mo."],
                    weeks: ["week", "wk."],
                    days: ["day", "day", "days"],
                    hours: ["hour", "hr."],
                    minutes: ["minute", "min."],
                    seconds: ["second", "sec."]
                },
                i = -1 === ["hours", "minutes", "seconds"].indexOf(e);
            if ("auto" === n && i) {
                const n = "days" === e;
                switch (t) {
                    case 1:
                        return n ? "tomorrow" : `next ${o[e][0]}`;
                    case -1:
                        return n ? "yesterday" : `last ${o[e][0]}`;
                    case 0:
                        return n ? "today" : `this ${o[e][0]}`
                }
            }
            const a = Object.is(t, -0) || t < 0,
                s = Math.abs(t),
                l = 1 === s,
                c = o[e],
                u = r ? l ? c[1] : c[2] || c[1] : l ? o[e][0] : e;
            return a ? `${s} ${u} ago` : `in ${s} ${u}`
        }(t, e, this.opts.numeric, "long" !== this.opts.style)
    }
    formatToParts(e, t) {
        return this.rtf ? this.rtf.formatToParts(e, t) : []
    }
}
const cn = {
    firstDay: 1,
    minimalDays: 4,
    weekend: [6, 7]
};
class un {
    static fromOpts(e) {
        return un.create(e.locale, e.numberingSystem, e.outputCalendar, e.weekSettings, e.defaultToEN)
    }
    static create(e, t, n, r, o = !1) {
        const i = e || Dn.defaultLocale,
            a = i || (o ? "en-US" : nn || (nn = (new Intl.DateTimeFormat).resolvedOptions().locale, nn)),
            s = t || Dn.defaultNumberingSystem,
            l = n || Dn.defaultOutputCalendar,
            c = Kn(r) || Dn.defaultWeekSettings;
        return new un(a, s, l, c, i)
    }
    static resetCache() {
        nn = null, Xt = {}, en = {}, tn = {}
    }
    static fromObject({
        locale: e,
        numberingSystem: t,
        outputCalendar: n,
        weekSettings: r
    } = {}) {
        return un.create(e, t, n, r)
    }
    constructor(e, t, n, r, o) {
        const [i, a, s] = function(e) {
            const t = e.indexOf("-x-"); - 1 !== t && (e = e.substring(0, t));
            const n = e.indexOf("-u-");
            if (-1 === n) return [e]; {
                let t, o;
                try {
                    t = Qt(e).resolvedOptions(), o = e
                } catch (r) {
                    const i = e.substring(0, n);
                    t = Qt(i).resolvedOptions(), o = i
                }
                const {
                    numberingSystem: i,
                    calendar: a
                } = t;
                return [o, i, a]
            }
        }(e);
        this.locale = i, this.numberingSystem = t || a || null, this.outputCalendar = n || s || null, this.weekSettings = r, this.intl = function(e, t, n) {
            return n || t ? (e.includes("-u-") || (e += "-u"), n && (e += `-ca-${n}`), t && (e += `-nu-${t}`), e) : e
        }(this.locale, this.numberingSystem, this.outputCalendar), this.weekdaysCache = {
            format: {},
            standalone: {}
        }, this.monthsCache = {
            format: {},
            standalone: {}
        }, this.meridiemCache = null, this.eraCache = {}, this.specifiedLocale = o, this.fastNumbersCached = null
    }
    get fastNumbers() {
        var e;
        return null == this.fastNumbersCached && (this.fastNumbersCached = (!(e = this).numberingSystem || "latn" === e.numberingSystem) && ("latn" === e.numberingSystem || !e.locale || e.locale.startsWith("en") || "latn" === new Intl.DateTimeFormat(e.intl).resolvedOptions().numberingSystem)), this.fastNumbersCached
    }
    listingMode() {
        const e = this.isEnglish(),
            t = !(null !== this.numberingSystem && "latn" !== this.numberingSystem || null !== this.outputCalendar && "gregory" !== this.outputCalendar);
        return e && t ? "en" : "intl"
    }
    clone(e) {
        return e && 0 !== Object.getOwnPropertyNames(e).length ? un.create(e.locale || this.specifiedLocale, e.numberingSystem || this.numberingSystem, e.outputCalendar || this.outputCalendar, Kn(e.weekSettings) || this.weekSettings, e.defaultToEN || !1) : this
    }
    redefaultToEN(e = {}) {
        return this.clone({ ...e,
            defaultToEN: !0
        })
    }
    redefaultToSystem(e = {}) {
        return this.clone({ ...e,
            defaultToEN: !1
        })
    }
    months(e, t = !1) {
        return on(this, e, xr, (() => {
            const n = t ? {
                    month: e,
                    day: "numeric"
                } : {
                    month: e
                },
                r = t ? "format" : "standalone";
            return this.monthsCache[r][e] || (this.monthsCache[r][e] = function(e) {
                const t = [];
                for (let n = 1; n <= 12; n++) {
                    const r = Ci.utc(2009, n, 1);
                    t.push(e(r))
                }
                return t
            }((e => this.extract(e, n, "month")))), this.monthsCache[r][e]
        }))
    }
    weekdays(e, t = !1) {
        return on(this, e, Cr, (() => {
            const n = t ? {
                    weekday: e,
                    year: "numeric",
                    month: "long",
                    day: "numeric"
                } : {
                    weekday: e
                },
                r = t ? "format" : "standalone";
            return this.weekdaysCache[r][e] || (this.weekdaysCache[r][e] = function(e) {
                const t = [];
                for (let n = 1; n <= 7; n++) {
                    const r = Ci.utc(2016, 11, 13 + n);
                    t.push(e(r))
                }
                return t
            }((e => this.extract(e, n, "weekday")))), this.weekdaysCache[r][e]
        }))
    }
    meridiems() {
        return on(this, void 0, (() => _r), (() => {
            if (!this.meridiemCache) {
                const e = {
                    hour: "numeric",
                    hourCycle: "h12"
                };
                this.meridiemCache = [Ci.utc(2016, 11, 13, 9), Ci.utc(2016, 11, 13, 19)].map((t => this.extract(t, e, "dayperiod")))
            }
            return this.meridiemCache
        }))
    }
    eras(e) {
        return on(this, e, Or, (() => {
            const t = {
                era: e
            };
            return this.eraCache[e] || (this.eraCache[e] = [Ci.utc(-40, 1, 1), Ci.utc(2017, 1, 1)].map((e => this.extract(e, t, "era")))), this.eraCache[e]
        }))
    }
    extract(e, t, n) {
        const r = this.dtFormatter(e, t).formatToParts().find((e => e.type.toLowerCase() === n));
        return r ? r.value : null
    }
    numberFormatter(e = {}) {
        return new an(this.intl, e.forceSimple || this.fastNumbers, e)
    }
    dtFormatter(e, t = {}) {
        return new sn(e, this.intl, t)
    }
    relFormatter(e = {}) {
        return new ln(this.intl, this.isEnglish(), e)
    }
    listFormatter(e = {}) {
        return function(e, t = {}) {
            const n = JSON.stringify([e, t]);
            let r = Kt[n];
            return r || (r = new Intl.ListFormat(e, t), Kt[n] = r), r
        }(this.intl, e)
    }
    isEnglish() {
        return "en" === this.locale || "en-us" === this.locale.toLowerCase() || new Intl.DateTimeFormat(this.intl).resolvedOptions().locale.startsWith("en-us")
    }
    getWeekSettings() {
        return this.weekSettings ? this.weekSettings : Gn() ? function(e) {
            let t = rn[e];
            if (!t) {
                const n = new Intl.Locale(e);
                t = "getWeekInfo" in n ? n.getWeekInfo() : n.weekInfo, rn[e] = t
            }
            return t
        }(this.locale) : cn
    }
    getStartOfWeek() {
        return this.getWeekSettings().firstDay
    }
    getMinDaysInFirstWeek() {
        return this.getWeekSettings().minimalDays
    }
    getWeekendDays() {
        return this.getWeekSettings().weekend
    }
    equals(e) {
        return this.locale === e.locale && this.numberingSystem === e.numberingSystem && this.outputCalendar === e.outputCalendar
    }
    toString() {
        return `Locale(${this.locale}, ${this.numberingSystem}, ${this.outputCalendar})`
    }
}
let dn = null;
class pn extends Ut {
    static get utcInstance() {
        return null === dn && (dn = new pn(0)), dn
    }
    static instance(e) {
        return 0 === e ? pn.utcInstance : new pn(e)
    }
    static parseSpecifier(e) {
        if (e) {
            const t = e.match(/^utc(?:([+-]\d{1,2})(?::(\d{2}))?)?$/i);
            if (t) return new pn(pr(t[1], t[2]))
        }
        return null
    }
    constructor(e) {
        super(), this.fixed = e
    }
    get type() {
        return "fixed"
    }
    get name() {
        return 0 === this.fixed ? "UTC" : `UTC${hr(this.fixed,"narrow")}`
    }
    get ianaName() {
        return 0 === this.fixed ? "Etc/UTC" : `Etc/GMT${hr(-this.fixed,"narrow")}`
    }
    offsetName() {
        return this.name
    }
    formatOffset(e, t) {
        return hr(this.fixed, t)
    }
    get isUniversal() {
        return !0
    }
    offset() {
        return this.fixed
    }
    equals(e) {
        return "fixed" === e.type && e.fixed === this.fixed
    }
    get isValid() {
        return !0
    }
}
class fn extends Ut {
    constructor(e) {
        super(), this.zoneName = e
    }
    get type() {
        return "invalid"
    }
    get name() {
        return this.zoneName
    }
    get isUniversal() {
        return !1
    }
    offsetName() {
        return null
    }
    formatOffset() {
        return ""
    }
    offset() {
        return NaN
    }
    equals() {
        return !1
    }
    get isValid() {
        return !1
    }
}

function mn(e, t) {
    if (Un(e) || null === e) return t;
    if (e instanceof Ut) return e;
    if ("string" == typeof e) {
        const n = e.toLowerCase();
        return "default" === n ? t : "local" === n || "system" === n ? $t.instance : "utc" === n || "gmt" === n ? pn.utcInstance : pn.parseSpecifier(n) || Jt.create(e)
    }
    return zn(e) ? pn.instance(e) : "object" == typeof e && "offset" in e && "function" == typeof e.offset ? e : new fn(e)
}
const hn = {
        arab: "[٠-٩]",
        arabext: "[۰-۹]",
        bali: "[᭐-᭙]",
        beng: "[০-৯]",
        deva: "[०-९]",
        fullwide: "[０-９]",
        gujr: "[૦-૯]",
        hanidec: "[〇|一|二|三|四|五|六|七|八|九]",
        khmr: "[០-៩]",
        knda: "[೦-೯]",
        laoo: "[໐-໙]",
        limb: "[᥆-᥏]",
        mlym: "[൦-൯]",
        mong: "[᠐-᠙]",
        mymr: "[၀-၉]",
        orya: "[୦-୯]",
        tamldec: "[௦-௯]",
        telu: "[౦-౯]",
        thai: "[๐-๙]",
        tibt: "[༠-༩]",
        latn: "\\d"
    },
    yn = {
        arab: [1632, 1641],
        arabext: [1776, 1785],
        bali: [6992, 7001],
        beng: [2534, 2543],
        deva: [2406, 2415],
        fullwide: [65296, 65303],
        gujr: [2790, 2799],
        khmr: [6112, 6121],
        knda: [3302, 3311],
        laoo: [3792, 3801],
        limb: [6470, 6479],
        mlym: [3430, 3439],
        mong: [6160, 6169],
        mymr: [4160, 4169],
        orya: [2918, 2927],
        tamldec: [3046, 3055],
        telu: [3174, 3183],
        thai: [3664, 3673],
        tibt: [3872, 3881]
    },
    gn = hn.hanidec.replace(/[\[|\]]/g, "").split("");
let vn = {};

function bn({
    numberingSystem: e
}, t = "") {
    const n = e || "latn";
    return vn[n] || (vn[n] = {}), vn[n][t] || (vn[n][t] = new RegExp(`${hn[n]}${t}`)), vn[n][t]
}
let xn, wn = () => Date.now(),
    kn = "system",
    Sn = null,
    Cn = null,
    _n = null,
    Tn = 60,
    An = null;
class Dn {
    static get now() {
        return wn
    }
    static set now(e) {
        wn = e
    }
    static set defaultZone(e) {
        kn = e
    }
    static get defaultZone() {
        return mn(kn, $t.instance)
    }
    static get defaultLocale() {
        return Sn
    }
    static set defaultLocale(e) {
        Sn = e
    }
    static get defaultNumberingSystem() {
        return Cn
    }
    static set defaultNumberingSystem(e) {
        Cn = e
    }
    static get defaultOutputCalendar() {
        return _n
    }
    static set defaultOutputCalendar(e) {
        _n = e
    }
    static get defaultWeekSettings() {
        return An
    }
    static set defaultWeekSettings(e) {
        An = Kn(e)
    }
    static get twoDigitCutoffYear() {
        return Tn
    }
    static set twoDigitCutoffYear(e) {
        Tn = e % 100
    }
    static get throwOnInvalid() {
        return xn
    }
    static set throwOnInvalid(e) {
        xn = e
    }
    static resetCaches() {
        un.resetCache(), Jt.resetCache(), Ci.resetCache(), vn = {}
    }
}
class On {
    constructor(e, t) {
        this.reason = e, this.explanation = t
    }
    toMessage() {
        return this.explanation ? `${this.reason}: ${this.explanation}` : this.reason
    }
}
const En = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334],
    In = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335];

function jn(e, t) {
    return new On("unit out of range", `you specified ${t} (of type ${typeof t}) as a ${e}, which is invalid`)
}

function Ln(e, t, n) {
    const r = new Date(Date.UTC(e, t - 1, n));
    e < 100 && e >= 0 && r.setUTCFullYear(r.getUTCFullYear() - 1900);
    const o = r.getUTCDay();
    return 0 === o ? 7 : o
}

function Pn(e, t, n) {
    return n + (or(e) ? In : En)[t - 1]
}

function Mn(e, t) {
    const n = or(e) ? In : En,
        r = n.findIndex((e => e < t));
    return {
        month: r + 1,
        day: t - n[r]
    }
}

function Nn(e, t) {
    return (e - t + 7) % 7 + 1
}

function Fn(e, t = 4, n = 1) {
    const {
        year: r,
        month: o,
        day: i
    } = e, a = Pn(r, o, i), s = Nn(Ln(r, o, i), n);
    let l, c = Math.floor((a - s + 14 - t) / 7);
    return c < 1 ? (l = r - 1, c = cr(l, t, n)) : c > cr(r, t, n) ? (l = r + 1, c = 1) : l = r, {
        weekYear: l,
        weekNumber: c,
        weekday: s,
        ...yr(e)
    }
}

function Rn(e, t = 4, n = 1) {
    const {
        weekYear: r,
        weekNumber: o,
        weekday: i
    } = e, a = Nn(Ln(r, 1, t), n), s = ir(r);
    let l, c = 7 * o + i - a - 7 + t;
    c < 1 ? (l = r - 1, c += ir(l)) : c > s ? (l = r + 1, c -= ir(r)) : l = r;
    const {
        month: u,
        day: d
    } = Mn(l, c);
    return {
        year: l,
        month: u,
        day: d,
        ...yr(e)
    }
}

function Wn(e) {
    const {
        year: t,
        month: n,
        day: r
    } = e;
    return {
        year: t,
        ordinal: Pn(t, n, r),
        ...yr(e)
    }
}

function Vn(e) {
    const {
        year: t,
        ordinal: n
    } = e, {
        month: r,
        day: o
    } = Mn(t, n);
    return {
        year: t,
        month: r,
        day: o,
        ...yr(e)
    }
}

function Bn(e, t) {
    if (!Un(e.localWeekday) || !Un(e.localWeekNumber) || !Un(e.localWeekYear)) {
        if (!Un(e.weekday) || !Un(e.weekNumber) || !Un(e.weekYear)) throw new ht("Cannot mix locale-based week fields with ISO-based week fields");
        return Un(e.localWeekday) || (e.weekday = e.localWeekday), Un(e.localWeekNumber) || (e.weekNumber = e.localWeekNumber), Un(e.localWeekYear) || (e.weekYear = e.localWeekYear), delete e.localWeekday, delete e.localWeekNumber, delete e.localWeekYear, {
            minDaysInFirstWeek: t.getMinDaysInFirstWeek(),
            startOfWeek: t.getStartOfWeek()
        }
    }
    return {
        minDaysInFirstWeek: 4,
        startOfWeek: 1
    }
}

function Hn(e) {
    const t = $n(e.year),
        n = Xn(e.month, 1, 12),
        r = Xn(e.day, 1, ar(e.year, e.month));
    return t ? n ? !r && jn("day", e.day) : jn("month", e.month) : jn("year", e.year)
}

function qn(e) {
    const {
        hour: t,
        minute: n,
        second: r,
        millisecond: o
    } = e, i = Xn(t, 0, 23) || 24 === t && 0 === n && 0 === r && 0 === o, a = Xn(n, 0, 59), s = Xn(r, 0, 59), l = Xn(o, 0, 999);
    return i ? a ? s ? !l && jn("millisecond", o) : jn("second", r) : jn("minute", n) : jn("hour", t)
}

function Un(e) {
    return void 0 === e
}

function zn(e) {
    return "number" == typeof e
}

function $n(e) {
    return "number" == typeof e && e % 1 == 0
}

function Zn() {
    try {
        return "undefined" != typeof Intl && !!Intl.RelativeTimeFormat
    } catch (e) {
        return !1
    }
}

function Gn() {
    try {
        return "undefined" != typeof Intl && !!Intl.Locale && ("weekInfo" in Intl.Locale.prototype || "getWeekInfo" in Intl.Locale.prototype)
    } catch (e) {
        return !1
    }
}

function Yn(e, t, n) {
    if (0 !== e.length) return e.reduce(((e, r) => {
        const o = [t(r), r];
        return e && n(e[0], o[0]) === e[0] ? e : o
    }), null)[1]
}

function Jn(e, t) {
    return Object.prototype.hasOwnProperty.call(e, t)
}

function Kn(e) {
    if (null == e) return null;
    if ("object" != typeof e) throw new gt("Week settings must be an object");
    if (!Xn(e.firstDay, 1, 7) || !Xn(e.minimalDays, 1, 7) || !Array.isArray(e.weekend) || e.weekend.some((e => !Xn(e, 1, 7)))) throw new gt("Invalid week settings");
    return {
        firstDay: e.firstDay,
        minimalDays: e.minimalDays,
        weekend: Array.from(e.weekend)
    }
}

function Xn(e, t, n) {
    return $n(e) && e >= t && e <= n
}

function Qn(e, t = 2) {
    let n;
    return n = e < 0 ? "-" + ("" + -e).padStart(t, "0") : ("" + e).padStart(t, "0"), n
}

function er(e) {
    return Un(e) || null === e || "" === e ? void 0 : parseInt(e, 10)
}

function tr(e) {
    return Un(e) || null === e || "" === e ? void 0 : parseFloat(e)
}

function nr(e) {
    if (!Un(e) && null !== e && "" !== e) {
        const t = 1e3 * parseFloat("0." + e);
        return Math.floor(t)
    }
}

function rr(e, t, n = !1) {
    const r = 10 ** t;
    return (n ? Math.trunc : Math.round)(e * r) / r
}

function or(e) {
    return e % 4 == 0 && (e % 100 != 0 || e % 400 == 0)
}

function ir(e) {
    return or(e) ? 366 : 365
}

function ar(e, t) {
    const n = (r = t - 1) - (o = 12) * Math.floor(r / o) + 1;
    var r, o;
    return 2 === n ? or(e + (t - n) / 12) ? 29 : 28 : [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][n - 1]
}

function sr(e) {
    let t = Date.UTC(e.year, e.month - 1, e.day, e.hour, e.minute, e.second, e.millisecond);
    return e.year < 100 && e.year >= 0 && (t = new Date(t), t.setUTCFullYear(e.year, e.month - 1, e.day)), +t
}

function lr(e, t, n) {
    return -Nn(Ln(e, 1, t), n) + t - 1
}

function cr(e, t = 4, n = 1) {
    const r = lr(e, t, n),
        o = lr(e + 1, t, n);
    return (ir(e) - r + o) / 7
}

function ur(e) {
    return e > 99 ? e : e > Dn.twoDigitCutoffYear ? 1900 + e : 2e3 + e
}

function dr(e, t, n, r = null) {
    const o = new Date(e),
        i = {
            hourCycle: "h23",
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit"
        };
    r && (i.timeZone = r);
    const a = {
            timeZoneName: t,
            ...i
        },
        s = new Intl.DateTimeFormat(n, a).formatToParts(o).find((e => "timezonename" === e.type.toLowerCase()));
    return s ? s.value : null
}

function pr(e, t) {
    let n = parseInt(e, 10);
    Number.isNaN(n) && (n = 0);
    const r = parseInt(t, 10) || 0;
    return 60 * n + (n < 0 || Object.is(n, -0) ? -r : r)
}

function fr(e) {
    const t = Number(e);
    if ("boolean" == typeof e || "" === e || Number.isNaN(t)) throw new gt(`Invalid unit value ${e}`);
    return t
}

function mr(e, t) {
    const n = {};
    for (const r in e)
        if (Jn(e, r)) {
            const o = e[r];
            if (null == o) continue;
            n[t(r)] = fr(o)
        }
    return n
}

function hr(e, t) {
    const n = Math.trunc(Math.abs(e / 60)),
        r = Math.trunc(Math.abs(e % 60)),
        o = e >= 0 ? "+" : "-";
    switch (t) {
        case "short":
            return `${o}${Qn(n,2)}:${Qn(r,2)}`;
        case "narrow":
            return `${o}${n}${r>0?`:${r}`:""}`;
        case "techie":
            return `${o}${Qn(n,2)}${Qn(r,2)}`;
        default:
            throw new RangeError(`Value format ${t} is out of range for property format`)
    }
}

function yr(e) {
    return function(e, t) {
        return t.reduce(((t, n) => (t[n] = e[n], t)), {})
    }(e, ["hour", "minute", "second", "millisecond"])
}
const gr = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    vr = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    br = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];

function xr(e) {
    switch (e) {
        case "narrow":
            return [...br];
        case "short":
            return [...vr];
        case "long":
            return [...gr];
        case "numeric":
            return ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];
        case "2-digit":
            return ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
        default:
            return null
    }
}
const wr = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    kr = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    Sr = ["M", "T", "W", "T", "F", "S", "S"];

function Cr(e) {
    switch (e) {
        case "narrow":
            return [...Sr];
        case "short":
            return [...kr];
        case "long":
            return [...wr];
        case "numeric":
            return ["1", "2", "3", "4", "5", "6", "7"];
        default:
            return null
    }
}
const _r = ["AM", "PM"],
    Tr = ["Before Christ", "Anno Domini"],
    Ar = ["BC", "AD"],
    Dr = ["B", "A"];

function Or(e) {
    switch (e) {
        case "narrow":
            return [...Dr];
        case "short":
            return [...Ar];
        case "long":
            return [...Tr];
        default:
            return null
    }
}

function Er(e, t) {
    let n = "";
    for (const r of e) r.literal ? n += r.val : n += t(r.val);
    return n
}
const Ir = {
    D: kt,
    DD: St,
    DDD: _t,
    DDDD: Tt,
    t: At,
    tt: Dt,
    ttt: Ot,
    tttt: Et,
    T: It,
    TT: jt,
    TTT: Lt,
    TTTT: Pt,
    f: Mt,
    ff: Ft,
    fff: Vt,
    ffff: Ht,
    F: Nt,
    FF: Rt,
    FFF: Bt,
    FFFF: qt
};
class jr {
    static create(e, t = {}) {
        return new jr(e, t)
    }
    static parseFormat(e) {
        let t = null,
            n = "",
            r = !1;
        const o = [];
        for (let i = 0; i < e.length; i++) {
            const a = e.charAt(i);
            "'" === a ? (n.length > 0 && o.push({
                literal: r || /^\s+$/.test(n),
                val: n
            }), t = null, n = "", r = !r) : r || a === t ? n += a : (n.length > 0 && o.push({
                literal: /^\s+$/.test(n),
                val: n
            }), n = a, t = a)
        }
        return n.length > 0 && o.push({
            literal: r || /^\s+$/.test(n),
            val: n
        }), o
    }
    static macroTokenToFormatOpts(e) {
        return Ir[e]
    }
    constructor(e, t) {
        this.opts = t, this.loc = e, this.systemLoc = null
    }
    formatWithSystemDefault(e, t) {
        null === this.systemLoc && (this.systemLoc = this.loc.redefaultToSystem());
        return this.systemLoc.dtFormatter(e, { ...this.opts,
            ...t
        }).format()
    }
    dtFormatter(e, t = {}) {
        return this.loc.dtFormatter(e, { ...this.opts,
            ...t
        })
    }
    formatDateTime(e, t) {
        return this.dtFormatter(e, t).format()
    }
    formatDateTimeParts(e, t) {
        return this.dtFormatter(e, t).formatToParts()
    }
    formatInterval(e, t) {
        return this.dtFormatter(e.start, t).dtf.formatRange(e.start.toJSDate(), e.end.toJSDate())
    }
    resolvedOptions(e, t) {
        return this.dtFormatter(e, t).resolvedOptions()
    }
    num(e, t = 0) {
        if (this.opts.forceSimple) return Qn(e, t);
        const n = { ...this.opts
        };
        return t > 0 && (n.padTo = t), this.loc.numberFormatter(n).format(e)
    }
    formatDateTimeFromString(e, t) {
        const n = "en" === this.loc.listingMode(),
            r = this.loc.outputCalendar && "gregory" !== this.loc.outputCalendar,
            o = (t, n) => this.loc.extract(e, t, n),
            i = t => e.isOffsetFixed && 0 === e.offset && t.allowZ ? "Z" : e.isValid ? e.zone.formatOffset(e.ts, t.format) : "",
            a = () => n ? function(e) {
                return _r[e.hour < 12 ? 0 : 1]
            }(e) : o({
                hour: "numeric",
                hourCycle: "h12"
            }, "dayperiod"),
            s = (t, r) => n ? function(e, t) {
                return xr(t)[e.month - 1]
            }(e, t) : o(r ? {
                month: t
            } : {
                month: t,
                day: "numeric"
            }, "month"),
            l = (t, r) => n ? function(e, t) {
                return Cr(t)[e.weekday - 1]
            }(e, t) : o(r ? {
                weekday: t
            } : {
                weekday: t,
                month: "long",
                day: "numeric"
            }, "weekday"),
            c = t => {
                const n = jr.macroTokenToFormatOpts(t);
                return n ? this.formatWithSystemDefault(e, n) : t
            },
            u = t => n ? function(e, t) {
                return Or(t)[e.year < 0 ? 0 : 1]
            }(e, t) : o({
                era: t
            }, "era");
        return Er(jr.parseFormat(t), (t => {
            switch (t) {
                case "S":
                    return this.num(e.millisecond);
                case "u":
                case "SSS":
                    return this.num(e.millisecond, 3);
                case "s":
                    return this.num(e.second);
                case "ss":
                    return this.num(e.second, 2);
                case "uu":
                    return this.num(Math.floor(e.millisecond / 10), 2);
                case "uuu":
                    return this.num(Math.floor(e.millisecond / 100));
                case "m":
                    return this.num(e.minute);
                case "mm":
                    return this.num(e.minute, 2);
                case "h":
                    return this.num(e.hour % 12 == 0 ? 12 : e.hour % 12);
                case "hh":
                    return this.num(e.hour % 12 == 0 ? 12 : e.hour % 12, 2);
                case "H":
                    return this.num(e.hour);
                case "HH":
                    return this.num(e.hour, 2);
                case "Z":
                    return i({
                        format: "narrow",
                        allowZ: this.opts.allowZ
                    });
                case "ZZ":
                    return i({
                        format: "short",
                        allowZ: this.opts.allowZ
                    });
                case "ZZZ":
                    return i({
                        format: "techie",
                        allowZ: this.opts.allowZ
                    });
                case "ZZZZ":
                    return e.zone.offsetName(e.ts, {
                        format: "short",
                        locale: this.loc.locale
                    });
                case "ZZZZZ":
                    return e.zone.offsetName(e.ts, {
                        format: "long",
                        locale: this.loc.locale
                    });
                case "z":
                    return e.zoneName;
                case "a":
                    return a();
                case "d":
                    return r ? o({
                        day: "numeric"
                    }, "day") : this.num(e.day);
                case "dd":
                    return r ? o({
                        day: "2-digit"
                    }, "day") : this.num(e.day, 2);
                case "c":
                case "E":
                    return this.num(e.weekday);
                case "ccc":
                    return l("short", !0);
                case "cccc":
                    return l("long", !0);
                case "ccccc":
                    return l("narrow", !0);
                case "EEE":
                    return l("short", !1);
                case "EEEE":
                    return l("long", !1);
                case "EEEEE":
                    return l("narrow", !1);
                case "L":
                    return r ? o({
                        month: "numeric",
                        day: "numeric"
                    }, "month") : this.num(e.month);
                case "LL":
                    return r ? o({
                        month: "2-digit",
                        day: "numeric"
                    }, "month") : this.num(e.month, 2);
                case "LLL":
                    return s("short", !0);
                case "LLLL":
                    return s("long", !0);
                case "LLLLL":
                    return s("narrow", !0);
                case "M":
                    return r ? o({
                        month: "numeric"
                    }, "month") : this.num(e.month);
                case "MM":
                    return r ? o({
                        month: "2-digit"
                    }, "month") : this.num(e.month, 2);
                case "MMM":
                    return s("short", !1);
                case "MMMM":
                    return s("long", !1);
                case "MMMMM":
                    return s("narrow", !1);
                case "y":
                    return r ? o({
                        year: "numeric"
                    }, "year") : this.num(e.year);
                case "yy":
                    return r ? o({
                        year: "2-digit"
                    }, "year") : this.num(e.year.toString().slice(-2), 2);
                case "yyyy":
                    return r ? o({
                        year: "numeric"
                    }, "year") : this.num(e.year, 4);
                case "yyyyyy":
                    return r ? o({
                        year: "numeric"
                    }, "year") : this.num(e.year, 6);
                case "G":
                    return u("short");
                case "GG":
                    return u("long");
                case "GGGGG":
                    return u("narrow");
                case "kk":
                    return this.num(e.weekYear.toString().slice(-2), 2);
                case "kkkk":
                    return this.num(e.weekYear, 4);
                case "W":
                    return this.num(e.weekNumber);
                case "WW":
                    return this.num(e.weekNumber, 2);
                case "n":
                    return this.num(e.localWeekNumber);
                case "nn":
                    return this.num(e.localWeekNumber, 2);
                case "ii":
                    return this.num(e.localWeekYear.toString().slice(-2), 2);
                case "iiii":
                    return this.num(e.localWeekYear, 4);
                case "o":
                    return this.num(e.ordinal);
                case "ooo":
                    return this.num(e.ordinal, 3);
                case "q":
                    return this.num(e.quarter);
                case "qq":
                    return this.num(e.quarter, 2);
                case "X":
                    return this.num(Math.floor(e.ts / 1e3));
                case "x":
                    return this.num(e.ts);
                default:
                    return c(t)
            }
        }))
    }
    formatDurationFromString(e, t) {
        const n = e => {
                switch (e[0]) {
                    case "S":
                        return "millisecond";
                    case "s":
                        return "second";
                    case "m":
                        return "minute";
                    case "h":
                        return "hour";
                    case "d":
                        return "day";
                    case "w":
                        return "week";
                    case "M":
                        return "month";
                    case "y":
                        return "year";
                    default:
                        return null
                }
            },
            r = jr.parseFormat(t),
            o = r.reduce(((e, {
                literal: t,
                val: n
            }) => t ? e : e.concat(n)), []);
        return Er(r, (e => t => {
            const r = n(t);
            return r ? this.num(e.get(r), t.length) : t
        })(e.shiftTo(...o.map(n).filter((e => e)))))
    }
}
const Lr = /[A-Za-z_+-]{1,256}(?::?\/[A-Za-z0-9_+-]{1,256}(?:\/[A-Za-z0-9_+-]{1,256})?)?/;

function Pr(...e) {
    const t = e.reduce(((e, t) => e + t.source), "");
    return RegExp(`^${t}$`)
}

function Mr(...e) {
    return t => e.reduce((([e, n, r], o) => {
        const [i, a, s] = o(t, r);
        return [{ ...e,
            ...i
        }, a || n, s]
    }), [{}, null, 1]).slice(0, 2)
}

function Nr(e, ...t) {
    if (null == e) return [null, null];
    for (const [n, r] of t) {
        const t = n.exec(e);
        if (t) return r(t)
    }
    return [null, null]
}

function Fr(...e) {
    return (t, n) => {
        const r = {};
        let o;
        for (o = 0; o < e.length; o++) r[e[o]] = er(t[n + o]);
        return [r, null, n + o]
    }
}
const Rr = /(?:(Z)|([+-]\d\d)(?::?(\d\d))?)/,
    Wr = /(\d\d)(?::?(\d\d)(?::?(\d\d)(?:[.,](\d{1,30}))?)?)?/,
    Vr = RegExp(`${Wr.source}${`(?:${Rr.source}?(?:\\[(${Lr.source})\\])?)?`}`),
    Br = RegExp(`(?:T${Vr.source})?`),
    Hr = Fr("weekYear", "weekNumber", "weekDay"),
    qr = Fr("year", "ordinal"),
    Ur = RegExp(`${Wr.source} ?(?:${Rr.source}|(${Lr.source}))?`),
    zr = RegExp(`(?: ${Ur.source})?`);

function $r(e, t, n) {
    const r = e[t];
    return Un(r) ? n : er(r)
}

function Zr(e, t) {
    return [{
        hours: $r(e, t, 0),
        minutes: $r(e, t + 1, 0),
        seconds: $r(e, t + 2, 0),
        milliseconds: nr(e[t + 3])
    }, null, t + 4]
}

function Gr(e, t) {
    const n = !e[t] && !e[t + 1],
        r = pr(e[t + 1], e[t + 2]);
    return [{}, n ? null : pn.instance(r), t + 3]
}

function Yr(e, t) {
    return [{}, e[t] ? Jt.create(e[t]) : null, t + 1]
}
const Jr = RegExp(`^T?${Wr.source}$`),
    Kr = /^-?P(?:(?:(-?\d{1,20}(?:\.\d{1,20})?)Y)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20}(?:\.\d{1,20})?)W)?(?:(-?\d{1,20}(?:\.\d{1,20})?)D)?(?:T(?:(-?\d{1,20}(?:\.\d{1,20})?)H)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20})(?:[.,](-?\d{1,20}))?S)?)?)$/;

function Xr(e) {
    const [t, n, r, o, i, a, s, l, c] = e, u = "-" === t[0], d = l && "-" === l[0], p = (e, t = !1) => void 0 !== e && (t || e && u) ? -e : e;
    return [{
        years: p(tr(n)),
        months: p(tr(r)),
        weeks: p(tr(o)),
        days: p(tr(i)),
        hours: p(tr(a)),
        minutes: p(tr(s)),
        seconds: p(tr(l), "-0" === l),
        milliseconds: p(nr(c), d)
    }]
}
const Qr = {
    GMT: 0,
    EDT: -240,
    EST: -300,
    CDT: -300,
    CST: -360,
    MDT: -360,
    MST: -420,
    PDT: -420,
    PST: -480
};

function eo(e, t, n, r, o, i, a) {
    const s = {
        year: 2 === t.length ? ur(er(t)) : er(t),
        month: vr.indexOf(n) + 1,
        day: er(r),
        hour: er(o),
        minute: er(i)
    };
    return a && (s.second = er(a)), e && (s.weekday = e.length > 3 ? wr.indexOf(e) + 1 : kr.indexOf(e) + 1), s
}
const to = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|(?:([+-]\d\d)(\d\d)))$/;

function no(e) {
    const [, t, n, r, o, i, a, s, l, c, u, d] = e, p = eo(t, o, r, n, i, a, s);
    let f;
    return f = l ? Qr[l] : c ? 0 : pr(u, d), [p, new pn(f)]
}
const ro = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), (\d\d) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d\d):(\d\d):(\d\d) GMT$/,
    oo = /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), (\d\d)-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-(\d\d) (\d\d):(\d\d):(\d\d) GMT$/,
    io = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ( \d|\d\d) (\d\d):(\d\d):(\d\d) (\d{4})$/;

function ao(e) {
    const [, t, n, r, o, i, a, s] = e;
    return [eo(t, o, r, n, i, a, s), pn.utcInstance]
}

function so(e) {
    const [, t, n, r, o, i, a, s] = e;
    return [eo(t, s, n, r, o, i, a), pn.utcInstance]
}
const lo = Pr(/([+-]\d{6}|\d{4})(?:-?(\d\d)(?:-?(\d\d))?)?/, Br),
    co = Pr(/(\d{4})-?W(\d\d)(?:-?(\d))?/, Br),
    uo = Pr(/(\d{4})-?(\d{3})/, Br),
    po = Pr(Vr),
    fo = Mr((function(e, t) {
        return [{
            year: $r(e, t),
            month: $r(e, t + 1, 1),
            day: $r(e, t + 2, 1)
        }, null, t + 3]
    }), Zr, Gr, Yr),
    mo = Mr(Hr, Zr, Gr, Yr),
    ho = Mr(qr, Zr, Gr, Yr),
    yo = Mr(Zr, Gr, Yr);
const go = Mr(Zr);
const vo = Pr(/(\d{4})-(\d\d)-(\d\d)/, zr),
    bo = Pr(Ur),
    xo = Mr(Zr, Gr, Yr);
const wo = "Invalid Duration",
    ko = {
        weeks: {
            days: 7,
            hours: 168,
            minutes: 10080,
            seconds: 604800,
            milliseconds: 6048e5
        },
        days: {
            hours: 24,
            minutes: 1440,
            seconds: 86400,
            milliseconds: 864e5
        },
        hours: {
            minutes: 60,
            seconds: 3600,
            milliseconds: 36e5
        },
        minutes: {
            seconds: 60,
            milliseconds: 6e4
        },
        seconds: {
            milliseconds: 1e3
        }
    },
    So = {
        years: {
            quarters: 4,
            months: 12,
            weeks: 52,
            days: 365,
            hours: 8760,
            minutes: 525600,
            seconds: 31536e3,
            milliseconds: 31536e6
        },
        quarters: {
            months: 3,
            weeks: 13,
            days: 91,
            hours: 2184,
            minutes: 131040,
            seconds: 7862400,
            milliseconds: 78624e5
        },
        months: {
            weeks: 4,
            days: 30,
            hours: 720,
            minutes: 43200,
            seconds: 2592e3,
            milliseconds: 2592e6
        },
        ...ko
    },
    Co = 365.2425,
    _o = 30.436875,
    To = {
        years: {
            quarters: 4,
            months: 12,
            weeks: 52.1775,
            days: Co,
            hours: 8765.82,
            minutes: 525949.2,
            seconds: 525949.2 * 60,
            milliseconds: 525949.2 * 60 * 1e3
        },
        quarters: {
            months: 3,
            weeks: 13.044375,
            days: 91.310625,
            hours: 2191.455,
            minutes: 131487.3,
            seconds: 525949.2 * 60 / 4,
            milliseconds: 7889237999.999999
        },
        months: {
            weeks: 4.3481250000000005,
            days: _o,
            hours: 730.485,
            minutes: 43829.1,
            seconds: 2629746,
            milliseconds: 2629746e3
        },
        ...ko
    },
    Ao = ["years", "quarters", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds"],
    Do = Ao.slice(0).reverse();

function Oo(e, t, n = !1) {
    const r = {
        values: n ? t.values : { ...e.values,
            ...t.values || {}
        },
        loc: e.loc.clone(t.loc),
        conversionAccuracy: t.conversionAccuracy || e.conversionAccuracy,
        matrix: t.matrix || e.matrix
    };
    return new jo(r)
}

function Eo(e, t) {
    let n = t.milliseconds ? ? 0;
    for (const r of Do.slice(1)) t[r] && (n += t[r] * e[r].milliseconds);
    return n
}

function Io(e, t) {
    const n = Eo(e, t) < 0 ? -1 : 1;
    Ao.reduceRight(((r, o) => {
        if (Un(t[o])) return r;
        if (r) {
            const i = t[r] * n,
                a = e[o][r],
                s = Math.floor(i / a);
            t[o] += s * n, t[r] -= s * a * n
        }
        return o
    }), null), Ao.reduce(((n, r) => {
        if (Un(t[r])) return n;
        if (n) {
            const o = t[n] % 1;
            t[n] -= o, t[r] += o * e[n][r]
        }
        return r
    }), null)
}
class jo {
    constructor(e) {
        const t = "longterm" === e.conversionAccuracy || !1;
        let n = t ? To : So;
        e.matrix && (n = e.matrix), this.values = e.values, this.loc = e.loc || un.create(), this.conversionAccuracy = t ? "longterm" : "casual", this.invalid = e.invalid || null, this.matrix = n, this.isLuxonDuration = !0
    }
    static fromMillis(e, t) {
        return jo.fromObject({
            milliseconds: e
        }, t)
    }
    static fromObject(e, t = {}) {
        if (null == e || "object" != typeof e) throw new gt("Duration.fromObject: argument expected to be an object, got " + (null === e ? "null" : typeof e));
        return new jo({
            values: mr(e, jo.normalizeUnit),
            loc: un.fromObject(t),
            conversionAccuracy: t.conversionAccuracy,
            matrix: t.matrix
        })
    }
    static fromDurationLike(e) {
        if (zn(e)) return jo.fromMillis(e);
        if (jo.isDuration(e)) return e;
        if ("object" == typeof e) return jo.fromObject(e);
        throw new gt(`Unknown duration argument ${e} of type ${typeof e}`)
    }
    static fromISO(e, t) {
        const [n] = Nr(e, [Kr, Xr]);
        return n ? jo.fromObject(n, t) : jo.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`)
    }
    static fromISOTime(e, t) {
        const [n] = Nr(e, [Jr, go]);
        return n ? jo.fromObject(n, t) : jo.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`)
    }
    static invalid(e, t = null) {
        if (!e) throw new gt("need to specify a reason the Duration is invalid");
        const n = e instanceof On ? e : new On(e, t);
        if (Dn.throwOnInvalid) throw new mt(n);
        return new jo({
            invalid: n
        })
    }
    static normalizeUnit(e) {
        const t = {
            year: "years",
            years: "years",
            quarter: "quarters",
            quarters: "quarters",
            month: "months",
            months: "months",
            week: "weeks",
            weeks: "weeks",
            day: "days",
            days: "days",
            hour: "hours",
            hours: "hours",
            minute: "minutes",
            minutes: "minutes",
            second: "seconds",
            seconds: "seconds",
            millisecond: "milliseconds",
            milliseconds: "milliseconds"
        }[e ? e.toLowerCase() : e];
        if (!t) throw new yt(e);
        return t
    }
    static isDuration(e) {
        return e && e.isLuxonDuration || !1
    }
    get locale() {
        return this.isValid ? this.loc.locale : null
    }
    get numberingSystem() {
        return this.isValid ? this.loc.numberingSystem : null
    }
    toFormat(e, t = {}) {
        const n = { ...t,
            floor: !1 !== t.round && !1 !== t.floor
        };
        return this.isValid ? jr.create(this.loc, n).formatDurationFromString(this, e) : wo
    }
    toHuman(e = {}) {
        if (!this.isValid) return wo;
        const t = Ao.map((t => {
            const n = this.values[t];
            return Un(n) ? null : this.loc.numberFormatter({
                style: "unit",
                unitDisplay: "long",
                ...e,
                unit: t.slice(0, -1)
            }).format(n)
        })).filter((e => e));
        return this.loc.listFormatter({
            type: "conjunction",
            style: e.listStyle || "narrow",
            ...e
        }).format(t)
    }
    toObject() {
        return this.isValid ? { ...this.values
        } : {}
    }
    toISO() {
        if (!this.isValid) return null;
        let e = "P";
        return 0 !== this.years && (e += this.years + "Y"), 0 === this.months && 0 === this.quarters || (e += this.months + 3 * this.quarters + "M"), 0 !== this.weeks && (e += this.weeks + "W"), 0 !== this.days && (e += this.days + "D"), 0 === this.hours && 0 === this.minutes && 0 === this.seconds && 0 === this.milliseconds || (e += "T"), 0 !== this.hours && (e += this.hours + "H"), 0 !== this.minutes && (e += this.minutes + "M"), 0 === this.seconds && 0 === this.milliseconds || (e += rr(this.seconds + this.milliseconds / 1e3, 3) + "S"), "P" === e && (e += "T0S"), e
    }
    toISOTime(e = {}) {
        if (!this.isValid) return null;
        const t = this.toMillis();
        if (t < 0 || t >= 864e5) return null;
        e = {
            suppressMilliseconds: !1,
            suppressSeconds: !1,
            includePrefix: !1,
            format: "extended",
            ...e,
            includeOffset: !1
        };
        return Ci.fromMillis(t, {
            zone: "UTC"
        }).toISOTime(e)
    }
    toJSON() {
        return this.toISO()
    }
    toString() {
        return this.toISO()
    }[Symbol.for("nodejs.util.inspect.custom")]() {
        return this.isValid ? `Duration { values: ${JSON.stringify(this.values)} }` : `Duration { Invalid, reason: ${this.invalidReason} }`
    }
    toMillis() {
        return this.isValid ? Eo(this.matrix, this.values) : NaN
    }
    valueOf() {
        return this.toMillis()
    }
    plus(e) {
        if (!this.isValid) return this;
        const t = jo.fromDurationLike(e),
            n = {};
        for (const r of Ao)(Jn(t.values, r) || Jn(this.values, r)) && (n[r] = t.get(r) + this.get(r));
        return Oo(this, {
            values: n
        }, !0)
    }
    minus(e) {
        if (!this.isValid) return this;
        const t = jo.fromDurationLike(e);
        return this.plus(t.negate())
    }
    mapUnits(e) {
        if (!this.isValid) return this;
        const t = {};
        for (const n of Object.keys(this.values)) t[n] = fr(e(this.values[n], n));
        return Oo(this, {
            values: t
        }, !0)
    }
    get(e) {
        return this[jo.normalizeUnit(e)]
    }
    set(e) {
        if (!this.isValid) return this;
        return Oo(this, {
            values: { ...this.values,
                ...mr(e, jo.normalizeUnit)
            }
        })
    }
    reconfigure({
        locale: e,
        numberingSystem: t,
        conversionAccuracy: n,
        matrix: r
    } = {}) {
        return Oo(this, {
            loc: this.loc.clone({
                locale: e,
                numberingSystem: t
            }),
            matrix: r,
            conversionAccuracy: n
        })
    }
    as(e) {
        return this.isValid ? this.shiftTo(e).get(e) : NaN
    }
    normalize() {
        if (!this.isValid) return this;
        const e = this.toObject();
        return Io(this.matrix, e), Oo(this, {
            values: e
        }, !0)
    }
    rescale() {
        if (!this.isValid) return this;
        return Oo(this, {
            values: function(e) {
                const t = {};
                for (const [n, r] of Object.entries(e)) 0 !== r && (t[n] = r);
                return t
            }(this.normalize().shiftToAll().toObject())
        }, !0)
    }
    shiftTo(...e) {
        if (!this.isValid) return this;
        if (0 === e.length) return this;
        e = e.map((e => jo.normalizeUnit(e)));
        const t = {},
            n = {},
            r = this.toObject();
        let o;
        for (const i of Ao)
            if (e.indexOf(i) >= 0) {
                o = i;
                let e = 0;
                for (const t in n) e += this.matrix[t][i] * n[t], n[t] = 0;
                zn(r[i]) && (e += r[i]);
                const a = Math.trunc(e);
                t[i] = a, n[i] = (1e3 * e - 1e3 * a) / 1e3
            } else zn(r[i]) && (n[i] = r[i]);
        for (const i in n) 0 !== n[i] && (t[o] += i === o ? n[i] : n[i] / this.matrix[o][i]);
        return Io(this.matrix, t), Oo(this, {
            values: t
        }, !0)
    }
    shiftToAll() {
        return this.isValid ? this.shiftTo("years", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds") : this
    }
    negate() {
        if (!this.isValid) return this;
        const e = {};
        for (const t of Object.keys(this.values)) e[t] = 0 === this.values[t] ? 0 : -this.values[t];
        return Oo(this, {
            values: e
        }, !0)
    }
    get years() {
        return this.isValid ? this.values.years || 0 : NaN
    }
    get quarters() {
        return this.isValid ? this.values.quarters || 0 : NaN
    }
    get months() {
        return this.isValid ? this.values.months || 0 : NaN
    }
    get weeks() {
        return this.isValid ? this.values.weeks || 0 : NaN
    }
    get days() {
        return this.isValid ? this.values.days || 0 : NaN
    }
    get hours() {
        return this.isValid ? this.values.hours || 0 : NaN
    }
    get minutes() {
        return this.isValid ? this.values.minutes || 0 : NaN
    }
    get seconds() {
        return this.isValid ? this.values.seconds || 0 : NaN
    }
    get milliseconds() {
        return this.isValid ? this.values.milliseconds || 0 : NaN
    }
    get isValid() {
        return null === this.invalid
    }
    get invalidReason() {
        return this.invalid ? this.invalid.reason : null
    }
    get invalidExplanation() {
        return this.invalid ? this.invalid.explanation : null
    }
    equals(e) {
        if (!this.isValid || !e.isValid) return !1;
        if (!this.loc.equals(e.loc)) return !1;
        for (const r of Ao)
            if (t = this.values[r], n = e.values[r], !(void 0 === t || 0 === t ? void 0 === n || 0 === n : t === n)) return !1;
        var t, n;
        return !0
    }
}
const Lo = "Invalid Interval";
class Po {
    constructor(e) {
        this.s = e.start, this.e = e.end, this.invalid = e.invalid || null, this.isLuxonInterval = !0
    }
    static invalid(e, t = null) {
        if (!e) throw new gt("need to specify a reason the Interval is invalid");
        const n = e instanceof On ? e : new On(e, t);
        if (Dn.throwOnInvalid) throw new ft(n);
        return new Po({
            invalid: n
        })
    }
    static fromDateTimes(e, t) {
        const n = _i(e),
            r = _i(t),
            o = function(e, t) {
                return e && e.isValid ? t && t.isValid ? t < e ? Po.invalid("end before start", `The end of an interval must be after its start, but you had start=${e.toISO()} and end=${t.toISO()}`) : null : Po.invalid("missing or invalid end") : Po.invalid("missing or invalid start")
            }(n, r);
        return null == o ? new Po({
            start: n,
            end: r
        }) : o
    }
    static after(e, t) {
        const n = jo.fromDurationLike(t),
            r = _i(e);
        return Po.fromDateTimes(r, r.plus(n))
    }
    static before(e, t) {
        const n = jo.fromDurationLike(t),
            r = _i(e);
        return Po.fromDateTimes(r.minus(n), r)
    }
    static fromISO(e, t) {
        const [n, r] = (e || "").split("/", 2);
        if (n && r) {
            let e, i, a, s;
            try {
                e = Ci.fromISO(n, t), i = e.isValid
            } catch (o) {
                i = !1
            }
            try {
                a = Ci.fromISO(r, t), s = a.isValid
            } catch (o) {
                s = !1
            }
            if (i && s) return Po.fromDateTimes(e, a);
            if (i) {
                const n = jo.fromISO(r, t);
                if (n.isValid) return Po.after(e, n)
            } else if (s) {
                const e = jo.fromISO(n, t);
                if (e.isValid) return Po.before(a, e)
            }
        }
        return Po.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`)
    }
    static isInterval(e) {
        return e && e.isLuxonInterval || !1
    }
    get start() {
        return this.isValid ? this.s : null
    }
    get end() {
        return this.isValid ? this.e : null
    }
    get isValid() {
        return null === this.invalidReason
    }
    get invalidReason() {
        return this.invalid ? this.invalid.reason : null
    }
    get invalidExplanation() {
        return this.invalid ? this.invalid.explanation : null
    }
    length(e = "milliseconds") {
        return this.isValid ? this.toDuration(e).get(e) : NaN
    }
    count(e = "milliseconds", t) {
        if (!this.isValid) return NaN;
        const n = this.start.startOf(e, t);
        let r;
        return r = (null == t ? void 0 : t.useLocaleWeeks) ? this.end.reconfigure({
            locale: n.locale
        }) : this.end, r = r.startOf(e, t), Math.floor(r.diff(n, e).get(e)) + (r.valueOf() !== this.end.valueOf())
    }
    hasSame(e) {
        return !!this.isValid && (this.isEmpty() || this.e.minus(1).hasSame(this.s, e))
    }
    isEmpty() {
        return this.s.valueOf() === this.e.valueOf()
    }
    isAfter(e) {
        return !!this.isValid && this.s > e
    }
    isBefore(e) {
        return !!this.isValid && this.e <= e
    }
    contains(e) {
        return !!this.isValid && (this.s <= e && this.e > e)
    }
    set({
        start: e,
        end: t
    } = {}) {
        return this.isValid ? Po.fromDateTimes(e || this.s, t || this.e) : this
    }
    splitAt(...e) {
        if (!this.isValid) return [];
        const t = e.map(_i).filter((e => this.contains(e))).sort(((e, t) => e.toMillis() - t.toMillis())),
            n = [];
        let {
            s: r
        } = this, o = 0;
        for (; r < this.e;) {
            const e = t[o] || this.e,
                i = +e > +this.e ? this.e : e;
            n.push(Po.fromDateTimes(r, i)), r = i, o += 1
        }
        return n
    }
    splitBy(e) {
        const t = jo.fromDurationLike(e);
        if (!this.isValid || !t.isValid || 0 === t.as("milliseconds")) return [];
        let n, {
                s: r
            } = this,
            o = 1;
        const i = [];
        for (; r < this.e;) {
            const e = this.start.plus(t.mapUnits((e => e * o)));
            n = +e > +this.e ? this.e : e, i.push(Po.fromDateTimes(r, n)), r = n, o += 1
        }
        return i
    }
    divideEqually(e) {
        return this.isValid ? this.splitBy(this.length() / e).slice(0, e) : []
    }
    overlaps(e) {
        return this.e > e.s && this.s < e.e
    }
    abutsStart(e) {
        return !!this.isValid && +this.e == +e.s
    }
    abutsEnd(e) {
        return !!this.isValid && +e.e == +this.s
    }
    engulfs(e) {
        return !!this.isValid && (this.s <= e.s && this.e >= e.e)
    }
    equals(e) {
        return !(!this.isValid || !e.isValid) && (this.s.equals(e.s) && this.e.equals(e.e))
    }
    intersection(e) {
        if (!this.isValid) return this;
        const t = this.s > e.s ? this.s : e.s,
            n = this.e < e.e ? this.e : e.e;
        return t >= n ? null : Po.fromDateTimes(t, n)
    }
    union(e) {
        if (!this.isValid) return this;
        const t = this.s < e.s ? this.s : e.s,
            n = this.e > e.e ? this.e : e.e;
        return Po.fromDateTimes(t, n)
    }
    static merge(e) {
        const [t, n] = e.sort(((e, t) => e.s - t.s)).reduce((([e, t], n) => t ? t.overlaps(n) || t.abutsStart(n) ? [e, t.union(n)] : [e.concat([t]), n] : [e, n]), [
            [], null
        ]);
        return n && t.push(n), t
    }
    static xor(e) {
        let t = null,
            n = 0;
        const r = [],
            o = e.map((e => [{
                time: e.s,
                type: "s"
            }, {
                time: e.e,
                type: "e"
            }])),
            i = Array.prototype.concat(...o).sort(((e, t) => e.time - t.time));
        for (const a of i) n += "s" === a.type ? 1 : -1, 1 === n ? t = a.time : (t && +t != +a.time && r.push(Po.fromDateTimes(t, a.time)), t = null);
        return Po.merge(r)
    }
    difference(...e) {
        return Po.xor([this].concat(e)).map((e => this.intersection(e))).filter((e => e && !e.isEmpty()))
    }
    toString() {
        return this.isValid ? `[${this.s.toISO()} – ${this.e.toISO()})` : Lo
    }[Symbol.for("nodejs.util.inspect.custom")]() {
        return this.isValid ? `Interval { start: ${this.s.toISO()}, end: ${this.e.toISO()} }` : `Interval { Invalid, reason: ${this.invalidReason} }`
    }
    toLocaleString(e = kt, t = {}) {
        return this.isValid ? jr.create(this.s.loc.clone(t), e).formatInterval(this) : Lo
    }
    toISO(e) {
        return this.isValid ? `${this.s.toISO(e)}/${this.e.toISO(e)}` : Lo
    }
    toISODate() {
        return this.isValid ? `${this.s.toISODate()}/${this.e.toISODate()}` : Lo
    }
    toISOTime(e) {
        return this.isValid ? `${this.s.toISOTime(e)}/${this.e.toISOTime(e)}` : Lo
    }
    toFormat(e, {
        separator: t = " – "
    } = {}) {
        return this.isValid ? `${this.s.toFormat(e)}${t}${this.e.toFormat(e)}` : Lo
    }
    toDuration(e, t) {
        return this.isValid ? this.e.diff(this.s, e, t) : jo.invalid(this.invalidReason)
    }
    mapEndpoints(e) {
        return Po.fromDateTimes(e(this.s), e(this.e))
    }
}
class Mo {
    static hasDST(e = Dn.defaultZone) {
        const t = Ci.now().setZone(e).set({
            month: 12
        });
        return !e.isUniversal && t.offset !== t.set({
            month: 6
        }).offset
    }
    static isValidIANAZone(e) {
        return Jt.isValidZone(e)
    }
    static normalizeZone(e) {
        return mn(e, Dn.defaultZone)
    }
    static getStartOfWeek({
        locale: e = null,
        locObj: t = null
    } = {}) {
        return (t || un.create(e)).getStartOfWeek()
    }
    static getMinimumDaysInFirstWeek({
        locale: e = null,
        locObj: t = null
    } = {}) {
        return (t || un.create(e)).getMinDaysInFirstWeek()
    }
    static getWeekendWeekdays({
        locale: e = null,
        locObj: t = null
    } = {}) {
        return (t || un.create(e)).getWeekendDays().slice()
    }
    static months(e = "long", {
        locale: t = null,
        numberingSystem: n = null,
        locObj: r = null,
        outputCalendar: o = "gregory"
    } = {}) {
        return (r || un.create(t, n, o)).months(e)
    }
    static monthsFormat(e = "long", {
        locale: t = null,
        numberingSystem: n = null,
        locObj: r = null,
        outputCalendar: o = "gregory"
    } = {}) {
        return (r || un.create(t, n, o)).months(e, !0)
    }
    static weekdays(e = "long", {
        locale: t = null,
        numberingSystem: n = null,
        locObj: r = null
    } = {}) {
        return (r || un.create(t, n, null)).weekdays(e)
    }
    static weekdaysFormat(e = "long", {
        locale: t = null,
        numberingSystem: n = null,
        locObj: r = null
    } = {}) {
        return (r || un.create(t, n, null)).weekdays(e, !0)
    }
    static meridiems({
        locale: e = null
    } = {}) {
        return un.create(e).meridiems()
    }
    static eras(e = "short", {
        locale: t = null
    } = {}) {
        return un.create(t, null, "gregory").eras(e)
    }
    static features() {
        return {
            relative: Zn(),
            localeWeek: Gn()
        }
    }
}

function No(e, t) {
    const n = e => e.toUTC(0, {
            keepLocalTime: !0
        }).startOf("day").valueOf(),
        r = n(t) - n(e);
    return Math.floor(jo.fromMillis(r).as("days"))
}

function Fo(e, t, n, r) {
    let [o, i, a, s] = function(e, t, n) {
        const r = [
                ["years", (e, t) => t.year - e.year],
                ["quarters", (e, t) => t.quarter - e.quarter + 4 * (t.year - e.year)],
                ["months", (e, t) => t.month - e.month + 12 * (t.year - e.year)],
                ["weeks", (e, t) => {
                    const n = No(e, t);
                    return (n - n % 7) / 7
                }],
                ["days", No]
            ],
            o = {},
            i = e;
        let a, s;
        for (const [l, c] of r) n.indexOf(l) >= 0 && (a = l, o[l] = c(e, t), s = i.plus(o), s > t ? (o[l]--, (e = i.plus(o)) > t && (s = e, o[l]--, e = i.plus(o))) : e = s);
        return [e, o, s, a]
    }(e, t, n);
    const l = t - o,
        c = n.filter((e => ["hours", "minutes", "seconds", "milliseconds"].indexOf(e) >= 0));
    0 === c.length && (a < t && (a = o.plus({
        [s]: 1
    })), a !== o && (i[s] = (i[s] || 0) + l / (a - o)));
    const u = jo.fromObject(i, r);
    return c.length > 0 ? jo.fromMillis(l, r).shiftTo(...c).plus(u) : u
}

function Ro(e, t = e => e) {
    return {
        regex: e,
        deser: ([e]) => t(function(e) {
            let t = parseInt(e, 10);
            if (isNaN(t)) {
                t = "";
                for (let n = 0; n < e.length; n++) {
                    const r = e.charCodeAt(n);
                    if (-1 !== e[n].search(hn.hanidec)) t += gn.indexOf(e[n]);
                    else
                        for (const e in yn) {
                            const [n, o] = yn[e];
                            r >= n && r <= o && (t += r - n)
                        }
                }
                return parseInt(t, 10)
            }
            return t
        }(e))
    }
}
const Wo = `[ ${String.fromCharCode(160)}]`,
    Vo = new RegExp(Wo, "g");

function Bo(e) {
    return e.replace(/\./g, "\\.?").replace(Vo, Wo)
}

function Ho(e) {
    return e.replace(/\./g, "").replace(Vo, " ").toLowerCase()
}

function qo(e, t) {
    return null === e ? null : {
        regex: RegExp(e.map(Bo).join("|")),
        deser: ([n]) => e.findIndex((e => Ho(n) === Ho(e))) + t
    }
}

function Uo(e, t) {
    return {
        regex: e,
        deser: ([, e, t]) => pr(e, t),
        groups: t
    }
}

function zo(e) {
    return {
        regex: e,
        deser: ([e]) => e
    }
}
const $o = {
    year: {
        "2-digit": "yy",
        numeric: "yyyyy"
    },
    month: {
        numeric: "M",
        "2-digit": "MM",
        short: "MMM",
        long: "MMMM"
    },
    day: {
        numeric: "d",
        "2-digit": "dd"
    },
    weekday: {
        short: "EEE",
        long: "EEEE"
    },
    dayperiod: "a",
    dayPeriod: "a",
    hour12: {
        numeric: "h",
        "2-digit": "hh"
    },
    hour24: {
        numeric: "H",
        "2-digit": "HH"
    },
    minute: {
        numeric: "m",
        "2-digit": "mm"
    },
    second: {
        numeric: "s",
        "2-digit": "ss"
    },
    timeZoneName: {
        long: "ZZZZZ",
        short: "ZZZ"
    }
};
let Zo = null;

function Go(e, t) {
    return Array.prototype.concat(...e.map((e => function(e, t) {
        if (e.literal) return e;
        const n = Ko(jr.macroTokenToFormatOpts(e.val), t);
        return null == n || n.includes(void 0) ? e : n
    }(e, t))))
}
class Yo {
    constructor(e, t) {
        if (this.locale = e, this.format = t, this.tokens = Go(jr.parseFormat(t), e), this.units = this.tokens.map((t => function(e, t) {
                const n = bn(t),
                    r = bn(t, "{2}"),
                    o = bn(t, "{3}"),
                    i = bn(t, "{4}"),
                    a = bn(t, "{6}"),
                    s = bn(t, "{1,2}"),
                    l = bn(t, "{1,3}"),
                    c = bn(t, "{1,6}"),
                    u = bn(t, "{1,9}"),
                    d = bn(t, "{2,4}"),
                    p = bn(t, "{4,6}"),
                    f = e => {
                        return {
                            regex: RegExp((t = e.val, t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&"))),
                            deser: ([e]) => e,
                            literal: !0
                        };
                        var t
                    },
                    m = (m => {
                        if (e.literal) return f(m);
                        switch (m.val) {
                            case "G":
                                return qo(t.eras("short"), 0);
                            case "GG":
                                return qo(t.eras("long"), 0);
                            case "y":
                                return Ro(c);
                            case "yy":
                            case "kk":
                                return Ro(d, ur);
                            case "yyyy":
                            case "kkkk":
                                return Ro(i);
                            case "yyyyy":
                                return Ro(p);
                            case "yyyyyy":
                                return Ro(a);
                            case "M":
                            case "L":
                            case "d":
                            case "H":
                            case "h":
                            case "m":
                            case "q":
                            case "s":
                            case "W":
                                return Ro(s);
                            case "MM":
                            case "LL":
                            case "dd":
                            case "HH":
                            case "hh":
                            case "mm":
                            case "qq":
                            case "ss":
                            case "WW":
                                return Ro(r);
                            case "MMM":
                                return qo(t.months("short", !0), 1);
                            case "MMMM":
                                return qo(t.months("long", !0), 1);
                            case "LLL":
                                return qo(t.months("short", !1), 1);
                            case "LLLL":
                                return qo(t.months("long", !1), 1);
                            case "o":
                            case "S":
                                return Ro(l);
                            case "ooo":
                            case "SSS":
                                return Ro(o);
                            case "u":
                                return zo(u);
                            case "uu":
                                return zo(s);
                            case "uuu":
                            case "E":
                            case "c":
                                return Ro(n);
                            case "a":
                                return qo(t.meridiems(), 0);
                            case "EEE":
                                return qo(t.weekdays("short", !1), 1);
                            case "EEEE":
                                return qo(t.weekdays("long", !1), 1);
                            case "ccc":
                                return qo(t.weekdays("short", !0), 1);
                            case "cccc":
                                return qo(t.weekdays("long", !0), 1);
                            case "Z":
                            case "ZZ":
                                return Uo(new RegExp(`([+-]${s.source})(?::(${r.source}))?`), 2);
                            case "ZZZ":
                                return Uo(new RegExp(`([+-]${s.source})(${r.source})?`), 2);
                            case "z":
                                return zo(/[a-z_+-/]{1,256}?/i);
                            case " ":
                                return zo(/[^\S\n\r]/);
                            default:
                                return f(m)
                        }
                    })(e) || {
                        invalidReason: "missing Intl.DateTimeFormat.formatToParts support"
                    };
                return m.token = e, m
            }(t, e))), this.disqualifyingUnit = this.units.find((e => e.invalidReason)), !this.disqualifyingUnit) {
            const [e, t] = [`^${(n=this.units).map((e=>e.regex)).reduce(((e,t)=>`${e}(${t.source})`),"")}$`, n];
            this.regex = RegExp(e, "i"), this.handlers = t
        }
        var n
    }
    explainFromTokens(e) {
        if (this.isValid) {
            const [t, n] = function(e, t, n) {
                const r = e.match(t);
                if (r) {
                    const e = {};
                    let t = 1;
                    for (const o in n)
                        if (Jn(n, o)) {
                            const i = n[o],
                                a = i.groups ? i.groups + 1 : 1;
                            !i.literal && i.token && (e[i.token.val[0]] = i.deser(r.slice(t, t + a))), t += a
                        }
                    return [r, e]
                }
                return [r, {}]
            }(e, this.regex, this.handlers), [r, o, i] = n ? function(e) {
                let t, n = null;
                return Un(e.z) || (n = Jt.create(e.z)), Un(e.Z) || (n || (n = new pn(e.Z)), t = e.Z), Un(e.q) || (e.M = 3 * (e.q - 1) + 1), Un(e.h) || (e.h < 12 && 1 === e.a ? e.h += 12 : 12 === e.h && 0 === e.a && (e.h = 0)), 0 === e.G && e.y && (e.y = -e.y), Un(e.u) || (e.S = nr(e.u)), [Object.keys(e).reduce(((t, n) => {
                    const r = (e => {
                        switch (e) {
                            case "S":
                                return "millisecond";
                            case "s":
                                return "second";
                            case "m":
                                return "minute";
                            case "h":
                            case "H":
                                return "hour";
                            case "d":
                                return "day";
                            case "o":
                                return "ordinal";
                            case "L":
                            case "M":
                                return "month";
                            case "y":
                                return "year";
                            case "E":
                            case "c":
                                return "weekday";
                            case "W":
                                return "weekNumber";
                            case "k":
                                return "weekYear";
                            case "q":
                                return "quarter";
                            default:
                                return null
                        }
                    })(n);
                    return r && (t[r] = e[n]), t
                }), {}), n, t]
            }(n) : [null, null, void 0];
            if (Jn(n, "a") && Jn(n, "H")) throw new ht("Can't include meridiem when specifying 24-hour format");
            return {
                input: e,
                tokens: this.tokens,
                regex: this.regex,
                rawMatches: t,
                matches: n,
                result: r,
                zone: o,
                specificOffset: i
            }
        }
        return {
            input: e,
            tokens: this.tokens,
            invalidReason: this.invalidReason
        }
    }
    get isValid() {
        return !this.disqualifyingUnit
    }
    get invalidReason() {
        return this.disqualifyingUnit ? this.disqualifyingUnit.invalidReason : null
    }
}

function Jo(e, t, n) {
    return new Yo(e, n).explainFromTokens(t)
}

function Ko(e, t) {
    if (!e) return null;
    const n = jr.create(t, e).dtFormatter((Zo || (Zo = Ci.fromMillis(1555555555555)), Zo)),
        r = n.formatToParts(),
        o = n.resolvedOptions();
    return r.map((t => function(e, t, n) {
        const {
            type: r,
            value: o
        } = e;
        if ("literal" === r) {
            const e = /^\s+$/.test(o);
            return {
                literal: !e,
                val: e ? " " : o
            }
        }
        const i = t[r];
        let a = r;
        "hour" === r && (a = null != t.hour12 ? t.hour12 ? "hour12" : "hour24" : null != t.hourCycle ? "h11" === t.hourCycle || "h12" === t.hourCycle ? "hour12" : "hour24" : n.hour12 ? "hour12" : "hour24");
        let s = $o[a];
        if ("object" == typeof s && (s = s[i]), s) return {
            literal: !1,
            val: s
        }
    }(t, e, o)))
}
const Xo = "Invalid DateTime",
    Qo = 864e13;

function ei(e) {
    return new On("unsupported zone", `the zone "${e.name}" is not supported`)
}

function ti(e) {
    return null === e.weekData && (e.weekData = Fn(e.c)), e.weekData
}

function ni(e) {
    return null === e.localWeekData && (e.localWeekData = Fn(e.c, e.loc.getMinDaysInFirstWeek(), e.loc.getStartOfWeek())), e.localWeekData
}

function ri(e, t) {
    const n = {
        ts: e.ts,
        zone: e.zone,
        c: e.c,
        o: e.o,
        loc: e.loc,
        invalid: e.invalid
    };
    return new Ci({ ...n,
        ...t,
        old: n
    })
}

function oi(e, t, n) {
    let r = e - 60 * t * 1e3;
    const o = n.offset(r);
    if (t === o) return [r, t];
    r -= 60 * (o - t) * 1e3;
    const i = n.offset(r);
    return o === i ? [r, o] : [e - 60 * Math.min(o, i) * 1e3, Math.max(o, i)]
}

function ii(e, t) {
    const n = new Date(e += 60 * t * 1e3);
    return {
        year: n.getUTCFullYear(),
        month: n.getUTCMonth() + 1,
        day: n.getUTCDate(),
        hour: n.getUTCHours(),
        minute: n.getUTCMinutes(),
        second: n.getUTCSeconds(),
        millisecond: n.getUTCMilliseconds()
    }
}

function ai(e, t, n) {
    return oi(sr(e), t, n)
}

function si(e, t) {
    const n = e.o,
        r = e.c.year + Math.trunc(t.years),
        o = e.c.month + Math.trunc(t.months) + 3 * Math.trunc(t.quarters),
        i = { ...e.c,
            year: r,
            month: o,
            day: Math.min(e.c.day, ar(r, o)) + Math.trunc(t.days) + 7 * Math.trunc(t.weeks)
        },
        a = jo.fromObject({
            years: t.years - Math.trunc(t.years),
            quarters: t.quarters - Math.trunc(t.quarters),
            months: t.months - Math.trunc(t.months),
            weeks: t.weeks - Math.trunc(t.weeks),
            days: t.days - Math.trunc(t.days),
            hours: t.hours,
            minutes: t.minutes,
            seconds: t.seconds,
            milliseconds: t.milliseconds
        }).as("milliseconds"),
        s = sr(i);
    let [l, c] = oi(s, n, e.zone);
    return 0 !== a && (l += a, c = e.zone.offset(l)), {
        ts: l,
        o: c
    }
}

function li(e, t, n, r, o, i) {
    const {
        setZone: a,
        zone: s
    } = n;
    if (e && 0 !== Object.keys(e).length || t) {
        const r = t || s,
            o = Ci.fromObject(e, { ...n,
                zone: r,
                specificOffset: i
            });
        return a ? o : o.setZone(s)
    }
    return Ci.invalid(new On("unparsable", `the input "${o}" can't be parsed as ${r}`))
}

function ci(e, t, n = !0) {
    return e.isValid ? jr.create(un.create("en-US"), {
        allowZ: n,
        forceSimple: !0
    }).formatDateTimeFromString(e, t) : null
}

function ui(e, t) {
    const n = e.c.year > 9999 || e.c.year < 0;
    let r = "";
    return n && e.c.year >= 0 && (r += "+"), r += Qn(e.c.year, n ? 6 : 4), t ? (r += "-", r += Qn(e.c.month), r += "-", r += Qn(e.c.day)) : (r += Qn(e.c.month), r += Qn(e.c.day)), r
}

function di(e, t, n, r, o, i) {
    let a = Qn(e.c.hour);
    return t ? (a += ":", a += Qn(e.c.minute), 0 === e.c.millisecond && 0 === e.c.second && n || (a += ":")) : a += Qn(e.c.minute), 0 === e.c.millisecond && 0 === e.c.second && n || (a += Qn(e.c.second), 0 === e.c.millisecond && r || (a += ".", a += Qn(e.c.millisecond, 3))), o && (e.isOffsetFixed && 0 === e.offset && !i ? a += "Z" : e.o < 0 ? (a += "-", a += Qn(Math.trunc(-e.o / 60)), a += ":", a += Qn(Math.trunc(-e.o % 60))) : (a += "+", a += Qn(Math.trunc(e.o / 60)), a += ":", a += Qn(Math.trunc(e.o % 60)))), i && (a += "[" + e.zone.ianaName + "]"), a
}
const pi = {
        month: 1,
        day: 1,
        hour: 0,
        minute: 0,
        second: 0,
        millisecond: 0
    },
    fi = {
        weekNumber: 1,
        weekday: 1,
        hour: 0,
        minute: 0,
        second: 0,
        millisecond: 0
    },
    mi = {
        ordinal: 1,
        hour: 0,
        minute: 0,
        second: 0,
        millisecond: 0
    },
    hi = ["year", "month", "day", "hour", "minute", "second", "millisecond"],
    yi = ["weekYear", "weekNumber", "weekday", "hour", "minute", "second", "millisecond"],
    gi = ["year", "ordinal", "hour", "minute", "second", "millisecond"];

function vi(e) {
    switch (e.toLowerCase()) {
        case "localweekday":
        case "localweekdays":
            return "localWeekday";
        case "localweeknumber":
        case "localweeknumbers":
            return "localWeekNumber";
        case "localweekyear":
        case "localweekyears":
            return "localWeekYear";
        default:
            return function(e) {
                const t = {
                    year: "year",
                    years: "year",
                    month: "month",
                    months: "month",
                    day: "day",
                    days: "day",
                    hour: "hour",
                    hours: "hour",
                    minute: "minute",
                    minutes: "minute",
                    quarter: "quarter",
                    quarters: "quarter",
                    second: "second",
                    seconds: "second",
                    millisecond: "millisecond",
                    milliseconds: "millisecond",
                    weekday: "weekday",
                    weekdays: "weekday",
                    weeknumber: "weekNumber",
                    weeksnumber: "weekNumber",
                    weeknumbers: "weekNumber",
                    weekyear: "weekYear",
                    weekyears: "weekYear",
                    ordinal: "ordinal"
                }[e.toLowerCase()];
                if (!t) throw new yt(e);
                return t
            }(e)
    }
}

function bi(e, t) {
    const n = mn(t.zone, Dn.defaultZone);
    if (!n.isValid) return Ci.invalid(ei(n));
    const r = un.fromObject(t);
    let o, i;
    if (Un(e.year)) o = Dn.now();
    else {
        for (const n of hi) Un(e[n]) && (e[n] = pi[n]);
        const t = Hn(e) || qn(e);
        if (t) return Ci.invalid(t);
        const r = function(e) {
            return Si[e] || (void 0 === ki && (ki = Dn.now()), Si[e] = e.offset(ki)), Si[e]
        }(n);
        [o, i] = ai(e, r, n)
    }
    return new Ci({
        ts: o,
        zone: n,
        loc: r,
        o: i
    })
}

function xi(e, t, n) {
    const r = !!Un(n.round) || n.round,
        o = (e, o) => {
            e = rr(e, r || n.calendary ? 0 : 2, !0);
            return t.loc.clone(n).relFormatter(n).format(e, o)
        },
        i = r => n.calendary ? t.hasSame(e, r) ? 0 : t.startOf(r).diff(e.startOf(r), r).get(r) : t.diff(e, r).get(r);
    if (n.unit) return o(i(n.unit), n.unit);
    for (const a of n.units) {
        const e = i(a);
        if (Math.abs(e) >= 1) return o(e, a)
    }
    return o(e > t ? -0 : 0, n.units[n.units.length - 1])
}

function wi(e) {
    let t, n = {};
    return e.length > 0 && "object" == typeof e[e.length - 1] ? (n = e[e.length - 1], t = Array.from(e).slice(0, e.length - 1)) : t = Array.from(e), [n, t]
}
let ki, Si = {};
class Ci {
    constructor(e) {
        const t = e.zone || Dn.defaultZone;
        let n = e.invalid || (Number.isNaN(e.ts) ? new On("invalid input") : null) || (t.isValid ? null : ei(t));
        this.ts = Un(e.ts) ? Dn.now() : e.ts;
        let r = null,
            o = null;
        if (!n) {
            if (e.old && e.old.ts === this.ts && e.old.zone.equals(t))[r, o] = [e.old.c, e.old.o];
            else {
                const i = zn(e.o) && !e.old ? e.o : t.offset(this.ts);
                r = ii(this.ts, i), n = Number.isNaN(r.year) ? new On("invalid input") : null, r = n ? null : r, o = n ? null : i
            }
        }
        this._zone = t, this.loc = e.loc || un.create(), this.invalid = n, this.weekData = null, this.localWeekData = null, this.c = r, this.o = o, this.isLuxonDateTime = !0
    }
    static now() {
        return new Ci({})
    }
    static local() {
        const [e, t] = wi(arguments), [n, r, o, i, a, s, l] = t;
        return bi({
            year: n,
            month: r,
            day: o,
            hour: i,
            minute: a,
            second: s,
            millisecond: l
        }, e)
    }
    static utc() {
        const [e, t] = wi(arguments), [n, r, o, i, a, s, l] = t;
        return e.zone = pn.utcInstance, bi({
            year: n,
            month: r,
            day: o,
            hour: i,
            minute: a,
            second: s,
            millisecond: l
        }, e)
    }
    static fromJSDate(e, t = {}) {
        const n = (r = e, "[object Date]" === Object.prototype.toString.call(r) ? e.valueOf() : NaN);
        var r;
        if (Number.isNaN(n)) return Ci.invalid("invalid input");
        const o = mn(t.zone, Dn.defaultZone);
        return o.isValid ? new Ci({
            ts: n,
            zone: o,
            loc: un.fromObject(t)
        }) : Ci.invalid(ei(o))
    }
    static fromMillis(e, t = {}) {
        if (zn(e)) return e < -Qo || e > Qo ? Ci.invalid("Timestamp out of range") : new Ci({
            ts: e,
            zone: mn(t.zone, Dn.defaultZone),
            loc: un.fromObject(t)
        });
        throw new gt(`fromMillis requires a numerical input, but received a ${typeof e} with value ${e}`)
    }
    static fromSeconds(e, t = {}) {
        if (zn(e)) return new Ci({
            ts: 1e3 * e,
            zone: mn(t.zone, Dn.defaultZone),
            loc: un.fromObject(t)
        });
        throw new gt("fromSeconds requires a numerical input")
    }
    static fromObject(e, t = {}) {
        e = e || {};
        const n = mn(t.zone, Dn.defaultZone);
        if (!n.isValid) return Ci.invalid(ei(n));
        const r = un.fromObject(t),
            o = mr(e, vi),
            {
                minDaysInFirstWeek: i,
                startOfWeek: a
            } = Bn(o, r),
            s = Dn.now(),
            l = Un(t.specificOffset) ? n.offset(s) : t.specificOffset,
            c = !Un(o.ordinal),
            u = !Un(o.year),
            d = !Un(o.month) || !Un(o.day),
            p = u || d,
            f = o.weekYear || o.weekNumber;
        if ((p || c) && f) throw new ht("Can't mix weekYear/weekNumber units with year/month/day or ordinals");
        if (d && c) throw new ht("Can't mix ordinal dates with month/day");
        const m = f || o.weekday && !p;
        let h, y, g = ii(s, l);
        m ? (h = yi, y = fi, g = Fn(g, i, a)) : c ? (h = gi, y = mi, g = Wn(g)) : (h = hi, y = pi);
        let v = !1;
        for (const _ of h) {
            Un(o[_]) ? o[_] = v ? y[_] : g[_] : v = !0
        }
        const b = m ? function(e, t = 4, n = 1) {
                const r = $n(e.weekYear),
                    o = Xn(e.weekNumber, 1, cr(e.weekYear, t, n)),
                    i = Xn(e.weekday, 1, 7);
                return r ? o ? !i && jn("weekday", e.weekday) : jn("week", e.weekNumber) : jn("weekYear", e.weekYear)
            }(o, i, a) : c ? function(e) {
                const t = $n(e.year),
                    n = Xn(e.ordinal, 1, ir(e.year));
                return t ? !n && jn("ordinal", e.ordinal) : jn("year", e.year)
            }(o) : Hn(o),
            x = b || qn(o);
        if (x) return Ci.invalid(x);
        const w = m ? Rn(o, i, a) : c ? Vn(o) : o,
            [k, S] = ai(w, l, n),
            C = new Ci({
                ts: k,
                zone: n,
                o: S,
                loc: r
            });
        return o.weekday && p && e.weekday !== C.weekday ? Ci.invalid("mismatched weekday", `you can't specify both a weekday of ${o.weekday} and a date of ${C.toISO()}`) : C.isValid ? C : Ci.invalid(C.invalid)
    }
    static fromISO(e, t = {}) {
        const [n, r] = Nr(e, [lo, fo], [co, mo], [uo, ho], [po, yo]);
        return li(n, r, t, "ISO 8601", e)
    }
    static fromRFC2822(e, t = {}) {
        const [n, r] = Nr(function(e) {
            return e.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").trim()
        }(e), [to, no]);
        return li(n, r, t, "RFC 2822", e)
    }
    static fromHTTP(e, t = {}) {
        const [n, r] = Nr(e, [ro, ao], [oo, ao], [io, so]);
        return li(n, r, t, "HTTP", t)
    }
    static fromFormat(e, t, n = {}) {
        if (Un(e) || Un(t)) throw new gt("fromFormat requires an input string and a format");
        const {
            locale: r = null,
            numberingSystem: o = null
        } = n, i = un.fromOpts({
            locale: r,
            numberingSystem: o,
            defaultToEN: !0
        }), [a, s, l, c] = function(e, t, n) {
            const {
                result: r,
                zone: o,
                specificOffset: i,
                invalidReason: a
            } = Jo(e, t, n);
            return [r, o, i, a]
        }(i, e, t);
        return c ? Ci.invalid(c) : li(a, s, n, `format ${t}`, e, l)
    }
    static fromString(e, t, n = {}) {
        return Ci.fromFormat(e, t, n)
    }
    static fromSQL(e, t = {}) {
        const [n, r] = Nr(e, [vo, fo], [bo, xo]);
        return li(n, r, t, "SQL", e)
    }
    static invalid(e, t = null) {
        if (!e) throw new gt("need to specify a reason the DateTime is invalid");
        const n = e instanceof On ? e : new On(e, t);
        if (Dn.throwOnInvalid) throw new pt(n);
        return new Ci({
            invalid: n
        })
    }
    static isDateTime(e) {
        return e && e.isLuxonDateTime || !1
    }
    static parseFormatForOpts(e, t = {}) {
        const n = Ko(e, un.fromObject(t));
        return n ? n.map((e => e ? e.val : null)).join("") : null
    }
    static expandFormat(e, t = {}) {
        return Go(jr.parseFormat(e), un.fromObject(t)).map((e => e.val)).join("")
    }
    static resetCache() {
        ki = void 0, Si = {}
    }
    get(e) {
        return this[e]
    }
    get isValid() {
        return null === this.invalid
    }
    get invalidReason() {
        return this.invalid ? this.invalid.reason : null
    }
    get invalidExplanation() {
        return this.invalid ? this.invalid.explanation : null
    }
    get locale() {
        return this.isValid ? this.loc.locale : null
    }
    get numberingSystem() {
        return this.isValid ? this.loc.numberingSystem : null
    }
    get outputCalendar() {
        return this.isValid ? this.loc.outputCalendar : null
    }
    get zone() {
        return this._zone
    }
    get zoneName() {
        return this.isValid ? this.zone.name : null
    }
    get year() {
        return this.isValid ? this.c.year : NaN
    }
    get quarter() {
        return this.isValid ? Math.ceil(this.c.month / 3) : NaN
    }
    get month() {
        return this.isValid ? this.c.month : NaN
    }
    get day() {
        return this.isValid ? this.c.day : NaN
    }
    get hour() {
        return this.isValid ? this.c.hour : NaN
    }
    get minute() {
        return this.isValid ? this.c.minute : NaN
    }
    get second() {
        return this.isValid ? this.c.second : NaN
    }
    get millisecond() {
        return this.isValid ? this.c.millisecond : NaN
    }
    get weekYear() {
        return this.isValid ? ti(this).weekYear : NaN
    }
    get weekNumber() {
        return this.isValid ? ti(this).weekNumber : NaN
    }
    get weekday() {
        return this.isValid ? ti(this).weekday : NaN
    }
    get isWeekend() {
        return this.isValid && this.loc.getWeekendDays().includes(this.weekday)
    }
    get localWeekday() {
        return this.isValid ? ni(this).weekday : NaN
    }
    get localWeekNumber() {
        return this.isValid ? ni(this).weekNumber : NaN
    }
    get localWeekYear() {
        return this.isValid ? ni(this).weekYear : NaN
    }
    get ordinal() {
        return this.isValid ? Wn(this.c).ordinal : NaN
    }
    get monthShort() {
        return this.isValid ? Mo.months("short", {
            locObj: this.loc
        })[this.month - 1] : null
    }
    get monthLong() {
        return this.isValid ? Mo.months("long", {
            locObj: this.loc
        })[this.month - 1] : null
    }
    get weekdayShort() {
        return this.isValid ? Mo.weekdays("short", {
            locObj: this.loc
        })[this.weekday - 1] : null
    }
    get weekdayLong() {
        return this.isValid ? Mo.weekdays("long", {
            locObj: this.loc
        })[this.weekday - 1] : null
    }
    get offset() {
        return this.isValid ? +this.o : NaN
    }
    get offsetNameShort() {
        return this.isValid ? this.zone.offsetName(this.ts, {
            format: "short",
            locale: this.locale
        }) : null
    }
    get offsetNameLong() {
        return this.isValid ? this.zone.offsetName(this.ts, {
            format: "long",
            locale: this.locale
        }) : null
    }
    get isOffsetFixed() {
        return this.isValid ? this.zone.isUniversal : null
    }
    get isInDST() {
        return !this.isOffsetFixed && (this.offset > this.set({
            month: 1,
            day: 1
        }).offset || this.offset > this.set({
            month: 5
        }).offset)
    }
    getPossibleOffsets() {
        if (!this.isValid || this.isOffsetFixed) return [this];
        const e = 864e5,
            t = 6e4,
            n = sr(this.c),
            r = this.zone.offset(n - e),
            o = this.zone.offset(n + e),
            i = this.zone.offset(n - r * t),
            a = this.zone.offset(n - o * t);
        if (i === a) return [this];
        const s = n - i * t,
            l = n - a * t,
            c = ii(s, i),
            u = ii(l, a);
        return c.hour === u.hour && c.minute === u.minute && c.second === u.second && c.millisecond === u.millisecond ? [ri(this, {
            ts: s
        }), ri(this, {
            ts: l
        })] : [this]
    }
    get isInLeapYear() {
        return or(this.year)
    }
    get daysInMonth() {
        return ar(this.year, this.month)
    }
    get daysInYear() {
        return this.isValid ? ir(this.year) : NaN
    }
    get weeksInWeekYear() {
        return this.isValid ? cr(this.weekYear) : NaN
    }
    get weeksInLocalWeekYear() {
        return this.isValid ? cr(this.localWeekYear, this.loc.getMinDaysInFirstWeek(), this.loc.getStartOfWeek()) : NaN
    }
    resolvedLocaleOptions(e = {}) {
        const {
            locale: t,
            numberingSystem: n,
            calendar: r
        } = jr.create(this.loc.clone(e), e).resolvedOptions(this);
        return {
            locale: t,
            numberingSystem: n,
            outputCalendar: r
        }
    }
    toUTC(e = 0, t = {}) {
        return this.setZone(pn.instance(e), t)
    }
    toLocal() {
        return this.setZone(Dn.defaultZone)
    }
    setZone(e, {
        keepLocalTime: t = !1,
        keepCalendarTime: n = !1
    } = {}) {
        if ((e = mn(e, Dn.defaultZone)).equals(this.zone)) return this;
        if (e.isValid) {
            let r = this.ts;
            if (t || n) {
                const t = e.offset(this.ts),
                    n = this.toObject();
                [r] = ai(n, t, e)
            }
            return ri(this, {
                ts: r,
                zone: e
            })
        }
        return Ci.invalid(ei(e))
    }
    reconfigure({
        locale: e,
        numberingSystem: t,
        outputCalendar: n
    } = {}) {
        return ri(this, {
            loc: this.loc.clone({
                locale: e,
                numberingSystem: t,
                outputCalendar: n
            })
        })
    }
    setLocale(e) {
        return this.reconfigure({
            locale: e
        })
    }
    set(e) {
        if (!this.isValid) return this;
        const t = mr(e, vi),
            {
                minDaysInFirstWeek: n,
                startOfWeek: r
            } = Bn(t, this.loc),
            o = !Un(t.weekYear) || !Un(t.weekNumber) || !Un(t.weekday),
            i = !Un(t.ordinal),
            a = !Un(t.year),
            s = !Un(t.month) || !Un(t.day),
            l = a || s,
            c = t.weekYear || t.weekNumber;
        if ((l || i) && c) throw new ht("Can't mix weekYear/weekNumber units with year/month/day or ordinals");
        if (s && i) throw new ht("Can't mix ordinal dates with month/day");
        let u;
        o ? u = Rn({ ...Fn(this.c, n, r),
            ...t
        }, n, r) : Un(t.ordinal) ? (u = { ...this.toObject(),
            ...t
        }, Un(t.day) && (u.day = Math.min(ar(u.year, u.month), u.day))) : u = Vn({ ...Wn(this.c),
            ...t
        });
        const [d, p] = ai(u, this.o, this.zone);
        return ri(this, {
            ts: d,
            o: p
        })
    }
    plus(e) {
        if (!this.isValid) return this;
        return ri(this, si(this, jo.fromDurationLike(e)))
    }
    minus(e) {
        if (!this.isValid) return this;
        return ri(this, si(this, jo.fromDurationLike(e).negate()))
    }
    startOf(e, {
        useLocaleWeeks: t = !1
    } = {}) {
        if (!this.isValid) return this;
        const n = {},
            r = jo.normalizeUnit(e);
        switch (r) {
            case "years":
                n.month = 1;
            case "quarters":
            case "months":
                n.day = 1;
            case "weeks":
            case "days":
                n.hour = 0;
            case "hours":
                n.minute = 0;
            case "minutes":
                n.second = 0;
            case "seconds":
                n.millisecond = 0
        }
        if ("weeks" === r)
            if (t) {
                const e = this.loc.getStartOfWeek(),
                    {
                        weekday: t
                    } = this;
                t < e && (n.weekNumber = this.weekNumber - 1), n.weekday = e
            } else n.weekday = 1;
        if ("quarters" === r) {
            const e = Math.ceil(this.month / 3);
            n.month = 3 * (e - 1) + 1
        }
        return this.set(n)
    }
    endOf(e, t) {
        return this.isValid ? this.plus({
            [e]: 1
        }).startOf(e, t).minus(1) : this
    }
    toFormat(e, t = {}) {
        return this.isValid ? jr.create(this.loc.redefaultToEN(t)).formatDateTimeFromString(this, e) : Xo
    }
    toLocaleString(e = kt, t = {}) {
        return this.isValid ? jr.create(this.loc.clone(t), e).formatDateTime(this) : Xo
    }
    toLocaleParts(e = {}) {
        return this.isValid ? jr.create(this.loc.clone(e), e).formatDateTimeParts(this) : []
    }
    toISO({
        format: e = "extended",
        suppressSeconds: t = !1,
        suppressMilliseconds: n = !1,
        includeOffset: r = !0,
        extendedZone: o = !1
    } = {}) {
        if (!this.isValid) return null;
        const i = "extended" === e;
        let a = ui(this, i);
        return a += "T", a += di(this, i, t, n, r, o), a
    }
    toISODate({
        format: e = "extended"
    } = {}) {
        return this.isValid ? ui(this, "extended" === e) : null
    }
    toISOWeekDate() {
        return ci(this, "kkkk-'W'WW-c")
    }
    toISOTime({
        suppressMilliseconds: e = !1,
        suppressSeconds: t = !1,
        includeOffset: n = !0,
        includePrefix: r = !1,
        extendedZone: o = !1,
        format: i = "extended"
    } = {}) {
        if (!this.isValid) return null;
        return (r ? "T" : "") + di(this, "extended" === i, t, e, n, o)
    }
    toRFC2822() {
        return ci(this, "EEE, dd LLL yyyy HH:mm:ss ZZZ", !1)
    }
    toHTTP() {
        return ci(this.toUTC(), "EEE, dd LLL yyyy HH:mm:ss 'GMT'")
    }
    toSQLDate() {
        return this.isValid ? ui(this, !0) : null
    }
    toSQLTime({
        includeOffset: e = !0,
        includeZone: t = !1,
        includeOffsetSpace: n = !0
    } = {}) {
        let r = "HH:mm:ss.SSS";
        return (t || e) && (n && (r += " "), t ? r += "z" : e && (r += "ZZ")), ci(this, r, !0)
    }
    toSQL(e = {}) {
        return this.isValid ? `${this.toSQLDate()} ${this.toSQLTime(e)}` : null
    }
    toString() {
        return this.isValid ? this.toISO() : Xo
    }[Symbol.for("nodejs.util.inspect.custom")]() {
        return this.isValid ? `DateTime { ts: ${this.toISO()}, zone: ${this.zone.name}, locale: ${this.locale} }` : `DateTime { Invalid, reason: ${this.invalidReason} }`
    }
    valueOf() {
        return this.toMillis()
    }
    toMillis() {
        return this.isValid ? this.ts : NaN
    }
    toSeconds() {
        return this.isValid ? this.ts / 1e3 : NaN
    }
    toUnixInteger() {
        return this.isValid ? Math.floor(this.ts / 1e3) : NaN
    }
    toJSON() {
        return this.toISO()
    }
    toBSON() {
        return this.toJSDate()
    }
    toObject(e = {}) {
        if (!this.isValid) return {};
        const t = { ...this.c
        };
        return e.includeConfig && (t.outputCalendar = this.outputCalendar, t.numberingSystem = this.loc.numberingSystem, t.locale = this.loc.locale), t
    }
    toJSDate() {
        return new Date(this.isValid ? this.ts : NaN)
    }
    diff(e, t = "milliseconds", n = {}) {
        if (!this.isValid || !e.isValid) return jo.invalid("created by diffing an invalid DateTime");
        const r = {
                locale: this.locale,
                numberingSystem: this.numberingSystem,
                ...n
            },
            o = (s = t, Array.isArray(s) ? s : [s]).map(jo.normalizeUnit),
            i = e.valueOf() > this.valueOf(),
            a = Fo(i ? this : e, i ? e : this, o, r);
        var s;
        return i ? a.negate() : a
    }
    diffNow(e = "milliseconds", t = {}) {
        return this.diff(Ci.now(), e, t)
    }
    until(e) {
        return this.isValid ? Po.fromDateTimes(this, e) : this
    }
    hasSame(e, t, n) {
        if (!this.isValid) return !1;
        const r = e.valueOf(),
            o = this.setZone(e.zone, {
                keepLocalTime: !0
            });
        return o.startOf(t, n) <= r && r <= o.endOf(t, n)
    }
    equals(e) {
        return this.isValid && e.isValid && this.valueOf() === e.valueOf() && this.zone.equals(e.zone) && this.loc.equals(e.loc)
    }
    toRelative(e = {}) {
        if (!this.isValid) return null;
        const t = e.base || Ci.fromObject({}, {
                zone: this.zone
            }),
            n = e.padding ? this < t ? -e.padding : e.padding : 0;
        let r = ["years", "months", "days", "hours", "minutes", "seconds"],
            o = e.unit;
        return Array.isArray(e.unit) && (r = e.unit, o = void 0), xi(t, this.plus(n), { ...e,
            numeric: "always",
            units: r,
            unit: o
        })
    }
    toRelativeCalendar(e = {}) {
        return this.isValid ? xi(e.base || Ci.fromObject({}, {
            zone: this.zone
        }), this, { ...e,
            numeric: "auto",
            units: ["years", "months", "days"],
            calendary: !0
        }) : null
    }
    static min(...e) {
        if (!e.every(Ci.isDateTime)) throw new gt("min requires all arguments be DateTimes");
        return Yn(e, (e => e.valueOf()), Math.min)
    }
    static max(...e) {
        if (!e.every(Ci.isDateTime)) throw new gt("max requires all arguments be DateTimes");
        return Yn(e, (e => e.valueOf()), Math.max)
    }
    static fromFormatExplain(e, t, n = {}) {
        const {
            locale: r = null,
            numberingSystem: o = null
        } = n;
        return Jo(un.fromOpts({
            locale: r,
            numberingSystem: o,
            defaultToEN: !0
        }), e, t)
    }
    static fromStringExplain(e, t, n = {}) {
        return Ci.fromFormatExplain(e, t, n)
    }
    static buildFormatParser(e, t = {}) {
        const {
            locale: n = null,
            numberingSystem: r = null
        } = t, o = un.fromOpts({
            locale: n,
            numberingSystem: r,
            defaultToEN: !0
        });
        return new Yo(o, e)
    }
    static fromFormatParser(e, t, n = {}) {
        if (Un(e) || Un(t)) throw new gt("fromFormatParser requires an input string and a format parser");
        const {
            locale: r = null,
            numberingSystem: o = null
        } = n, i = un.fromOpts({
            locale: r,
            numberingSystem: o,
            defaultToEN: !0
        });
        if (!i.equals(t.locale)) throw new gt(`fromFormatParser called with a locale of ${i}, but the format parser was created for ${t.locale}`);
        const {
            result: a,
            zone: s,
            specificOffset: l,
            invalidReason: c
        } = t.explainFromTokens(e);
        return c ? Ci.invalid(c) : li(a, s, n, `format ${t.format}`, e, l)
    }
    static get DATE_SHORT() {
        return kt
    }
    static get DATE_MED() {
        return St
    }
    static get DATE_MED_WITH_WEEKDAY() {
        return Ct
    }
    static get DATE_FULL() {
        return _t
    }
    static get DATE_HUGE() {
        return Tt
    }
    static get TIME_SIMPLE() {
        return At
    }
    static get TIME_WITH_SECONDS() {
        return Dt
    }
    static get TIME_WITH_SHORT_OFFSET() {
        return Ot
    }
    static get TIME_WITH_LONG_OFFSET() {
        return Et
    }
    static get TIME_24_SIMPLE() {
        return It
    }
    static get TIME_24_WITH_SECONDS() {
        return jt
    }
    static get TIME_24_WITH_SHORT_OFFSET() {
        return Lt
    }
    static get TIME_24_WITH_LONG_OFFSET() {
        return Pt
    }
    static get DATETIME_SHORT() {
        return Mt
    }
    static get DATETIME_SHORT_WITH_SECONDS() {
        return Nt
    }
    static get DATETIME_MED() {
        return Ft
    }
    static get DATETIME_MED_WITH_SECONDS() {
        return Rt
    }
    static get DATETIME_MED_WITH_WEEKDAY() {
        return Wt
    }
    static get DATETIME_FULL() {
        return Vt
    }
    static get DATETIME_FULL_WITH_SECONDS() {
        return Bt
    }
    static get DATETIME_HUGE() {
        return Ht
    }
    static get DATETIME_HUGE_WITH_SECONDS() {
        return qt
    }
}

function _i(e) {
    if (Ci.isDateTime(e)) return e;
    if (e && e.valueOf && zn(e.valueOf())) return Ci.fromJSDate(e);
    if (e && "object" == typeof e) return Ci.fromObject(e);
    throw new gt(`Unknown datetime argument: ${e}, of type ${typeof e}`)
}
var Ti, Ai = Error,
    Di = EvalError,
    Oi = RangeError,
    Ei = ReferenceError,
    Ii = SyntaxError,
    ji = TypeError,
    Li = URIError,
    Pi = "undefined" != typeof Symbol && Symbol,
    Mi = function() {
        if ("function" != typeof Symbol || "function" != typeof Object.getOwnPropertySymbols) return !1;
        if ("symbol" == typeof Symbol.iterator) return !0;
        var e = {},
            t = Symbol("test"),
            n = Object(t);
        if ("string" == typeof t) return !1;
        if ("[object Symbol]" !== Object.prototype.toString.call(t)) return !1;
        if ("[object Symbol]" !== Object.prototype.toString.call(n)) return !1;
        for (t in e[t] = 42, e) return !1;
        if ("function" == typeof Object.keys && 0 !== Object.keys(e).length) return !1;
        if ("function" == typeof Object.getOwnPropertyNames && 0 !== Object.getOwnPropertyNames(e).length) return !1;
        var r = Object.getOwnPropertySymbols(e);
        if (1 !== r.length || r[0] !== t) return !1;
        if (!Object.prototype.propertyIsEnumerable.call(e, t)) return !1;
        if ("function" == typeof Object.getOwnPropertyDescriptor) {
            var o = Object.getOwnPropertyDescriptor(e, t);
            if (42 !== o.value || !0 !== o.enumerable) return !1
        }
        return !0
    },
    Ni = {
        __proto__: null,
        foo: {}
    },
    Fi = Object,
    Ri = Object.prototype.toString,
    Wi = Math.max,
    Vi = function(e, t) {
        for (var n = [], r = 0; r < e.length; r += 1) n[r] = e[r];
        for (var o = 0; o < t.length; o += 1) n[o + e.length] = t[o];
        return n
    },
    Bi = function(e) {
        var t = this;
        if ("function" != typeof t || "[object Function]" !== Ri.apply(t)) throw new TypeError("Function.prototype.bind called on incompatible " + t);
        for (var n, r = function(e, t) {
                for (var n = [], r = t, o = 0; r < e.length; r += 1, o += 1) n[o] = e[r];
                return n
            }(arguments, 1), o = Wi(0, t.length - r.length), i = [], a = 0; a < o; a++) i[a] = "$" + a;
        if (n = Function("binder", "return function (" + function(e, t) {
                for (var n = "", r = 0; r < e.length; r += 1) n += e[r], r + 1 < e.length && (n += t);
                return n
            }(i, ",") + "){ return binder.apply(this,arguments); }")((function() {
                if (this instanceof n) {
                    var o = t.apply(this, Vi(r, arguments));
                    return Object(o) === o ? o : this
                }
                return t.apply(e, Vi(r, arguments))
            })), t.prototype) {
            var s = function() {};
            s.prototype = t.prototype, n.prototype = new s, s.prototype = null
        }
        return n
    },
    Hi = Function.prototype.bind || Bi,
    qi = Function.prototype.call,
    Ui = Object.prototype.hasOwnProperty,
    zi = Hi.call(qi, Ui),
    $i = Ai,
    Zi = Di,
    Gi = Oi,
    Yi = Ei,
    Ji = Ii,
    Ki = ji,
    Xi = Li,
    Qi = Function,
    ea = function(e) {
        try {
            return Qi('"use strict"; return (' + e + ").constructor;")()
        } catch (t) {}
    },
    ta = Object.getOwnPropertyDescriptor;
if (ta) try {
    ta({}, "")
} catch (Fy) {
    ta = null
}
var na = function() {
        throw new Ki
    },
    ra = ta ? function() {
        try {
            return na
        } catch (e) {
            try {
                return ta(arguments, "callee").get
            } catch (t) {
                return na
            }
        }
    }() : na,
    oa = "function" == typeof Pi && "function" == typeof Symbol && "symbol" == typeof Pi("foo") && "symbol" == typeof Symbol("bar") && Mi(),
    ia = {
        __proto__: Ni
    }.foo === Ni.foo && !(Ni instanceof Fi),
    aa = Object.getPrototypeOf || (ia ? function(e) {
        return e.__proto__
    } : null),
    sa = {},
    la = "undefined" != typeof Uint8Array && aa ? aa(Uint8Array) : Ti,
    ca = {
        __proto__: null,
        "%AggregateError%": "undefined" == typeof AggregateError ? Ti : AggregateError,
        "%Array%": Array,
        "%ArrayBuffer%": "undefined" == typeof ArrayBuffer ? Ti : ArrayBuffer,
        "%ArrayIteratorPrototype%": oa && aa ? aa([][Symbol.iterator]()) : Ti,
        "%AsyncFromSyncIteratorPrototype%": Ti,
        "%AsyncFunction%": sa,
        "%AsyncGenerator%": sa,
        "%AsyncGeneratorFunction%": sa,
        "%AsyncIteratorPrototype%": sa,
        "%Atomics%": "undefined" == typeof Atomics ? Ti : Atomics,
        "%BigInt%": "undefined" == typeof BigInt ? Ti : BigInt,
        "%BigInt64Array%": "undefined" == typeof BigInt64Array ? Ti : BigInt64Array,
        "%BigUint64Array%": "undefined" == typeof BigUint64Array ? Ti : BigUint64Array,
        "%Boolean%": Boolean,
        "%DataView%": "undefined" == typeof DataView ? Ti : DataView,
        "%Date%": Date,
        "%decodeURI%": decodeURI,
        "%decodeURIComponent%": decodeURIComponent,
        "%encodeURI%": encodeURI,
        "%encodeURIComponent%": encodeURIComponent,
        "%Error%": $i,
        "%eval%": eval,
        "%EvalError%": Zi,
        "%Float32Array%": "undefined" == typeof Float32Array ? Ti : Float32Array,
        "%Float64Array%": "undefined" == typeof Float64Array ? Ti : Float64Array,
        "%FinalizationRegistry%": "undefined" == typeof FinalizationRegistry ? Ti : FinalizationRegistry,
        "%Function%": Qi,
        "%GeneratorFunction%": sa,
        "%Int8Array%": "undefined" == typeof Int8Array ? Ti : Int8Array,
        "%Int16Array%": "undefined" == typeof Int16Array ? Ti : Int16Array,
        "%Int32Array%": "undefined" == typeof Int32Array ? Ti : Int32Array,
        "%isFinite%": isFinite,
        "%isNaN%": isNaN,
        "%IteratorPrototype%": oa && aa ? aa(aa([][Symbol.iterator]())) : Ti,
        "%JSON%": "object" == typeof JSON ? JSON : Ti,
        "%Map%": "undefined" == typeof Map ? Ti : Map,
        "%MapIteratorPrototype%": "undefined" != typeof Map && oa && aa ? aa((new Map)[Symbol.iterator]()) : Ti,
        "%Math%": Math,
        "%Number%": Number,
        "%Object%": Object,
        "%parseFloat%": parseFloat,
        "%parseInt%": parseInt,
        "%Promise%": "undefined" == typeof Promise ? Ti : Promise,
        "%Proxy%": "undefined" == typeof Proxy ? Ti : Proxy,
        "%RangeError%": Gi,
        "%ReferenceError%": Yi,
        "%Reflect%": "undefined" == typeof Reflect ? Ti : Reflect,
        "%RegExp%": RegExp,
        "%Set%": "undefined" == typeof Set ? Ti : Set,
        "%SetIteratorPrototype%": "undefined" != typeof Set && oa && aa ? aa((new Set)[Symbol.iterator]()) : Ti,
        "%SharedArrayBuffer%": "undefined" == typeof SharedArrayBuffer ? Ti : SharedArrayBuffer,
        "%String%": String,
        "%StringIteratorPrototype%": oa && aa ? aa("" [Symbol.iterator]()) : Ti,
        "%Symbol%": oa ? Symbol : Ti,
        "%SyntaxError%": Ji,
        "%ThrowTypeError%": ra,
        "%TypedArray%": la,
        "%TypeError%": Ki,
        "%Uint8Array%": "undefined" == typeof Uint8Array ? Ti : Uint8Array,
        "%Uint8ClampedArray%": "undefined" == typeof Uint8ClampedArray ? Ti : Uint8ClampedArray,
        "%Uint16Array%": "undefined" == typeof Uint16Array ? Ti : Uint16Array,
        "%Uint32Array%": "undefined" == typeof Uint32Array ? Ti : Uint32Array,
        "%URIError%": Xi,
        "%WeakMap%": "undefined" == typeof WeakMap ? Ti : WeakMap,
        "%WeakRef%": "undefined" == typeof WeakRef ? Ti : WeakRef,
        "%WeakSet%": "undefined" == typeof WeakSet ? Ti : WeakSet
    };
if (aa) try {
    null.error
} catch (Fy) {
    var ua = aa(aa(Fy));
    ca["%Error.prototype%"] = ua
}
var da, pa, fa = function e(t) {
        var n;
        if ("%AsyncFunction%" === t) n = ea("async function () {}");
        else if ("%GeneratorFunction%" === t) n = ea("function* () {}");
        else if ("%AsyncGeneratorFunction%" === t) n = ea("async function* () {}");
        else if ("%AsyncGenerator%" === t) {
            var r = e("%AsyncGeneratorFunction%");
            r && (n = r.prototype)
        } else if ("%AsyncIteratorPrototype%" === t) {
            var o = e("%AsyncGenerator%");
            o && aa && (n = aa(o.prototype))
        }
        return ca[t] = n, n
    },
    ma = {
        __proto__: null,
        "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
        "%ArrayPrototype%": ["Array", "prototype"],
        "%ArrayProto_entries%": ["Array", "prototype", "entries"],
        "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
        "%ArrayProto_keys%": ["Array", "prototype", "keys"],
        "%ArrayProto_values%": ["Array", "prototype", "values"],
        "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
        "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
        "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
        "%BooleanPrototype%": ["Boolean", "prototype"],
        "%DataViewPrototype%": ["DataView", "prototype"],
        "%DatePrototype%": ["Date", "prototype"],
        "%ErrorPrototype%": ["Error", "prototype"],
        "%EvalErrorPrototype%": ["EvalError", "prototype"],
        "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
        "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
        "%FunctionPrototype%": ["Function", "prototype"],
        "%Generator%": ["GeneratorFunction", "prototype"],
        "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
        "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
        "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
        "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
        "%JSONParse%": ["JSON", "parse"],
        "%JSONStringify%": ["JSON", "stringify"],
        "%MapPrototype%": ["Map", "prototype"],
        "%NumberPrototype%": ["Number", "prototype"],
        "%ObjectPrototype%": ["Object", "prototype"],
        "%ObjProto_toString%": ["Object", "prototype", "toString"],
        "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
        "%PromisePrototype%": ["Promise", "prototype"],
        "%PromiseProto_then%": ["Promise", "prototype", "then"],
        "%Promise_all%": ["Promise", "all"],
        "%Promise_reject%": ["Promise", "reject"],
        "%Promise_resolve%": ["Promise", "resolve"],
        "%RangeErrorPrototype%": ["RangeError", "prototype"],
        "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
        "%RegExpPrototype%": ["RegExp", "prototype"],
        "%SetPrototype%": ["Set", "prototype"],
        "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
        "%StringPrototype%": ["String", "prototype"],
        "%SymbolPrototype%": ["Symbol", "prototype"],
        "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
        "%TypedArrayPrototype%": ["TypedArray", "prototype"],
        "%TypeErrorPrototype%": ["TypeError", "prototype"],
        "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
        "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
        "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
        "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
        "%URIErrorPrototype%": ["URIError", "prototype"],
        "%WeakMapPrototype%": ["WeakMap", "prototype"],
        "%WeakSetPrototype%": ["WeakSet", "prototype"]
    },
    ha = Hi,
    ya = zi,
    ga = ha.call(Function.call, Array.prototype.concat),
    va = ha.call(Function.apply, Array.prototype.splice),
    ba = ha.call(Function.call, String.prototype.replace),
    xa = ha.call(Function.call, String.prototype.slice),
    wa = ha.call(Function.call, RegExp.prototype.exec),
    ka = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g,
    Sa = /\\(\\)?/g,
    Ca = function(e, t) {
        var n, r = e;
        if (ya(ma, r) && (r = "%" + (n = ma[r])[0] + "%"), ya(ca, r)) {
            var o = ca[r];
            if (o === sa && (o = fa(r)), void 0 === o && !t) throw new Ki("intrinsic " + e + " exists, but is not available. Please file an issue!");
            return {
                alias: n,
                name: r,
                value: o
            }
        }
        throw new Ji("intrinsic " + e + " does not exist!")
    },
    _a = function(e, t) {
        if ("string" != typeof e || 0 === e.length) throw new Ki("intrinsic name must be a non-empty string");
        if (arguments.length > 1 && "boolean" != typeof t) throw new Ki('"allowMissing" argument must be a boolean');
        if (null === wa(/^%?[^%]*%?$/, e)) throw new Ji("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
        var n = function(e) {
                var t = xa(e, 0, 1),
                    n = xa(e, -1);
                if ("%" === t && "%" !== n) throw new Ji("invalid intrinsic syntax, expected closing `%`");
                if ("%" === n && "%" !== t) throw new Ji("invalid intrinsic syntax, expected opening `%`");
                var r = [];
                return ba(e, ka, (function(e, t, n, o) {
                    r[r.length] = n ? ba(o, Sa, "$1") : t || e
                })), r
            }(e),
            r = n.length > 0 ? n[0] : "",
            o = Ca("%" + r + "%", t),
            i = o.name,
            a = o.value,
            s = !1,
            l = o.alias;
        l && (r = l[0], va(n, ga([0, 1], l)));
        for (var c = 1, u = !0; c < n.length; c += 1) {
            var d = n[c],
                p = xa(d, 0, 1),
                f = xa(d, -1);
            if (('"' === p || "'" === p || "`" === p || '"' === f || "'" === f || "`" === f) && p !== f) throw new Ji("property names with quotes must have matching quotes");
            if ("constructor" !== d && u || (s = !0), ya(ca, i = "%" + (r += "." + d) + "%")) a = ca[i];
            else if (null != a) {
                if (!(d in a)) {
                    if (!t) throw new Ki("base intrinsic for " + e + " exists, but the property is not available.");
                    return
                }
                if (ta && c + 1 >= n.length) {
                    var m = ta(a, d);
                    a = (u = !!m) && "get" in m && !("originalValue" in m.get) ? m.get : a[d]
                } else u = ya(a, d), a = a[d];
                u && !s && (ca[i] = a)
            }
        }
        return a
    },
    Ta = {
        exports: {}
    };

function Aa() {
    if (pa) return da;
    pa = 1;
    var e = _a("%Object.defineProperty%", !0) || !1;
    if (e) try {
        e({}, "a", {
            value: 1
        })
    } catch (Fy) {
        e = !1
    }
    return da = e
}
var Da = _a("%Object.getOwnPropertyDescriptor%", !0);
if (Da) try {
    Da([], "length")
} catch (Fy) {
    Da = null
}
var Oa = Da,
    Ea = Aa(),
    Ia = Ii,
    ja = ji,
    La = Oa,
    Pa = Aa(),
    Ma = function() {
        return !!Pa
    };
Ma.hasArrayLengthDefineBug = function() {
    if (!Pa) return null;
    try {
        return 1 !== Pa([], "length", {
            value: 1
        }).length
    } catch (Fy) {
        return !0
    }
};
var Na = _a,
    Fa = function(e, t, n) {
        if (!e || "object" != typeof e && "function" != typeof e) throw new ja("`obj` must be an object or a function`");
        if ("string" != typeof t && "symbol" != typeof t) throw new ja("`property` must be a string or a symbol`");
        if (arguments.length > 3 && "boolean" != typeof arguments[3] && null !== arguments[3]) throw new ja("`nonEnumerable`, if provided, must be a boolean or null");
        if (arguments.length > 4 && "boolean" != typeof arguments[4] && null !== arguments[4]) throw new ja("`nonWritable`, if provided, must be a boolean or null");
        if (arguments.length > 5 && "boolean" != typeof arguments[5] && null !== arguments[5]) throw new ja("`nonConfigurable`, if provided, must be a boolean or null");
        if (arguments.length > 6 && "boolean" != typeof arguments[6]) throw new ja("`loose`, if provided, must be a boolean");
        var r = arguments.length > 3 ? arguments[3] : null,
            o = arguments.length > 4 ? arguments[4] : null,
            i = arguments.length > 5 ? arguments[5] : null,
            a = arguments.length > 6 && arguments[6],
            s = !!La && La(e, t);
        if (Ea) Ea(e, t, {
            configurable: null === i && s ? s.configurable : !i,
            enumerable: null === r && s ? s.enumerable : !r,
            value: n,
            writable: null === o && s ? s.writable : !o
        });
        else {
            if (!a && (r || o || i)) throw new Ia("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.");
            e[t] = n
        }
    },
    Ra = Ma(),
    Wa = Oa,
    Va = ji,
    Ba = Na("%Math.floor%"),
    Ha = function(e, t) {
        if ("function" != typeof e) throw new Va("`fn` is not a function");
        if ("number" != typeof t || t < 0 || t > 4294967295 || Ba(t) !== t) throw new Va("`length` must be a positive 32-bit integer");
        var n = arguments.length > 2 && !!arguments[2],
            r = !0,
            o = !0;
        if ("length" in e && Wa) {
            var i = Wa(e, "length");
            i && !i.configurable && (r = !1), i && !i.writable && (o = !1)
        }
        return (r || o || !n) && (Ra ? Fa(e, "length", t, !0, !0) : Fa(e, "length", t)), e
    };
! function(e) {
    var t = Hi,
        n = _a,
        r = Ha,
        o = ji,
        i = n("%Function.prototype.apply%"),
        a = n("%Function.prototype.call%"),
        s = n("%Reflect.apply%", !0) || t.call(a, i),
        l = Aa(),
        c = n("%Math.max%");
    e.exports = function(e) {
        if ("function" != typeof e) throw new o("a function is required");
        var n = s(t, a, arguments);
        return r(n, 1 + c(0, e.length - (arguments.length - 1)), !0)
    };
    var u = function() {
        return s(t, i, arguments)
    };
    l ? l(e.exports, "apply", {
        value: u
    }) : e.exports.apply = u
}(Ta);
var qa = _a,
    Ua = Ta.exports,
    za = Ua(qa("String.prototype.indexOf")),
    $a = "function" == typeof Map && Map.prototype,
    Za = Object.getOwnPropertyDescriptor && $a ? Object.getOwnPropertyDescriptor(Map.prototype, "size") : null,
    Ga = $a && Za && "function" == typeof Za.get ? Za.get : null,
    Ya = $a && Map.prototype.forEach,
    Ja = "function" == typeof Set && Set.prototype,
    Ka = Object.getOwnPropertyDescriptor && Ja ? Object.getOwnPropertyDescriptor(Set.prototype, "size") : null,
    Xa = Ja && Ka && "function" == typeof Ka.get ? Ka.get : null,
    Qa = Ja && Set.prototype.forEach,
    es = "function" == typeof WeakMap && WeakMap.prototype ? WeakMap.prototype.has : null,
    ts = "function" == typeof WeakSet && WeakSet.prototype ? WeakSet.prototype.has : null,
    ns = "function" == typeof WeakRef && WeakRef.prototype ? WeakRef.prototype.deref : null,
    rs = Boolean.prototype.valueOf,
    os = Object.prototype.toString,
    is = Function.prototype.toString,
    as = String.prototype.match,
    ss = String.prototype.slice,
    ls = String.prototype.replace,
    cs = String.prototype.toUpperCase,
    us = String.prototype.toLowerCase,
    ds = RegExp.prototype.test,
    ps = Array.prototype.concat,
    fs = Array.prototype.join,
    ms = Array.prototype.slice,
    hs = Math.floor,
    ys = "function" == typeof BigInt ? BigInt.prototype.valueOf : null,
    gs = Object.getOwnPropertySymbols,
    vs = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? Symbol.prototype.toString : null,
    bs = "function" == typeof Symbol && "object" == typeof Symbol.iterator,
    xs = "function" == typeof Symbol && Symbol.toStringTag && (typeof Symbol.toStringTag === bs || "symbol") ? Symbol.toStringTag : null,
    ws = Object.prototype.propertyIsEnumerable,
    ks = ("function" == typeof Reflect ? Reflect.getPrototypeOf : Object.getPrototypeOf) || ([].__proto__ === Array.prototype ? function(e) {
        return e.__proto__
    } : null);

function Ss(e, t) {
    if (e === 1 / 0 || e === -1 / 0 || e != e || e && e > -1e3 && e < 1e3 || ds.call(/e/, t)) return t;
    var n = /[0-9](?=(?:[0-9]{3})+(?![0-9]))/g;
    if ("number" == typeof e) {
        var r = e < 0 ? -hs(-e) : hs(e);
        if (r !== e) {
            var o = String(r),
                i = ss.call(t, o.length + 1);
            return ls.call(o, n, "$&_") + "." + ls.call(ls.call(i, /([0-9]{3})/g, "$&_"), /_$/, "")
        }
    }
    return ls.call(t, n, "$&_")
}
var Cs = X,
    _s = Cs.custom,
    Ts = Is(_s) ? _s : null;

function As(e, t, n) {
    var r = "double" === (n.quoteStyle || t) ? '"' : "'";
    return r + e + r
}

function Ds(e) {
    return ls.call(String(e), /"/g, "&quot;")
}

function Os(e) {
    return !("[object Array]" !== Ps(e) || xs && "object" == typeof e && xs in e)
}

function Es(e) {
    return !("[object RegExp]" !== Ps(e) || xs && "object" == typeof e && xs in e)
}

function Is(e) {
    if (bs) return e && "object" == typeof e && e instanceof Symbol;
    if ("symbol" == typeof e) return !0;
    if (!e || "object" != typeof e || !vs) return !1;
    try {
        return vs.call(e), !0
    } catch (Fy) {}
    return !1
}
var js = Object.prototype.hasOwnProperty || function(e) {
    return e in this
};

function Ls(e, t) {
    return js.call(e, t)
}

function Ps(e) {
    return os.call(e)
}

function Ms(e, t) {
    if (e.indexOf) return e.indexOf(t);
    for (var n = 0, r = e.length; n < r; n++)
        if (e[n] === t) return n;
    return -1
}

function Ns(e, t) {
    if (e.length > t.maxStringLength) {
        var n = e.length - t.maxStringLength,
            r = "... " + n + " more character" + (n > 1 ? "s" : "");
        return Ns(ss.call(e, 0, t.maxStringLength), t) + r
    }
    return As(ls.call(ls.call(e, /(['\\])/g, "\\$1"), /[\x00-\x1f]/g, Fs), "single", t)
}

function Fs(e) {
    var t = e.charCodeAt(0),
        n = {
            8: "b",
            9: "t",
            10: "n",
            12: "f",
            13: "r"
        }[t];
    return n ? "\\" + n : "\\x" + (t < 16 ? "0" : "") + cs.call(t.toString(16))
}

function Rs(e) {
    return "Object(" + e + ")"
}

function Ws(e) {
    return e + " { ? }"
}

function Vs(e, t, n, r) {
    return e + " (" + t + ") {" + (r ? Bs(n, r) : fs.call(n, ", ")) + "}"
}

function Bs(e, t) {
    if (0 === e.length) return "";
    var n = "\n" + t.prev + t.base;
    return n + fs.call(e, "," + n) + "\n" + t.prev
}

function Hs(e, t) {
    var n = Os(e),
        r = [];
    if (n) {
        r.length = e.length;
        for (var o = 0; o < e.length; o++) r[o] = Ls(e, o) ? t(e[o], e) : ""
    }
    var i, a = "function" == typeof gs ? gs(e) : [];
    if (bs) {
        i = {};
        for (var s = 0; s < a.length; s++) i["$" + a[s]] = a[s]
    }
    for (var l in e) Ls(e, l) && (n && String(Number(l)) === l && l < e.length || bs && i["$" + l] instanceof Symbol || (ds.call(/[^\w$]/, l) ? r.push(t(l, e) + ": " + t(e[l], e)) : r.push(l + ": " + t(e[l], e))));
    if ("function" == typeof gs)
        for (var c = 0; c < a.length; c++) ws.call(e, a[c]) && r.push("[" + t(a[c]) + "]: " + t(e[a[c]], e));
    return r
}
var qs = _a,
    Us = function(e, t) {
        var n = qa(e, !!t);
        return "function" == typeof n && za(e, ".prototype.") > -1 ? Ua(n) : n
    },
    zs = function e(t, n, r, o) {
        var i = n || {};
        if (Ls(i, "quoteStyle") && "single" !== i.quoteStyle && "double" !== i.quoteStyle) throw new TypeError('option "quoteStyle" must be "single" or "double"');
        if (Ls(i, "maxStringLength") && ("number" == typeof i.maxStringLength ? i.maxStringLength < 0 && i.maxStringLength !== 1 / 0 : null !== i.maxStringLength)) throw new TypeError('option "maxStringLength", if provided, must be a positive integer, Infinity, or `null`');
        var a = !Ls(i, "customInspect") || i.customInspect;
        if ("boolean" != typeof a && "symbol" !== a) throw new TypeError("option \"customInspect\", if provided, must be `true`, `false`, or `'symbol'`");
        if (Ls(i, "indent") && null !== i.indent && "\t" !== i.indent && !(parseInt(i.indent, 10) === i.indent && i.indent > 0)) throw new TypeError('option "indent" must be "\\t", an integer > 0, or `null`');
        if (Ls(i, "numericSeparator") && "boolean" != typeof i.numericSeparator) throw new TypeError('option "numericSeparator", if provided, must be `true` or `false`');
        var s = i.numericSeparator;
        if (void 0 === t) return "undefined";
        if (null === t) return "null";
        if ("boolean" == typeof t) return t ? "true" : "false";
        if ("string" == typeof t) return Ns(t, i);
        if ("number" == typeof t) {
            if (0 === t) return 1 / 0 / t > 0 ? "0" : "-0";
            var l = String(t);
            return s ? Ss(t, l) : l
        }
        if ("bigint" == typeof t) {
            var c = String(t) + "n";
            return s ? Ss(t, c) : c
        }
        var u = void 0 === i.depth ? 5 : i.depth;
        if (void 0 === r && (r = 0), r >= u && u > 0 && "object" == typeof t) return Os(t) ? "[Array]" : "[Object]";
        var d = function(e, t) {
            var n;
            if ("\t" === e.indent) n = "\t";
            else {
                if (!("number" == typeof e.indent && e.indent > 0)) return null;
                n = fs.call(Array(e.indent + 1), " ")
            }
            return {
                base: n,
                prev: fs.call(Array(t + 1), n)
            }
        }(i, r);
        if (void 0 === o) o = [];
        else if (Ms(o, t) >= 0) return "[Circular]";

        function p(t, n, a) {
            if (n && (o = ms.call(o)).push(n), a) {
                var s = {
                    depth: i.depth
                };
                return Ls(i, "quoteStyle") && (s.quoteStyle = i.quoteStyle), e(t, s, r + 1, o)
            }
            return e(t, i, r + 1, o)
        }
        if ("function" == typeof t && !Es(t)) {
            var f = function(e) {
                    if (e.name) return e.name;
                    var t = as.call(is.call(e), /^function\s*([\w$]+)/);
                    if (t) return t[1];
                    return null
                }(t),
                m = Hs(t, p);
            return "[Function" + (f ? ": " + f : " (anonymous)") + "]" + (m.length > 0 ? " { " + fs.call(m, ", ") + " }" : "")
        }
        if (Is(t)) {
            var h = bs ? ls.call(String(t), /^(Symbol\(.*\))_[^)]*$/, "$1") : vs.call(t);
            return "object" != typeof t || bs ? h : Rs(h)
        }
        if (function(e) {
                if (!e || "object" != typeof e) return !1;
                if ("undefined" != typeof HTMLElement && e instanceof HTMLElement) return !0;
                return "string" == typeof e.nodeName && "function" == typeof e.getAttribute
            }(t)) {
            for (var y = "<" + us.call(String(t.nodeName)), v = t.attributes || [], b = 0; b < v.length; b++) y += " " + v[b].name + "=" + As(Ds(v[b].value), "double", i);
            return y += ">", t.childNodes && t.childNodes.length && (y += "..."), y += "</" + us.call(String(t.nodeName)) + ">"
        }
        if (Os(t)) {
            if (0 === t.length) return "[]";
            var x = Hs(t, p);
            return d && ! function(e) {
                for (var t = 0; t < e.length; t++)
                    if (Ms(e[t], "\n") >= 0) return !1;
                return !0
            }(x) ? "[" + Bs(x, d) + "]" : "[ " + fs.call(x, ", ") + " ]"
        }
        if (function(e) {
                return !("[object Error]" !== Ps(e) || xs && "object" == typeof e && xs in e)
            }(t)) {
            var w = Hs(t, p);
            return "cause" in Error.prototype || !("cause" in t) || ws.call(t, "cause") ? 0 === w.length ? "[" + String(t) + "]" : "{ [" + String(t) + "] " + fs.call(w, ", ") + " }" : "{ [" + String(t) + "] " + fs.call(ps.call("[cause]: " + p(t.cause), w), ", ") + " }"
        }
        if ("object" == typeof t && a) {
            if (Ts && "function" == typeof t[Ts] && Cs) return Cs(t, {
                depth: u - r
            });
            if ("symbol" !== a && "function" == typeof t.inspect) return t.inspect()
        }
        if (function(e) {
                if (!Ga || !e || "object" != typeof e) return !1;
                try {
                    Ga.call(e);
                    try {
                        Xa.call(e)
                    } catch (y) {
                        return !0
                    }
                    return e instanceof Map
                } catch (Fy) {}
                return !1
            }(t)) {
            var k = [];
            return Ya && Ya.call(t, (function(e, n) {
                k.push(p(n, t, !0) + " => " + p(e, t))
            })), Vs("Map", Ga.call(t), k, d)
        }
        if (function(e) {
                if (!Xa || !e || "object" != typeof e) return !1;
                try {
                    Xa.call(e);
                    try {
                        Ga.call(e)
                    } catch (t) {
                        return !0
                    }
                    return e instanceof Set
                } catch (Fy) {}
                return !1
            }(t)) {
            var S = [];
            return Qa && Qa.call(t, (function(e) {
                S.push(p(e, t))
            })), Vs("Set", Xa.call(t), S, d)
        }
        if (function(e) {
                if (!es || !e || "object" != typeof e) return !1;
                try {
                    es.call(e, es);
                    try {
                        ts.call(e, ts)
                    } catch (y) {
                        return !0
                    }
                    return e instanceof WeakMap
                } catch (Fy) {}
                return !1
            }(t)) return Ws("WeakMap");
        if (function(e) {
                if (!ts || !e || "object" != typeof e) return !1;
                try {
                    ts.call(e, ts);
                    try {
                        es.call(e, es)
                    } catch (y) {
                        return !0
                    }
                    return e instanceof WeakSet
                } catch (Fy) {}
                return !1
            }(t)) return Ws("WeakSet");
        if (function(e) {
                if (!ns || !e || "object" != typeof e) return !1;
                try {
                    return ns.call(e), !0
                } catch (Fy) {}
                return !1
            }(t)) return Ws("WeakRef");
        if (function(e) {
                return !("[object Number]" !== Ps(e) || xs && "object" == typeof e && xs in e)
            }(t)) return Rs(p(Number(t)));
        if (function(e) {
                if (!e || "object" != typeof e || !ys) return !1;
                try {
                    return ys.call(e), !0
                } catch (Fy) {}
                return !1
            }(t)) return Rs(p(ys.call(t)));
        if (function(e) {
                return !("[object Boolean]" !== Ps(e) || xs && "object" == typeof e && xs in e)
            }(t)) return Rs(rs.call(t));
        if (function(e) {
                return !("[object String]" !== Ps(e) || xs && "object" == typeof e && xs in e)
            }(t)) return Rs(p(String(t)));
        if ("undefined" != typeof window && t === window) return "{ [object Window] }";
        if (t === g) return "{ [object globalThis] }";
        if (! function(e) {
                return !("[object Date]" !== Ps(e) || xs && "object" == typeof e && xs in e)
            }(t) && !Es(t)) {
            var C = Hs(t, p),
                _ = ks ? ks(t) === Object.prototype : t instanceof Object || t.constructor === Object,
                T = t instanceof Object ? "" : "null prototype",
                A = !_ && xs && Object(t) === t && xs in t ? ss.call(Ps(t), 8, -1) : T ? "Object" : "",
                D = (_ || "function" != typeof t.constructor ? "" : t.constructor.name ? t.constructor.name + " " : "") + (A || T ? "[" + fs.call(ps.call([], A || [], T || []), ": ") + "] " : "");
            return 0 === C.length ? D + "{}" : d ? D + "{" + Bs(C, d) + "}" : D + "{ " + fs.call(C, ", ") + " }"
        }
        return String(t)
    },
    $s = ji,
    Zs = qs("%WeakMap%", !0),
    Gs = qs("%Map%", !0),
    Ys = Us("WeakMap.prototype.get", !0),
    Js = Us("WeakMap.prototype.set", !0),
    Ks = Us("WeakMap.prototype.has", !0),
    Xs = Us("Map.prototype.get", !0),
    Qs = Us("Map.prototype.set", !0),
    el = Us("Map.prototype.has", !0),
    tl = function(e, t) {
        for (var n, r = e; null !== (n = r.next); r = n)
            if (n.key === t) return r.next = n.next, n.next = e.next, e.next = n, n
    },
    nl = String.prototype.replace,
    rl = /%20/g,
    ol = "RFC3986",
    il = {
        default: ol,
        formatters: {
            RFC1738: function(e) {
                return nl.call(e, rl, "+")
            },
            RFC3986: function(e) {
                return String(e)
            }
        },
        RFC1738: "RFC1738",
        RFC3986: ol
    },
    al = il,
    sl = Object.prototype.hasOwnProperty,
    ll = Array.isArray,
    cl = function() {
        for (var e = [], t = 0; t < 256; ++t) e.push("%" + ((t < 16 ? "0" : "") + t.toString(16)).toUpperCase());
        return e
    }(),
    ul = function(e, t) {
        for (var n = t && t.plainObjects ? Object.create(null) : {}, r = 0; r < e.length; ++r) void 0 !== e[r] && (n[r] = e[r]);
        return n
    },
    dl = 1024,
    pl = {
        arrayToObject: ul,
        assign: function(e, t) {
            return Object.keys(t).reduce((function(e, n) {
                return e[n] = t[n], e
            }), e)
        },
        combine: function(e, t) {
            return [].concat(e, t)
        },
        compact: function(e) {
            for (var t = [{
                    obj: {
                        o: e
                    },
                    prop: "o"
                }], n = [], r = 0; r < t.length; ++r)
                for (var o = t[r], i = o.obj[o.prop], a = Object.keys(i), s = 0; s < a.length; ++s) {
                    var l = a[s],
                        c = i[l];
                    "object" == typeof c && null !== c && -1 === n.indexOf(c) && (t.push({
                        obj: i,
                        prop: l
                    }), n.push(c))
                }
            return function(e) {
                for (; e.length > 1;) {
                    var t = e.pop(),
                        n = t.obj[t.prop];
                    if (ll(n)) {
                        for (var r = [], o = 0; o < n.length; ++o) void 0 !== n[o] && r.push(n[o]);
                        t.obj[t.prop] = r
                    }
                }
            }(t), e
        },
        decode: function(e, t, n) {
            var r = e.replace(/\+/g, " ");
            if ("iso-8859-1" === n) return r.replace(/%[0-9a-f]{2}/gi, unescape);
            try {
                return decodeURIComponent(r)
            } catch (Fy) {
                return r
            }
        },
        encode: function(e, t, n, r, o) {
            if (0 === e.length) return e;
            var i = e;
            if ("symbol" == typeof e ? i = Symbol.prototype.toString.call(e) : "string" != typeof e && (i = String(e)), "iso-8859-1" === n) return escape(i).replace(/%u[0-9a-f]{4}/gi, (function(e) {
                return "%26%23" + parseInt(e.slice(2), 16) + "%3B"
            }));
            for (var a = "", s = 0; s < i.length; s += dl) {
                for (var l = i.length >= dl ? i.slice(s, s + dl) : i, c = [], u = 0; u < l.length; ++u) {
                    var d = l.charCodeAt(u);
                    45 === d || 46 === d || 95 === d || 126 === d || d >= 48 && d <= 57 || d >= 65 && d <= 90 || d >= 97 && d <= 122 || o === al.RFC1738 && (40 === d || 41 === d) ? c[c.length] = l.charAt(u) : d < 128 ? c[c.length] = cl[d] : d < 2048 ? c[c.length] = cl[192 | d >> 6] + cl[128 | 63 & d] : d < 55296 || d >= 57344 ? c[c.length] = cl[224 | d >> 12] + cl[128 | d >> 6 & 63] + cl[128 | 63 & d] : (u += 1, d = 65536 + ((1023 & d) << 10 | 1023 & l.charCodeAt(u)), c[c.length] = cl[240 | d >> 18] + cl[128 | d >> 12 & 63] + cl[128 | d >> 6 & 63] + cl[128 | 63 & d])
                }
                a += c.join("")
            }
            return a
        },
        isBuffer: function(e) {
            return !(!e || "object" != typeof e) && !!(e.constructor && e.constructor.isBuffer && e.constructor.isBuffer(e))
        },
        isRegExp: function(e) {
            return "[object RegExp]" === Object.prototype.toString.call(e)
        },
        maybeMap: function(e, t) {
            if (ll(e)) {
                for (var n = [], r = 0; r < e.length; r += 1) n.push(t(e[r]));
                return n
            }
            return t(e)
        },
        merge: function e(t, n, r) {
            if (!n) return t;
            if ("object" != typeof n) {
                if (ll(t)) t.push(n);
                else {
                    if (!t || "object" != typeof t) return [t, n];
                    (r && (r.plainObjects || r.allowPrototypes) || !sl.call(Object.prototype, n)) && (t[n] = !0)
                }
                return t
            }
            if (!t || "object" != typeof t) return [t].concat(n);
            var o = t;
            return ll(t) && !ll(n) && (o = ul(t, r)), ll(t) && ll(n) ? (n.forEach((function(n, o) {
                if (sl.call(t, o)) {
                    var i = t[o];
                    i && "object" == typeof i && n && "object" == typeof n ? t[o] = e(i, n, r) : t.push(n)
                } else t[o] = n
            })), t) : Object.keys(n).reduce((function(t, o) {
                var i = n[o];
                return sl.call(t, o) ? t[o] = e(t[o], i, r) : t[o] = i, t
            }), o)
        }
    },
    fl = function() {
        var e, t, n, r = {
            assert: function(e) {
                if (!r.has(e)) throw new $s("Side channel does not contain " + zs(e))
            },
            get: function(r) {
                if (Zs && r && ("object" == typeof r || "function" == typeof r)) {
                    if (e) return Ys(e, r)
                } else if (Gs) {
                    if (t) return Xs(t, r)
                } else if (n) return function(e, t) {
                    var n = tl(e, t);
                    return n && n.value
                }(n, r)
            },
            has: function(r) {
                if (Zs && r && ("object" == typeof r || "function" == typeof r)) {
                    if (e) return Ks(e, r)
                } else if (Gs) {
                    if (t) return el(t, r)
                } else if (n) return function(e, t) {
                    return !!tl(e, t)
                }(n, r);
                return !1
            },
            set: function(r, o) {
                Zs && r && ("object" == typeof r || "function" == typeof r) ? (e || (e = new Zs), Js(e, r, o)) : Gs ? (t || (t = new Gs), Qs(t, r, o)) : (n || (n = {
                    key: {},
                    next: null
                }), function(e, t, n) {
                    var r = tl(e, t);
                    r ? r.value = n : e.next = {
                        key: t,
                        next: e.next,
                        value: n
                    }
                }(n, r, o))
            }
        };
        return r
    },
    ml = pl,
    hl = il,
    yl = Object.prototype.hasOwnProperty,
    gl = {
        brackets: function(e) {
            return e + "[]"
        },
        comma: "comma",
        indices: function(e, t) {
            return e + "[" + t + "]"
        },
        repeat: function(e) {
            return e
        }
    },
    vl = Array.isArray,
    bl = Array.prototype.push,
    xl = function(e, t) {
        bl.apply(e, vl(t) ? t : [t])
    },
    wl = Date.prototype.toISOString,
    kl = hl.default,
    Sl = {
        addQueryPrefix: !1,
        allowDots: !1,
        allowEmptyArrays: !1,
        arrayFormat: "indices",
        charset: "utf-8",
        charsetSentinel: !1,
        delimiter: "&",
        encode: !0,
        encodeDotInKeys: !1,
        encoder: ml.encode,
        encodeValuesOnly: !1,
        format: kl,
        formatter: hl.formatters[kl],
        indices: !1,
        serializeDate: function(e) {
            return wl.call(e)
        },
        skipNulls: !1,
        strictNullHandling: !1
    },
    Cl = {},
    _l = function e(t, n, r, o, i, a, s, l, c, u, d, p, f, m, h, y, g, v) {
        for (var b, x = t, w = v, k = 0, S = !1; void 0 !== (w = w.get(Cl)) && !S;) {
            var C = w.get(t);
            if (k += 1, void 0 !== C) {
                if (C === k) throw new RangeError("Cyclic object value");
                S = !0
            }
            void 0 === w.get(Cl) && (k = 0)
        }
        if ("function" == typeof u ? x = u(n, x) : x instanceof Date ? x = f(x) : "comma" === r && vl(x) && (x = ml.maybeMap(x, (function(e) {
                return e instanceof Date ? f(e) : e
            }))), null === x) {
            if (a) return c && !y ? c(n, Sl.encoder, g, "key", m) : n;
            x = ""
        }
        if ("string" == typeof(b = x) || "number" == typeof b || "boolean" == typeof b || "symbol" == typeof b || "bigint" == typeof b || ml.isBuffer(x)) return c ? [h(y ? n : c(n, Sl.encoder, g, "key", m)) + "=" + h(c(x, Sl.encoder, g, "value", m))] : [h(n) + "=" + h(String(x))];
        var _, T = [];
        if (void 0 === x) return T;
        if ("comma" === r && vl(x)) y && c && (x = ml.maybeMap(x, c)), _ = [{
            value: x.length > 0 ? x.join(",") || null : void 0
        }];
        else if (vl(u)) _ = u;
        else {
            var A = Object.keys(x);
            _ = d ? A.sort(d) : A
        }
        var D = l ? n.replace(/\./g, "%2E") : n,
            O = o && vl(x) && 1 === x.length ? D + "[]" : D;
        if (i && vl(x) && 0 === x.length) return O + "[]";
        for (var E = 0; E < _.length; ++E) {
            var I = _[E],
                j = "object" == typeof I && void 0 !== I.value ? I.value : x[I];
            if (!s || null !== j) {
                var L = p && l ? I.replace(/\./g, "%2E") : I,
                    P = vl(x) ? "function" == typeof r ? r(O, L) : O : O + (p ? "." + L : "[" + L + "]");
                v.set(t, k);
                var M = fl();
                M.set(Cl, v), xl(T, e(j, P, r, o, i, a, s, l, "comma" === r && y && vl(x) ? null : c, u, d, p, f, m, h, y, g, M))
            }
        }
        return T
    },
    Tl = pl,
    Al = Object.prototype.hasOwnProperty,
    Dl = Array.isArray,
    Ol = {
        allowDots: !1,
        allowEmptyArrays: !1,
        allowPrototypes: !1,
        allowSparse: !1,
        arrayLimit: 20,
        charset: "utf-8",
        charsetSentinel: !1,
        comma: !1,
        decodeDotInKeys: !1,
        decoder: Tl.decode,
        delimiter: "&",
        depth: 5,
        duplicates: "combine",
        ignoreQueryPrefix: !1,
        interpretNumericEntities: !1,
        parameterLimit: 1e3,
        parseArrays: !0,
        plainObjects: !1,
        strictDepth: !1,
        strictNullHandling: !1
    },
    El = function(e) {
        return e.replace(/&#(\d+);/g, (function(e, t) {
            return String.fromCharCode(parseInt(t, 10))
        }))
    },
    Il = function(e, t) {
        return e && "string" == typeof e && t.comma && e.indexOf(",") > -1 ? e.split(",") : e
    },
    jl = function(e, t, n, r) {
        if (e) {
            var o = n.allowDots ? e.replace(/\.([^.[]+)/g, "[$1]") : e,
                i = /(\[[^[\]]*])/g,
                a = n.depth > 0 && /(\[[^[\]]*])/.exec(o),
                s = a ? o.slice(0, a.index) : o,
                l = [];
            if (s) {
                if (!n.plainObjects && Al.call(Object.prototype, s) && !n.allowPrototypes) return;
                l.push(s)
            }
            for (var c = 0; n.depth > 0 && null !== (a = i.exec(o)) && c < n.depth;) {
                if (c += 1, !n.plainObjects && Al.call(Object.prototype, a[1].slice(1, -1)) && !n.allowPrototypes) return;
                l.push(a[1])
            }
            if (a) {
                if (!0 === n.strictDepth) throw new RangeError("Input depth exceeded depth option of " + n.depth + " and strictDepth is true");
                l.push("[" + o.slice(a.index) + "]")
            }
            return function(e, t, n, r) {
                for (var o = r ? t : Il(t, n), i = e.length - 1; i >= 0; --i) {
                    var a, s = e[i];
                    if ("[]" === s && n.parseArrays) a = n.allowEmptyArrays && ("" === o || n.strictNullHandling && null === o) ? [] : [].concat(o);
                    else {
                        a = n.plainObjects ? Object.create(null) : {};
                        var l = "[" === s.charAt(0) && "]" === s.charAt(s.length - 1) ? s.slice(1, -1) : s,
                            c = n.decodeDotInKeys ? l.replace(/%2E/g, ".") : l,
                            u = parseInt(c, 10);
                        n.parseArrays || "" !== c ? !isNaN(u) && s !== c && String(u) === c && u >= 0 && n.parseArrays && u <= n.arrayLimit ? (a = [])[u] = o : "__proto__" !== c && (a[c] = o) : a = {
                            0: o
                        }
                    }
                    o = a
                }
                return o
            }(l, t, n, r)
        }
    };
const Ll = v({
        formats: il,
        parse: function(e, t) {
            var n = function(e) {
                if (!e) return Ol;
                if (void 0 !== e.allowEmptyArrays && "boolean" != typeof e.allowEmptyArrays) throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
                if (void 0 !== e.decodeDotInKeys && "boolean" != typeof e.decodeDotInKeys) throw new TypeError("`decodeDotInKeys` option can only be `true` or `false`, when provided");
                if (null !== e.decoder && void 0 !== e.decoder && "function" != typeof e.decoder) throw new TypeError("Decoder has to be a function.");
                if (void 0 !== e.charset && "utf-8" !== e.charset && "iso-8859-1" !== e.charset) throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
                var t = void 0 === e.charset ? Ol.charset : e.charset,
                    n = void 0 === e.duplicates ? Ol.duplicates : e.duplicates;
                if ("combine" !== n && "first" !== n && "last" !== n) throw new TypeError("The duplicates option must be either combine, first, or last");
                return {
                    allowDots: void 0 === e.allowDots ? !0 === e.decodeDotInKeys || Ol.allowDots : !!e.allowDots,
                    allowEmptyArrays: "boolean" == typeof e.allowEmptyArrays ? !!e.allowEmptyArrays : Ol.allowEmptyArrays,
                    allowPrototypes: "boolean" == typeof e.allowPrototypes ? e.allowPrototypes : Ol.allowPrototypes,
                    allowSparse: "boolean" == typeof e.allowSparse ? e.allowSparse : Ol.allowSparse,
                    arrayLimit: "number" == typeof e.arrayLimit ? e.arrayLimit : Ol.arrayLimit,
                    charset: t,
                    charsetSentinel: "boolean" == typeof e.charsetSentinel ? e.charsetSentinel : Ol.charsetSentinel,
                    comma: "boolean" == typeof e.comma ? e.comma : Ol.comma,
                    decodeDotInKeys: "boolean" == typeof e.decodeDotInKeys ? e.decodeDotInKeys : Ol.decodeDotInKeys,
                    decoder: "function" == typeof e.decoder ? e.decoder : Ol.decoder,
                    delimiter: "string" == typeof e.delimiter || Tl.isRegExp(e.delimiter) ? e.delimiter : Ol.delimiter,
                    depth: "number" == typeof e.depth || !1 === e.depth ? +e.depth : Ol.depth,
                    duplicates: n,
                    ignoreQueryPrefix: !0 === e.ignoreQueryPrefix,
                    interpretNumericEntities: "boolean" == typeof e.interpretNumericEntities ? e.interpretNumericEntities : Ol.interpretNumericEntities,
                    parameterLimit: "number" == typeof e.parameterLimit ? e.parameterLimit : Ol.parameterLimit,
                    parseArrays: !1 !== e.parseArrays,
                    plainObjects: "boolean" == typeof e.plainObjects ? e.plainObjects : Ol.plainObjects,
                    strictDepth: "boolean" == typeof e.strictDepth ? !!e.strictDepth : Ol.strictDepth,
                    strictNullHandling: "boolean" == typeof e.strictNullHandling ? e.strictNullHandling : Ol.strictNullHandling
                }
            }(t);
            if ("" === e || null == e) return n.plainObjects ? Object.create(null) : {};
            for (var r = "string" == typeof e ? function(e, t) {
                    var n = {
                            __proto__: null
                        },
                        r = t.ignoreQueryPrefix ? e.replace(/^\?/, "") : e;
                    r = r.replace(/%5B/gi, "[").replace(/%5D/gi, "]");
                    var o, i = t.parameterLimit === 1 / 0 ? void 0 : t.parameterLimit,
                        a = r.split(t.delimiter, i),
                        s = -1,
                        l = t.charset;
                    if (t.charsetSentinel)
                        for (o = 0; o < a.length; ++o) 0 === a[o].indexOf("utf8=") && ("utf8=%E2%9C%93" === a[o] ? l = "utf-8" : "utf8=%26%2310003%3B" === a[o] && (l = "iso-8859-1"), s = o, o = a.length);
                    for (o = 0; o < a.length; ++o)
                        if (o !== s) {
                            var c, u, d = a[o],
                                p = d.indexOf("]="),
                                f = -1 === p ? d.indexOf("=") : p + 1; - 1 === f ? (c = t.decoder(d, Ol.decoder, l, "key"), u = t.strictNullHandling ? null : "") : (c = t.decoder(d.slice(0, f), Ol.decoder, l, "key"), u = Tl.maybeMap(Il(d.slice(f + 1), t), (function(e) {
                                return t.decoder(e, Ol.decoder, l, "value")
                            }))), u && t.interpretNumericEntities && "iso-8859-1" === l && (u = El(u)), d.indexOf("[]=") > -1 && (u = Dl(u) ? [u] : u);
                            var m = Al.call(n, c);
                            m && "combine" === t.duplicates ? n[c] = Tl.combine(n[c], u) : m && "last" !== t.duplicates || (n[c] = u)
                        }
                    return n
                }(e, n) : e, o = n.plainObjects ? Object.create(null) : {}, i = Object.keys(r), a = 0; a < i.length; ++a) {
                var s = i[a],
                    l = jl(s, r[s], n, "string" == typeof e);
                o = Tl.merge(o, l, n)
            }
            return !0 === n.allowSparse ? o : Tl.compact(o)
        },
        stringify: function(e, t) {
            var n, r = e,
                o = function(e) {
                    if (!e) return Sl;
                    if (void 0 !== e.allowEmptyArrays && "boolean" != typeof e.allowEmptyArrays) throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
                    if (void 0 !== e.encodeDotInKeys && "boolean" != typeof e.encodeDotInKeys) throw new TypeError("`encodeDotInKeys` option can only be `true` or `false`, when provided");
                    if (null !== e.encoder && void 0 !== e.encoder && "function" != typeof e.encoder) throw new TypeError("Encoder has to be a function.");
                    var t = e.charset || Sl.charset;
                    if (void 0 !== e.charset && "utf-8" !== e.charset && "iso-8859-1" !== e.charset) throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
                    var n = hl.default;
                    if (void 0 !== e.format) {
                        if (!yl.call(hl.formatters, e.format)) throw new TypeError("Unknown format option provided.");
                        n = e.format
                    }
                    var r, o = hl.formatters[n],
                        i = Sl.filter;
                    if (("function" == typeof e.filter || vl(e.filter)) && (i = e.filter), r = e.arrayFormat in gl ? e.arrayFormat : "indices" in e ? e.indices ? "indices" : "repeat" : Sl.arrayFormat, "commaRoundTrip" in e && "boolean" != typeof e.commaRoundTrip) throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
                    var a = void 0 === e.allowDots ? !0 === e.encodeDotInKeys || Sl.allowDots : !!e.allowDots;
                    return {
                        addQueryPrefix: "boolean" == typeof e.addQueryPrefix ? e.addQueryPrefix : Sl.addQueryPrefix,
                        allowDots: a,
                        allowEmptyArrays: "boolean" == typeof e.allowEmptyArrays ? !!e.allowEmptyArrays : Sl.allowEmptyArrays,
                        arrayFormat: r,
                        charset: t,
                        charsetSentinel: "boolean" == typeof e.charsetSentinel ? e.charsetSentinel : Sl.charsetSentinel,
                        commaRoundTrip: e.commaRoundTrip,
                        delimiter: void 0 === e.delimiter ? Sl.delimiter : e.delimiter,
                        encode: "boolean" == typeof e.encode ? e.encode : Sl.encode,
                        encodeDotInKeys: "boolean" == typeof e.encodeDotInKeys ? e.encodeDotInKeys : Sl.encodeDotInKeys,
                        encoder: "function" == typeof e.encoder ? e.encoder : Sl.encoder,
                        encodeValuesOnly: "boolean" == typeof e.encodeValuesOnly ? e.encodeValuesOnly : Sl.encodeValuesOnly,
                        filter: i,
                        format: n,
                        formatter: o,
                        serializeDate: "function" == typeof e.serializeDate ? e.serializeDate : Sl.serializeDate,
                        skipNulls: "boolean" == typeof e.skipNulls ? e.skipNulls : Sl.skipNulls,
                        sort: "function" == typeof e.sort ? e.sort : null,
                        strictNullHandling: "boolean" == typeof e.strictNullHandling ? e.strictNullHandling : Sl.strictNullHandling
                    }
                }(t);
            "function" == typeof o.filter ? r = (0, o.filter)("", r) : vl(o.filter) && (n = o.filter);
            var i = [];
            if ("object" != typeof r || null === r) return "";
            var a = gl[o.arrayFormat],
                s = "comma" === a && o.commaRoundTrip;
            n || (n = Object.keys(r)), o.sort && n.sort(o.sort);
            for (var l = fl(), c = 0; c < n.length; ++c) {
                var u = n[c];
                o.skipNulls && null === r[u] || xl(i, _l(r[u], u, a, s, o.allowEmptyArrays, o.strictNullHandling, o.skipNulls, o.encodeDotInKeys, o.encode ? o.encoder : null, o.filter, o.sort, o.allowDots, o.serializeDate, o.format, o.formatter, o.encodeValuesOnly, o.charset, l))
            }
            var d = i.join(o.delimiter),
                p = !0 === o.addQueryPrefix ? "?" : "";
            return o.charsetSentinel && ("iso-8859-1" === o.charset ? p += "utf8=%26%2310003%3B&" : p += "utf8=%E2%9C%93&"), d.length > 0 ? p + d : ""
        }
    }),
    {
        Api: Pl
    } = s(),
    Ml = async e => Pl.getHistory(Ll.stringify(e)).then((e => {
        if ("ok" !== e.status && !e.data.length) return [null];
        return [e.data.map((e => ({
            time: e[0],
            open: e[1],
            high: e[2],
            low: e[3],
            close: e[4],
            volume: e[5]
        }))).sort(((e, t) => e.time > t.time ? 1 : -1))]
    })),
    Nl = 36e5,
    Fl = {
        1: "1MIN",
        5: "5MINS",
        15: "15MINS",
        30: "30MINS",
        60: "1HOUR",
        "1D": "1DAY"
    },
    Rl = {
        1: {
            defaultRange: Nl
        },
        5: {
            defaultRange: 5 * Nl
        },
        15: {
            defaultRange: 15 * Nl
        },
        30: {
            defaultRange: 30 * Nl
        },
        60: {
            defaultRange: 3 * 864e5
        },
        "1D": {
            defaultRange: 2 * 2628e6
        }
    },
    Wl = Ci.local().get("zoneName"),
    Vl = {
        supported_resolutions: Object.keys(Fl),
        exchanges: [{
            value: "OPZ",
            name: "OPZ",
            desc: "OPZ Exchange"
        }],
        symbols_types: [{
            name: "crypto",
            value: "crypto"
        }]
    },
    Bl = (e, t, n, r, o, i) => ({
        onReady: e => {
            setTimeout((() => e(Vl)))
        },
        updateKLine: (e, t, n, r) => {
            r([])
        },
        searchSymbols: (e, t, n, r) => {
            r([])
        },
        resolveSymbol: async (t, n, r) => {
            const o = {
                ticker: t,
                name: t,
                description: t,
                type: "crypto",
                full_name: t,
                exchange: "OPZ",
                listed_exchange: "OPZ",
                has_intraday: !0,
                has_daily: !0,
                minmov: 1,
                pricescale: Math.pow(10, e),
                session: "24x7",
                intraday_multipliers: ["1", "5", "15", "30", "60"],
                supported_resolutions: Vl.supported_resolutions,
                data_status: "streaming",
                timezone: Wl,
                format: "price"
            };
            setTimeout((() => n(o)), 0)
        },
        getBars: async (e, t, n, r, o) => {
            if (!e) return;
            const {
                countBack: i,
                from: a,
                to: s,
                firstDataRequest: l
            } = n, c = 1e3 * a;
            let u = 1e3 * s;
            l && "1D" === t && (u += 1);
            try {
                if (!l) {
                    const [n] = await Ml({
                        symbol: e.name,
                        resolution: t,
                        from: c,
                        to: u
                    });
                    return void r(n || [], {
                        noData: !n
                    })
                }
                const [n] = await Ml({
                    symbol: e.name,
                    resolution: t,
                    from: c,
                    to: u
                });
                return void r(n || [], {
                    noData: !n
                })
            } catch (d) {}
        },
        subscribeBars: (e, t, r, o, i) => {
            n(o, e.name, r)
        },
        unsubscribeBars: e => {
            r(e)
        }
    }),
    Hl = Ci.local().get("zoneName"),
    ql = {
        name: "KLineWidget",
        props: {
            symbol: {
                type: String
            },
            stompClient: {
                type: V
            },
            basep: {
                type: Number
            },
            pricep: {
                type: Number
            },
            mobileWidth: {
                type: Boolean
            }
        },
        emits: ["depth"],
        setup(e, {
            emit: t
        }) {
            const n = l(null),
                r = l(!1),
                o = l("5min"),
                {
                    symbol: i,
                    stompClient: a,
                    basep: s,
                    pricep: u
                } = b(e);
            l(null), l(null);
            const d = l(!1),
                p = x(),
                f = (e, t, n) => {
                    a.value.subscribe("/topic/market/kline/" + t, (function(e) {
                        d.value || (d.value = !0, m.value = e.headers.subscription);
                        var t = JSON.parse(e.body);
                        n({
                            time: t.time,
                            open: t.openPrice,
                            high: t.highestPrice,
                            low: t.lowestPrice,
                            close: t.closePrice,
                            volume: t.volume
                        })
                    }))
                },
                m = l(""),
                h = e => {
                    a.value.unsubscribe(e || m.value), d.value = !1, m.value = ""
                },
                {
                    t: y,
                    locale: g
                } = w(),
                v = ["ar", "cs", "da_DK", "de", "el", "en", "es", "et_EE", "fa", "fr", "he_IL", "hu_HU", "id_ID", "it", "ja", "ko", "ms_MY", "nl_NL", "no", "pl", "pt", "ro", "ru", "sk_SK", "sv", "th", "tr", "vi", "zh_TW", "zh"];

            function S(e) {
                return v.find((t => t.startsWith(e.substring(0, 2))))
            }
            const C = e => {
                const t = e.includes("-") ? e.replace("-", "_") : e;
                switch (t) {
                    case "zh_CN":
                        return "zh";
                    case "zh_TC":
                        return "en"
                }
                return v.includes(t) ? t : S(t) ? S(t) : "en"
            };
            k(g, (() => {
                n.value && (n.value.setLanguage(C(g.value)), n.value.headerReady().then((function() {
                    var e = n.value.createButton({
                        align: "right"
                    });
                    e.setAttribute("title", y("exh.depth")), e.addEventListener("click", (function() {
                        t("depth")
                    })), e.textContent = y("exh.depth")
                })))
            }));
            const _ = (() => {
                    const e = "#12b886",
                        t = "#fa5252",
                        n = "#131313";
                    return {
                        overrides: {
                            editorFontsList: ["DINPRO-Regular", "Courier New", "Times New Roman", "Arial"],
                            "paneProperties.background": "#131313",
                            "mainSeriesProperties.lineStyle.color": "#0094FF",
                            "mainSeriesProperties.lineStyle.linewidth": 1,
                            "mainSeriesProperties.lineStyle.priceSource": "close",
                            "paneProperties.vertGridProperties.color": "rgba(0,0,0,.1)",
                            "paneProperties.horzGridProperties.color": "rgba(0,0,0,.1)",
                            "scalesProperties.textColor": "#61688A",
                            "paneProperties.legendProperties.showLegend": !0,
                            "mainSeriesProperties.areaStyle.color1": "#606090",
                            "mainSeriesProperties.areaStyle.color2": "#1976d2",
                            "mainSeriesProperties.areaStyle.linecolor": "#0094FF",
                            "mainSeriesProperties.areaStyle.linewidth": 1,
                            "mainSeriesProperties.areaStyle.priceSource": "close",
                            volumePaneSize: "small",
                            "paneProperties.crossHairProperties.style": 1,
                            "paneProperties.legendProperties.showBarChange": !1,
                            "paneProperties.backgroundType": "solid",
                            "mainSeriesProperties.style": 1,
                            "mainSeriesProperties.candleStyle.upColor": e,
                            "mainSeriesProperties.candleStyle.borderUpColor": e,
                            "mainSeriesProperties.candleStyle.wickUpColor": e,
                            "mainSeriesProperties.candleStyle.downColor": t,
                            "mainSeriesProperties.candleStyle.borderDownColor": t,
                            "mainSeriesProperties.candleStyle.wickDownColor": t,
                            "mainSeriesProperties.statusViewStyle.symbolTextSource": "ticker",
                            "scalesProperties.backgroundColor": "#6e87a5",
                            "scalesProperties.lineColor": "#2b2b2b"
                        },
                        studies_overrides: {
                            "volume.volume.transparency": 25,
                            "volume.volume.color.0": "#632929",
                            "volume.volume.color.1": "#124c3b",
                            "volume.volume ma.visible": !1,
                            "volume.precision": 4,
                            "relative strength index.plot.color": "#7303fc",
                            "relative strength index.plot.linewidth": 1.5,
                            "relative strength index.hlines background.color": "#134A9F"
                        },
                        loading_screen: {
                            backgroundColor: n,
                            foregroundColor: n
                        }
                    }
                })(),
                T = () => {
                    n.value = new ct({ ..._,
                        fullscreen: !0,
                        autosize: !0,
                        height: e.mobileWidth ? 270 : 320,
                        toolbar_bg: "#131313",
                        theme: "Dark",
                        symbol: i.value,
                        interval: "5",
                        container: "tv_chart_container",
                        datafeed: Bl(s.value, o.value, f, h, 0, a.value),
                        library_path: "/assets/charting/",
                        locale: C(g.value),
                        favorites: {
                            intervals: ["1", "5", "15", "30", "60", "1D"],
                            chartTypes: ["Line"]
                        },
                        timezone: Hl,
                        drawings_access: {
                            type: "black",
                            tools: [{
                                name: "Regression Trend"
                            }]
                        },
                        custom_css_url: "/assets/charting/custom-styles.css",
                        enabled_features: ["remove_library_container_border", "hide_last_na_study_output", "dont_show_boolean_study_arguments", "hide_left_toolbar_by_default"],
                        disabled_features: p.isAdvancedChart ? ["header_symbol_search", "header_compare", "compare_symbol", "symbol_info", "border_around_the_chart", "symbol_search_hot_key"] : ["timeframes_toolbar", "header_symbol_search", "header_compare", "header_saveload", "volume_force_overlay", "compare_symbol", "go_to_date", "header_interval_dialog_button", "symbol_info", "control_bar", "border_around_the_chart", "symbol_search_hot_key"]
                    }), n.value.onChartReady((() => {
                        n.value.activeChart().createStudy("Moving Average", !1, !1, {
                            length: 7
                        }, {
                            "Plot.color": "#ab67fd",
                            showLabelsOnPriceScale: !1
                        }), e.mobileWidth || n.value.activeChart().createStudy("Moving Average", !1, !1, {
                            length: 25
                        }, {
                            "Plot.color": "#6702e2",
                            showLabelsOnPriceScale: !1
                        }), n.value.activeChart().onIntervalChanged().subscribe(null, ((e, t) => {
                            console.log("interval", e), (e => {
                                var t, r;
                                const {
                                    defaultRange: o
                                } = Rl[e], i = {
                                    from: (Date.now() - o) / 1e3,
                                    to: Date.now() / 1e3
                                };
                                null == (r = null == (t = n.value) ? void 0 : t.activeChart()) || r.setVisibleRange(i, {
                                    percentRightMargin: 10
                                })
                            })(e)
                        }))
                    })), n.value.headerReady().then((function() {
                        var e = n.value.createButton({
                            align: "right"
                        });
                        e.setAttribute("title", y("exh.depth")), e.addEventListener("click", (function() {
                            t("depth")
                        })), e.textContent = y("exh.depth")
                    }))
                };
            return c((() => {
                T()
            })), {
                widget: n,
                setSymbol: e => {
                    var t;
                    h(), i.value = e, null == (t = n.value) || t.setSymbol(e.toLocaleUpperCase(), ut[o.value], (() => {
                        console.log("------setSymbol---------", i.value)
                    }))
                },
                depths: r
            }
        }
    },
    Ul = {
        class: "kline"
    };
const zl = q(ql, [
        ["render", function(e, n, r, a, s, l) {
            return o(), t("div", Ul, n[0] || (n[0] = [i("div", {
                id: "tv_chart_container"
            }, null, -1)]))
        }]
    ]),
    $l = {
        key: 0,
        class: "text-center text-gray-300 w-100"
    },
    Zl = {
        key: 0,
        class: "text-gray2"
    },
    Gl = {
        class: "text-gray2"
    },
    Yl = {
        class: "text-gray2"
    },
    Jl = {
        class: "text-gray2"
    },
    Kl = {
        class: "text-gray2"
    },
    Xl = {
        class: "text-yellow-darken"
    },
    Ql = {
        class: "mob-table-header"
    },
    ec = {
        class: "mob-t-text"
    },
    tc = {
        class: "mob-t-text-end flex items-center"
    },
    nc = ["onClick"],
    rc = ["id"],
    oc = {
        class: "mob-data-top"
    },
    ic = {
        class: "mob-data-top-left"
    },
    ac = {
        class: "mob-data-top-right"
    },
    sc = {
        class: "mob-data-top"
    },
    lc = {
        class: "mob-data-top-left"
    },
    cc = {
        class: "mob-data-top-right"
    },
    uc = {
        class: "text-gray1"
    },
    dc = {
        class: "mob-data-top"
    },
    pc = {
        class: "mob-data-top-left"
    },
    fc = {
        class: "mob-data-top-right"
    },
    mc = {
        key: 0
    },
    hc = {
        class: "text-gray1"
    },
    yc = {
        key: 1
    },
    gc = {
        key: 0,
        class: "mob-data-top"
    },
    vc = {
        class: "mob-data-top-left"
    },
    bc = {
        class: "mob-data-top-right"
    },
    xc = {
        class: "text-gray1"
    },
    wc = {
        key: 1,
        class: "mob-data-top"
    },
    kc = {
        class: "mob-data-top-left"
    },
    Sc = {
        class: "mob-data-top-right"
    },
    Cc = {
        class: "text-gray1"
    },
    _c = {
        "aria-hidden": "true",
        class: "mob-data-bottom"
    },
    Tc = {
        class: "mob-data-bottom2"
    },
    Ac = {
        key: 0,
        class: "mob-data-top"
    },
    Dc = {
        class: "mob-data-top-left"
    },
    Oc = {
        direction: "buy",
        class: "mob-data-top-right"
    },
    Ec = {
        class: "text-gray1"
    },
    Ic = {
        key: 1,
        class: "mob-data-top"
    },
    jc = {
        class: "mob-data-top-left"
    },
    Lc = {
        class: "mob-data-top-right"
    },
    Pc = {
        class: "text-gray1"
    },
    Mc = {
        key: 0,
        class: "block-dis e864twd10"
    },
    Nc = {
        class: "text-gray1"
    },
    Fc = {
        key: 2,
        class: "mob-data-top"
    },
    Rc = {
        class: "mob-data-top-left"
    },
    Wc = {
        class: "mob-data-top-right"
    },
    Vc = ["onClick"],
    Bc = {
        class: "view-more"
    },
    Hc = q(e({
        __name: "OrderTable",
        props: {
            rows: {},
            trigger: {
                type: Boolean
            },
            mobileWidth: {
                type: Boolean
            },
            baseScale: {},
            modelValue: {
                type: Boolean,
                default: !0
            }
        },
        emits: ["orderCancel", "cancelAll"],
        setup(e, {
            emit: n
        }) {
            l(!0);
            const s = x();
            l(!1);
            const {
                t: c
            } = w(), g = e, v = (e, t) => {
                b("orderCancel", t.orderId)
            }, b = n, k = () => {
                b("cancelAll")
            };
            l(window.innerWidth <= 1472);
            const T = e => {
                let t = 0;
                return e.detail.forEach((e => {
                    t += e.price
                })), t > 0 ? t / e.detail.length : 0
            };
            return (e, n) => g.rows.length <= 0 ? (o(), t("p", $l, f(m(c)("exh.no-records-found")), 1)) : g.mobileWidth ? (o(!0), t(_, {
                key: 2
            }, C(g.rows, ((l, u) => {
                var d;
                return o(), t("div", {
                    key: u,
                    class: "mob-table"
                }, [i("div", Ql, [i("div", {
                    class: "mob-t-img",
                    style: p("background-image: url(/images/icons/coin/" + (null == (d = l.baseSymbol) ? void 0 : d.toLowerCase()) + ".svg")
                }, null, 4), i("div", ec, f(l.symbol), 1), i("div", {
                    class: r(["mob-t-text-small", "SELL" == l.direction ? "red-txt" : "green-txt"])
                }, f(("SELL" == l.direction ? m(c)("wall.sell") : m(c)("wall.buy")) + " " + (2 == l.type ? m(c)("exh.trigger") + " " : "") + (1 == l.type || 2 == l.type && Number(l.price) > 0 ? m(c)("wall.limit-order") : m(c)("wall.market-order"))), 3), i("div", tc, [i("img", {
                    src: "/images/svg/cancel-w.svg",
                    width: "14",
                    alt: "Cancel",
                    class: "cnc-img",
                    onClick: e => v(0, l)
                }, null, 8, nc)])]), i("div", {
                    id: "mob-table-" + u,
                    class: "mob-table-body"
                }, [i("div", oc, [i("div", ic, [i("span", null, f(m(c)("wall.order-time")), 1)]), i("div", ac, f(m(ie)(l.time).format("MM-DD HH:mm:ss")), 1)]), i("div", sc, [i("div", lc, [i("span", null, f(m(c)("depwi.amount")), 1)]), i("div", cc, [a(f(l.amount.toFixed(e.baseScale)) + " ", 1), i("span", uc, f(l.baseSymbol), 1)])]), i("div", dc, [i("div", pc, [i("span", null, f(m(c)("wall.price")), 1)]), i("div", fc, [1 == l.type || 2 == l.type && Number(l.price) > 0 ? (o(), t("div", mc, [a(f(l.price.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), i("span", hc, f(l.quoteSymbol), 1)])) : (o(), t("div", yc, f(m(c)("wall.market-order")), 1))])]), g.trigger ? (o(), t("div", gc, [i("div", vc, [i("span", null, f(m(c)("wall.trigger-price")), 1)]), i("div", bc, [i("div", null, [a(f(l.triggerPrice.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), i("span", xc, f(l.quoteSymbol), 1)])])])) : y("", !0), g.trigger ? y("", !0) : (o(), t("div", wc, [i("div", kc, [i("span", null, f(m(c)("wall.filled")), 1)]), i("div", Sc, [a(f(l.tradedAmount.toFixed(e.baseScale)) + " ", 1), i("span", Cc, f(l.baseSymbol), 1)])])), i("div", _c, [i("div", Tc, [g.trigger ? y("", !0) : (o(), t("div", Ac, [i("div", Dc, [i("span", null, f(m(c)("dash.in-c-order")), 1)]), i("div", Oc, [a(f((l.amount - l.tradedAmount).toFixed(e.baseScale)) + " ", 1), i("span", Ec, f(l.baseSymbol), 1)])])), g.trigger && 0 == Number(l.price) ? y("", !0) : (o(), t("div", Ic, [i("div", jc, [i("span", null, f(m(c)("wall.total")), 1)]), i("div", Lc, [a(f((l.amount * (Number(l.price) || T(l))).toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), i("span", Pc, f(l.quoteSymbol), 1), "USD" != m(s).currency ? (o(), t("div", Mc, [i("span", null, [a(f(" = " + (l.amount * T(l) * Number(m(s).currencyRate.toString())).toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), i("span", Nc, f(" " + m(s).currency), 1)])])) : y("", !0)])])), g.trigger ? (o(), t("div", Fc, [i("div", Rc, [i("span", null, f(m(c)("wall.status")), 1)]), i("div", Wc, f(1 == l.status ? "Completed" : 2 == l.status ? "Canceled" : 3 == l.status ? "Overtimed" : "Pending"), 1)])) : y("", !0)])]), i("div", {
                    class: "more-info",
                    onClick: e => (e => {
                        const t = document.getElementById(e);
                        if (null != t) {
                            const e = document.getElementsByClassName("enabled-dc");
                            if (t.classList.toString().includes("enabled-dc")) return void t.classList.remove("enabled-dc");
                            null != e && null != e[0] && e[0].classList.remove("enabled-dc"), t.classList.add("enabled-dc")
                        }
                    })("mob-table-" + u)
                }, [i("span", Bc, f(m(c)("wall.view-more")), 1), n[1] || (n[1] = i("span", {
                    class: "view-less"
                }, f("View Less"), -1)), n[2] || (n[2] = i("button", {
                    class: "btn-more"
                }, null, -1))], 8, Vc)], 8, rc)])
            })), 128)) : S((o(), h(m(de), {
                key: 1,
                data: g.rows,
                "table-layout": "fixed",
                style: {
                    width: "100%"
                },
                "class-name": "ordersTable",
                "max-height": "266",
                "element-loading-background": "rgba(0, 0, 0, 0.3)",
                "element-loading-text": m(c)("pga.loading"),
                "element-loading-spinner": m(ae),
                "element-loading-svg-view-box": "-10, -10, 50, 50"
            }, {
                default: d((() => [u(m(ue), {
                    label: m(c)("wall.order-time"),
                    width: "120",
                    "class-name": "timeColumn",
                    prop: "time"
                }, {
                    default: d((e => [a(f(m(ie)(e.row.time).format("MM-DD HH:mm:ss")), 1)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    prop: "symbol",
                    label: m(c)("wall.symbol")
                }, null, 8, ["label"]), u(m(ue), {
                    label: m(c)("wall.direction")
                }, {
                    default: d((e => [i("div", {
                        class: r("SELL" == e.row.direction ? "text-red-darken" : "text-green-darken")
                    }, f(e.row.direction), 3)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    label: m(c)("wall.price")
                }, {
                    default: d((e => [a(f(0 === e.row.type || 0 == e.row.price ? m(c)("exh.market-price") : e.row.price.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })) + " ", 1), 0 !== e.row.type && 0 != e.row.price ? (o(), t("span", Zl, f(e.row.quoteSymbol), 1)) : y("", !0)])),
                    _: 1
                }, 8, ["label"]), g.trigger ? (o(), h(m(ue), {
                    key: 0,
                    prop: "triggerPrice",
                    label: m(c)("wall.trigger-price")
                }, {
                    default: d((e => [a(f(e.row.triggerPrice.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })) + " ", 1), i("span", Gl, f(e.row.quoteSymbol), 1)])),
                    _: 1
                }, 8, ["label"])) : y("", !0), u(m(ue), {
                    prop: "amount",
                    label: m(c)("exh.amount"),
                    width: "120"
                }, {
                    default: d((t => [a(f(t.row.amount.toFixed(e.baseScale)) + " ", 1), i("span", Yl, f(t.row.baseSymbol), 1)])),
                    _: 1
                }, 8, ["label"]), g.trigger ? y("", !0) : (o(), h(m(ue), {
                    key: 1,
                    prop: "filled",
                    label: m(c)("wall.filled")
                }, {
                    default: d((t => [a(f(t.row.tradedAmount.toFixed(e.baseScale)) + " ", 1), i("span", Jl, f(t.row.baseSymbol), 1)])),
                    _: 1
                }, 8, ["label"])), g.trigger ? y("", !0) : (o(), h(m(ue), {
                    key: 2,
                    prop: "filled",
                    label: m(c)("dash.in-c-order")
                }, {
                    default: d((t => [a(f((t.row.amount - t.row.tradedAmount).toFixed(e.baseScale)) + " ", 1), i("span", Kl, f(t.row.baseSymbol), 1)])),
                    _: 1
                }, 8, ["label"])), g.trigger ? (o(), h(m(ue), {
                    key: 3,
                    label: m(c)("wall.status"),
                    width: "100"
                }, {
                    default: d((e => [a(f(1 == e.row.status ? m(c)("hiss.completed") : 2 == e.row.status ? m(c)("exh.canceled") : 3 == e.row.status ? m(c)("exh.overtimed") : 4 == e.row.status ? m(c)("exh.pending") : m(c)("exh.rejected")), 1)])),
                    _: 1
                }, 8, ["label"])) : y("", !0), u(m(ue), {
                    width: "120",
                    "class-name": "cancelColumn"
                }, {
                    header: d((() => [m(s).isCancelAll ? (o(), h(m(fe), {
                        key: 0,
                        width: 200,
                        "confirm-button-text": m(c)("sett.yes"),
                        "cancel-button-text": m(c)("sett.no"),
                        "icon-color": "red",
                        title: m(c)("exh.cancel-all-orders-sure"),
                        onConfirm: k
                    }, {
                        reference: d((() => [i("span", Xl, [a(f(m(c)("wall.cancel-all")), 1), n[0] || (n[0] = i("svg", {
                            class: "cancelhicon",
                            focusable: "false",
                            viewBox: "0 0 20 26",
                            "aria-hidden": "true"
                        }, [i("path", {
                            d: "M7 10l5 5 5-5z"
                        })], -1))])])),
                        _: 1
                    }, 8, ["confirm-button-text", "cancel-button-text", "title"])) : y("", !0)])),
                    default: d((e => [0 != e.row.type ? (o(), h(m(me), {
                        key: 0,
                        text: "",
                        size: "small",
                        class: "text-10 btn-cancel",
                        onClick: t => v(e.$index, e.row)
                    }, {
                        default: d((() => [a(f(m(c)("wall.cancel")), 1)])),
                        _: 2
                    }, 1032, ["onClick"])) : y("", !0)])),
                    _: 1
                })])),
                _: 1
            }, 8, ["data", "element-loading-text", "element-loading-spinner"])), [
                [m(se), e.modelValue]
            ])
        }
    }), [
        ["__scopeId", "data-v-1a903dff"]
    ]),
    qc = {
        key: 0,
        class: "text-center text-gray-300 w-100"
    },
    Uc = {
        class: "text-gray2"
    },
    zc = {
        key: 0,
        class: "text-gray2"
    },
    $c = {
        class: "text-gray2"
    },
    Zc = {
        class: "mob-table-header"
    },
    Gc = {
        class: "mob-t-text"
    },
    Yc = ["id"],
    Jc = {
        class: "mob-data-top"
    },
    Kc = {
        class: "mob-data-top-left"
    },
    Xc = {
        class: "mob-data-top-right"
    },
    Qc = {
        class: "mob-data-top"
    },
    eu = {
        class: "mob-data-top-left"
    },
    tu = {
        class: "mob-data-top-right"
    },
    nu = {
        class: "text-gray1"
    },
    ru = {
        class: "mob-data-top"
    },
    ou = {
        class: "mob-data-top-left"
    },
    iu = {
        class: "mob-data-top-right"
    },
    au = {
        class: "text-gray1"
    },
    su = {
        class: "mob-data-top"
    },
    lu = {
        class: "mob-data-top-left"
    },
    cu = {
        class: "mob-data-top-right"
    },
    uu = {
        key: 0
    },
    du = {
        class: "text-gray1"
    },
    pu = {
        key: 1
    },
    fu = {
        class: "mob-data-top"
    },
    mu = {
        class: "mob-data-top-left"
    },
    hu = {
        class: "mob-data-top-right"
    },
    yu = {
        class: "text-gray1"
    },
    gu = {
        "aria-hidden": "true",
        class: "mob-data-bottom"
    },
    vu = {
        class: "mob-data-bottom2"
    },
    bu = {
        class: "mob-data-top"
    },
    xu = {
        class: "mob-data-top-left"
    },
    wu = {
        class: "mob-data-top-right"
    },
    ku = {
        class: "text-gray1"
    },
    Su = {
        key: 0,
        class: "block-dis e864twd10"
    },
    Cu = {
        class: "text-gray1"
    },
    _u = ["onClick"],
    Tu = {
        class: "view-more"
    },
    Au = {
        key: 3,
        class: "mt-1"
    },
    Du = q(e({
        __name: "HistoryTable",
        props: {
            baseScale: {},
            mobileWidth: {
                type: Boolean
            },
            symbol: {}
        },
        setup(e) {
            const {
                Api: n
            } = s(), c = l(!0), {
                t: g
            } = w(), v = e, b = x(), k = l(1), A = e => {
                let t = 0;
                return e.detail.forEach((e => {
                    t += e.price
                })), t > 0 ? t / e.detail.length : 0
            }, D = T({
                openHistory: {
                    pageSize: 10,
                    total: 1,
                    page: 1,
                    rows: []
                },
                openDetailsHistory: {
                    pageSize: 10,
                    total: 1,
                    page: 1,
                    rows: []
                }
            }), O = () => {
                D.openHistory.rows = [];
                const e = new re;
                e.append("pageNo", String(k.value)), e.append("pageSize", String(D.openHistory.pageSize)), e.append("symbol", v.symbol), n.getOpenHistory(e).then((e => {
                    const t = e.data;
                    t.content && t.content.length > 0 && (D.openHistory.total = t.totalElements, D.openHistory.page = t.number, D.openHistory.rows = t.content), c.value = !1
                }))
            };
            return O(), (e, n) => (o(), t(_, null, [D.openHistory.rows.length <= 0 ? (o(), t("p", qc, f(m(g)("exh.no-records-found")), 1)) : v.mobileWidth ? (o(!0), t(_, {
                key: 2
            }, C(D.openHistory.rows, ((s, l) => {
                var c;
                return o(), t("div", {
                    key: l,
                    class: "mob-table"
                }, [i("div", Zc, [i("div", {
                    class: "mob-t-img",
                    style: p("background-image: url(/images/icons/coin/" + (null == (c = s.baseSymbol) ? void 0 : c.toLowerCase()) + ".svg")
                }, null, 4), i("div", Gc, f(s.symbol), 1), i("div", {
                    class: r(["mob-t-text-end flex items-center", "SELL" == s.direction ? "red-txt" : "green-txt"])
                }, f(("SELL" == s.direction ? m(g)("wall.sell") : m(g)("wall.buy")) + " " + (2 == s.type ? m(g)("exh.trigger") + " " : "") + (1 == s.type || 2 == s.type && Number(s.price) > 0 ? m(g)("wall.limit-order") : m(g)("wall.market-order"))), 3)]), i("div", {
                    id: "mob-table-" + l,
                    class: "mob-table-body"
                }, [i("div", Jc, [i("div", Kc, [i("span", null, f(m(g)("wall.order-time")), 1)]), i("div", Xc, f(m(ie)(s.time).format("MM-DD HH:mm:ss")), 1)]), i("div", Qc, [i("div", eu, [i("span", null, f(m(g)("depwi.amount")), 1)]), i("div", tu, [a(f(s.amount.toFixed(e.baseScale)) + " ", 1), i("span", nu, f(s.baseSymbol), 1)])]), i("div", ru, [i("div", ou, [i("span", null, f(m(g)("wall.avg-filled-price")), 1)]), i("div", iu, [a(f(A(s).toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), i("span", au, f(s.quoteSymbol), 1)])]), i("div", su, [i("div", lu, [i("span", null, f(m(g)("wall.price")), 1)]), i("div", cu, [1 == s.type ? (o(), t("div", uu, [a(f(s.price.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), i("span", du, f(s.quoteSymbol), 1)])) : (o(), t("div", pu, f(m(g)("wall.market-order")), 1))])]), i("div", fu, [i("div", mu, [i("span", null, f(m(g)("wall.filled")), 1)]), i("div", hu, [a(f(s.tradedAmount.toFixed(e.baseScale)) + " ", 1), i("span", yu, f(s.baseSymbol), 1)])]), i("div", gu, [i("div", vu, [i("div", bu, [i("div", xu, [i("span", null, f(m(g)("wall.total")), 1)]), i("div", wu, [a(f((s.amount * (s.price || A(s))).toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), i("span", ku, f(s.quoteSymbol), 1), "USD" != m(b).currency ? (o(), t("div", Su, [i("span", null, [a(f(" = " + (s.amount * A(s) * Number(m(b).currencyRate.toString())).toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), i("span", Cu, f(" " + m(b).currency), 1)])])) : y("", !0)])])])]), i("div", {
                    class: "more-info",
                    onClick: e => (e => {
                        const t = document.getElementById(e);
                        if (null != t) {
                            const e = document.getElementsByClassName("enabled-dc");
                            if (t.classList.toString().includes("enabled-dc")) return void t.classList.remove("enabled-dc");
                            null != e && null != e[0] && e[0].classList.remove("enabled-dc"), t.classList.add("enabled-dc")
                        }
                    })("mob-table-" + l)
                }, [i("span", Tu, f(m(g)("wall.view-more")), 1), n[2] || (n[2] = i("span", {
                    class: "view-less"
                }, f("View Less"), -1)), n[3] || (n[3] = i("button", {
                    class: "btn-more"
                }, null, -1))], 8, _u)], 8, Yc)])
            })), 128)) : S((o(), h(m(de), {
                key: 1,
                data: D.openHistory.rows,
                "table-layout": "fixed",
                style: {
                    width: "100%"
                },
                "class-name": "ordersTable",
                "max-height": "266",
                "element-loading-background": "rgba(0, 0, 0, 0.3)",
                "element-loading-text": m(g)("pga.loading"),
                "element-loading-spinner": m(ae),
                "element-loading-svg-view-box": "-10, -10, 50, 50"
            }, {
                default: d((() => [u(m(ue), {
                    label: m(g)("wall.order-time"),
                    width: "130",
                    "class-name": "timeColumn",
                    prop: "time"
                }, {
                    default: d((e => [a(f(m(ie)(e.row.time).format("MM-DD HH:mm:ss")), 1)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    prop: "symbol",
                    label: m(g)("wall.symbol"),
                    width: "120"
                }, null, 8, ["label"]), u(m(ue), {
                    prop: "type",
                    label: m(g)("wall.type"),
                    width: "120"
                }, {
                    default: d((e => [a(f(1 == e.row.type ? m(g)("exh.limit") : 0 == e.row.type ? m(g)("exh.market") : m(g)("exh.trigger")), 1)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    label: m(g)("wall.direction"),
                    width: "120"
                }, {
                    default: d((e => [i("div", {
                        class: r("SELL" == e.row.direction ? "text-red-darken" : "text-green-darken")
                    }, f(e.row.direction), 3)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    label: m(g)("wall.avg-filled-price")
                }, {
                    default: d((e => [a(f(A(e.row).toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })) + " ", 1), i("span", Uc, f(e.row.quoteSymbol), 1)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    label: m(g)("wall.price")
                }, {
                    default: d((e => [a(f(0 === e.row.type || 0 == e.row.price ? m(g)("exh.market-price") : e.row.price.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })) + " ", 1), 0 !== e.row.type && 0 != e.row.price ? (o(), t("span", zc, f(e.row.quoteSymbol), 1)) : y("", !0)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    label: m(g)("wall.filled")
                }, {
                    default: d((t => [a(f(t.row.tradedAmount.toFixed(e.baseScale)) + " ", 1), i("span", $c, f(t.row.baseSymbol), 1)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    label: m(g)("wall.status")
                }, {
                    default: d((e => [a(f(1 == e.row.status ? m(g)("hiss.completed") : 2 == e.row.status ? m(g)("exh.canceled") : 3 == e.row.status ? m(g)("exh.overtimed") : 4 == e.row.status ? m(g)("exh.pending") : m(g)("exh.rejected")), 1)])),
                    _: 1
                }, 8, ["label"])])),
                _: 1
            }, 8, ["data", "element-loading-text", "element-loading-spinner"])), [
                [m(se), c.value]
            ]), D.openHistory.rows.length >= 0 ? (o(), t("div", Au, [u(m(he), {
                currentPage: k.value,
                "onUpdate:currentPage": n[0] || (n[0] = e => k.value = e),
                background: "",
                size: "small",
                layout: "prev, pager, next",
                total: D.openHistory.total,
                onCurrentChange: n[1] || (n[1] = e => O())
            }, null, 8, ["currentPage", "total"])])) : y("", !0)], 64))
        }
    }), [
        ["__scopeId", "data-v-11985ad2"]
    ]),
    Ou = {
        key: 0,
        class: "text-center text-gray-300"
    },
    Eu = {
        class: "text-gray2"
    },
    Iu = {
        class: "text-gray2"
    },
    ju = {
        class: "text-gray2"
    },
    Lu = {
        class: "text-gray2"
    },
    Pu = {
        class: "mob-table-header"
    },
    Mu = {
        class: "mob-t-text"
    },
    Nu = {
        class: "mob-t-text-end flex items-center"
    },
    Fu = ["id"],
    Ru = {
        class: "mob-data-top"
    },
    Wu = {
        class: "mob-data-top-left"
    },
    Vu = {
        class: "mob-data-top-right"
    },
    Bu = {
        class: "text-gray1"
    },
    Hu = {
        class: "mob-data-top"
    },
    qu = {
        class: "mob-data-top-left"
    },
    Uu = {
        class: "mob-data-top-right"
    },
    zu = {
        class: "text-gray1"
    },
    $u = {
        class: "mob-data-top"
    },
    Zu = {
        class: "mob-data-top-left"
    },
    Gu = {
        class: "mob-data-top-right"
    },
    Yu = {
        class: "text-gray2"
    },
    Ju = {
        class: "mob-data-top mb-3"
    },
    Ku = {
        class: "mob-data-top-left"
    },
    Xu = {
        class: "mob-data-top-right"
    },
    Qu = {
        class: "text-gray2"
    },
    ed = q(e({
        __name: "TradeHistory",
        props: {
            mobileWidth: {
                type: Boolean
            },
            baseScale: {},
            symbol: {}
        },
        setup(e) {
            const {
                Api: n
            } = s(), r = l(!0), {
                t: c
            } = w(), g = e;
            x();
            let v = g.symbol.split("/");
            const b = l(v[0]),
                k = l(v[1]),
                A = l(1),
                D = T({
                    openHistory: {
                        pageSize: 15,
                        total: 1,
                        page: 1,
                        rows: []
                    },
                    openDetailsHistory: {
                        pageSize: 10,
                        total: 1,
                        page: 1,
                        rows: []
                    }
                }),
                O = () => {
                    D.openHistory.total > A.value * D.openHistory.pageSize && (A.value = A.value + 1, E())
                },
                E = () => {
                    const e = new re;
                    e.append("pageNo", String(A.value)), e.append("pageSize", String(D.openHistory.pageSize)), e.append("symbol", g.symbol), e.append("hasTraded", "true"), n.getOpenHistory(e).then((e => {
                        const t = e.data;
                        t.content && t.content.length > 0 && (D.openHistory.total = t.totalElements, D.openHistory.page = t.number, D.openHistory.rows = t.content, D.openHistory.rows.forEach(((e, t) => {
                            var n;
                            e.price = 1 == e.type ? e.price : c("exh.market-price");
                            for (let r = 0; r < (null == (n = e.detail) ? void 0 : n.length); r++) e.detail[r].symbol = e.symbol, D.openDetailsHistory.rows.push(e.detail[r])
                        }))), r.value = !1
                    }))
                };
            E();
            const I = e => {
                const t = "string" == typeof e ? parseFloat(e) : e;
                if (isNaN(t) || !isFinite(t)) return "";
                const n = t.toString();
                if (/e/i.test(n)) {
                    const e = n.match(/e(?:\+|-)(\d+)$/);
                    if (e && e[1]) {
                        const n = parseInt(e[1], 10);
                        return t.toFixed(n + 1).replace(/\.?0+$/, "")
                    }
                }
                return t.toString()
            };
            return (e, n) => (o(), t(_, null, [D.openHistory.rows.length <= 0 ? (o(), t("p", Ou, f(m(c)("exh.no-records-found")), 1)) : g.mobileWidth ? (o(!0), t(_, {
                key: 2
            }, C(D.openDetailsHistory.rows, ((n, r) => {
                var s;
                return o(), t("div", {
                    key: r,
                    class: "mob-table"
                }, [i("div", Pu, [i("div", {
                    class: "mob-t-img",
                    style: p("background-image: url(/images/icons/coin/" + (null == (s = b.value) ? void 0 : s.toLowerCase()) + ".svg")
                }, null, 4), i("div", Mu, f(n.symbol), 1), i("div", Nu, f(m(ie)(n.time).format("MM-DD HH:mm:ss")), 1)]), i("div", {
                    id: "mob-table-" + r,
                    class: "mob-table-body"
                }, [i("div", Ru, [i("div", Wu, [i("span", null, f(m(c)("wall.price")), 1)]), i("div", Vu, [a(f(n.price.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), i("span", Bu, f(k.value), 1)])]), i("div", Hu, [i("div", qu, [i("span", null, f(m(c)("depwi.amount")), 1)]), i("div", Uu, [a(f(n.amount.toFixed(e.baseScale)) + " ", 1), i("span", zu, f(b.value), 1)])]), i("div", $u, [i("div", Zu, [i("span", null, f(m(c)("wall.total")), 1)]), i("div", Gu, [a(f((n.price * n.amount).toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), i("span", Yu, f(k.value), 1)])]), i("div", Ju, [i("div", Ku, [i("span", null, f(m(c)("wall.fee")), 1)]), i("div", Xu, [a(f(I(n.fee)) + " ", 1), i("span", Qu, f(k.value), 1)])])], 8, Fu)])
            })), 128)) : S((o(), h(m(de), {
                key: 1,
                data: D.openDetailsHistory.rows,
                "table-layout": "fixed",
                style: {
                    width: "100%"
                },
                "class-name": "ordersTable",
                "max-height": "220",
                "element-loading-background": "rgba(0, 0, 0, 0.3)",
                "element-loading-text": m(c)("pga.loading"),
                "element-loading-spinner": m(ae),
                "element-loading-svg-view-box": "-10, -10, 50, 50"
            }, {
                default: d((() => [u(m(ue), {
                    label: m(c)("wall.order-time"),
                    "class-name": "timeColumn",
                    prop: "time"
                }, {
                    default: d((e => [a(f(m(ie)(e.row.time).format("MM-DD HH:mm:ss")), 1)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    prop: "symbol",
                    label: m(c)("wall.symbol")
                }, null, 8, ["label"]), u(m(ue), {
                    label: m(c)("wall.price")
                }, {
                    default: d((e => [a(f(e.row.price.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })) + " ", 1), i("span", Eu, f(k.value), 1)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    label: m(c)("exh.amount")
                }, {
                    default: d((t => [a(f(t.row.amount.toFixed(e.baseScale)) + " ", 1), i("span", Iu, f(b.value), 1)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    label: m(c)("wall.total")
                }, {
                    default: d((e => [a(f((e.row.price * e.row.amount).toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })) + " ", 1), i("span", ju, f(k.value), 1)])),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    label: m(c)("wall.fee")
                }, {
                    default: d((e => [a(f(I(e.row.fee)) + " ", 1), i("span", Lu, f(k.value), 1)])),
                    _: 1
                }, 8, ["label"])])),
                _: 1
            }, 8, ["data", "element-loading-text", "element-loading-spinner"])), [
                [m(se), r.value]
            ]), D.openHistory.rows.length >= 0 ? (o(), h(m(me), {
                key: 3,
                class: "mt-4",
                style: {
                    width: "100%"
                },
                disabled: D.openHistory.total < A.value * D.openHistory.pageSize,
                onClick: O
            }, {
                default: d((() => [a(f(m(c)("pga.view-more")), 1)])),
                _: 1
            }, 8, ["disabled"])) : y("", !0)], 64))
        }
    }), [
        ["__scopeId", "data-v-9121426a"]
    ]),
    td = {
        class: "search-symbol px-3 pt-4"
    },
    nd = {
        class: "tab-sort mt-0 mb-3"
    },
    rd = {
        class: "custom-tabs-label"
    },
    od = {
        class: "flex flex-row justify-between px-3"
    },
    id = {
        key: 1,
        class: "right-shadow-sym"
    },
    ad = {
        class: "table-coins"
    },
    sd = {
        class: "mx-3",
        style: {
            width: "100%"
        }
    },
    ld = {
        class: "flex flex-row justify-between items-center mr-2"
    },
    cd = {
        class: "mr-4"
    },
    ud = {
        class: "flex flex-row justify-between items-center mt-1 mr-2"
    },
    dd = {
        class: "mr-4"
    },
    pd = {
        class: "flex flex-row justify-between items-center mt-1 mr-2"
    },
    fd = {
        class: "mr-4"
    },
    md = {
        class: "flex flex-row justify-between items-center mt-1 mr-2"
    },
    hd = {
        class: "mr-4"
    },
    yd = {
        class: "flex flex-row justify-between items-center mt-1 mr-2"
    },
    gd = {
        class: "mr-4"
    },
    vd = ["onClick"],
    bd = {
        key: 0,
        width: "1.2em",
        height: "1.2em",
        viewBox: "0 0 24 24",
        style: {
            color: "#979797"
        },
        class: "icon-favored"
    },
    xd = {
        key: 1,
        width: "1.2em",
        height: "1.2em",
        viewBox: "0 0 24 24",
        style: {
            color: "#f0a70a"
        },
        class: "icon-favored"
    },
    wd = ["onClick"],
    kd = {
        class: "imgParent"
    },
    Sd = ["src"],
    Cd = ["onClick"],
    _d = {
        key: 0,
        class: "text-gray1"
    },
    Td = ["onClick"],
    Ad = {
        key: 0,
        class: "text-green-500"
    },
    Dd = {
        key: 1,
        class: "text-red-500"
    },
    Od = {
        key: 2,
        class: "text-green-500"
    },
    Ed = q(e({
        __name: "AllSymbols",
        props: {
            scoins: {
                default: []
            },
            symbol: {
                default: ""
            },
            mobile: {
                type: Boolean,
                default: !1
            }
        },
        emits: ["selectCoin", "onFavor"],
        setup(e, {
            emit: n
        }) {
            const {
                Api: c
            } = s(), {
                t: p
            } = w(), g = l("spot"), v = l(""), b = l(""), x = l(!1), k = l(!0), S = l(), D = e, O = n, E = T({
                categories: [],
                categoriesName: []
            });
            c.getSiteData().then((e => {
                const t = e.data;
                0 == t.code && (E.categories = t.data, Object.keys(E.categories).forEach((e => {
                    const t = e,
                        n = E.categories[e];
                    t && "id" != t && n && E.categoriesName.push(t)
                })))
            }));
            const I = l(!1),
                j = l(0),
                L = l(0),
                P = e => {
                    I.value = !0, S.value.$el.classList.add("active"), j.value = e.pageX - S.value.$el.offsetLeft, L.value = S.value.$el.scrollLeft
                },
                M = e => {
                    if (!I.value) return;
                    e.preventDefault();
                    const t = 1.5 * (e.pageX - S.value.$el.offsetLeft - j.value);
                    S.value.$el.scrollLeft = L.value - t
                },
                N = e => {
                    I.value = !1, S.value.$el.classList.remove("active")
                },
                F = e => {
                    I.value = !1, S.value.$el.classList.remove("active")
                },
                R = e => {
                    e.srcElement.scrollLeftMax == e.srcElement.scrollLeft ? (x.value = !0, k.value = !1) : 0 == e.srcElement.scrollLeft ? (x.value = !1, k.value = !0) : (x.value = !0, k.value = !0)
                },
                W = e => {
                    const t = document.getElementById("scrollRight");
                    let n = 0;
                    const r = setInterval((function() {
                        e ? t.scrollLeft += 10 : t.scrollLeft -= 10, n += 10, n >= t.scrollLeftMax && window.clearInterval(r)
                    }), 10)
                },
                V = A((() => ("spot" == g.value ? D.scoins.USDT : "favor" == g.value ? D.scoins.favor : D.scoins.BTC).filter((e => (!v.value || e.symbol.toLowerCase().includes(v.value.toLowerCase())) && (!b.value || String(E.categories[b.value]).includes(e.symbol.split("/")[0]))))));
            return (e, n) => (o(), t("div", {
                class: r(["all-symbols flex flex-col", D.mobile && "mobile"])
            }, [i("div", td, [u(m(ge), {
                modelValue: v.value,
                "onUpdate:modelValue": n[1] || (n[1] = e => v.value = e),
                placeholder: m(p)("dash.search-coin"),
                class: "input-symbols"
            }, {
                prefix: d((() => n[6] || (n[6] = [i("i", {
                    class: "el-input__icon fas fa-search"
                }, null, -1)]))),
                suffix: d((() => ["" != v.value ? (o(), t("i", {
                    key: 0,
                    class: "cursor-pointer el-input__icon fas fa-burn clsbtn",
                    onClick: n[0] || (n[0] = e => v.value = "")
                })) : y("", !0)])),
                _: 1
            }, 8, ["modelValue", "placeholder"])]), i("div", nd, [u(m(ce), {
                modelValue: g.value,
                "onUpdate:modelValue": n[2] || (n[2] = e => g.value = e),
                class: "symbol-tabs"
            }, {
                default: d((() => [u(m(le), {
                    name: "favor"
                }, {
                    label: d((() => [i("span", rd, [n[7] || (n[7] = i("i", {
                        class: "iconStar fas fa-star"
                    }, null, -1)), i("span", null, f(m(p)("wall.favorites")), 1)])])),
                    _: 1
                }), u(m(le), {
                    label: m(p)("exh.spot"),
                    name: "spot"
                }, null, 8, ["label"]), u(m(le), {
                    label: m(p)("dash.derivates"),
                    name: "perpetual"
                }, null, 8, ["label"])])),
                _: 1
            }, 8, ["modelValue"]), i("div", od, [u(m(be), {
                id: "scrollRight",
                ref_key: "scrollCat",
                ref: S,
                modelValue: b.value,
                "onUpdate:modelValue": n[3] || (n[3] = e => b.value = e),
                size: "small",
                class: "text-medium",
                style: {
                    overflow: "hidden"
                },
                onScroll: R,
                onMousedown: P,
                onMousemove: M,
                onMouseup: F,
                onMouseleave: N
            }, {
                default: d((() => [u(m(ve), {
                    value: "",
                    name: ""
                }, {
                    default: d((() => [a(f(m(p)("dash.all")), 1)])),
                    _: 1
                }), (o(!0), t(_, null, C(E.categoriesName, ((e, t) => (o(), h(m(ve), {
                    key: t,
                    label: e
                }, {
                    default: d((() => [a(f(m(p)("ctm." + e)), 1)])),
                    _: 2
                }, 1032, ["label"])))), 128)), n[8] || (n[8] = a(" > "))])),
                _: 1
            }, 8, ["modelValue"]), x.value ? (o(), t("div", {
                key: 0,
                class: "left-shadow-sym",
                onClick: n[4] || (n[4] = e => W(!1))
            }, n[9] || (n[9] = [i("i", {
                class: "fas fa-chevron-left cursor-pointer justify-start"
            }, null, -1)]))) : y("", !0), k.value ? (o(), t("div", id, [k.value ? (o(), t("i", {
                key: 0,
                class: "fas fa-chevron-right cursor-pointer justify-end",
                onClick: n[5] || (n[5] = e => W(!0))
            })) : y("", !0)])) : y("", !0)])]), i("div", ad, [u(m(de), {
                class: "slim-table",
                data: V.value,
                "tooltip-effect": "dark",
                "table-layout": "fixed",
                style: {
                    width: "100%",
                    "font-size": "12px"
                },
                "row-key": "symbol"
            }, {
                default: d((() => [u(m(ue), {
                    type: "expand",
                    width: "20"
                }, {
                    default: d((e => {
                        return [i("div", sd, [i("div", ld, [n[10] || (n[10] = i("span", {
                            class: "ml-4"
                        }, "Volume:", -1)), i("span", cd, f(e.row.volume.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        }) + " " + e.row.coin + " ($" + (t = e.row.volume * e.row.usdRate, (t < 1e3 ? t.toString() : t >= 1e3 && t < 1e6 ? +(t / 1e3).toFixed(2) + "K" : t >= 1e6 && t < 1e9 ? +(t / 1e6).toFixed(2) + "M" : t >= 1e9 && t < 1e12 ? +(t / 1e9).toFixed(2) + "B" : t >= 1e12 ? +(t / 1e12).toFixed(2) + "T" : t.toString()) + ")")), 1)]), u(m(xe)), i("div", ud, [n[11] || (n[11] = i("span", {
                            class: "ml-4"
                        }, "Low:", -1)), i("span", dd, f(e.row.low.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        }) + " " + e.row.base), 1)]), u(m(xe)), i("div", pd, [n[12] || (n[12] = i("span", {
                            class: "ml-4"
                        }, "High:", -1)), i("span", fd, f(e.row.high.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        }) + " " + e.row.base), 1)]), u(m(xe)), i("div", md, [n[13] || (n[13] = i("span", {
                            class: "ml-4"
                        }, "Open:", -1)), i("span", hd, f(e.row.open.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        }) + " " + e.row.base), 1)]), u(m(xe)), i("div", yd, [n[14] || (n[14] = i("span", {
                            class: "ml-4"
                        }, "Last day close:", -1)), i("span", gd, f(e.row.lastDayClose.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        }) + " " + e.row.base), 1)])])];
                        var t
                    })),
                    _: 1
                }), u(m(ue), {
                    label: m(p)("wall.symbol"),
                    "label-class-name": "coinName"
                }, {
                    default: d((e => {
                        var s;
                        return [i("button", {
                            class: "btnRate",
                            onClick: () => O("onFavor", e.row)
                        }, [e.row.isFavor ? y("", !0) : (o(), t("svg", bd, n[15] || (n[15] = [i("g", {
                            fill: "none",
                            stroke: "currentColor",
                            "stroke-width": "2",
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round"
                        }, [i("path", {
                            d: "M12 2l3.09 6.26L22 9.27l-5 4.87l1.18 6.88L12 17.77l-6.18 3.25L7 14.14L2 9.27l6.91-1.01L12 2z"
                        })], -1)]))), e.row.isFavor ? (o(), t("svg", xd, n[16] || (n[16] = [i("g", {
                            fill: "none",
                            stroke: "currentColor",
                            "stroke-width": "2",
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round"
                        }, [i("path", {
                            d: "M12 2l3.09 6.26L22 9.27l-5 4.87l1.18 6.88L12 17.77l-6.18 3.25L7 14.14L2 9.27l6.91-1.01L12 2z",
                            style: {
                                fill: "#f0a70a"
                            }
                        })], -1)]))) : y("", !0)], 8, vd), i("div", {
                            class: r(e.row.symbol == D.symbol ? "" : "cursor-pointer"),
                            onClick: () => {
                                e.row.symbol != D.symbol && O("selectCoin", e.row)
                            }
                        }, [i("span", kd, [i("img", {
                            class: "imgSelect",
                            src: "/images/icons/coin/" + (null == (s = e.row.coin) ? void 0 : s.toLowerCase()) + ".svg"
                        }, null, 8, Sd)]), a(" " + f(e.row.symbol), 1)], 10, wd)]
                    })),
                    _: 1
                }, 8, ["label"]), u(m(ue), {
                    label: m(p)("exh.price"),
                    width: (D.mobile, "108"),
                    prop: "usdRate",
                    align: "right",
                    sortable: ""
                }, {
                    default: d((e => [i("div", {
                        class: r(e.row.symbol == D.symbol ? "" : "cursor-pointer"),
                        onClick: () => {
                            e.row.symbol != D.symbol && O("selectCoin", e.row)
                        }
                    }, [a(f(e.row.usdRate.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })) + " ", 1), D.mobile ? y("", !0) : (o(), t("span", _d, "USDT"))], 10, Cd)])),
                    _: 1
                }, 8, ["label", "width"]), u(m(ue), {
                    label: D.mobile ? "24H" : m(p)("exh.24h-change"),
                    width: D.mobile ? "80" : "120",
                    prop: "change",
                    align: "right",
                    sortable: ""
                }, {
                    default: d((e => [i("div", {
                        class: r(e.row.symbol == D.symbol ? "" : "cursor-pointer"),
                        onClick: () => {
                            e.row.symbol != D.symbol && O("selectCoin", e.row)
                        }
                    }, [e.row.chg > 0 ? (o(), t("span", Ad, " +" + f((100 * e.row.chg).toFixed(2)) + "% ", 1)) : y("", !0), e.row.chg < 0 ? (o(), t("span", Dd, f((100 * e.row.chg).toFixed(2)) + "% ", 1)) : y("", !0), 0 == e.row.chg ? (o(), t("span", Od, f((100 * e.row.chg).toFixed(2)) + "% ", 1)) : y("", !0)], 10, Td)])),
                    _: 1
                }, 8, ["label", "width"])])),
                _: 1
            }, 8, ["data"])])], 2))
        }
    }), [
        ["__scopeId", "data-v-484bbf92"]
    ]),
    Id = {
        class: "mobile-trade-head"
    },
    jd = {
        class: "trade-info-left"
    },
    Ld = {
        class: "show-price-popover text-white text-bold mb-0 pr-1 ml-3 flex"
    },
    Pd = {
        key: 0,
        class: "btn-all-search",
        tabindex: "0",
        type: "button"
    },
    Md = {
        class: "symbol-info"
    },
    Nd = {
        class: "flex col"
    },
    Fd = {
        class: "chg"
    },
    Rd = {
        key: 0,
        class: "price-sec"
    },
    Wd = {
        class: "trade-info-right"
    },
    Vd = {
        class: "info-item"
    },
    Bd = {
        class: "label"
    },
    Hd = {
        class: "data"
    },
    qd = {
        class: "info-item"
    },
    Ud = {
        class: "label"
    },
    zd = {
        class: "data"
    },
    $d = {
        class: "info-item"
    },
    Zd = {
        class: "label"
    },
    Gd = {
        class: "data"
    },
    Yd = {
        class: "info-item mb-0"
    },
    Jd = {
        class: "label"
    },
    Kd = {
        class: "data"
    },
    Xd = q(e({
        __name: "MobileTradeHeader",
        props: {
            currentCoin: {
                default: {}
            },
            scoins: {
                default: []
            },
            name: {
                default: ""
            }
        },
        emits: ["enableDetails", "onFavor", "selectCoin"],
        setup(e, {
            emit: n
        }) {
            s();
            const p = n,
                {
                    t: h
                } = w(),
                g = l(!1),
                v = x(),
                b = l(v.isAppOn),
                k = e,
                S = () => {
                    g.value = !0
                };
            return c((() => {})), (e, n) => {
                const s = ye;
                return o(), t(_, null, [i("div", Id, [i("div", jd, [i("div", {
                    class: "relative flex cointop",
                    onClick: n[0] || (n[0] = e => S()),
                    onKeydown: n[1] || (n[1] = e => S())
                }, [u(s, {
                    class: "coin-img",
                    picture: "/images/icons/coin/" + k.currentCoin.coin.toLowerCase() + ".svg",
                    size: "small",
                    badge: "/images/icons/coin/usdt-white.svg"
                }, null, 8, ["picture"]), i("button", Ld, f(k.currentCoin.coin) + "/" + f(k.currentCoin.base), 1), b.value ? y("", !0) : (o(), t("button", Pd, n[6] || (n[6] = [i("span", {
                    class: "btn-all-label"
                }, [i("svg", {
                    class: "btn-all-icon",
                    focusable: "false",
                    viewBox: "0 0 24 24",
                    "aria-hidden": "true"
                }, [i("path", {
                    d: "M7 10l5 5 5-5z"
                })])], -1)])))], 32), i("div", Md, [i("span", {
                    class: "flex items-center",
                    onClick: n[2] || (n[2] = e => p("enableDetails"))
                }, [n[7] || (n[7] = i("i", {
                    class: "symbol-info-icon fas fa-book"
                }, null, -1)), a(f(k.name), 1)])]), i("div", {
                    class: r(["xs:mb-2 sm:mr-6 curcoin", k.currentCoin.change > 0 ? "up text-green-darken" : "down text-red-darken"])
                }, [i("div", Nd, [i("span", null, f(k.currentCoin.price.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })), 1)]), i("span", Fd, f((100 * k.currentCoin.chg).toFixed(2)) + "%", 1)], 2), "USD" != m(v).currency ? (o(), t("span", Rd, "≈" + f((k.currentCoin.price * m(v).currencyRate).toLocaleString(void 0, {
                    minimumFractionDigits: 2
                }) + " " + m(v).currency), 1)) : y("", !0), n[8] || (n[8] = i("div", null, [i("p", {
                    class: "price-sec help text-gray3",
                    style: {
                        "line-height": "13px",
                        "font-size": "9px"
                    }
                }, "DEMO Trading")], -1))]), i("div", Wd, [i("div", Vd, [i("span", Bd, f(m(h)("exh.24h-high")), 1), i("span", Hd, " $" + f(k.currentCoin.high.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })), 1)]), i("div", qd, [i("span", Ud, f(m(h)("exh.24h-low")), 1), i("span", zd, " $" + f(k.currentCoin.low.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })), 1)]), i("div", $d, [i("span", Zd, f(m(h)("exh.24h-volume") + " (" + k.currentCoin.base + ")"), 1), i("span", Gd, f((l = k.currentCoin.volume * k.currentCoin.price, l < 1e3 ? l.toString() : l >= 1e3 && l < 1e6 ? +(l / 1e3).toFixed(2) + "K" : l >= 1e6 && l < 1e9 ? +(l / 1e6).toFixed(2) + "M" : l >= 1e9 && l < 1e12 ? +(l / 1e9).toFixed(2) + "B" : l >= 1e12 ? +(l / 1e12).toFixed(2) + "T" : l.toString())), 1)]), i("div", Yd, [i("span", Jd, f(m(h)("exh.24h-volume") + " (" + k.currentCoin.coin + ")"), 1), i("span", Kd, f(k.currentCoin.volume.toFixed(2)), 1)])])]), u(m(we), {
                    modelValue: g.value,
                    "onUpdate:modelValue": n[5] || (n[5] = e => g.value = e),
                    "with-header": !1,
                    class: "drawerSymbols",
                    direction: "btt",
                    "append-to-body": !0,
                    "lock-scroll": !0,
                    "destroy-on-close": !0,
                    size: "80%"
                }, {
                    default: d((() => [u(Ed, {
                        ref: "allSymbols",
                        symbol: k.currentCoin.symbol,
                        scoins: k.scoins,
                        mobile: !0,
                        onSelectCoin: n[3] || (n[3] = e => (e => {
                            p("selectCoin", e), g.value = !1
                        })(e)),
                        onOnFavor: n[4] || (n[4] = e => p("onFavor", e))
                    }, null, 8, ["symbol", "scoins"])])),
                    _: 1
                }, 8, ["modelValue"])], 64);
                var l
            }
        }
    }), [
        ["__scopeId", "data-v-1ce33e94"]
    ]),
    Qd = {
        id: "seed-sale",
        class: "flex flex-col items-center justify-center token-detail-card relative mt-2 pb-5 px-2 space-y-8 bg-card-light"
    },
    ep = {
        id: "",
        class: "flex flex-col items-center justify-normal z-20 space-y-4 at-3a",
        style: {
            "z-index": "11111"
        }
    },
    tp = {
        key: 0
    },
    np = {
        width: "330px",
        height: "180px",
        style: {
            top: "126px",
            display: "flex",
            "flex-direction": "column",
            "align-items": "center",
            "justify-content": "center",
            width: "330px",
            height: "180px"
        },
        class: "items-center justify-center",
        initial: {
            opacity: 0,
            y: 0,
            scale: .5
        },
        enter: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                type: "spring",
                stiffness: 25,
                damping: 10,
                mass: 1,
                delay: 100
            }
        }
    },
    rp = {
        style: {
            width: "210px"
        }
    },
    op = {
        class: "title-nw mt-2 text-gray4",
        style: {
            display: "flex",
            position: "relative",
            "justify-content": "start",
            "padding-left": "36px",
            top: "-33px",
            "font-size": "12px"
        }
    },
    ip = {
        key: 1,
        style: {
            width: "100%"
        },
        class: "box-ai-t"
    },
    ap = {
        class: "container"
    },
    sp = {
        class: "content"
    },
    lp = q(e({
        __name: "OPZAITRADE",
        props: {
            btn: {
                type: Boolean,
                default: !1
            },
            modelValue: {
                type: Boolean,
                default: !0
            },
            symbol: {
                default: ""
            }
        },
        emits: ["update:modelValue", "close"],
        setup(e, {
            emit: n
        }) {
            w(), s();
            const r = n,
                c = e,
                p = A({
                    get: () => c.modelValue,
                    set: e => r("update:modelValue", e)
                }),
                g = l("Generating " + c.symbol + " Analysis");
            let v;
            D((() => {
                v && clearInterval(v)
            }));
            const b = () => {
                    r("update:modelValue", !1)
                },
                k = () => {
                    descAi.value = "", loadingAI.value = !0, (() => {
                        const e = [".", "..", "..."];
                        let t = 0;
                        v = setInterval((() => {
                            g.value = "Generating " + c.symbol + `  Analysis${e[t%e.length]}`, t++
                        }), 500)
                    })(), generateQuery(), r("update:modelValue", !0);
                    const e = `${window.location.pathname}`;
                    window.history.replaceState({}, "", e)
                },
                C = x();
            return (e, n) => {
                const r = ke,
                    s = Se,
                    l = ot,
                    v = O("motion");
                return o(), t(_, null, [!m(C).isAppOn && c.btn ? (o(), h(r, {
                    key: 0,
                    class: "btn-opz-ai",
                    style: {
                        "min-width": "inherit"
                    },
                    size: "small",
                    onClick: n[0] || (n[0] = e => k())
                }, {
                    default: d((() => n[3] || (n[3] = [a("AI")]))),
                    _: 1
                })) : y("", !0), u(m(_e), {
                    modelValue: p.value,
                    "onUpdate:modelValue": n[1] || (n[1] = e => p.value = e),
                    "append-to": "#app",
                    class: "dialogw cdetail buy-card-pop heads2 rass",
                    "destroy-on-close": "",
                    width: "100%",
                    onClose: b,
                    onOpen: n[2] || (n[2] = e => k())
                }, {
                    header: d((() => n[4] || (n[4] = []))),
                    default: d((() => [i("div", null, [i("div", Qd, [n[5] || (n[5] = i("div", {
                        class: "pattern left"
                    }, null, -1)), i("div", ep, [e.loadingAI ? (o(), t("div", tp, [S((o(), t("div", np, [u(m(Ce), {
                        class: "fbz-img-lt",
                        animationLink: "/assets/animated/ai5.json",
                        height: 90,
                        width: 90
                    }), u(s, {
                        width: "210px",
                        height: "30px",
                        style: {
                            "border-radius": "3px",
                            "margin-top": "12px"
                        }
                    }), i("div", rp, [i("p", op, f(g.value), 1)])])), [
                        [v]
                    ])])) : (o(), t("div", ip, [i("div", ap, [i("div", sp, [(o(), h(l, {
                        coin: "BTC",
                        key: "pricing-tabbed-BTC"
                    }))])])]))]), n[6] || (n[6] = i("div", {
                        class: "pattern right"
                    }, null, -1))])])])),
                    _: 1
                }, 8, ["modelValue"])], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-bc343bc6"]
    ]),
    cp = {
        class: "flex items-center"
    },
    up = {
        class: "flex items-center mr-6"
    },
    dp = {
        class: "relative flex cointop"
    },
    pp = {
        class: "show-price-popover text-white text-bold mb-0 pr-1 ml-3 flex"
    },
    fp = {
        class: "symbol-info"
    },
    mp = {
        class: "flex"
    },
    hp = {
        class: "flex col"
    },
    yp = {
        key: 0,
        class: "price-sec"
    },
    gp = {
        class: "chg"
    },
    vp = {
        class: "xs:mb-2 sm:mr-6"
    },
    bp = {
        class: "text-gray-darken text-medium text-12 mb-1"
    },
    xp = {
        class: "text-gray5 text-medium text-12 mb-1"
    },
    wp = {
        class: "xs:mb-2 sm:mr-6"
    },
    kp = {
        class: "text-gray-darken text-medium text-12 mb-1"
    },
    Sp = {
        class: "text-gray5 text-medium text-12 mb-1"
    },
    Cp = {
        class: "text-gray-darken text-medium text-12 mb-1"
    },
    _p = {
        class: "text-gray5 text-medium text-12 mb-1"
    },
    Tp = {
        class: "text-gray-darken text-medium text-12 mb-1"
    },
    Ap = {
        class: "text-gray5 text-medium text-12 mb-1"
    },
    Dp = q(e({
        __name: "FullTradeHeader",
        props: {
            currentCoin: {
                default: {}
            },
            scoins: {
                default: []
            },
            name: {
                default: ""
            }
        },
        emits: ["enableDetails", "onFavor", "selectCoin"],
        setup(e, {
            emit: n
        }) {
            s();
            const p = n,
                {
                    t: g
                } = w(),
                v = l(!1),
                b = x();
            l(b.isAppOn);
            const k = e;
            l(!1), c((() => {}));
            const S = l(!1),
                C = l(!1);
            return (e, n) => {
                const s = ye,
                    l = ke;
                return o(), t(_, null, [i("div", cp, [u(m(Te), {
                    ref: "allSymbolsRef",
                    placement: "bottom",
                    trigger: "click",
                    "popper-class": "pop-symbols",
                    persistent: !1,
                    width: 440
                }, {
                    reference: d((() => [i("div", up, [i("div", dp, [u(s, {
                        class: "mt-1",
                        picture: "/images/icons/coin/" + k.currentCoin.coin.toLowerCase() + ".svg",
                        size: "small",
                        badge: "/images/icons/coin/usdt-white.svg"
                    }, null, 8, ["picture"]), i("button", pp, [a(f(k.currentCoin.coin) + "/" + f(k.currentCoin.base) + " ", 1), n[5] || (n[5] = i("p", {
                        class: "pl-1 help text-gray3",
                        style: {
                            "line-height": "14px"
                        }
                    }, "DEMO", -1))]), n[6] || (n[6] = i("button", {
                        class: "btn-all-search",
                        tabindex: "0",
                        type: "button"
                    }, [i("span", {
                        class: "btn-all-label"
                    }, [i("svg", {
                        class: "btn-all-icon",
                        focusable: "false",
                        viewBox: "0 0 24 24",
                        "aria-hidden": "true"
                    }, [i("path", {
                        d: "M7 10l5 5 5-5z"
                    })])])], -1))])])])),
                    default: d((() => [u(Ed, {
                        ref: "allSymbols",
                        symbol: k.currentCoin.symbol,
                        scoins: k.scoins,
                        mobile: !1,
                        onSelectCoin: n[0] || (n[0] = e => (e => {
                            p("selectCoin", e), v.value = !1
                        })(e)),
                        onOnFavor: n[1] || (n[1] = e => p("onFavor", e))
                    }, null, 8, ["symbol", "scoins"])])),
                    _: 1
                }, 512), i("div", fp, [i("span", {
                    class: "flex",
                    onClick: n[2] || (n[2] = e => p("enableDetails"))
                }, [n[7] || (n[7] = i("i", {
                    class: "symbol-info-icon fas fa-book"
                }, null, -1)), a(f(k.name), 1)])]), i("div", mp, [i("div", {
                    class: r(["xs:mb-2 sm:mr-6 curcoin", k.currentCoin.change > 0 ? "up text-green-darken" : "down text-red-darken"])
                }, [i("div", hp, [i("span", null, f(k.currentCoin.price.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })), 1), "USD" != m(b).currency ? (o(), t("span", yp, f((k.currentCoin.price * m(b).currencyRate).toLocaleString(void 0, {
                    minimumFractionDigits: 2
                }) + " " + m(b).currency), 1)) : y("", !0)]), i("span", gp, f((100 * k.currentCoin.chg).toFixed(2)) + "%", 1)], 2), i("div", vp, [i("p", bp, f(m(g)("exh.24h-high")), 1), i("p", xp, " $" + f(k.currentCoin.high.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })), 1)]), i("div", wp, [i("p", kp, f(m(g)("exh.24h-low")), 1), i("p", Sp, " $" + f(k.currentCoin.low.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })), 1)]), i("div", {
                    class: r(["xs:mb-2 sm:mr-6 trade-header", m(b).isTradeAiMode && "ai-trade-header"])
                }, [i("p", Cp, f(m(g)("exh.24h-volume")), 1), i("p", _p, f((k.currentCoin.volume * k.currentCoin.price).toLocaleString(void 0, {
                    maximumFractionDigits: 2
                })) + " " + f(k.currentCoin.base), 1)], 2), m(b).isTradeAiMode ? y("", !0) : (o(), t("div", {
                    key: 0,
                    class: r(["xs:mb-2 sm:mr-6", !m(b).isTradeAiMode && "trade-header-sx"])
                }, [i("p", Tp, f(m(g)("exh.24h-volume") + "(" + k.currentCoin.coin + ")"), 1), i("p", Ap, f(k.currentCoin.volume) + " " + f(k.currentCoin.coin), 1)], 2)), m(b).isTradeAiMode ? (o(), h(l, {
                    key: 1,
                    class: "p-0 m-0",
                    style: {
                        width: "90px",
                        "max-width": "90px",
                        "min-width": "90px"
                    },
                    size: "small",
                    onClick: n[3] || (n[3] = () => (S.value = !0, void(C.value = !0)))
                }, {
                    default: d((() => n[8] || (n[8] = [a("AI Tools")]))),
                    _: 1
                })) : y("", !0)])]), C.value ? (o(), h(lp, {
                    key: 0,
                    modelValue: C.value,
                    "onUpdate:modelValue": n[4] || (n[4] = e => C.value = e)
                }, null, 8, ["modelValue"])) : y("", !0)], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-266d101a"]
    ]);

function Op(e, t) {
    return function(e) {
        if (Array.isArray(e)) return e
    }(e) || function(e, t) {
        if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) {
            var n = [],
                r = !0,
                o = !1,
                i = void 0;
            try {
                for (var a, s = e[Symbol.iterator](); !(r = (a = s.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
            } catch (l) {
                o = !0, i = l
            } finally {
                try {
                    r || null == s.return || s.return()
                } finally {
                    if (o) throw i
                }
            }
            return n
        }
    }(e, t)
}

function Ep(e, t) {
    var n, r;
    (n = HTMLCanvasElement.prototype).getContext = (r = n.getContext, function(e) {
        var t, n, o = r.call(this, e);
        return "2d" === e && (t = o.backingStorePixelRatio || o.webkitBackingStorePixelRatio || o.mozBackingStorePixelRatio || o.msBackingStorePixelRatio || o.oBackingStorePixelRatio || o.backingStorePixelRatio || 1, (n = (window.devicePixelRatio || 1) / t) > 1 && (this.style.height = this.height + "px", this.style.width = this.width + "px", this.width *= n, this.height *= n)), o
    });
    var o = {
            "hb-night": {
                bidsLineColor: t && t.bidsLineColor || "rgba(0, 141, 115, 1)",
                asksLineColor: t && t.asksLineColor || "rgba(236, 49, 75, 1)",
                bidsFillColor: t && t.bidsFillColor || "rgba(0, 141, 115, .6)",
                asksFillColor: t && t.asksFillColor || "rgba(236, 49, 75, .6)",
                axisColor: t && t.axisColor || "rgba(97, 104, 138, .3)",
                color: t && t.color || "rgba(81, 128, 159, .8)",
                bgColor: t && t.bgColor || "rgba(23, 54, 72, .95)",
                dotColor: "rgba(0 , 126, 224, 1)",
                tipColor: t && t.tipColor || "#C7CCE6",
                tipShadow: 4
            },
            "hb-day": {
                bidsLineColor: t && t.bidsLineColor || "rgba(3, 192, 135, 0)",
                asksLineColor: t && t.asksLineColor || "rgba(231, 109, 66, 0)",
                bidsFillColor: t && t.bidsFillColor || "rgba(3, 192, 135, .6)",
                asksFillColor: t && t.asksFillColor || "rgba(231, 109, 66, .6)",
                axisColor: t && t.axisColor || "rgba(180, 188, 227, .3)",
                color: t && t.color || "#232A4A",
                bgColor: t && t.bgColor || "#ffffff",
                dotColor: "rgba(0 , 126, 224, 1)",
                tipColor: t && t.tipColor || "#9CA9B5",
                tipShadow: 4
            }
        },
        i = {
            theme: t && t.theme || "hb-night",
            ruleHeight: t && t.ruleHeight || 30,
            ruleWidth: t && t.ruleWidth || 54,
            priceFix: t && t.priceFix || 2,
            amountFix: t && t.amountFix || 0,
            paddingTop: t && t.paddingTop || 15,
            noAmountTick: t && t.noAmountTick || 500,
            lang: t && t.lang || "en-us",
            langMap: t && t.langMap
        };

    function a(e) {
        var t = e || i.theme;
        Object.keys(o["hb-day"]).forEach((function(e) {
            i[e] = o[t][e]
        }))
    }
    a();
    var s, l, c, u = Object.assign({
            "en-us": {
                price: "Price",
                amount: "Amount"
            }
        }, i.langMap || {}),
        d = [],
        p = [],
        f = 0,
        m = "string" == typeof e ? document.querySelector("#" + e.replace("#", "")) : e || document.querySelector("#chart"),
        h = document.createElement("canvas"),
        y = m.offsetWidth,
        g = m.offsetHeight,
        v = document.createElement("canvas"),
        b = !0,
        x = h.getContext("2d"),
        w = v.getContext("2d"),
        k = (c = x, (window.devicePixelRatio || 1) / (c.backingStorePixelRatio || c.webkitBackingStorePixelRatio || c.mozBackingStorePixelRatio || c.msBackingStorePixelRatio || c.oBackingStorePixelRatio || c.backingStorePixelRatio || 1)),
        S = y - i.ruleWidth,
        C = g - i.ruleHeight,
        _ = ~~(g * i.paddingTop / 100),
        T = _ * k,
        A = C - _,
        D = A * k,
        O = S * k,
        E = C * k;

    function I(e, t) {
        if (e = e || l)
            if (l = e, H(w), b = !1, e > O - k) b = !0;
            else {
                for (var n = x.getImageData(e, 0, 1, E - 1 * k), r = 0; r < n.height; r++) {
                    var o = n.data[4 * r * n.width],
                        i = n.data[4 * r * n.width + 1];
                    if (o || i) return P(e, r, e > O / 2 ? "asks" : "bids"), void(b = !0)
                }
                b = !0
            }
    }

    function j(e) {
        return Op((e + "").split("."), 1)[0].length
    }
    h.width = v.width = y * k, h.height = v.height = g * k, h.style.position = v.style.position = "absolute", h.style.width = v.style.width = y + "px", h.style.height = v.style.height = g + "px", m.style.position = "relative", m.appendChild(h), m.appendChild(v);
    var L = {
        1e3: ["K", "M", "B"],
        1e4: ["万", "亿", "兆"]
    };

    function P(e, t, n) {
        (function(e, t, n) {
            var r, o;
            i.dotColor = "bids" === n ? i.bidsLineColor : i.asksLineColor, w.beginPath(), w.arc(e, t, 10 * k, 0, 2 * Math.PI), w.closePath(), w.fillStyle = i.dotColor.replace("1)", ".3)"), w.fill(), w.beginPath(), w.arc(e, t, 5 * k, 0, 2 * Math.PI), w.closePath(), w.fillStyle = i.dotColor, w.fill(), r = e, o = n, w.beginPath(), w.strokeStyle = i[o + "LineColor"], w.lineWidth = ~~(2 * k), w.setLineDash([5 * k, 5 * k]), w.moveTo(r, 0), w.lineTo(r, E), w.stroke(), w.closePath()
        })(e, t, n), CanvasRenderingContext2D.prototype.roundRect = function(e, t, n, r, o) {
            var i = Math.min(n, r);
            return o > i / 2 && (o = i / 2), this.beginPath(), this.moveTo(e + o, t), this.arcTo(e + n, t, e + n, t + r, o), this.arcTo(e + n, t + r, e, t + r, o), this.arcTo(e, t + r, e, t, o), this.arcTo(e, t, e + n, t, o), this.closePath(), this
        };
        var r = (6 * (f ? Math.max(f.toFixed(i.amountFix).toString().length - 9, 0) : 0) + 140) * k,
            o = 90 * k,
            a = 18 * k;
        w.shadowBlur = i.tipShadow * k, w.shadowOffsetY = i.tipShadow * k;
        var l = S - e > r ? e + 4 : e - r - 2,
            c = t - o - a > w.shadowBlur ? t - o - a : t + a,
            m = t - o - a > w.shadowBlur ? t - o - a : t + a,
            h = t - o - a > w.shadowBlur ? t - a : t + o + a,
            y = q(),
            g = y.pTick * e + y.pMin,
            v = function(e, t) {
                if ("bids" === t) {
                    var n = p.map((function(t) {
                        return Math.abs(t[0] - e)
                    }));
                    return n.indexOf(Math.min.apply(null, n)) > -1 && (s = p[n.indexOf(Math.min.apply(null, n))][1]), s
                }
                var r = d.map((function(t) {
                    return Math.abs(t[0] - e)
                }));
                return r.indexOf(Math.min.apply(null, r)) > -1 && (s = d[r.indexOf(Math.min.apply(null, r))][1]), s
            }(g, n);
        w.beginPath(), w.moveTo(V(e), V(m)), w.lineTo(V(e), V(h)), w.closePath(), w.lineWidth = ~~(4 * k), w.strokeStyle = "bids" === n ? i.bidsLineColor : i.asksLineColor, w.stroke(), w.fillStyle = i.bgColor, w.roundRect(l, c, r, o, 3 * k), w.fill(), w.shadowBlur = 0, w.shadowOffsetY = 0, w.fillStyle = i.tipColor, w.font = 12 * k + "px Arial", w.fillText(u[i.lang].price, l + 16 * k, c + 20 * k), w.fillText(g.toFixed(i.priceFix), l + 16 * k, c + 36 * k), w.fillText(u[i.lang].amount, l + 16 * k, c + 60 * k), w.fillText(v.toFixed(i.amountFix), l + 16 * k, c + 76 * k)
    }

    function M() {
        x.strokeStyle = i.axisColor, x.lineWidth = ~~(1.5 * k), x.beginPath(), x.moveTo(V(0), V(E)), x.lineTo(V(O), V(E)), x.lineTo(V(O), V(0)), x.stroke(), x.closePath()
    }

    function N() {
        var e = x.createLinearGradient(0, 0, 0, g);
        e.addColorStop(0, i.bidsFillColor), e.addColorStop(1, "transparent"), x.strokeStyle = i.bidsLineColor, x.lineWidth = ~~(2 * k), x.beginPath();
        for (var t = p.sort((function(e, t) {
                return e[0] - t[0]
            })), n = O / t.length / 2, r = 0; r < t.length; r++) 0 === r && x.moveTo(V(r * n), V(B(t[r][1]))), x.lineTo(V(r * n), V(B(t[r][1]))), r === t.length - 1 && x.lineTo(V(r * n), V(E - k));
        x.stroke(), x.lineTo(V(0), V(E)), x.lineTo(V(0), V(0)), x.closePath(), x.fillStyle = e, x.fill()
    }

    function F() {
        var e = x.createLinearGradient(0, 0, 0, g);
        e.addColorStop(0, i.asksFillColor), e.addColorStop(1, "transparent"), x.strokeStyle = i.asksLineColor, x.beginPath();
        for (var t = d.sort((function(e, t) {
                return e[0] - t[0]
            })), n = O / t.length / 2, r = O / 2 + 2 * k, o = 0; o < t.length; o++) 0 === o && x.lineTo(V(r), V(E - k)), x.lineTo(V(o * n + r), V(B(t[o][1]))), o === t.length - 1 && x.lineTo(V(O), V(B(t[o][1])));
        x.stroke(), x.lineTo(V(O), V(E - k)), x.lineTo(V(r), V(E - k)), x.closePath(), x.fillStyle = e, x.fill()
    }

    function R() {
        for (var e = 32 * k, t = 1 + ~~(C / 100), n = (O - 2 * e) / (~~(S / 100) - 1), r = (E - 16 * k * 2) / t, o = [], a = [], s = [], l = [], c = 0, u = [], d = [], p = q(), m = e; m < O; m += n) o.push(m), a.push(p.pMin + m * p.pTick);
        for (var h = E - k; h > 0; h -= r) s.push(h), l.push((E - k - h) * p.aTick);
        l.forEach((function(e, t) {
            c += e, u.push(i.noAmountTick * t), d.push(t)
        })), f < 5 && 0 !== c && (l = d, f = (D - r * t - 1) / r + 5), 0 === c && (l = u), l[0] = 0, W(o, a, "x"), W(s, l, "y")
    }

    function W(e, t, n) {
        x.lineWidth = ~~(1.5 * k), x.strokeStyle = i.axisColor, x.font = 12 * k + "px Arial", x.fillStyle = i.color, x.textAlign = "x" === n ? "center" : "left";
        var r = k;
        "x" === n ? e.forEach((function(e, n) {
            x.beginPath(), x.lineTo(V(e), E + r), x.lineTo(V(e), (C + 4) * k + r), x.stroke(), x.closePath(), x.fillText(t[n].toFixed(i.priceFix), V(e), (C + 20) * k + r)
        })) : e.forEach((function(e, n) {
            var o = t[n] <= 1e3 ? t[n].toFixed(0) : function(e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1e3,
                    r = L[n].reduce((function(e, t) {
                        return e[0] > n && (e[0] /= n, e[1] = t), e
                    }), [e, ""]),
                    o = t;
                return j(r[0]) === j(n) - 1 && (o -= 1), r[0] = r[0].toFixed(o), r.join("")
            }(t[n], 2, 1e3);
            x.beginPath(), x.lineTo(O + r, V(e + r)), x.lineTo((S + 4) * k + r, V(e + r)), x.stroke(), x.fillText(o, (S + 8) * k + r, V(e + 4 * k)), x.closePath()
        }))
    }

    function V(e) {
        return .5 + ~~e
    }

    function B(e) {
        if (0 === e) return E - k;
        var t = D - D * e / f + T;
        return t - E < ~~(x.lineWidth * k) ? t - ~~(x.lineWidth * k) : t
    }

    function H(e) {
        e.clearRect(0, 0, y * k, g * k)
    }

    function q() {
        var e = p[0] && p[0][0] || 0,
            t = d[d.length - 1] && d[d.length - 1][0] || 0;
        return {
            pMin: 1 * e,
            pMax: 1 * t,
            pTick: (t - e) / O,
            aTick: f / D
        }
    }

    function U() {
        H(x), M(), R(), N(), F()
    }
    return v.addEventListener("mousemove", (function(e) {
        var t, n, r = (t = e, n = h.getBoundingClientRect(), {
            x: (t.clientX - n.left) * k,
            y: (t.clientY - n.top) * k
        });
        b && I(r.x)
    }), !1), v.addEventListener("mouseout", (function(e) {
        setTimeout((function() {
            return H(w)
        }), 500), l = null
    }), !1), {
        update: U,
        putData: function(e) {
            H(x), H(w),
                function(e) {
                    var t = [],
                        n = [];
                    e.asks.forEach((function(e, n) {
                        var r = [];
                        r.push(e[0]), n - 1 > -1 ? r.push(1 * e[1] + 1 * t[n - 1][1]) : r.push(e[1]), t.push(r)
                    }));
                    var r = t[t.length - 1] ? t[t.length - 1][1] : 0;
                    e.bids.forEach((function(e, t) {
                        var r = [];
                        r.push(e[0]), t - 1 > -1 ? r.push(1 * e[1] + 1 * n[t - 1][1]) : r.push(e[1]), n.push(r)
                    }));
                    var o = n[n.length - 1] ? n[n.length - 1][1] : 0;
                    f = Math.max(o, r), d = t, p = n.reverse()
                }(e), M(), R(), N(), F(), I()
        },
        forceUpdate: function() {
            y = m.offsetWidth, g = m.offsetHeight, h.width = v.width = y * k, h.height = v.height = g * k, h.style.width = v.style.width = y + "px", h.style.height = v.style.height = g + "px", S = y - i.ruleWidth, C = g - i.ruleHeight, _ = ~~(g * i.paddingTop / 100), T = _ * k, D = (A = C - _) * k, O = S * k, E = C * k, b = !0, H(w), U()
        },
        initTheme: a,
        reload: function(e) {
            Object.assign(i, e)
        }
    }
}
var Ip, jp, Lp = {
    exports: {}
};
/*!
 * jQuery JavaScript Library v3.7.1
 * https://jquery.com/
 *
 * Copyright OpenJS Foundation and other contributors
 * Released under the MIT license
 * https://jquery.org/license
 *
 * Date: 2023-08-28T13:37Z
 */
Ip = "undefined" != typeof window ? window : g, jp = function(e, t) {
    var n = [],
        r = Object.getPrototypeOf,
        o = n.slice,
        i = n.flat ? function(e) {
            return n.flat.call(e)
        } : function(e) {
            return n.concat.apply([], e)
        },
        a = n.push,
        s = n.indexOf,
        l = {},
        c = l.toString,
        u = l.hasOwnProperty,
        d = u.toString,
        p = d.call(Object),
        f = {},
        m = function(e) {
            return "function" == typeof e && "number" != typeof e.nodeType && "function" != typeof e.item
        },
        h = function(e) {
            return null != e && e === e.window
        },
        y = e.document,
        g = {
            type: !0,
            src: !0,
            nonce: !0,
            noModule: !0
        };

    function v(e, t, n) {
        var r, o, i = (n = n || y).createElement("script");
        if (i.text = e, t)
            for (r in g)(o = t[r] || t.getAttribute && t.getAttribute(r)) && i.setAttribute(r, o);
        n.head.appendChild(i).parentNode.removeChild(i)
    }

    function b(e) {
        return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? l[c.call(e)] || "object" : typeof e
    }
    var x = "3.7.1",
        w = /HTML$/i,
        k = function(e, t) {
            return new k.fn.init(e, t)
        };

    function S(e) {
        var t = !!e && "length" in e && e.length,
            n = b(e);
        return !m(e) && !h(e) && ("array" === n || 0 === t || "number" == typeof t && t > 0 && t - 1 in e)
    }

    function C(e, t) {
        return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
    }
    k.fn = k.prototype = {
        jquery: x,
        constructor: k,
        length: 0,
        toArray: function() {
            return o.call(this)
        },
        get: function(e) {
            return null == e ? o.call(this) : e < 0 ? this[e + this.length] : this[e]
        },
        pushStack: function(e) {
            var t = k.merge(this.constructor(), e);
            return t.prevObject = this, t
        },
        each: function(e) {
            return k.each(this, e)
        },
        map: function(e) {
            return this.pushStack(k.map(this, (function(t, n) {
                return e.call(t, n, t)
            })))
        },
        slice: function() {
            return this.pushStack(o.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        even: function() {
            return this.pushStack(k.grep(this, (function(e, t) {
                return (t + 1) % 2
            })))
        },
        odd: function() {
            return this.pushStack(k.grep(this, (function(e, t) {
                return t % 2
            })))
        },
        eq: function(e) {
            var t = this.length,
                n = +e + (e < 0 ? t : 0);
            return this.pushStack(n >= 0 && n < t ? [this[n]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor()
        },
        push: a,
        sort: n.sort,
        splice: n.splice
    }, k.extend = k.fn.extend = function() {
        var e, t, n, r, o, i, a = arguments[0] || {},
            s = 1,
            l = arguments.length,
            c = !1;
        for ("boolean" == typeof a && (c = a, a = arguments[s] || {}, s++), "object" == typeof a || m(a) || (a = {}), s === l && (a = this, s--); s < l; s++)
            if (null != (e = arguments[s]))
                for (t in e) r = e[t], "__proto__" !== t && a !== r && (c && r && (k.isPlainObject(r) || (o = Array.isArray(r))) ? (n = a[t], i = o && !Array.isArray(n) ? [] : o || k.isPlainObject(n) ? n : {}, o = !1, a[t] = k.extend(c, i, r)) : void 0 !== r && (a[t] = r));
        return a
    }, k.extend({
        expando: "jQuery" + (x + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(e) {
            throw new Error(e)
        },
        noop: function() {},
        isPlainObject: function(e) {
            var t, n;
            return !(!e || "[object Object]" !== c.call(e) || (t = r(e)) && ("function" != typeof(n = u.call(t, "constructor") && t.constructor) || d.call(n) !== p))
        },
        isEmptyObject: function(e) {
            var t;
            for (t in e) return !1;
            return !0
        },
        globalEval: function(e, t, n) {
            v(e, {
                nonce: t && t.nonce
            }, n)
        },
        each: function(e, t) {
            var n, r = 0;
            if (S(e))
                for (n = e.length; r < n && !1 !== t.call(e[r], r, e[r]); r++);
            else
                for (r in e)
                    if (!1 === t.call(e[r], r, e[r])) break;
            return e
        },
        text: function(e) {
            var t, n = "",
                r = 0,
                o = e.nodeType;
            if (!o)
                for (; t = e[r++];) n += k.text(t);
            return 1 === o || 11 === o ? e.textContent : 9 === o ? e.documentElement.textContent : 3 === o || 4 === o ? e.nodeValue : n
        },
        makeArray: function(e, t) {
            var n = t || [];
            return null != e && (S(Object(e)) ? k.merge(n, "string" == typeof e ? [e] : e) : a.call(n, e)), n
        },
        inArray: function(e, t, n) {
            return null == t ? -1 : s.call(t, e, n)
        },
        isXMLDoc: function(e) {
            var t = e && e.namespaceURI,
                n = e && (e.ownerDocument || e).documentElement;
            return !w.test(t || n && n.nodeName || "HTML")
        },
        merge: function(e, t) {
            for (var n = +t.length, r = 0, o = e.length; r < n; r++) e[o++] = t[r];
            return e.length = o, e
        },
        grep: function(e, t, n) {
            for (var r = [], o = 0, i = e.length, a = !n; o < i; o++) !t(e[o], o) !== a && r.push(e[o]);
            return r
        },
        map: function(e, t, n) {
            var r, o, a = 0,
                s = [];
            if (S(e))
                for (r = e.length; a < r; a++) null != (o = t(e[a], a, n)) && s.push(o);
            else
                for (a in e) null != (o = t(e[a], a, n)) && s.push(o);
            return i(s)
        },
        guid: 1,
        support: f
    }), "function" == typeof Symbol && (k.fn[Symbol.iterator] = n[Symbol.iterator]), k.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), (function(e, t) {
        l["[object " + t + "]"] = t.toLowerCase()
    }));
    var _ = n.pop,
        T = n.sort,
        A = n.splice,
        D = "[\\x20\\t\\r\\n\\f]",
        O = new RegExp("^" + D + "+|((?:^|[^\\\\])(?:\\\\.)*)" + D + "+$", "g");
    k.contains = function(e, t) {
        var n = t && t.parentNode;
        return e === n || !(!n || 1 !== n.nodeType || !(e.contains ? e.contains(n) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(n)))
    };
    var E = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g;

    function I(e, t) {
        return t ? "\0" === e ? "�" : e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " " : "\\" + e
    }
    k.escapeSelector = function(e) {
        return (e + "").replace(E, I)
    };
    var j = y,
        L = a;
    ! function() {
        var t, r, i, a, l, c, d, p, m, h, y = L,
            g = k.expando,
            v = 0,
            b = 0,
            x = ee(),
            w = ee(),
            S = ee(),
            E = ee(),
            I = function(e, t) {
                return e === t && (l = !0), 0
            },
            P = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
            M = "(?:\\\\[\\da-fA-F]{1,6}" + D + "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+",
            N = "\\[" + D + "*(" + M + ")(?:" + D + "*([*^$|!~]?=)" + D + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + M + "))|)" + D + "*\\]",
            F = ":(" + M + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + N + ")*)|.*)\\)|)",
            R = new RegExp(D + "+", "g"),
            W = new RegExp("^" + D + "*," + D + "*"),
            V = new RegExp("^" + D + "*([>+~]|" + D + ")" + D + "*"),
            B = new RegExp(D + "|>"),
            H = new RegExp(F),
            q = new RegExp("^" + M + "$"),
            U = {
                ID: new RegExp("^#(" + M + ")"),
                CLASS: new RegExp("^\\.(" + M + ")"),
                TAG: new RegExp("^(" + M + "|[*])"),
                ATTR: new RegExp("^" + N),
                PSEUDO: new RegExp("^" + F),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + D + "*(even|odd|(([+-]|)(\\d*)n|)" + D + "*(?:([+-]|)" + D + "*(\\d+)|))" + D + "*\\)|)", "i"),
                bool: new RegExp("^(?:" + P + ")$", "i"),
                needsContext: new RegExp("^" + D + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + D + "*((?:-\\d)?\\d*)" + D + "*\\)|)(?=[^-]|$)", "i")
            },
            z = /^(?:input|select|textarea|button)$/i,
            $ = /^h\d$/i,
            Z = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            G = /[+~]/,
            Y = new RegExp("\\\\[\\da-fA-F]{1,6}" + D + "?|\\\\([^\\r\\n\\f])", "g"),
            J = function(e, t) {
                var n = "0x" + e.slice(1) - 65536;
                return t || (n < 0 ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, 1023 & n | 56320))
            },
            K = function() {
                le()
            },
            X = pe((function(e) {
                return !0 === e.disabled && C(e, "fieldset")
            }), {
                dir: "parentNode",
                next: "legend"
            });
        try {
            y.apply(n = o.call(j.childNodes), j.childNodes), n[j.childNodes.length].nodeType
        } catch (Fy) {
            y = {
                apply: function(e, t) {
                    L.apply(e, o.call(t))
                },
                call: function(e) {
                    L.apply(e, o.call(arguments, 1))
                }
            }
        }

        function Q(e, t, n, r) {
            var o, i, a, s, l, u, d, h = t && t.ownerDocument,
                v = t ? t.nodeType : 9;
            if (n = n || [], "string" != typeof e || !e || 1 !== v && 9 !== v && 11 !== v) return n;
            if (!r && (le(t), t = t || c, p)) {
                if (11 !== v && (l = Z.exec(e)))
                    if (o = l[1]) {
                        if (9 === v) {
                            if (!(a = t.getElementById(o))) return n;
                            if (a.id === o) return y.call(n, a), n
                        } else if (h && (a = h.getElementById(o)) && Q.contains(t, a) && a.id === o) return y.call(n, a), n
                    } else {
                        if (l[2]) return y.apply(n, t.getElementsByTagName(e)), n;
                        if ((o = l[3]) && t.getElementsByClassName) return y.apply(n, t.getElementsByClassName(o)), n
                    }
                if (!(E[e + " "] || m && m.test(e))) {
                    if (d = e, h = t, 1 === v && (B.test(e) || V.test(e))) {
                        for ((h = G.test(e) && se(t.parentNode) || t) == t && f.scope || ((s = t.getAttribute("id")) ? s = k.escapeSelector(s) : t.setAttribute("id", s = g)), i = (u = ue(e)).length; i--;) u[i] = (s ? "#" + s : ":scope") + " " + de(u[i]);
                        d = u.join(",")
                    }
                    try {
                        return y.apply(n, h.querySelectorAll(d)), n
                    } catch (b) {
                        E(e, !0)
                    } finally {
                        s === g && t.removeAttribute("id")
                    }
                }
            }
            return ve(e.replace(O, "$1"), t, n, r)
        }

        function ee() {
            var e = [];
            return function t(n, o) {
                return e.push(n + " ") > r.cacheLength && delete t[e.shift()], t[n + " "] = o
            }
        }

        function te(e) {
            return e[g] = !0, e
        }

        function ne(e) {
            var t = c.createElement("fieldset");
            try {
                return !!e(t)
            } catch (Fy) {
                return !1
            } finally {
                t.parentNode && t.parentNode.removeChild(t), t = null
            }
        }

        function re(e) {
            return function(t) {
                return C(t, "input") && t.type === e
            }
        }

        function oe(e) {
            return function(t) {
                return (C(t, "input") || C(t, "button")) && t.type === e
            }
        }

        function ie(e) {
            return function(t) {
                return "form" in t ? t.parentNode && !1 === t.disabled ? "label" in t ? "label" in t.parentNode ? t.parentNode.disabled === e : t.disabled === e : t.isDisabled === e || t.isDisabled !== !e && X(t) === e : t.disabled === e : "label" in t && t.disabled === e
            }
        }

        function ae(e) {
            return te((function(t) {
                return t = +t, te((function(n, r) {
                    for (var o, i = e([], n.length, t), a = i.length; a--;) n[o = i[a]] && (n[o] = !(r[o] = n[o]))
                }))
            }))
        }

        function se(e) {
            return e && void 0 !== e.getElementsByTagName && e
        }

        function le(e) {
            var t, n = e ? e.ownerDocument || e : j;
            return n != c && 9 === n.nodeType && n.documentElement ? (d = (c = n).documentElement, p = !k.isXMLDoc(c), h = d.matches || d.webkitMatchesSelector || d.msMatchesSelector, d.msMatchesSelector && j != c && (t = c.defaultView) && t.top !== t && t.addEventListener("unload", K), f.getById = ne((function(e) {
                return d.appendChild(e).id = k.expando, !c.getElementsByName || !c.getElementsByName(k.expando).length
            })), f.disconnectedMatch = ne((function(e) {
                return h.call(e, "*")
            })), f.scope = ne((function() {
                return c.querySelectorAll(":scope")
            })), f.cssHas = ne((function() {
                try {
                    return c.querySelector(":has(*,:jqfake)"), !1
                } catch (Fy) {
                    return !0
                }
            })), f.getById ? (r.filter.ID = function(e) {
                var t = e.replace(Y, J);
                return function(e) {
                    return e.getAttribute("id") === t
                }
            }, r.find.ID = function(e, t) {
                if (void 0 !== t.getElementById && p) {
                    var n = t.getElementById(e);
                    return n ? [n] : []
                }
            }) : (r.filter.ID = function(e) {
                var t = e.replace(Y, J);
                return function(e) {
                    var n = void 0 !== e.getAttributeNode && e.getAttributeNode("id");
                    return n && n.value === t
                }
            }, r.find.ID = function(e, t) {
                if (void 0 !== t.getElementById && p) {
                    var n, r, o, i = t.getElementById(e);
                    if (i) {
                        if ((n = i.getAttributeNode("id")) && n.value === e) return [i];
                        for (o = t.getElementsByName(e), r = 0; i = o[r++];)
                            if ((n = i.getAttributeNode("id")) && n.value === e) return [i]
                    }
                    return []
                }
            }), r.find.TAG = function(e, t) {
                return void 0 !== t.getElementsByTagName ? t.getElementsByTagName(e) : t.querySelectorAll(e)
            }, r.find.CLASS = function(e, t) {
                if (void 0 !== t.getElementsByClassName && p) return t.getElementsByClassName(e)
            }, m = [], ne((function(e) {
                var t;
                d.appendChild(e).innerHTML = "<a id='" + g + "' href='' disabled='disabled'></a><select id='" + g + "-\r\\' disabled='disabled'><option selected=''></option></select>", e.querySelectorAll("[selected]").length || m.push("\\[" + D + "*(?:value|" + P + ")"), e.querySelectorAll("[id~=" + g + "-]").length || m.push("~="), e.querySelectorAll("a#" + g + "+*").length || m.push(".#.+[+~]"), e.querySelectorAll(":checked").length || m.push(":checked"), (t = c.createElement("input")).setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), d.appendChild(e).disabled = !0, 2 !== e.querySelectorAll(":disabled").length && m.push(":enabled", ":disabled"), (t = c.createElement("input")).setAttribute("name", ""), e.appendChild(t), e.querySelectorAll("[name='']").length || m.push("\\[" + D + "*name" + D + "*=" + D + "*(?:''|\"\")")
            })), f.cssHas || m.push(":has"), m = m.length && new RegExp(m.join("|")), I = function(e, t) {
                if (e === t) return l = !0, 0;
                var n = !e.compareDocumentPosition - !t.compareDocumentPosition;
                return n || (1 & (n = (e.ownerDocument || e) == (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1) || !f.sortDetached && t.compareDocumentPosition(e) === n ? e === c || e.ownerDocument == j && Q.contains(j, e) ? -1 : t === c || t.ownerDocument == j && Q.contains(j, t) ? 1 : a ? s.call(a, e) - s.call(a, t) : 0 : 4 & n ? -1 : 1)
            }, c) : c
        }
        for (t in Q.matches = function(e, t) {
                return Q(e, null, null, t)
            }, Q.matchesSelector = function(e, t) {
                if (le(e), p && !E[t + " "] && (!m || !m.test(t))) try {
                    var n = h.call(e, t);
                    if (n || f.disconnectedMatch || e.document && 11 !== e.document.nodeType) return n
                } catch (Fy) {
                    E(t, !0)
                }
                return Q(t, c, null, [e]).length > 0
            }, Q.contains = function(e, t) {
                return (e.ownerDocument || e) != c && le(e), k.contains(e, t)
            }, Q.attr = function(e, t) {
                (e.ownerDocument || e) != c && le(e);
                var n = r.attrHandle[t.toLowerCase()],
                    o = n && u.call(r.attrHandle, t.toLowerCase()) ? n(e, t, !p) : void 0;
                return void 0 !== o ? o : e.getAttribute(t)
            }, Q.error = function(e) {
                throw new Error("Syntax error, unrecognized expression: " + e)
            }, k.uniqueSort = function(e) {
                var t, n = [],
                    r = 0,
                    i = 0;
                if (l = !f.sortStable, a = !f.sortStable && o.call(e, 0), T.call(e, I), l) {
                    for (; t = e[i++];) t === e[i] && (r = n.push(i));
                    for (; r--;) A.call(e, n[r], 1)
                }
                return a = null, e
            }, k.fn.uniqueSort = function() {
                return this.pushStack(k.uniqueSort(o.apply(this)))
            }, (r = k.expr = {
                cacheLength: 50,
                createPseudo: te,
                match: U,
                attrHandle: {},
                find: {},
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function(e) {
                        return e[1] = e[1].replace(Y, J), e[3] = (e[3] || e[4] || e[5] || "").replace(Y, J), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                    },
                    CHILD: function(e) {
                        return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || Q.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && Q.error(e[0]), e
                    },
                    PSEUDO: function(e) {
                        var t, n = !e[6] && e[2];
                        return U.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && H.test(n) && (t = ue(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function(e) {
                        var t = e.replace(Y, J).toLowerCase();
                        return "*" === e ? function() {
                            return !0
                        } : function(e) {
                            return C(e, t)
                        }
                    },
                    CLASS: function(e) {
                        var t = x[e + " "];
                        return t || (t = new RegExp("(^|" + D + ")" + e + "(" + D + "|$)")) && x(e, (function(e) {
                            return t.test("string" == typeof e.className && e.className || void 0 !== e.getAttribute && e.getAttribute("class") || "")
                        }))
                    },
                    ATTR: function(e, t, n) {
                        return function(r) {
                            var o = Q.attr(r, e);
                            return null == o ? "!=" === t : !t || (o += "", "=" === t ? o === n : "!=" === t ? o !== n : "^=" === t ? n && 0 === o.indexOf(n) : "*=" === t ? n && o.indexOf(n) > -1 : "$=" === t ? n && o.slice(-n.length) === n : "~=" === t ? (" " + o.replace(R, " ") + " ").indexOf(n) > -1 : "|=" === t && (o === n || o.slice(0, n.length + 1) === n + "-"))
                        }
                    },
                    CHILD: function(e, t, n, r, o) {
                        var i = "nth" !== e.slice(0, 3),
                            a = "last" !== e.slice(-4),
                            s = "of-type" === t;
                        return 1 === r && 0 === o ? function(e) {
                            return !!e.parentNode
                        } : function(t, n, l) {
                            var c, u, d, p, f, m = i !== a ? "nextSibling" : "previousSibling",
                                h = t.parentNode,
                                y = s && t.nodeName.toLowerCase(),
                                b = !l && !s,
                                x = !1;
                            if (h) {
                                if (i) {
                                    for (; m;) {
                                        for (d = t; d = d[m];)
                                            if (s ? C(d, y) : 1 === d.nodeType) return !1;
                                        f = m = "only" === e && !f && "nextSibling"
                                    }
                                    return !0
                                }
                                if (f = [a ? h.firstChild : h.lastChild], a && b) {
                                    for (x = (p = (c = (u = h[g] || (h[g] = {}))[e] || [])[0] === v && c[1]) && c[2], d = p && h.childNodes[p]; d = ++p && d && d[m] || (x = p = 0) || f.pop();)
                                        if (1 === d.nodeType && ++x && d === t) {
                                            u[e] = [v, p, x];
                                            break
                                        }
                                } else if (b && (x = p = (c = (u = t[g] || (t[g] = {}))[e] || [])[0] === v && c[1]), !1 === x)
                                    for (;
                                        (d = ++p && d && d[m] || (x = p = 0) || f.pop()) && (!(s ? C(d, y) : 1 === d.nodeType) || !++x || (b && ((u = d[g] || (d[g] = {}))[e] = [v, x]), d !== t)););
                                return (x -= o) === r || x % r == 0 && x / r >= 0
                            }
                        }
                    },
                    PSEUDO: function(e, t) {
                        var n, o = r.pseudos[e] || r.setFilters[e.toLowerCase()] || Q.error("unsupported pseudo: " + e);
                        return o[g] ? o(t) : o.length > 1 ? (n = [e, e, "", t], r.setFilters.hasOwnProperty(e.toLowerCase()) ? te((function(e, n) {
                            for (var r, i = o(e, t), a = i.length; a--;) e[r = s.call(e, i[a])] = !(n[r] = i[a])
                        })) : function(e) {
                            return o(e, 0, n)
                        }) : o
                    }
                },
                pseudos: {
                    not: te((function(e) {
                        var t = [],
                            n = [],
                            r = ge(e.replace(O, "$1"));
                        return r[g] ? te((function(e, t, n, o) {
                            for (var i, a = r(e, null, o, []), s = e.length; s--;)(i = a[s]) && (e[s] = !(t[s] = i))
                        })) : function(e, o, i) {
                            return t[0] = e, r(t, null, i, n), t[0] = null, !n.pop()
                        }
                    })),
                    has: te((function(e) {
                        return function(t) {
                            return Q(e, t).length > 0
                        }
                    })),
                    contains: te((function(e) {
                        return e = e.replace(Y, J),
                            function(t) {
                                return (t.textContent || k.text(t)).indexOf(e) > -1
                            }
                    })),
                    lang: te((function(e) {
                        return q.test(e || "") || Q.error("unsupported lang: " + e), e = e.replace(Y, J).toLowerCase(),
                            function(t) {
                                var n;
                                do {
                                    if (n = p ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return (n = n.toLowerCase()) === e || 0 === n.indexOf(e + "-")
                                } while ((t = t.parentNode) && 1 === t.nodeType);
                                return !1
                            }
                    })),
                    target: function(t) {
                        var n = e.location && e.location.hash;
                        return n && n.slice(1) === t.id
                    },
                    root: function(e) {
                        return e === d
                    },
                    focus: function(e) {
                        return e === function() {
                            try {
                                return c.activeElement
                            } catch (e) {}
                        }() && c.hasFocus() && !!(e.type || e.href || ~e.tabIndex)
                    },
                    enabled: ie(!1),
                    disabled: ie(!0),
                    checked: function(e) {
                        return C(e, "input") && !!e.checked || C(e, "option") && !!e.selected
                    },
                    selected: function(e) {
                        return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected
                    },
                    empty: function(e) {
                        for (e = e.firstChild; e; e = e.nextSibling)
                            if (e.nodeType < 6) return !1;
                        return !0
                    },
                    parent: function(e) {
                        return !r.pseudos.empty(e)
                    },
                    header: function(e) {
                        return $.test(e.nodeName)
                    },
                    input: function(e) {
                        return z.test(e.nodeName)
                    },
                    button: function(e) {
                        return C(e, "input") && "button" === e.type || C(e, "button")
                    },
                    text: function(e) {
                        var t;
                        return C(e, "input") && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                    },
                    first: ae((function() {
                        return [0]
                    })),
                    last: ae((function(e, t) {
                        return [t - 1]
                    })),
                    eq: ae((function(e, t, n) {
                        return [n < 0 ? n + t : n]
                    })),
                    even: ae((function(e, t) {
                        for (var n = 0; n < t; n += 2) e.push(n);
                        return e
                    })),
                    odd: ae((function(e, t) {
                        for (var n = 1; n < t; n += 2) e.push(n);
                        return e
                    })),
                    lt: ae((function(e, t, n) {
                        var r;
                        for (r = n < 0 ? n + t : n > t ? t : n; --r >= 0;) e.push(r);
                        return e
                    })),
                    gt: ae((function(e, t, n) {
                        for (var r = n < 0 ? n + t : n; ++r < t;) e.push(r);
                        return e
                    }))
                }
            }).pseudos.nth = r.pseudos.eq, {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            }) r.pseudos[t] = re(t);
        for (t in {
                submit: !0,
                reset: !0
            }) r.pseudos[t] = oe(t);

        function ce() {}

        function ue(e, t) {
            var n, o, i, a, s, l, c, u = w[e + " "];
            if (u) return t ? 0 : u.slice(0);
            for (s = e, l = [], c = r.preFilter; s;) {
                for (a in n && !(o = W.exec(s)) || (o && (s = s.slice(o[0].length) || s), l.push(i = [])), n = !1, (o = V.exec(s)) && (n = o.shift(), i.push({
                        value: n,
                        type: o[0].replace(O, " ")
                    }), s = s.slice(n.length)), r.filter) !(o = U[a].exec(s)) || c[a] && !(o = c[a](o)) || (n = o.shift(), i.push({
                    value: n,
                    type: a,
                    matches: o
                }), s = s.slice(n.length));
                if (!n) break
            }
            return t ? s.length : s ? Q.error(e) : w(e, l).slice(0)
        }

        function de(e) {
            for (var t = 0, n = e.length, r = ""; t < n; t++) r += e[t].value;
            return r
        }

        function pe(e, t, n) {
            var r = t.dir,
                o = t.next,
                i = o || r,
                a = n && "parentNode" === i,
                s = b++;
            return t.first ? function(t, n, o) {
                for (; t = t[r];)
                    if (1 === t.nodeType || a) return e(t, n, o);
                return !1
            } : function(t, n, l) {
                var c, u, d = [v, s];
                if (l) {
                    for (; t = t[r];)
                        if ((1 === t.nodeType || a) && e(t, n, l)) return !0
                } else
                    for (; t = t[r];)
                        if (1 === t.nodeType || a)
                            if (u = t[g] || (t[g] = {}), o && C(t, o)) t = t[r] || t;
                            else {
                                if ((c = u[i]) && c[0] === v && c[1] === s) return d[2] = c[2];
                                if (u[i] = d, d[2] = e(t, n, l)) return !0
                            } return !1
            }
        }

        function fe(e) {
            return e.length > 1 ? function(t, n, r) {
                for (var o = e.length; o--;)
                    if (!e[o](t, n, r)) return !1;
                return !0
            } : e[0]
        }

        function me(e, t, n, r, o) {
            for (var i, a = [], s = 0, l = e.length, c = null != t; s < l; s++)(i = e[s]) && (n && !n(i, r, o) || (a.push(i), c && t.push(s)));
            return a
        }

        function he(e, t, n, r, o, i) {
            return r && !r[g] && (r = he(r)), o && !o[g] && (o = he(o, i)), te((function(i, a, l, c) {
                var u, d, p, f, m = [],
                    h = [],
                    g = a.length,
                    v = i || function(e, t, n) {
                        for (var r = 0, o = t.length; r < o; r++) Q(e, t[r], n);
                        return n
                    }(t || "*", l.nodeType ? [l] : l, []),
                    b = !e || !i && t ? v : me(v, m, e, l, c);
                if (n ? n(b, f = o || (i ? e : g || r) ? [] : a, l, c) : f = b, r)
                    for (u = me(f, h), r(u, [], l, c), d = u.length; d--;)(p = u[d]) && (f[h[d]] = !(b[h[d]] = p));
                if (i) {
                    if (o || e) {
                        if (o) {
                            for (u = [], d = f.length; d--;)(p = f[d]) && u.push(b[d] = p);
                            o(null, f = [], u, c)
                        }
                        for (d = f.length; d--;)(p = f[d]) && (u = o ? s.call(i, p) : m[d]) > -1 && (i[u] = !(a[u] = p))
                    }
                } else f = me(f === a ? f.splice(g, f.length) : f), o ? o(null, a, f, c) : y.apply(a, f)
            }))
        }

        function ye(e) {
            for (var t, n, o, a = e.length, l = r.relative[e[0].type], c = l || r.relative[" "], u = l ? 1 : 0, d = pe((function(e) {
                    return e === t
                }), c, !0), p = pe((function(e) {
                    return s.call(t, e) > -1
                }), c, !0), f = [function(e, n, r) {
                    var o = !l && (r || n != i) || ((t = n).nodeType ? d(e, n, r) : p(e, n, r));
                    return t = null, o
                }]; u < a; u++)
                if (n = r.relative[e[u].type]) f = [pe(fe(f), n)];
                else {
                    if ((n = r.filter[e[u].type].apply(null, e[u].matches))[g]) {
                        for (o = ++u; o < a && !r.relative[e[o].type]; o++);
                        return he(u > 1 && fe(f), u > 1 && de(e.slice(0, u - 1).concat({
                            value: " " === e[u - 2].type ? "*" : ""
                        })).replace(O, "$1"), n, u < o && ye(e.slice(u, o)), o < a && ye(e = e.slice(o)), o < a && de(e))
                    }
                    f.push(n)
                }
            return fe(f)
        }

        function ge(e, t) {
            var n, o = [],
                a = [],
                s = S[e + " "];
            if (!s) {
                for (t || (t = ue(e)), n = t.length; n--;)(s = ye(t[n]))[g] ? o.push(s) : a.push(s);
                s = S(e, function(e, t) {
                    var n = t.length > 0,
                        o = e.length > 0,
                        a = function(a, s, l, u, d) {
                            var f, m, h, g = 0,
                                b = "0",
                                x = a && [],
                                w = [],
                                S = i,
                                C = a || o && r.find.TAG("*", d),
                                T = v += null == S ? 1 : Math.random() || .1,
                                A = C.length;
                            for (d && (i = s == c || s || d); b !== A && null != (f = C[b]); b++) {
                                if (o && f) {
                                    for (m = 0, s || f.ownerDocument == c || (le(f), l = !p); h = e[m++];)
                                        if (h(f, s || c, l)) {
                                            y.call(u, f);
                                            break
                                        }
                                    d && (v = T)
                                }
                                n && ((f = !h && f) && g--, a && x.push(f))
                            }
                            if (g += b, n && b !== g) {
                                for (m = 0; h = t[m++];) h(x, w, s, l);
                                if (a) {
                                    if (g > 0)
                                        for (; b--;) x[b] || w[b] || (w[b] = _.call(u));
                                    w = me(w)
                                }
                                y.apply(u, w), d && !a && w.length > 0 && g + t.length > 1 && k.uniqueSort(u)
                            }
                            return d && (v = T, i = S), x
                        };
                    return n ? te(a) : a
                }(a, o)), s.selector = e
            }
            return s
        }

        function ve(e, t, n, o) {
            var i, a, s, l, c, u = "function" == typeof e && e,
                d = !o && ue(e = u.selector || e);
            if (n = n || [], 1 === d.length) {
                if ((a = d[0] = d[0].slice(0)).length > 2 && "ID" === (s = a[0]).type && 9 === t.nodeType && p && r.relative[a[1].type]) {
                    if (!(t = (r.find.ID(s.matches[0].replace(Y, J), t) || [])[0])) return n;
                    u && (t = t.parentNode), e = e.slice(a.shift().value.length)
                }
                for (i = U.needsContext.test(e) ? 0 : a.length; i-- && (s = a[i], !r.relative[l = s.type]);)
                    if ((c = r.find[l]) && (o = c(s.matches[0].replace(Y, J), G.test(a[0].type) && se(t.parentNode) || t))) {
                        if (a.splice(i, 1), !(e = o.length && de(a))) return y.apply(n, o), n;
                        break
                    }
            }
            return (u || ge(e, d))(o, t, !p, n, !t || G.test(e) && se(t.parentNode) || t), n
        }
        ce.prototype = r.filters = r.pseudos, r.setFilters = new ce, f.sortStable = g.split("").sort(I).join("") === g, le(), f.sortDetached = ne((function(e) {
            return 1 & e.compareDocumentPosition(c.createElement("fieldset"))
        })), k.find = Q, k.expr[":"] = k.expr.pseudos, k.unique = k.uniqueSort, Q.compile = ge, Q.select = ve, Q.setDocument = le, Q.tokenize = ue, Q.escape = k.escapeSelector, Q.getText = k.text, Q.isXML = k.isXMLDoc, Q.selectors = k.expr, Q.support = k.support, Q.uniqueSort = k.uniqueSort
    }();
    var P = function(e, t, n) {
            for (var r = [], o = void 0 !== n;
                (e = e[t]) && 9 !== e.nodeType;)
                if (1 === e.nodeType) {
                    if (o && k(e).is(n)) break;
                    r.push(e)
                }
            return r
        },
        M = function(e, t) {
            for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n
        },
        N = k.expr.match.needsContext,
        F = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;

    function R(e, t, n) {
        return m(t) ? k.grep(e, (function(e, r) {
            return !!t.call(e, r, e) !== n
        })) : t.nodeType ? k.grep(e, (function(e) {
            return e === t !== n
        })) : "string" != typeof t ? k.grep(e, (function(e) {
            return s.call(t, e) > -1 !== n
        })) : k.filter(t, e, n)
    }
    k.filter = function(e, t, n) {
        var r = t[0];
        return n && (e = ":not(" + e + ")"), 1 === t.length && 1 === r.nodeType ? k.find.matchesSelector(r, e) ? [r] : [] : k.find.matches(e, k.grep(t, (function(e) {
            return 1 === e.nodeType
        })))
    }, k.fn.extend({
        find: function(e) {
            var t, n, r = this.length,
                o = this;
            if ("string" != typeof e) return this.pushStack(k(e).filter((function() {
                for (t = 0; t < r; t++)
                    if (k.contains(o[t], this)) return !0
            })));
            for (n = this.pushStack([]), t = 0; t < r; t++) k.find(e, o[t], n);
            return r > 1 ? k.uniqueSort(n) : n
        },
        filter: function(e) {
            return this.pushStack(R(this, e || [], !1))
        },
        not: function(e) {
            return this.pushStack(R(this, e || [], !0))
        },
        is: function(e) {
            return !!R(this, "string" == typeof e && N.test(e) ? k(e) : e || [], !1).length
        }
    });
    var W, V = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
    (k.fn.init = function(e, t, n) {
        var r, o;
        if (!e) return this;
        if (n = n || W, "string" == typeof e) {
            if (!(r = "<" === e[0] && ">" === e[e.length - 1] && e.length >= 3 ? [null, e, null] : V.exec(e)) || !r[1] && t) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
            if (r[1]) {
                if (t = t instanceof k ? t[0] : t, k.merge(this, k.parseHTML(r[1], t && t.nodeType ? t.ownerDocument || t : y, !0)), F.test(r[1]) && k.isPlainObject(t))
                    for (r in t) m(this[r]) ? this[r](t[r]) : this.attr(r, t[r]);
                return this
            }
            return (o = y.getElementById(r[2])) && (this[0] = o, this.length = 1), this
        }
        return e.nodeType ? (this[0] = e, this.length = 1, this) : m(e) ? void 0 !== n.ready ? n.ready(e) : e(k) : k.makeArray(e, this)
    }).prototype = k.fn, W = k(y);
    var B = /^(?:parents|prev(?:Until|All))/,
        H = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };

    function q(e, t) {
        for (;
            (e = e[t]) && 1 !== e.nodeType;);
        return e
    }
    k.fn.extend({
        has: function(e) {
            var t = k(e, this),
                n = t.length;
            return this.filter((function() {
                for (var e = 0; e < n; e++)
                    if (k.contains(this, t[e])) return !0
            }))
        },
        closest: function(e, t) {
            var n, r = 0,
                o = this.length,
                i = [],
                a = "string" != typeof e && k(e);
            if (!N.test(e))
                for (; r < o; r++)
                    for (n = this[r]; n && n !== t; n = n.parentNode)
                        if (n.nodeType < 11 && (a ? a.index(n) > -1 : 1 === n.nodeType && k.find.matchesSelector(n, e))) {
                            i.push(n);
                            break
                        }
            return this.pushStack(i.length > 1 ? k.uniqueSort(i) : i)
        },
        index: function(e) {
            return e ? "string" == typeof e ? s.call(k(e), this[0]) : s.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function(e, t) {
            return this.pushStack(k.uniqueSort(k.merge(this.get(), k(e, t))))
        },
        addBack: function(e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
        }
    }), k.each({
        parent: function(e) {
            var t = e.parentNode;
            return t && 11 !== t.nodeType ? t : null
        },
        parents: function(e) {
            return P(e, "parentNode")
        },
        parentsUntil: function(e, t, n) {
            return P(e, "parentNode", n)
        },
        next: function(e) {
            return q(e, "nextSibling")
        },
        prev: function(e) {
            return q(e, "previousSibling")
        },
        nextAll: function(e) {
            return P(e, "nextSibling")
        },
        prevAll: function(e) {
            return P(e, "previousSibling")
        },
        nextUntil: function(e, t, n) {
            return P(e, "nextSibling", n)
        },
        prevUntil: function(e, t, n) {
            return P(e, "previousSibling", n)
        },
        siblings: function(e) {
            return M((e.parentNode || {}).firstChild, e)
        },
        children: function(e) {
            return M(e.firstChild)
        },
        contents: function(e) {
            return null != e.contentDocument && r(e.contentDocument) ? e.contentDocument : (C(e, "template") && (e = e.content || e), k.merge([], e.childNodes))
        }
    }, (function(e, t) {
        k.fn[e] = function(n, r) {
            var o = k.map(this, t, n);
            return "Until" !== e.slice(-5) && (r = n), r && "string" == typeof r && (o = k.filter(r, o)), this.length > 1 && (H[e] || k.uniqueSort(o), B.test(e) && o.reverse()), this.pushStack(o)
        }
    }));
    var U = /[^\x20\t\r\n\f]+/g;

    function z(e) {
        return e
    }

    function $(e) {
        throw e
    }

    function Z(e, t, n, r) {
        var o;
        try {
            e && m(o = e.promise) ? o.call(e).done(t).fail(n) : e && m(o = e.then) ? o.call(e, t, n) : t.apply(void 0, [e].slice(r))
        } catch (i) {
            n.apply(void 0, [i])
        }
    }
    k.Callbacks = function(e) {
        e = "string" == typeof e ? function(e) {
            var t = {};
            return k.each(e.match(U) || [], (function(e, n) {
                t[n] = !0
            })), t
        }(e) : k.extend({}, e);
        var t, n, r, o, i = [],
            a = [],
            s = -1,
            l = function() {
                for (o = o || e.once, r = t = !0; a.length; s = -1)
                    for (n = a.shift(); ++s < i.length;) !1 === i[s].apply(n[0], n[1]) && e.stopOnFalse && (s = i.length, n = !1);
                e.memory || (n = !1), t = !1, o && (i = n ? [] : "")
            },
            c = {
                add: function() {
                    return i && (n && !t && (s = i.length - 1, a.push(n)), function t(n) {
                        k.each(n, (function(n, r) {
                            m(r) ? e.unique && c.has(r) || i.push(r) : r && r.length && "string" !== b(r) && t(r)
                        }))
                    }(arguments), n && !t && l()), this
                },
                remove: function() {
                    return k.each(arguments, (function(e, t) {
                        for (var n;
                            (n = k.inArray(t, i, n)) > -1;) i.splice(n, 1), n <= s && s--
                    })), this
                },
                has: function(e) {
                    return e ? k.inArray(e, i) > -1 : i.length > 0
                },
                empty: function() {
                    return i && (i = []), this
                },
                disable: function() {
                    return o = a = [], i = n = "", this
                },
                disabled: function() {
                    return !i
                },
                lock: function() {
                    return o = a = [], n || t || (i = n = ""), this
                },
                locked: function() {
                    return !!o
                },
                fireWith: function(e, n) {
                    return o || (n = [e, (n = n || []).slice ? n.slice() : n], a.push(n), t || l()), this
                },
                fire: function() {
                    return c.fireWith(this, arguments), this
                },
                fired: function() {
                    return !!r
                }
            };
        return c
    }, k.extend({
        Deferred: function(t) {
            var n = [
                    ["notify", "progress", k.Callbacks("memory"), k.Callbacks("memory"), 2],
                    ["resolve", "done", k.Callbacks("once memory"), k.Callbacks("once memory"), 0, "resolved"],
                    ["reject", "fail", k.Callbacks("once memory"), k.Callbacks("once memory"), 1, "rejected"]
                ],
                r = "pending",
                o = {
                    state: function() {
                        return r
                    },
                    always: function() {
                        return i.done(arguments).fail(arguments), this
                    },
                    catch: function(e) {
                        return o.then(null, e)
                    },
                    pipe: function() {
                        var e = arguments;
                        return k.Deferred((function(t) {
                            k.each(n, (function(n, r) {
                                var o = m(e[r[4]]) && e[r[4]];
                                i[r[1]]((function() {
                                    var e = o && o.apply(this, arguments);
                                    e && m(e.promise) ? e.promise().progress(t.notify).done(t.resolve).fail(t.reject) : t[r[0] + "With"](this, o ? [e] : arguments)
                                }))
                            })), e = null
                        })).promise()
                    },
                    then: function(t, r, o) {
                        var i = 0;

                        function a(t, n, r, o) {
                            return function() {
                                var s = this,
                                    l = arguments,
                                    c = function() {
                                        var e, c;
                                        if (!(t < i)) {
                                            if ((e = r.apply(s, l)) === n.promise()) throw new TypeError("Thenable self-resolution");
                                            c = e && ("object" == typeof e || "function" == typeof e) && e.then, m(c) ? o ? c.call(e, a(i, n, z, o), a(i, n, $, o)) : (i++, c.call(e, a(i, n, z, o), a(i, n, $, o), a(i, n, z, n.notifyWith))) : (r !== z && (s = void 0, l = [e]), (o || n.resolveWith)(s, l))
                                        }
                                    },
                                    u = o ? c : function() {
                                        try {
                                            c()
                                        } catch (Fy) {
                                            k.Deferred.exceptionHook && k.Deferred.exceptionHook(Fy, u.error), t + 1 >= i && (r !== $ && (s = void 0, l = [Fy]), n.rejectWith(s, l))
                                        }
                                    };
                                t ? u() : (k.Deferred.getErrorHook ? u.error = k.Deferred.getErrorHook() : k.Deferred.getStackHook && (u.error = k.Deferred.getStackHook()), e.setTimeout(u))
                            }
                        }
                        return k.Deferred((function(e) {
                            n[0][3].add(a(0, e, m(o) ? o : z, e.notifyWith)), n[1][3].add(a(0, e, m(t) ? t : z)), n[2][3].add(a(0, e, m(r) ? r : $))
                        })).promise()
                    },
                    promise: function(e) {
                        return null != e ? k.extend(e, o) : o
                    }
                },
                i = {};
            return k.each(n, (function(e, t) {
                var a = t[2],
                    s = t[5];
                o[t[1]] = a.add, s && a.add((function() {
                    r = s
                }), n[3 - e][2].disable, n[3 - e][3].disable, n[0][2].lock, n[0][3].lock), a.add(t[3].fire), i[t[0]] = function() {
                    return i[t[0] + "With"](this === i ? void 0 : this, arguments), this
                }, i[t[0] + "With"] = a.fireWith
            })), o.promise(i), t && t.call(i, i), i
        },
        when: function(e) {
            var t = arguments.length,
                n = t,
                r = Array(n),
                i = o.call(arguments),
                a = k.Deferred(),
                s = function(e) {
                    return function(n) {
                        r[e] = this, i[e] = arguments.length > 1 ? o.call(arguments) : n, --t || a.resolveWith(r, i)
                    }
                };
            if (t <= 1 && (Z(e, a.done(s(n)).resolve, a.reject, !t), "pending" === a.state() || m(i[n] && i[n].then))) return a.then();
            for (; n--;) Z(i[n], s(n), a.reject);
            return a.promise()
        }
    });
    var G = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
    k.Deferred.exceptionHook = function(t, n) {
        e.console && e.console.warn && t && G.test(t.name) && e.console.warn("jQuery.Deferred exception: " + t.message, t.stack, n)
    }, k.readyException = function(t) {
        e.setTimeout((function() {
            throw t
        }))
    };
    var Y = k.Deferred();

    function J() {
        y.removeEventListener("DOMContentLoaded", J), e.removeEventListener("load", J), k.ready()
    }
    k.fn.ready = function(e) {
        return Y.then(e).catch((function(e) {
            k.readyException(e)
        })), this
    }, k.extend({
        isReady: !1,
        readyWait: 1,
        ready: function(e) {
            (!0 === e ? --k.readyWait : k.isReady) || (k.isReady = !0, !0 !== e && --k.readyWait > 0 || Y.resolveWith(y, [k]))
        }
    }), k.ready.then = Y.then, "complete" === y.readyState || "loading" !== y.readyState && !y.documentElement.doScroll ? e.setTimeout(k.ready) : (y.addEventListener("DOMContentLoaded", J), e.addEventListener("load", J));
    var K = function(e, t, n, r, o, i, a) {
            var s = 0,
                l = e.length,
                c = null == n;
            if ("object" === b(n))
                for (s in o = !0, n) K(e, t, s, n[s], !0, i, a);
            else if (void 0 !== r && (o = !0, m(r) || (a = !0), c && (a ? (t.call(e, r), t = null) : (c = t, t = function(e, t, n) {
                    return c.call(k(e), n)
                })), t))
                for (; s < l; s++) t(e[s], n, a ? r : r.call(e[s], s, t(e[s], n)));
            return o ? e : c ? t.call(e) : l ? t(e[0], n) : i
        },
        X = /^-ms-/,
        Q = /-([a-z])/g;

    function ee(e, t) {
        return t.toUpperCase()
    }

    function te(e) {
        return e.replace(X, "ms-").replace(Q, ee)
    }
    var ne = function(e) {
        return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType
    };

    function re() {
        this.expando = k.expando + re.uid++
    }
    re.uid = 1, re.prototype = {
        cache: function(e) {
            var t = e[this.expando];
            return t || (t = {}, ne(e) && (e.nodeType ? e[this.expando] = t : Object.defineProperty(e, this.expando, {
                value: t,
                configurable: !0
            }))), t
        },
        set: function(e, t, n) {
            var r, o = this.cache(e);
            if ("string" == typeof t) o[te(t)] = n;
            else
                for (r in t) o[te(r)] = t[r];
            return o
        },
        get: function(e, t) {
            return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][te(t)]
        },
        access: function(e, t, n) {
            return void 0 === t || t && "string" == typeof t && void 0 === n ? this.get(e, t) : (this.set(e, t, n), void 0 !== n ? n : t)
        },
        remove: function(e, t) {
            var n, r = e[this.expando];
            if (void 0 !== r) {
                if (void 0 !== t) {
                    n = (t = Array.isArray(t) ? t.map(te) : (t = te(t)) in r ? [t] : t.match(U) || []).length;
                    for (; n--;) delete r[t[n]]
                }(void 0 === t || k.isEmptyObject(r)) && (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando])
            }
        },
        hasData: function(e) {
            var t = e[this.expando];
            return void 0 !== t && !k.isEmptyObject(t)
        }
    };
    var oe = new re,
        ie = new re,
        ae = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        se = /[A-Z]/g;

    function le(e, t, n) {
        var r;
        if (void 0 === n && 1 === e.nodeType)
            if (r = "data-" + t.replace(se, "-$&").toLowerCase(), "string" == typeof(n = e.getAttribute(r))) {
                try {
                    n = function(e) {
                        return "true" === e || "false" !== e && ("null" === e ? null : e === +e + "" ? +e : ae.test(e) ? JSON.parse(e) : e)
                    }(n)
                } catch (Fy) {}
                ie.set(e, t, n)
            } else n = void 0;
        return n
    }
    k.extend({
        hasData: function(e) {
            return ie.hasData(e) || oe.hasData(e)
        },
        data: function(e, t, n) {
            return ie.access(e, t, n)
        },
        removeData: function(e, t) {
            ie.remove(e, t)
        },
        _data: function(e, t, n) {
            return oe.access(e, t, n)
        },
        _removeData: function(e, t) {
            oe.remove(e, t)
        }
    }), k.fn.extend({
        data: function(e, t) {
            var n, r, o, i = this[0],
                a = i && i.attributes;
            if (void 0 === e) {
                if (this.length && (o = ie.get(i), 1 === i.nodeType && !oe.get(i, "hasDataAttrs"))) {
                    for (n = a.length; n--;) a[n] && 0 === (r = a[n].name).indexOf("data-") && (r = te(r.slice(5)), le(i, r, o[r]));
                    oe.set(i, "hasDataAttrs", !0)
                }
                return o
            }
            return "object" == typeof e ? this.each((function() {
                ie.set(this, e)
            })) : K(this, (function(t) {
                var n;
                if (i && void 0 === t) return void 0 !== (n = ie.get(i, e)) || void 0 !== (n = le(i, e)) ? n : void 0;
                this.each((function() {
                    ie.set(this, e, t)
                }))
            }), null, t, arguments.length > 1, null, !0)
        },
        removeData: function(e) {
            return this.each((function() {
                ie.remove(this, e)
            }))
        }
    }), k.extend({
        queue: function(e, t, n) {
            var r;
            if (e) return t = (t || "fx") + "queue", r = oe.get(e, t), n && (!r || Array.isArray(n) ? r = oe.access(e, t, k.makeArray(n)) : r.push(n)), r || []
        },
        dequeue: function(e, t) {
            t = t || "fx";
            var n = k.queue(e, t),
                r = n.length,
                o = n.shift(),
                i = k._queueHooks(e, t);
            "inprogress" === o && (o = n.shift(), r--), o && ("fx" === t && n.unshift("inprogress"), delete i.stop, o.call(e, (function() {
                k.dequeue(e, t)
            }), i)), !r && i && i.empty.fire()
        },
        _queueHooks: function(e, t) {
            var n = t + "queueHooks";
            return oe.get(e, n) || oe.access(e, n, {
                empty: k.Callbacks("once memory").add((function() {
                    oe.remove(e, [t + "queue", n])
                }))
            })
        }
    }), k.fn.extend({
        queue: function(e, t) {
            var n = 2;
            return "string" != typeof e && (t = e, e = "fx", n--), arguments.length < n ? k.queue(this[0], e) : void 0 === t ? this : this.each((function() {
                var n = k.queue(this, e, t);
                k._queueHooks(this, e), "fx" === e && "inprogress" !== n[0] && k.dequeue(this, e)
            }))
        },
        dequeue: function(e) {
            return this.each((function() {
                k.dequeue(this, e)
            }))
        },
        clearQueue: function(e) {
            return this.queue(e || "fx", [])
        },
        promise: function(e, t) {
            var n, r = 1,
                o = k.Deferred(),
                i = this,
                a = this.length,
                s = function() {
                    --r || o.resolveWith(i, [i])
                };
            for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; a--;)(n = oe.get(i[a], e + "queueHooks")) && n.empty && (r++, n.empty.add(s));
            return s(), o.promise(t)
        }
    });
    var ce = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        ue = new RegExp("^(?:([+-])=|)(" + ce + ")([a-z%]*)$", "i"),
        de = ["Top", "Right", "Bottom", "Left"],
        pe = y.documentElement,
        fe = function(e) {
            return k.contains(e.ownerDocument, e)
        },
        me = {
            composed: !0
        };
    pe.getRootNode && (fe = function(e) {
        return k.contains(e.ownerDocument, e) || e.getRootNode(me) === e.ownerDocument
    });
    var he = function(e, t) {
        return "none" === (e = t || e).style.display || "" === e.style.display && fe(e) && "none" === k.css(e, "display")
    };

    function ye(e, t, n, r) {
        var o, i, a = 20,
            s = r ? function() {
                return r.cur()
            } : function() {
                return k.css(e, t, "")
            },
            l = s(),
            c = n && n[3] || (k.cssNumber[t] ? "" : "px"),
            u = e.nodeType && (k.cssNumber[t] || "px" !== c && +l) && ue.exec(k.css(e, t));
        if (u && u[3] !== c) {
            for (l /= 2, c = c || u[3], u = +l || 1; a--;) k.style(e, t, u + c), (1 - i) * (1 - (i = s() / l || .5)) <= 0 && (a = 0), u /= i;
            u *= 2, k.style(e, t, u + c), n = n || []
        }
        return n && (u = +u || +l || 0, o = n[1] ? u + (n[1] + 1) * n[2] : +n[2], r && (r.unit = c, r.start = u, r.end = o)), o
    }
    var ge = {};

    function ve(e) {
        var t, n = e.ownerDocument,
            r = e.nodeName,
            o = ge[r];
        return o || (t = n.body.appendChild(n.createElement(r)), o = k.css(t, "display"), t.parentNode.removeChild(t), "none" === o && (o = "block"), ge[r] = o, o)
    }

    function be(e, t) {
        for (var n, r, o = [], i = 0, a = e.length; i < a; i++)(r = e[i]).style && (n = r.style.display, t ? ("none" === n && (o[i] = oe.get(r, "display") || null, o[i] || (r.style.display = "")), "" === r.style.display && he(r) && (o[i] = ve(r))) : "none" !== n && (o[i] = "none", oe.set(r, "display", n)));
        for (i = 0; i < a; i++) null != o[i] && (e[i].style.display = o[i]);
        return e
    }
    k.fn.extend({
        show: function() {
            return be(this, !0)
        },
        hide: function() {
            return be(this)
        },
        toggle: function(e) {
            return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each((function() {
                he(this) ? k(this).show() : k(this).hide()
            }))
        }
    });
    var xe, we, ke = /^(?:checkbox|radio)$/i,
        Se = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
        Ce = /^$|^module$|\/(?:java|ecma)script/i;
    xe = y.createDocumentFragment().appendChild(y.createElement("div")), (we = y.createElement("input")).setAttribute("type", "radio"), we.setAttribute("checked", "checked"), we.setAttribute("name", "t"), xe.appendChild(we), f.checkClone = xe.cloneNode(!0).cloneNode(!0).lastChild.checked, xe.innerHTML = "<textarea>x</textarea>", f.noCloneChecked = !!xe.cloneNode(!0).lastChild.defaultValue, xe.innerHTML = "<option></option>", f.option = !!xe.lastChild;
    var _e = {
        thead: [1, "<table>", "</table>"],
        col: [2, "<table><colgroup>", "</colgroup></table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        _default: [0, "", ""]
    };

    function Te(e, t) {
        var n;
        return n = void 0 !== e.getElementsByTagName ? e.getElementsByTagName(t || "*") : void 0 !== e.querySelectorAll ? e.querySelectorAll(t || "*") : [], void 0 === t || t && C(e, t) ? k.merge([e], n) : n
    }

    function Ae(e, t) {
        for (var n = 0, r = e.length; n < r; n++) oe.set(e[n], "globalEval", !t || oe.get(t[n], "globalEval"))
    }
    _e.tbody = _e.tfoot = _e.colgroup = _e.caption = _e.thead, _e.th = _e.td, f.option || (_e.optgroup = _e.option = [1, "<select multiple='multiple'>", "</select>"]);
    var De = /<|&#?\w+;/;

    function Oe(e, t, n, r, o) {
        for (var i, a, s, l, c, u, d = t.createDocumentFragment(), p = [], f = 0, m = e.length; f < m; f++)
            if ((i = e[f]) || 0 === i)
                if ("object" === b(i)) k.merge(p, i.nodeType ? [i] : i);
                else if (De.test(i)) {
            for (a = a || d.appendChild(t.createElement("div")), s = (Se.exec(i) || ["", ""])[1].toLowerCase(), l = _e[s] || _e._default, a.innerHTML = l[1] + k.htmlPrefilter(i) + l[2], u = l[0]; u--;) a = a.lastChild;
            k.merge(p, a.childNodes), (a = d.firstChild).textContent = ""
        } else p.push(t.createTextNode(i));
        for (d.textContent = "", f = 0; i = p[f++];)
            if (r && k.inArray(i, r) > -1) o && o.push(i);
            else if (c = fe(i), a = Te(d.appendChild(i), "script"), c && Ae(a), n)
            for (u = 0; i = a[u++];) Ce.test(i.type || "") && n.push(i);
        return d
    }
    var Ee = /^([^.]*)(?:\.(.+)|)/;

    function Ie() {
        return !0
    }

    function je() {
        return !1
    }

    function Le(e, t, n, r, o, i) {
        var a, s;
        if ("object" == typeof t) {
            for (s in "string" != typeof n && (r = r || n, n = void 0), t) Le(e, s, n, r, t[s], i);
            return e
        }
        if (null == r && null == o ? (o = n, r = n = void 0) : null == o && ("string" == typeof n ? (o = r, r = void 0) : (o = r, r = n, n = void 0)), !1 === o) o = je;
        else if (!o) return e;
        return 1 === i && (a = o, o = function(e) {
            return k().off(e), a.apply(this, arguments)
        }, o.guid = a.guid || (a.guid = k.guid++)), e.each((function() {
            k.event.add(this, t, o, r, n)
        }))
    }

    function Pe(e, t, n) {
        n ? (oe.set(e, t, !1), k.event.add(e, t, {
            namespace: !1,
            handler: function(e) {
                var n, r = oe.get(this, t);
                if (1 & e.isTrigger && this[t]) {
                    if (r)(k.event.special[t] || {}).delegateType && e.stopPropagation();
                    else if (r = o.call(arguments), oe.set(this, t, r), this[t](), n = oe.get(this, t), oe.set(this, t, !1), r !== n) return e.stopImmediatePropagation(), e.preventDefault(), n
                } else r && (oe.set(this, t, k.event.trigger(r[0], r.slice(1), this)), e.stopPropagation(), e.isImmediatePropagationStopped = Ie)
            }
        })) : void 0 === oe.get(e, t) && k.event.add(e, t, Ie)
    }
    k.event = {
        global: {},
        add: function(e, t, n, r, o) {
            var i, a, s, l, c, u, d, p, f, m, h, y = oe.get(e);
            if (ne(e))
                for (n.handler && (n = (i = n).handler, o = i.selector), o && k.find.matchesSelector(pe, o), n.guid || (n.guid = k.guid++), (l = y.events) || (l = y.events = Object.create(null)), (a = y.handle) || (a = y.handle = function(t) {
                        return void 0 !== k && k.event.triggered !== t.type ? k.event.dispatch.apply(e, arguments) : void 0
                    }), c = (t = (t || "").match(U) || [""]).length; c--;) f = h = (s = Ee.exec(t[c]) || [])[1], m = (s[2] || "").split(".").sort(), f && (d = k.event.special[f] || {}, f = (o ? d.delegateType : d.bindType) || f, d = k.event.special[f] || {}, u = k.extend({
                    type: f,
                    origType: h,
                    data: r,
                    handler: n,
                    guid: n.guid,
                    selector: o,
                    needsContext: o && k.expr.match.needsContext.test(o),
                    namespace: m.join(".")
                }, i), (p = l[f]) || ((p = l[f] = []).delegateCount = 0, d.setup && !1 !== d.setup.call(e, r, m, a) || e.addEventListener && e.addEventListener(f, a)), d.add && (d.add.call(e, u), u.handler.guid || (u.handler.guid = n.guid)), o ? p.splice(p.delegateCount++, 0, u) : p.push(u), k.event.global[f] = !0)
        },
        remove: function(e, t, n, r, o) {
            var i, a, s, l, c, u, d, p, f, m, h, y = oe.hasData(e) && oe.get(e);
            if (y && (l = y.events)) {
                for (c = (t = (t || "").match(U) || [""]).length; c--;)
                    if (f = h = (s = Ee.exec(t[c]) || [])[1], m = (s[2] || "").split(".").sort(), f) {
                        for (d = k.event.special[f] || {}, p = l[f = (r ? d.delegateType : d.bindType) || f] || [], s = s[2] && new RegExp("(^|\\.)" + m.join("\\.(?:.*\\.|)") + "(\\.|$)"), a = i = p.length; i--;) u = p[i], !o && h !== u.origType || n && n.guid !== u.guid || s && !s.test(u.namespace) || r && r !== u.selector && ("**" !== r || !u.selector) || (p.splice(i, 1), u.selector && p.delegateCount--, d.remove && d.remove.call(e, u));
                        a && !p.length && (d.teardown && !1 !== d.teardown.call(e, m, y.handle) || k.removeEvent(e, f, y.handle), delete l[f])
                    } else
                        for (f in l) k.event.remove(e, f + t[c], n, r, !0);
                k.isEmptyObject(l) && oe.remove(e, "handle events")
            }
        },
        dispatch: function(e) {
            var t, n, r, o, i, a, s = new Array(arguments.length),
                l = k.event.fix(e),
                c = (oe.get(this, "events") || Object.create(null))[l.type] || [],
                u = k.event.special[l.type] || {};
            for (s[0] = l, t = 1; t < arguments.length; t++) s[t] = arguments[t];
            if (l.delegateTarget = this, !u.preDispatch || !1 !== u.preDispatch.call(this, l)) {
                for (a = k.event.handlers.call(this, l, c), t = 0;
                    (o = a[t++]) && !l.isPropagationStopped();)
                    for (l.currentTarget = o.elem, n = 0;
                        (i = o.handlers[n++]) && !l.isImmediatePropagationStopped();) l.rnamespace && !1 !== i.namespace && !l.rnamespace.test(i.namespace) || (l.handleObj = i, l.data = i.data, void 0 !== (r = ((k.event.special[i.origType] || {}).handle || i.handler).apply(o.elem, s)) && !1 === (l.result = r) && (l.preventDefault(), l.stopPropagation()));
                return u.postDispatch && u.postDispatch.call(this, l), l.result
            }
        },
        handlers: function(e, t) {
            var n, r, o, i, a, s = [],
                l = t.delegateCount,
                c = e.target;
            if (l && c.nodeType && !("click" === e.type && e.button >= 1))
                for (; c !== this; c = c.parentNode || this)
                    if (1 === c.nodeType && ("click" !== e.type || !0 !== c.disabled)) {
                        for (i = [], a = {}, n = 0; n < l; n++) void 0 === a[o = (r = t[n]).selector + " "] && (a[o] = r.needsContext ? k(o, this).index(c) > -1 : k.find(o, this, null, [c]).length), a[o] && i.push(r);
                        i.length && s.push({
                            elem: c,
                            handlers: i
                        })
                    }
            return c = this, l < t.length && s.push({
                elem: c,
                handlers: t.slice(l)
            }), s
        },
        addProp: function(e, t) {
            Object.defineProperty(k.Event.prototype, e, {
                enumerable: !0,
                configurable: !0,
                get: m(t) ? function() {
                    if (this.originalEvent) return t(this.originalEvent)
                } : function() {
                    if (this.originalEvent) return this.originalEvent[e]
                },
                set: function(t) {
                    Object.defineProperty(this, e, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: t
                    })
                }
            })
        },
        fix: function(e) {
            return e[k.expando] ? e : new k.Event(e)
        },
        special: {
            load: {
                noBubble: !0
            },
            click: {
                setup: function(e) {
                    var t = this || e;
                    return ke.test(t.type) && t.click && C(t, "input") && Pe(t, "click", !0), !1
                },
                trigger: function(e) {
                    var t = this || e;
                    return ke.test(t.type) && t.click && C(t, "input") && Pe(t, "click"), !0
                },
                _default: function(e) {
                    var t = e.target;
                    return ke.test(t.type) && t.click && C(t, "input") && oe.get(t, "click") || C(t, "a")
                }
            },
            beforeunload: {
                postDispatch: function(e) {
                    void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
                }
            }
        }
    }, k.removeEvent = function(e, t, n) {
        e.removeEventListener && e.removeEventListener(t, n)
    }, k.Event = function(e, t) {
        if (!(this instanceof k.Event)) return new k.Event(e, t);
        e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && !1 === e.returnValue ? Ie : je, this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode : e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget) : this.type = e, t && k.extend(this, t), this.timeStamp = e && e.timeStamp || Date.now(), this[k.expando] = !0
    }, k.Event.prototype = {
        constructor: k.Event,
        isDefaultPrevented: je,
        isPropagationStopped: je,
        isImmediatePropagationStopped: je,
        isSimulated: !1,
        preventDefault: function() {
            var e = this.originalEvent;
            this.isDefaultPrevented = Ie, e && !this.isSimulated && e.preventDefault()
        },
        stopPropagation: function() {
            var e = this.originalEvent;
            this.isPropagationStopped = Ie, e && !this.isSimulated && e.stopPropagation()
        },
        stopImmediatePropagation: function() {
            var e = this.originalEvent;
            this.isImmediatePropagationStopped = Ie, e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation()
        }
    }, k.each({
        altKey: !0,
        bubbles: !0,
        cancelable: !0,
        changedTouches: !0,
        ctrlKey: !0,
        detail: !0,
        eventPhase: !0,
        metaKey: !0,
        pageX: !0,
        pageY: !0,
        shiftKey: !0,
        view: !0,
        char: !0,
        code: !0,
        charCode: !0,
        key: !0,
        keyCode: !0,
        button: !0,
        buttons: !0,
        clientX: !0,
        clientY: !0,
        offsetX: !0,
        offsetY: !0,
        pointerId: !0,
        pointerType: !0,
        screenX: !0,
        screenY: !0,
        targetTouches: !0,
        toElement: !0,
        touches: !0,
        which: !0
    }, k.event.addProp), k.each({
        focus: "focusin",
        blur: "focusout"
    }, (function(e, t) {
        function n(e) {
            if (y.documentMode) {
                var n = oe.get(this, "handle"),
                    r = k.event.fix(e);
                r.type = "focusin" === e.type ? "focus" : "blur", r.isSimulated = !0, n(e), r.target === r.currentTarget && n(r)
            } else k.event.simulate(t, e.target, k.event.fix(e))
        }
        k.event.special[e] = {
            setup: function() {
                var r;
                if (Pe(this, e, !0), !y.documentMode) return !1;
                (r = oe.get(this, t)) || this.addEventListener(t, n), oe.set(this, t, (r || 0) + 1)
            },
            trigger: function() {
                return Pe(this, e), !0
            },
            teardown: function() {
                var e;
                if (!y.documentMode) return !1;
                (e = oe.get(this, t) - 1) ? oe.set(this, t, e): (this.removeEventListener(t, n), oe.remove(this, t))
            },
            _default: function(t) {
                return oe.get(t.target, e)
            },
            delegateType: t
        }, k.event.special[t] = {
            setup: function() {
                var r = this.ownerDocument || this.document || this,
                    o = y.documentMode ? this : r,
                    i = oe.get(o, t);
                i || (y.documentMode ? this.addEventListener(t, n) : r.addEventListener(e, n, !0)), oe.set(o, t, (i || 0) + 1)
            },
            teardown: function() {
                var r = this.ownerDocument || this.document || this,
                    o = y.documentMode ? this : r,
                    i = oe.get(o, t) - 1;
                i ? oe.set(o, t, i) : (y.documentMode ? this.removeEventListener(t, n) : r.removeEventListener(e, n, !0), oe.remove(o, t))
            }
        }
    })), k.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    }, (function(e, t) {
        k.event.special[e] = {
            delegateType: t,
            bindType: t,
            handle: function(e) {
                var n, r = e.relatedTarget,
                    o = e.handleObj;
                return r && (r === this || k.contains(this, r)) || (e.type = o.origType, n = o.handler.apply(this, arguments), e.type = t), n
            }
        }
    })), k.fn.extend({
        on: function(e, t, n, r) {
            return Le(this, e, t, n, r)
        },
        one: function(e, t, n, r) {
            return Le(this, e, t, n, r, 1)
        },
        off: function(e, t, n) {
            var r, o;
            if (e && e.preventDefault && e.handleObj) return r = e.handleObj, k(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
            if ("object" == typeof e) {
                for (o in e) this.off(o, t, e[o]);
                return this
            }
            return !1 !== t && "function" != typeof t || (n = t, t = void 0), !1 === n && (n = je), this.each((function() {
                k.event.remove(this, e, n, t)
            }))
        }
    });
    var Me = /<script|<style|<link/i,
        Ne = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Fe = /^\s*<!\[CDATA\[|\]\]>\s*$/g;

    function Re(e, t) {
        return C(e, "table") && C(11 !== t.nodeType ? t : t.firstChild, "tr") && k(e).children("tbody")[0] || e
    }

    function We(e) {
        return e.type = (null !== e.getAttribute("type")) + "/" + e.type, e
    }

    function Ve(e) {
        return "true/" === (e.type || "").slice(0, 5) ? e.type = e.type.slice(5) : e.removeAttribute("type"), e
    }

    function Be(e, t) {
        var n, r, o, i, a, s;
        if (1 === t.nodeType) {
            if (oe.hasData(e) && (s = oe.get(e).events))
                for (o in oe.remove(t, "handle events"), s)
                    for (n = 0, r = s[o].length; n < r; n++) k.event.add(t, o, s[o][n]);
            ie.hasData(e) && (i = ie.access(e), a = k.extend({}, i), ie.set(t, a))
        }
    }

    function He(e, t, n, r) {
        t = i(t);
        var o, a, s, l, c, u, d = 0,
            p = e.length,
            h = p - 1,
            y = t[0],
            g = m(y);
        if (g || p > 1 && "string" == typeof y && !f.checkClone && Ne.test(y)) return e.each((function(o) {
            var i = e.eq(o);
            g && (t[0] = y.call(this, o, i.html())), He(i, t, n, r)
        }));
        if (p && (a = (o = Oe(t, e[0].ownerDocument, !1, e, r)).firstChild, 1 === o.childNodes.length && (o = a), a || r)) {
            for (l = (s = k.map(Te(o, "script"), We)).length; d < p; d++) c = o, d !== h && (c = k.clone(c, !0, !0), l && k.merge(s, Te(c, "script"))), n.call(e[d], c, d);
            if (l)
                for (u = s[s.length - 1].ownerDocument, k.map(s, Ve), d = 0; d < l; d++) c = s[d], Ce.test(c.type || "") && !oe.access(c, "globalEval") && k.contains(u, c) && (c.src && "module" !== (c.type || "").toLowerCase() ? k._evalUrl && !c.noModule && k._evalUrl(c.src, {
                    nonce: c.nonce || c.getAttribute("nonce")
                }, u) : v(c.textContent.replace(Fe, ""), c, u))
        }
        return e
    }

    function qe(e, t, n) {
        for (var r, o = t ? k.filter(t, e) : e, i = 0; null != (r = o[i]); i++) n || 1 !== r.nodeType || k.cleanData(Te(r)), r.parentNode && (n && fe(r) && Ae(Te(r, "script")), r.parentNode.removeChild(r));
        return e
    }
    k.extend({
        htmlPrefilter: function(e) {
            return e
        },
        clone: function(e, t, n) {
            var r, o, i, a, s, l, c, u = e.cloneNode(!0),
                d = fe(e);
            if (!(f.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || k.isXMLDoc(e)))
                for (a = Te(u), r = 0, o = (i = Te(e)).length; r < o; r++) s = i[r], l = a[r], c = void 0, "input" === (c = l.nodeName.toLowerCase()) && ke.test(s.type) ? l.checked = s.checked : "input" !== c && "textarea" !== c || (l.defaultValue = s.defaultValue);
            if (t)
                if (n)
                    for (i = i || Te(e), a = a || Te(u), r = 0, o = i.length; r < o; r++) Be(i[r], a[r]);
                else Be(e, u);
            return (a = Te(u, "script")).length > 0 && Ae(a, !d && Te(e, "script")), u
        },
        cleanData: function(e) {
            for (var t, n, r, o = k.event.special, i = 0; void 0 !== (n = e[i]); i++)
                if (ne(n)) {
                    if (t = n[oe.expando]) {
                        if (t.events)
                            for (r in t.events) o[r] ? k.event.remove(n, r) : k.removeEvent(n, r, t.handle);
                        n[oe.expando] = void 0
                    }
                    n[ie.expando] && (n[ie.expando] = void 0)
                }
        }
    }), k.fn.extend({
        detach: function(e) {
            return qe(this, e, !0)
        },
        remove: function(e) {
            return qe(this, e)
        },
        text: function(e) {
            return K(this, (function(e) {
                return void 0 === e ? k.text(this) : this.empty().each((function() {
                    1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = e)
                }))
            }), null, e, arguments.length)
        },
        append: function() {
            return He(this, arguments, (function(e) {
                1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || Re(this, e).appendChild(e)
            }))
        },
        prepend: function() {
            return He(this, arguments, (function(e) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var t = Re(this, e);
                    t.insertBefore(e, t.firstChild)
                }
            }))
        },
        before: function() {
            return He(this, arguments, (function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this)
            }))
        },
        after: function() {
            return He(this, arguments, (function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
            }))
        },
        empty: function() {
            for (var e, t = 0; null != (e = this[t]); t++) 1 === e.nodeType && (k.cleanData(Te(e, !1)), e.textContent = "");
            return this
        },
        clone: function(e, t) {
            return e = null != e && e, t = null == t ? e : t, this.map((function() {
                return k.clone(this, e, t)
            }))
        },
        html: function(e) {
            return K(this, (function(e) {
                var t = this[0] || {},
                    n = 0,
                    r = this.length;
                if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
                if ("string" == typeof e && !Me.test(e) && !_e[(Se.exec(e) || ["", ""])[1].toLowerCase()]) {
                    e = k.htmlPrefilter(e);
                    try {
                        for (; n < r; n++) 1 === (t = this[n] || {}).nodeType && (k.cleanData(Te(t, !1)), t.innerHTML = e);
                        t = 0
                    } catch (Fy) {}
                }
                t && this.empty().append(e)
            }), null, e, arguments.length)
        },
        replaceWith: function() {
            var e = [];
            return He(this, arguments, (function(t) {
                var n = this.parentNode;
                k.inArray(this, e) < 0 && (k.cleanData(Te(this)), n && n.replaceChild(t, this))
            }), e)
        }
    }), k.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, (function(e, t) {
        k.fn[e] = function(e) {
            for (var n, r = [], o = k(e), i = o.length - 1, s = 0; s <= i; s++) n = s === i ? this : this.clone(!0), k(o[s])[t](n), a.apply(r, n.get());
            return this.pushStack(r)
        }
    }));
    var Ue = new RegExp("^(" + ce + ")(?!px)[a-z%]+$", "i"),
        ze = /^--/,
        $e = function(t) {
            var n = t.ownerDocument.defaultView;
            return n && n.opener || (n = e), n.getComputedStyle(t)
        },
        Ze = function(e, t, n) {
            var r, o, i = {};
            for (o in t) i[o] = e.style[o], e.style[o] = t[o];
            for (o in r = n.call(e), t) e.style[o] = i[o];
            return r
        },
        Ge = new RegExp(de.join("|"), "i");

    function Ye(e, t, n) {
        var r, o, i, a, s = ze.test(t),
            l = e.style;
        return (n = n || $e(e)) && (a = n.getPropertyValue(t) || n[t], s && a && (a = a.replace(O, "$1") || void 0), "" !== a || fe(e) || (a = k.style(e, t)), !f.pixelBoxStyles() && Ue.test(a) && Ge.test(t) && (r = l.width, o = l.minWidth, i = l.maxWidth, l.minWidth = l.maxWidth = l.width = a, a = n.width, l.width = r, l.minWidth = o, l.maxWidth = i)), void 0 !== a ? a + "" : a
    }

    function Je(e, t) {
        return {
            get: function() {
                if (!e()) return (this.get = t).apply(this, arguments);
                delete this.get
            }
        }
    }! function() {
        function t() {
            if (u) {
                c.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0", u.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%", pe.appendChild(c).appendChild(u);
                var t = e.getComputedStyle(u);
                r = "1%" !== t.top, l = 12 === n(t.marginLeft), u.style.right = "60%", a = 36 === n(t.right), o = 36 === n(t.width), u.style.position = "absolute", i = 12 === n(u.offsetWidth / 3), pe.removeChild(c), u = null
            }
        }

        function n(e) {
            return Math.round(parseFloat(e))
        }
        var r, o, i, a, s, l, c = y.createElement("div"),
            u = y.createElement("div");
        u.style && (u.style.backgroundClip = "content-box", u.cloneNode(!0).style.backgroundClip = "", f.clearCloneStyle = "content-box" === u.style.backgroundClip, k.extend(f, {
            boxSizingReliable: function() {
                return t(), o
            },
            pixelBoxStyles: function() {
                return t(), a
            },
            pixelPosition: function() {
                return t(), r
            },
            reliableMarginLeft: function() {
                return t(), l
            },
            scrollboxSize: function() {
                return t(), i
            },
            reliableTrDimensions: function() {
                var t, n, r, o;
                return null == s && (t = y.createElement("table"), n = y.createElement("tr"), r = y.createElement("div"), t.style.cssText = "position:absolute;left:-11111px;border-collapse:separate", n.style.cssText = "box-sizing:content-box;border:1px solid", n.style.height = "1px", r.style.height = "9px", r.style.display = "block", pe.appendChild(t).appendChild(n).appendChild(r), o = e.getComputedStyle(n), s = parseInt(o.height, 10) + parseInt(o.borderTopWidth, 10) + parseInt(o.borderBottomWidth, 10) === n.offsetHeight, pe.removeChild(t)), s
            }
        }))
    }();
    var Ke = ["Webkit", "Moz", "ms"],
        Xe = y.createElement("div").style,
        Qe = {};

    function et(e) {
        var t = k.cssProps[e] || Qe[e];
        return t || (e in Xe ? e : Qe[e] = function(e) {
            for (var t = e[0].toUpperCase() + e.slice(1), n = Ke.length; n--;)
                if ((e = Ke[n] + t) in Xe) return e
        }(e) || e)
    }
    var tt = /^(none|table(?!-c[ea]).+)/,
        nt = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        rt = {
            letterSpacing: "0",
            fontWeight: "400"
        };

    function ot(e, t, n) {
        var r = ue.exec(t);
        return r ? Math.max(0, r[2] - (n || 0)) + (r[3] || "px") : t
    }

    function it(e, t, n, r, o, i) {
        var a = "width" === t ? 1 : 0,
            s = 0,
            l = 0,
            c = 0;
        if (n === (r ? "border" : "content")) return 0;
        for (; a < 4; a += 2) "margin" === n && (c += k.css(e, n + de[a], !0, o)), r ? ("content" === n && (l -= k.css(e, "padding" + de[a], !0, o)), "margin" !== n && (l -= k.css(e, "border" + de[a] + "Width", !0, o))) : (l += k.css(e, "padding" + de[a], !0, o), "padding" !== n ? l += k.css(e, "border" + de[a] + "Width", !0, o) : s += k.css(e, "border" + de[a] + "Width", !0, o));
        return !r && i >= 0 && (l += Math.max(0, Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - i - l - s - .5)) || 0), l + c
    }

    function at(e, t, n) {
        var r = $e(e),
            o = (!f.boxSizingReliable() || n) && "border-box" === k.css(e, "boxSizing", !1, r),
            i = o,
            a = Ye(e, t, r),
            s = "offset" + t[0].toUpperCase() + t.slice(1);
        if (Ue.test(a)) {
            if (!n) return a;
            a = "auto"
        }
        return (!f.boxSizingReliable() && o || !f.reliableTrDimensions() && C(e, "tr") || "auto" === a || !parseFloat(a) && "inline" === k.css(e, "display", !1, r)) && e.getClientRects().length && (o = "border-box" === k.css(e, "boxSizing", !1, r), (i = s in e) && (a = e[s])), (a = parseFloat(a) || 0) + it(e, t, n || (o ? "border" : "content"), i, r, a) + "px"
    }

    function st(e, t, n, r, o) {
        return new st.prototype.init(e, t, n, r, o)
    }
    k.extend({
        cssHooks: {
            opacity: {
                get: function(e, t) {
                    if (t) {
                        var n = Ye(e, "opacity");
                        return "" === n ? "1" : n
                    }
                }
            }
        },
        cssNumber: {
            animationIterationCount: !0,
            aspectRatio: !0,
            borderImageSlice: !0,
            columnCount: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            gridArea: !0,
            gridColumn: !0,
            gridColumnEnd: !0,
            gridColumnStart: !0,
            gridRow: !0,
            gridRowEnd: !0,
            gridRowStart: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            scale: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0,
            fillOpacity: !0,
            floodOpacity: !0,
            stopOpacity: !0,
            strokeMiterlimit: !0,
            strokeOpacity: !0
        },
        cssProps: {},
        style: function(e, t, n, r) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var o, i, a, s = te(t),
                    l = ze.test(t),
                    c = e.style;
                if (l || (t = et(s)), a = k.cssHooks[t] || k.cssHooks[s], void 0 === n) return a && "get" in a && void 0 !== (o = a.get(e, !1, r)) ? o : c[t];
                "string" == (i = typeof n) && (o = ue.exec(n)) && o[1] && (n = ye(e, t, o), i = "number"), null != n && n == n && ("number" !== i || l || (n += o && o[3] || (k.cssNumber[s] ? "" : "px")), f.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (c[t] = "inherit"), a && "set" in a && void 0 === (n = a.set(e, n, r)) || (l ? c.setProperty(t, n) : c[t] = n))
            }
        },
        css: function(e, t, n, r) {
            var o, i, a, s = te(t);
            return ze.test(t) || (t = et(s)), (a = k.cssHooks[t] || k.cssHooks[s]) && "get" in a && (o = a.get(e, !0, n)), void 0 === o && (o = Ye(e, t, r)), "normal" === o && t in rt && (o = rt[t]), "" === n || n ? (i = parseFloat(o), !0 === n || isFinite(i) ? i || 0 : o) : o
        }
    }), k.each(["height", "width"], (function(e, t) {
        k.cssHooks[t] = {
            get: function(e, n, r) {
                if (n) return !tt.test(k.css(e, "display")) || e.getClientRects().length && e.getBoundingClientRect().width ? at(e, t, r) : Ze(e, nt, (function() {
                    return at(e, t, r)
                }))
            },
            set: function(e, n, r) {
                var o, i = $e(e),
                    a = !f.scrollboxSize() && "absolute" === i.position,
                    s = (a || r) && "border-box" === k.css(e, "boxSizing", !1, i),
                    l = r ? it(e, t, r, s, i) : 0;
                return s && a && (l -= Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - parseFloat(i[t]) - it(e, t, "border", !1, i) - .5)), l && (o = ue.exec(n)) && "px" !== (o[3] || "px") && (e.style[t] = n, n = k.css(e, t)), ot(0, n, l)
            }
        }
    })), k.cssHooks.marginLeft = Je(f.reliableMarginLeft, (function(e, t) {
        if (t) return (parseFloat(Ye(e, "marginLeft")) || e.getBoundingClientRect().left - Ze(e, {
            marginLeft: 0
        }, (function() {
            return e.getBoundingClientRect().left
        }))) + "px"
    })), k.each({
        margin: "",
        padding: "",
        border: "Width"
    }, (function(e, t) {
        k.cssHooks[e + t] = {
            expand: function(n) {
                for (var r = 0, o = {}, i = "string" == typeof n ? n.split(" ") : [n]; r < 4; r++) o[e + de[r] + t] = i[r] || i[r - 2] || i[0];
                return o
            }
        }, "margin" !== e && (k.cssHooks[e + t].set = ot)
    })), k.fn.extend({
        css: function(e, t) {
            return K(this, (function(e, t, n) {
                var r, o, i = {},
                    a = 0;
                if (Array.isArray(t)) {
                    for (r = $e(e), o = t.length; a < o; a++) i[t[a]] = k.css(e, t[a], !1, r);
                    return i
                }
                return void 0 !== n ? k.style(e, t, n) : k.css(e, t)
            }), e, t, arguments.length > 1)
        }
    }), k.Tween = st, st.prototype = {
        constructor: st,
        init: function(e, t, n, r, o, i) {
            this.elem = e, this.prop = n, this.easing = o || k.easing._default, this.options = t, this.start = this.now = this.cur(), this.end = r, this.unit = i || (k.cssNumber[n] ? "" : "px")
        },
        cur: function() {
            var e = st.propHooks[this.prop];
            return e && e.get ? e.get(this) : st.propHooks._default.get(this)
        },
        run: function(e) {
            var t, n = st.propHooks[this.prop];
            return this.options.duration ? this.pos = t = k.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : st.propHooks._default.set(this), this
        }
    }, st.prototype.init.prototype = st.prototype, st.propHooks = {
        _default: {
            get: function(e) {
                var t;
                return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (t = k.css(e.elem, e.prop, "")) && "auto" !== t ? t : 0
            },
            set: function(e) {
                k.fx.step[e.prop] ? k.fx.step[e.prop](e) : 1 !== e.elem.nodeType || !k.cssHooks[e.prop] && null == e.elem.style[et(e.prop)] ? e.elem[e.prop] = e.now : k.style(e.elem, e.prop, e.now + e.unit)
            }
        }
    }, st.propHooks.scrollTop = st.propHooks.scrollLeft = {
        set: function(e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    }, k.easing = {
        linear: function(e) {
            return e
        },
        swing: function(e) {
            return .5 - Math.cos(e * Math.PI) / 2
        },
        _default: "swing"
    }, k.fx = st.prototype.init, k.fx.step = {};
    var lt, ct, ut = /^(?:toggle|show|hide)$/,
        dt = /queueHooks$/;

    function pt() {
        ct && (!1 === y.hidden && e.requestAnimationFrame ? e.requestAnimationFrame(pt) : e.setTimeout(pt, k.fx.interval), k.fx.tick())
    }

    function ft() {
        return e.setTimeout((function() {
            lt = void 0
        })), lt = Date.now()
    }

    function mt(e, t) {
        var n, r = 0,
            o = {
                height: e
            };
        for (t = t ? 1 : 0; r < 4; r += 2 - t) o["margin" + (n = de[r])] = o["padding" + n] = e;
        return t && (o.opacity = o.width = e), o
    }

    function ht(e, t, n) {
        for (var r, o = (yt.tweeners[t] || []).concat(yt.tweeners["*"]), i = 0, a = o.length; i < a; i++)
            if (r = o[i].call(n, t, e)) return r
    }

    function yt(e, t, n) {
        var r, o, i = 0,
            a = yt.prefilters.length,
            s = k.Deferred().always((function() {
                delete l.elem
            })),
            l = function() {
                if (o) return !1;
                for (var t = lt || ft(), n = Math.max(0, c.startTime + c.duration - t), r = 1 - (n / c.duration || 0), i = 0, a = c.tweens.length; i < a; i++) c.tweens[i].run(r);
                return s.notifyWith(e, [c, r, n]), r < 1 && a ? n : (a || s.notifyWith(e, [c, 1, 0]), s.resolveWith(e, [c]), !1)
            },
            c = s.promise({
                elem: e,
                props: k.extend({}, t),
                opts: k.extend(!0, {
                    specialEasing: {},
                    easing: k.easing._default
                }, n),
                originalProperties: t,
                originalOptions: n,
                startTime: lt || ft(),
                duration: n.duration,
                tweens: [],
                createTween: function(t, n) {
                    var r = k.Tween(e, c.opts, t, n, c.opts.specialEasing[t] || c.opts.easing);
                    return c.tweens.push(r), r
                },
                stop: function(t) {
                    var n = 0,
                        r = t ? c.tweens.length : 0;
                    if (o) return this;
                    for (o = !0; n < r; n++) c.tweens[n].run(1);
                    return t ? (s.notifyWith(e, [c, 1, 0]), s.resolveWith(e, [c, t])) : s.rejectWith(e, [c, t]), this
                }
            }),
            u = c.props;
        for (function(e, t) {
                var n, r, o, i, a;
                for (n in e)
                    if (o = t[r = te(n)], i = e[n], Array.isArray(i) && (o = i[1], i = e[n] = i[0]), n !== r && (e[r] = i, delete e[n]), (a = k.cssHooks[r]) && "expand" in a)
                        for (n in i = a.expand(i), delete e[r], i) n in e || (e[n] = i[n], t[n] = o);
                    else t[r] = o
            }(u, c.opts.specialEasing); i < a; i++)
            if (r = yt.prefilters[i].call(c, e, u, c.opts)) return m(r.stop) && (k._queueHooks(c.elem, c.opts.queue).stop = r.stop.bind(r)), r;
        return k.map(u, ht, c), m(c.opts.start) && c.opts.start.call(e, c), c.progress(c.opts.progress).done(c.opts.done, c.opts.complete).fail(c.opts.fail).always(c.opts.always), k.fx.timer(k.extend(l, {
            elem: e,
            anim: c,
            queue: c.opts.queue
        })), c
    }
    k.Animation = k.extend(yt, {
            tweeners: {
                "*": [function(e, t) {
                    var n = this.createTween(e, t);
                    return ye(n.elem, e, ue.exec(t), n), n
                }]
            },
            tweener: function(e, t) {
                m(e) ? (t = e, e = ["*"]) : e = e.match(U);
                for (var n, r = 0, o = e.length; r < o; r++) n = e[r], yt.tweeners[n] = yt.tweeners[n] || [], yt.tweeners[n].unshift(t)
            },
            prefilters: [function(e, t, n) {
                var r, o, i, a, s, l, c, u, d = "width" in t || "height" in t,
                    p = this,
                    f = {},
                    m = e.style,
                    h = e.nodeType && he(e),
                    y = oe.get(e, "fxshow");
                for (r in n.queue || (null == (a = k._queueHooks(e, "fx")).unqueued && (a.unqueued = 0, s = a.empty.fire, a.empty.fire = function() {
                        a.unqueued || s()
                    }), a.unqueued++, p.always((function() {
                        p.always((function() {
                            a.unqueued--, k.queue(e, "fx").length || a.empty.fire()
                        }))
                    }))), t)
                    if (o = t[r], ut.test(o)) {
                        if (delete t[r], i = i || "toggle" === o, o === (h ? "hide" : "show")) {
                            if ("show" !== o || !y || void 0 === y[r]) continue;
                            h = !0
                        }
                        f[r] = y && y[r] || k.style(e, r)
                    }
                if ((l = !k.isEmptyObject(t)) || !k.isEmptyObject(f))
                    for (r in d && 1 === e.nodeType && (n.overflow = [m.overflow, m.overflowX, m.overflowY], null == (c = y && y.display) && (c = oe.get(e, "display")), "none" === (u = k.css(e, "display")) && (c ? u = c : (be([e], !0), c = e.style.display || c, u = k.css(e, "display"), be([e]))), ("inline" === u || "inline-block" === u && null != c) && "none" === k.css(e, "float") && (l || (p.done((function() {
                            m.display = c
                        })), null == c && (u = m.display, c = "none" === u ? "" : u)), m.display = "inline-block")), n.overflow && (m.overflow = "hidden", p.always((function() {
                            m.overflow = n.overflow[0], m.overflowX = n.overflow[1], m.overflowY = n.overflow[2]
                        }))), l = !1, f) l || (y ? "hidden" in y && (h = y.hidden) : y = oe.access(e, "fxshow", {
                        display: c
                    }), i && (y.hidden = !h), h && be([e], !0), p.done((function() {
                        for (r in h || be([e]), oe.remove(e, "fxshow"), f) k.style(e, r, f[r])
                    }))), l = ht(h ? y[r] : 0, r, p), r in y || (y[r] = l.start, h && (l.end = l.start, l.start = 0))
            }],
            prefilter: function(e, t) {
                t ? yt.prefilters.unshift(e) : yt.prefilters.push(e)
            }
        }), k.speed = function(e, t, n) {
            var r = e && "object" == typeof e ? k.extend({}, e) : {
                complete: n || !n && t || m(e) && e,
                duration: e,
                easing: n && t || t && !m(t) && t
            };
            return k.fx.off ? r.duration = 0 : "number" != typeof r.duration && (r.duration in k.fx.speeds ? r.duration = k.fx.speeds[r.duration] : r.duration = k.fx.speeds._default), null != r.queue && !0 !== r.queue || (r.queue = "fx"), r.old = r.complete, r.complete = function() {
                m(r.old) && r.old.call(this), r.queue && k.dequeue(this, r.queue)
            }, r
        }, k.fn.extend({
            fadeTo: function(e, t, n, r) {
                return this.filter(he).css("opacity", 0).show().end().animate({
                    opacity: t
                }, e, n, r)
            },
            animate: function(e, t, n, r) {
                var o = k.isEmptyObject(e),
                    i = k.speed(t, n, r),
                    a = function() {
                        var t = yt(this, k.extend({}, e), i);
                        (o || oe.get(this, "finish")) && t.stop(!0)
                    };
                return a.finish = a, o || !1 === i.queue ? this.each(a) : this.queue(i.queue, a)
            },
            stop: function(e, t, n) {
                var r = function(e) {
                    var t = e.stop;
                    delete e.stop, t(n)
                };
                return "string" != typeof e && (n = t, t = e, e = void 0), t && this.queue(e || "fx", []), this.each((function() {
                    var t = !0,
                        o = null != e && e + "queueHooks",
                        i = k.timers,
                        a = oe.get(this);
                    if (o) a[o] && a[o].stop && r(a[o]);
                    else
                        for (o in a) a[o] && a[o].stop && dt.test(o) && r(a[o]);
                    for (o = i.length; o--;) i[o].elem !== this || null != e && i[o].queue !== e || (i[o].anim.stop(n), t = !1, i.splice(o, 1));
                    !t && n || k.dequeue(this, e)
                }))
            },
            finish: function(e) {
                return !1 !== e && (e = e || "fx"), this.each((function() {
                    var t, n = oe.get(this),
                        r = n[e + "queue"],
                        o = n[e + "queueHooks"],
                        i = k.timers,
                        a = r ? r.length : 0;
                    for (n.finish = !0, k.queue(this, e, []), o && o.stop && o.stop.call(this, !0), t = i.length; t--;) i[t].elem === this && i[t].queue === e && (i[t].anim.stop(!0), i.splice(t, 1));
                    for (t = 0; t < a; t++) r[t] && r[t].finish && r[t].finish.call(this);
                    delete n.finish
                }))
            }
        }), k.each(["toggle", "show", "hide"], (function(e, t) {
            var n = k.fn[t];
            k.fn[t] = function(e, r, o) {
                return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(mt(t, !0), e, r, o)
            }
        })), k.each({
            slideDown: mt("show"),
            slideUp: mt("hide"),
            slideToggle: mt("toggle"),
            fadeIn: {
                opacity: "show"
            },
            fadeOut: {
                opacity: "hide"
            },
            fadeToggle: {
                opacity: "toggle"
            }
        }, (function(e, t) {
            k.fn[e] = function(e, n, r) {
                return this.animate(t, e, n, r)
            }
        })), k.timers = [], k.fx.tick = function() {
            var e, t = 0,
                n = k.timers;
            for (lt = Date.now(); t < n.length; t++)(e = n[t])() || n[t] !== e || n.splice(t--, 1);
            n.length || k.fx.stop(), lt = void 0
        }, k.fx.timer = function(e) {
            k.timers.push(e), k.fx.start()
        }, k.fx.interval = 13, k.fx.start = function() {
            ct || (ct = !0, pt())
        }, k.fx.stop = function() {
            ct = null
        }, k.fx.speeds = {
            slow: 600,
            fast: 200,
            _default: 400
        }, k.fn.delay = function(t, n) {
            return t = k.fx && k.fx.speeds[t] || t, n = n || "fx", this.queue(n, (function(n, r) {
                var o = e.setTimeout(n, t);
                r.stop = function() {
                    e.clearTimeout(o)
                }
            }))
        },
        function() {
            var e = y.createElement("input"),
                t = y.createElement("select").appendChild(y.createElement("option"));
            e.type = "checkbox", f.checkOn = "" !== e.value, f.optSelected = t.selected, (e = y.createElement("input")).value = "t", e.type = "radio", f.radioValue = "t" === e.value
        }();
    var gt, vt = k.expr.attrHandle;
    k.fn.extend({
        attr: function(e, t) {
            return K(this, k.attr, e, t, arguments.length > 1)
        },
        removeAttr: function(e) {
            return this.each((function() {
                k.removeAttr(this, e)
            }))
        }
    }), k.extend({
        attr: function(e, t, n) {
            var r, o, i = e.nodeType;
            if (3 !== i && 8 !== i && 2 !== i) return void 0 === e.getAttribute ? k.prop(e, t, n) : (1 === i && k.isXMLDoc(e) || (o = k.attrHooks[t.toLowerCase()] || (k.expr.match.bool.test(t) ? gt : void 0)), void 0 !== n ? null === n ? void k.removeAttr(e, t) : o && "set" in o && void 0 !== (r = o.set(e, n, t)) ? r : (e.setAttribute(t, n + ""), n) : o && "get" in o && null !== (r = o.get(e, t)) ? r : null == (r = k.find.attr(e, t)) ? void 0 : r)
        },
        attrHooks: {
            type: {
                set: function(e, t) {
                    if (!f.radioValue && "radio" === t && C(e, "input")) {
                        var n = e.value;
                        return e.setAttribute("type", t), n && (e.value = n), t
                    }
                }
            }
        },
        removeAttr: function(e, t) {
            var n, r = 0,
                o = t && t.match(U);
            if (o && 1 === e.nodeType)
                for (; n = o[r++];) e.removeAttribute(n)
        }
    }), gt = {
        set: function(e, t, n) {
            return !1 === t ? k.removeAttr(e, n) : e.setAttribute(n, n), n
        }
    }, k.each(k.expr.match.bool.source.match(/\w+/g), (function(e, t) {
        var n = vt[t] || k.find.attr;
        vt[t] = function(e, t, r) {
            var o, i, a = t.toLowerCase();
            return r || (i = vt[a], vt[a] = o, o = null != n(e, t, r) ? a : null, vt[a] = i), o
        }
    }));
    var bt = /^(?:input|select|textarea|button)$/i,
        xt = /^(?:a|area)$/i;

    function wt(e) {
        return (e.match(U) || []).join(" ")
    }

    function kt(e) {
        return e.getAttribute && e.getAttribute("class") || ""
    }

    function St(e) {
        return Array.isArray(e) ? e : "string" == typeof e && e.match(U) || []
    }
    k.fn.extend({
        prop: function(e, t) {
            return K(this, k.prop, e, t, arguments.length > 1)
        },
        removeProp: function(e) {
            return this.each((function() {
                delete this[k.propFix[e] || e]
            }))
        }
    }), k.extend({
        prop: function(e, t, n) {
            var r, o, i = e.nodeType;
            if (3 !== i && 8 !== i && 2 !== i) return 1 === i && k.isXMLDoc(e) || (t = k.propFix[t] || t, o = k.propHooks[t]), void 0 !== n ? o && "set" in o && void 0 !== (r = o.set(e, n, t)) ? r : e[t] = n : o && "get" in o && null !== (r = o.get(e, t)) ? r : e[t]
        },
        propHooks: {
            tabIndex: {
                get: function(e) {
                    var t = k.find.attr(e, "tabindex");
                    return t ? parseInt(t, 10) : bt.test(e.nodeName) || xt.test(e.nodeName) && e.href ? 0 : -1
                }
            }
        },
        propFix: {
            for: "htmlFor",
            class: "className"
        }
    }), f.optSelected || (k.propHooks.selected = {
        get: function(e) {
            var t = e.parentNode;
            return t && t.parentNode && t.parentNode.selectedIndex, null
        },
        set: function(e) {
            var t = e.parentNode;
            t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex)
        }
    }), k.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], (function() {
        k.propFix[this.toLowerCase()] = this
    })), k.fn.extend({
        addClass: function(e) {
            var t, n, r, o, i, a;
            return m(e) ? this.each((function(t) {
                k(this).addClass(e.call(this, t, kt(this)))
            })) : (t = St(e)).length ? this.each((function() {
                if (r = kt(this), n = 1 === this.nodeType && " " + wt(r) + " ") {
                    for (i = 0; i < t.length; i++) o = t[i], n.indexOf(" " + o + " ") < 0 && (n += o + " ");
                    a = wt(n), r !== a && this.setAttribute("class", a)
                }
            })) : this
        },
        removeClass: function(e) {
            var t, n, r, o, i, a;
            return m(e) ? this.each((function(t) {
                k(this).removeClass(e.call(this, t, kt(this)))
            })) : arguments.length ? (t = St(e)).length ? this.each((function() {
                if (r = kt(this), n = 1 === this.nodeType && " " + wt(r) + " ") {
                    for (i = 0; i < t.length; i++)
                        for (o = t[i]; n.indexOf(" " + o + " ") > -1;) n = n.replace(" " + o + " ", " ");
                    a = wt(n), r !== a && this.setAttribute("class", a)
                }
            })) : this : this.attr("class", "")
        },
        toggleClass: function(e, t) {
            var n, r, o, i, a = typeof e,
                s = "string" === a || Array.isArray(e);
            return m(e) ? this.each((function(n) {
                k(this).toggleClass(e.call(this, n, kt(this), t), t)
            })) : "boolean" == typeof t && s ? t ? this.addClass(e) : this.removeClass(e) : (n = St(e), this.each((function() {
                if (s)
                    for (i = k(this), o = 0; o < n.length; o++) r = n[o], i.hasClass(r) ? i.removeClass(r) : i.addClass(r);
                else void 0 !== e && "boolean" !== a || ((r = kt(this)) && oe.set(this, "__className__", r), this.setAttribute && this.setAttribute("class", r || !1 === e ? "" : oe.get(this, "__className__") || ""))
            })))
        },
        hasClass: function(e) {
            var t, n, r = 0;
            for (t = " " + e + " "; n = this[r++];)
                if (1 === n.nodeType && (" " + wt(kt(n)) + " ").indexOf(t) > -1) return !0;
            return !1
        }
    });
    var Ct = /\r/g;
    k.fn.extend({
        val: function(e) {
            var t, n, r, o = this[0];
            return arguments.length ? (r = m(e), this.each((function(n) {
                var o;
                1 === this.nodeType && (null == (o = r ? e.call(this, n, k(this).val()) : e) ? o = "" : "number" == typeof o ? o += "" : Array.isArray(o) && (o = k.map(o, (function(e) {
                    return null == e ? "" : e + ""
                }))), (t = k.valHooks[this.type] || k.valHooks[this.nodeName.toLowerCase()]) && "set" in t && void 0 !== t.set(this, o, "value") || (this.value = o))
            }))) : o ? (t = k.valHooks[o.type] || k.valHooks[o.nodeName.toLowerCase()]) && "get" in t && void 0 !== (n = t.get(o, "value")) ? n : "string" == typeof(n = o.value) ? n.replace(Ct, "") : null == n ? "" : n : void 0
        }
    }), k.extend({
        valHooks: {
            option: {
                get: function(e) {
                    var t = k.find.attr(e, "value");
                    return null != t ? t : wt(k.text(e))
                }
            },
            select: {
                get: function(e) {
                    var t, n, r, o = e.options,
                        i = e.selectedIndex,
                        a = "select-one" === e.type,
                        s = a ? null : [],
                        l = a ? i + 1 : o.length;
                    for (r = i < 0 ? l : a ? i : 0; r < l; r++)
                        if (((n = o[r]).selected || r === i) && !n.disabled && (!n.parentNode.disabled || !C(n.parentNode, "optgroup"))) {
                            if (t = k(n).val(), a) return t;
                            s.push(t)
                        }
                    return s
                },
                set: function(e, t) {
                    for (var n, r, o = e.options, i = k.makeArray(t), a = o.length; a--;)((r = o[a]).selected = k.inArray(k.valHooks.option.get(r), i) > -1) && (n = !0);
                    return n || (e.selectedIndex = -1), i
                }
            }
        }
    }), k.each(["radio", "checkbox"], (function() {
        k.valHooks[this] = {
            set: function(e, t) {
                if (Array.isArray(t)) return e.checked = k.inArray(k(e).val(), t) > -1
            }
        }, f.checkOn || (k.valHooks[this].get = function(e) {
            return null === e.getAttribute("value") ? "on" : e.value
        })
    }));
    var _t = e.location,
        Tt = {
            guid: Date.now()
        },
        At = /\?/;
    k.parseXML = function(t) {
        var n, r;
        if (!t || "string" != typeof t) return null;
        try {
            n = (new e.DOMParser).parseFromString(t, "text/xml")
        } catch (Fy) {}
        return r = n && n.getElementsByTagName("parsererror")[0], n && !r || k.error("Invalid XML: " + (r ? k.map(r.childNodes, (function(e) {
            return e.textContent
        })).join("\n") : t)), n
    };
    var Dt = /^(?:focusinfocus|focusoutblur)$/,
        Ot = function(e) {
            e.stopPropagation()
        };
    k.extend(k.event, {
        trigger: function(t, n, r, o) {
            var i, a, s, l, c, d, p, f, g = [r || y],
                v = u.call(t, "type") ? t.type : t,
                b = u.call(t, "namespace") ? t.namespace.split(".") : [];
            if (a = f = s = r = r || y, 3 !== r.nodeType && 8 !== r.nodeType && !Dt.test(v + k.event.triggered) && (v.indexOf(".") > -1 && (b = v.split("."), v = b.shift(), b.sort()), c = v.indexOf(":") < 0 && "on" + v, (t = t[k.expando] ? t : new k.Event(v, "object" == typeof t && t)).isTrigger = o ? 2 : 3, t.namespace = b.join("."), t.rnamespace = t.namespace ? new RegExp("(^|\\.)" + b.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, t.result = void 0, t.target || (t.target = r), n = null == n ? [t] : k.makeArray(n, [t]), p = k.event.special[v] || {}, o || !p.trigger || !1 !== p.trigger.apply(r, n))) {
                if (!o && !p.noBubble && !h(r)) {
                    for (l = p.delegateType || v, Dt.test(l + v) || (a = a.parentNode); a; a = a.parentNode) g.push(a), s = a;
                    s === (r.ownerDocument || y) && g.push(s.defaultView || s.parentWindow || e)
                }
                for (i = 0;
                    (a = g[i++]) && !t.isPropagationStopped();) f = a, t.type = i > 1 ? l : p.bindType || v, (d = (oe.get(a, "events") || Object.create(null))[t.type] && oe.get(a, "handle")) && d.apply(a, n), (d = c && a[c]) && d.apply && ne(a) && (t.result = d.apply(a, n), !1 === t.result && t.preventDefault());
                return t.type = v, o || t.isDefaultPrevented() || p._default && !1 !== p._default.apply(g.pop(), n) || !ne(r) || c && m(r[v]) && !h(r) && ((s = r[c]) && (r[c] = null), k.event.triggered = v, t.isPropagationStopped() && f.addEventListener(v, Ot), r[v](), t.isPropagationStopped() && f.removeEventListener(v, Ot), k.event.triggered = void 0, s && (r[c] = s)), t.result
            }
        },
        simulate: function(e, t, n) {
            var r = k.extend(new k.Event, n, {
                type: e,
                isSimulated: !0
            });
            k.event.trigger(r, null, t)
        }
    }), k.fn.extend({
        trigger: function(e, t) {
            return this.each((function() {
                k.event.trigger(e, t, this)
            }))
        },
        triggerHandler: function(e, t) {
            var n = this[0];
            if (n) return k.event.trigger(e, t, n, !0)
        }
    });
    var Et = /\[\]$/,
        It = /\r?\n/g,
        jt = /^(?:submit|button|image|reset|file)$/i,
        Lt = /^(?:input|select|textarea|keygen)/i;

    function Pt(e, t, n, r) {
        var o;
        if (Array.isArray(t)) k.each(t, (function(t, o) {
            n || Et.test(e) ? r(e, o) : Pt(e + "[" + ("object" == typeof o && null != o ? t : "") + "]", o, n, r)
        }));
        else if (n || "object" !== b(t)) r(e, t);
        else
            for (o in t) Pt(e + "[" + o + "]", t[o], n, r)
    }
    k.param = function(e, t) {
        var n, r = [],
            o = function(e, t) {
                var n = m(t) ? t() : t;
                r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(null == n ? "" : n)
            };
        if (null == e) return "";
        if (Array.isArray(e) || e.jquery && !k.isPlainObject(e)) k.each(e, (function() {
            o(this.name, this.value)
        }));
        else
            for (n in e) Pt(n, e[n], t, o);
        return r.join("&")
    }, k.fn.extend({
        serialize: function() {
            return k.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map((function() {
                var e = k.prop(this, "elements");
                return e ? k.makeArray(e) : this
            })).filter((function() {
                var e = this.type;
                return this.name && !k(this).is(":disabled") && Lt.test(this.nodeName) && !jt.test(e) && (this.checked || !ke.test(e))
            })).map((function(e, t) {
                var n = k(this).val();
                return null == n ? null : Array.isArray(n) ? k.map(n, (function(e) {
                    return {
                        name: t.name,
                        value: e.replace(It, "\r\n")
                    }
                })) : {
                    name: t.name,
                    value: n.replace(It, "\r\n")
                }
            })).get()
        }
    });
    var Mt = /%20/g,
        Nt = /#.*$/,
        Ft = /([?&])_=[^&]*/,
        Rt = /^(.*?):[ \t]*([^\r\n]*)$/gm,
        Wt = /^(?:GET|HEAD)$/,
        Vt = /^\/\//,
        Bt = {},
        Ht = {},
        qt = "*/".concat("*"),
        Ut = y.createElement("a");

    function zt(e) {
        return function(t, n) {
            "string" != typeof t && (n = t, t = "*");
            var r, o = 0,
                i = t.toLowerCase().match(U) || [];
            if (m(n))
                for (; r = i[o++];) "+" === r[0] ? (r = r.slice(1) || "*", (e[r] = e[r] || []).unshift(n)) : (e[r] = e[r] || []).push(n)
        }
    }

    function $t(e, t, n, r) {
        var o = {},
            i = e === Ht;

        function a(s) {
            var l;
            return o[s] = !0, k.each(e[s] || [], (function(e, s) {
                var c = s(t, n, r);
                return "string" != typeof c || i || o[c] ? i ? !(l = c) : void 0 : (t.dataTypes.unshift(c), a(c), !1)
            })), l
        }
        return a(t.dataTypes[0]) || !o["*"] && a("*")
    }

    function Zt(e, t) {
        var n, r, o = k.ajaxSettings.flatOptions || {};
        for (n in t) void 0 !== t[n] && ((o[n] ? e : r || (r = {}))[n] = t[n]);
        return r && k.extend(!0, e, r), e
    }
    Ut.href = _t.href, k.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: _t.href,
            type: "GET",
            isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(_t.protocol),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": qt,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /\bxml\b/,
                html: /\bhtml/,
                json: /\bjson\b/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": JSON.parse,
                "text xml": k.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(e, t) {
            return t ? Zt(Zt(e, k.ajaxSettings), t) : Zt(k.ajaxSettings, e)
        },
        ajaxPrefilter: zt(Bt),
        ajaxTransport: zt(Ht),
        ajax: function(t, n) {
            "object" == typeof t && (n = t, t = void 0), n = n || {};
            var r, o, i, a, s, l, c, u, d, p, f = k.ajaxSetup({}, n),
                m = f.context || f,
                h = f.context && (m.nodeType || m.jquery) ? k(m) : k.event,
                g = k.Deferred(),
                v = k.Callbacks("once memory"),
                b = f.statusCode || {},
                x = {},
                w = {},
                S = "canceled",
                C = {
                    readyState: 0,
                    getResponseHeader: function(e) {
                        var t;
                        if (c) {
                            if (!a)
                                for (a = {}; t = Rt.exec(i);) a[t[1].toLowerCase() + " "] = (a[t[1].toLowerCase() + " "] || []).concat(t[2]);
                            t = a[e.toLowerCase() + " "]
                        }
                        return null == t ? null : t.join(", ")
                    },
                    getAllResponseHeaders: function() {
                        return c ? i : null
                    },
                    setRequestHeader: function(e, t) {
                        return null == c && (e = w[e.toLowerCase()] = w[e.toLowerCase()] || e, x[e] = t), this
                    },
                    overrideMimeType: function(e) {
                        return null == c && (f.mimeType = e), this
                    },
                    statusCode: function(e) {
                        var t;
                        if (e)
                            if (c) C.always(e[C.status]);
                            else
                                for (t in e) b[t] = [b[t], e[t]];
                        return this
                    },
                    abort: function(e) {
                        var t = e || S;
                        return r && r.abort(t), _(0, t), this
                    }
                };
            if (g.promise(C), f.url = ((t || f.url || _t.href) + "").replace(Vt, _t.protocol + "//"), f.type = n.method || n.type || f.method || f.type, f.dataTypes = (f.dataType || "*").toLowerCase().match(U) || [""], null == f.crossDomain) {
                l = y.createElement("a");
                try {
                    l.href = f.url, l.href = l.href, f.crossDomain = Ut.protocol + "//" + Ut.host != l.protocol + "//" + l.host
                } catch (Fy) {
                    f.crossDomain = !0
                }
            }
            if (f.data && f.processData && "string" != typeof f.data && (f.data = k.param(f.data, f.traditional)), $t(Bt, f, n, C), c) return C;
            for (d in (u = k.event && f.global) && 0 == k.active++ && k.event.trigger("ajaxStart"), f.type = f.type.toUpperCase(), f.hasContent = !Wt.test(f.type), o = f.url.replace(Nt, ""), f.hasContent ? f.data && f.processData && 0 === (f.contentType || "").indexOf("application/x-www-form-urlencoded") && (f.data = f.data.replace(Mt, "+")) : (p = f.url.slice(o.length), f.data && (f.processData || "string" == typeof f.data) && (o += (At.test(o) ? "&" : "?") + f.data, delete f.data), !1 === f.cache && (o = o.replace(Ft, "$1"), p = (At.test(o) ? "&" : "?") + "_=" + Tt.guid++ + p), f.url = o + p), f.ifModified && (k.lastModified[o] && C.setRequestHeader("If-Modified-Since", k.lastModified[o]), k.etag[o] && C.setRequestHeader("If-None-Match", k.etag[o])), (f.data && f.hasContent && !1 !== f.contentType || n.contentType) && C.setRequestHeader("Content-Type", f.contentType), C.setRequestHeader("Accept", f.dataTypes[0] && f.accepts[f.dataTypes[0]] ? f.accepts[f.dataTypes[0]] + ("*" !== f.dataTypes[0] ? ", " + qt + "; q=0.01" : "") : f.accepts["*"]), f.headers) C.setRequestHeader(d, f.headers[d]);
            if (f.beforeSend && (!1 === f.beforeSend.call(m, C, f) || c)) return C.abort();
            if (S = "abort", v.add(f.complete), C.done(f.success), C.fail(f.error), r = $t(Ht, f, n, C)) {
                if (C.readyState = 1, u && h.trigger("ajaxSend", [C, f]), c) return C;
                f.async && f.timeout > 0 && (s = e.setTimeout((function() {
                    C.abort("timeout")
                }), f.timeout));
                try {
                    c = !1, r.send(x, _)
                } catch (Fy) {
                    if (c) throw Fy;
                    _(-1, Fy)
                }
            } else _(-1, "No Transport");

            function _(t, n, a, l) {
                var d, p, y, x, w, S = n;
                c || (c = !0, s && e.clearTimeout(s), r = void 0, i = l || "", C.readyState = t > 0 ? 4 : 0, d = t >= 200 && t < 300 || 304 === t, a && (x = function(e, t, n) {
                    for (var r, o, i, a, s = e.contents, l = e.dataTypes;
                        "*" === l[0];) l.shift(), void 0 === r && (r = e.mimeType || t.getResponseHeader("Content-Type"));
                    if (r)
                        for (o in s)
                            if (s[o] && s[o].test(r)) {
                                l.unshift(o);
                                break
                            }
                    if (l[0] in n) i = l[0];
                    else {
                        for (o in n) {
                            if (!l[0] || e.converters[o + " " + l[0]]) {
                                i = o;
                                break
                            }
                            a || (a = o)
                        }
                        i = i || a
                    }
                    if (i) return i !== l[0] && l.unshift(i), n[i]
                }(f, C, a)), !d && k.inArray("script", f.dataTypes) > -1 && k.inArray("json", f.dataTypes) < 0 && (f.converters["text script"] = function() {}), x = function(e, t, n, r) {
                    var o, i, a, s, l, c = {},
                        u = e.dataTypes.slice();
                    if (u[1])
                        for (a in e.converters) c[a.toLowerCase()] = e.converters[a];
                    for (i = u.shift(); i;)
                        if (e.responseFields[i] && (n[e.responseFields[i]] = t), !l && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), l = i, i = u.shift())
                            if ("*" === i) i = l;
                            else if ("*" !== l && l !== i) {
                        if (!(a = c[l + " " + i] || c["* " + i]))
                            for (o in c)
                                if ((s = o.split(" "))[1] === i && (a = c[l + " " + s[0]] || c["* " + s[0]])) {
                                    !0 === a ? a = c[o] : !0 !== c[o] && (i = s[0], u.unshift(s[1]));
                                    break
                                }
                        if (!0 !== a)
                            if (a && e.throws) t = a(t);
                            else try {
                                t = a(t)
                            } catch (Fy) {
                                return {
                                    state: "parsererror",
                                    error: a ? Fy : "No conversion from " + l + " to " + i
                                }
                            }
                    }
                    return {
                        state: "success",
                        data: t
                    }
                }(f, x, C, d), d ? (f.ifModified && ((w = C.getResponseHeader("Last-Modified")) && (k.lastModified[o] = w), (w = C.getResponseHeader("etag")) && (k.etag[o] = w)), 204 === t || "HEAD" === f.type ? S = "nocontent" : 304 === t ? S = "notmodified" : (S = x.state, p = x.data, d = !(y = x.error))) : (y = S, !t && S || (S = "error", t < 0 && (t = 0))), C.status = t, C.statusText = (n || S) + "", d ? g.resolveWith(m, [p, S, C]) : g.rejectWith(m, [C, S, y]), C.statusCode(b), b = void 0, u && h.trigger(d ? "ajaxSuccess" : "ajaxError", [C, f, d ? p : y]), v.fireWith(m, [C, S]), u && (h.trigger("ajaxComplete", [C, f]), --k.active || k.event.trigger("ajaxStop")))
            }
            return C
        },
        getJSON: function(e, t, n) {
            return k.get(e, t, n, "json")
        },
        getScript: function(e, t) {
            return k.get(e, void 0, t, "script")
        }
    }), k.each(["get", "post"], (function(e, t) {
        k[t] = function(e, n, r, o) {
            return m(n) && (o = o || r, r = n, n = void 0), k.ajax(k.extend({
                url: e,
                type: t,
                dataType: o,
                data: n,
                success: r
            }, k.isPlainObject(e) && e))
        }
    })), k.ajaxPrefilter((function(e) {
        var t;
        for (t in e.headers) "content-type" === t.toLowerCase() && (e.contentType = e.headers[t] || "")
    })), k._evalUrl = function(e, t, n) {
        return k.ajax({
            url: e,
            type: "GET",
            dataType: "script",
            cache: !0,
            async: !1,
            global: !1,
            converters: {
                "text script": function() {}
            },
            dataFilter: function(e) {
                k.globalEval(e, t, n)
            }
        })
    }, k.fn.extend({
        wrapAll: function(e) {
            var t;
            return this[0] && (m(e) && (e = e.call(this[0])), t = k(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && t.insertBefore(this[0]), t.map((function() {
                for (var e = this; e.firstElementChild;) e = e.firstElementChild;
                return e
            })).append(this)), this
        },
        wrapInner: function(e) {
            return m(e) ? this.each((function(t) {
                k(this).wrapInner(e.call(this, t))
            })) : this.each((function() {
                var t = k(this),
                    n = t.contents();
                n.length ? n.wrapAll(e) : t.append(e)
            }))
        },
        wrap: function(e) {
            var t = m(e);
            return this.each((function(n) {
                k(this).wrapAll(t ? e.call(this, n) : e)
            }))
        },
        unwrap: function(e) {
            return this.parent(e).not("body").each((function() {
                k(this).replaceWith(this.childNodes)
            })), this
        }
    }), k.expr.pseudos.hidden = function(e) {
        return !k.expr.pseudos.visible(e)
    }, k.expr.pseudos.visible = function(e) {
        return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
    }, k.ajaxSettings.xhr = function() {
        try {
            return new e.XMLHttpRequest
        } catch (Fy) {}
    };
    var Gt = {
            0: 200,
            1223: 204
        },
        Yt = k.ajaxSettings.xhr();
    f.cors = !!Yt && "withCredentials" in Yt, f.ajax = Yt = !!Yt, k.ajaxTransport((function(t) {
        var n, r;
        if (f.cors || Yt && !t.crossDomain) return {
            send: function(o, i) {
                var a, s = t.xhr();
                if (s.open(t.type, t.url, t.async, t.username, t.password), t.xhrFields)
                    for (a in t.xhrFields) s[a] = t.xhrFields[a];
                for (a in t.mimeType && s.overrideMimeType && s.overrideMimeType(t.mimeType), t.crossDomain || o["X-Requested-With"] || (o["X-Requested-With"] = "XMLHttpRequest"), o) s.setRequestHeader(a, o[a]);
                n = function(e) {
                    return function() {
                        n && (n = r = s.onload = s.onerror = s.onabort = s.ontimeout = s.onreadystatechange = null, "abort" === e ? s.abort() : "error" === e ? "number" != typeof s.status ? i(0, "error") : i(s.status, s.statusText) : i(Gt[s.status] || s.status, s.statusText, "text" !== (s.responseType || "text") || "string" != typeof s.responseText ? {
                            binary: s.response
                        } : {
                            text: s.responseText
                        }, s.getAllResponseHeaders()))
                    }
                }, s.onload = n(), r = s.onerror = s.ontimeout = n("error"), void 0 !== s.onabort ? s.onabort = r : s.onreadystatechange = function() {
                    4 === s.readyState && e.setTimeout((function() {
                        n && r()
                    }))
                }, n = n("abort");
                try {
                    s.send(t.hasContent && t.data || null)
                } catch (Fy) {
                    if (n) throw Fy
                }
            },
            abort: function() {
                n && n()
            }
        }
    })), k.ajaxPrefilter((function(e) {
        e.crossDomain && (e.contents.script = !1)
    })), k.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /\b(?:java|ecma)script\b/
        },
        converters: {
            "text script": function(e) {
                return k.globalEval(e), e
            }
        }
    }), k.ajaxPrefilter("script", (function(e) {
        void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET")
    })), k.ajaxTransport("script", (function(e) {
        var t, n;
        if (e.crossDomain || e.scriptAttrs) return {
            send: function(r, o) {
                t = k("<script>").attr(e.scriptAttrs || {}).prop({
                    charset: e.scriptCharset,
                    src: e.url
                }).on("load error", n = function(e) {
                    t.remove(), n = null, e && o("error" === e.type ? 404 : 200, e.type)
                }), y.head.appendChild(t[0])
            },
            abort: function() {
                n && n()
            }
        }
    }));
    var Jt, Kt = [],
        Xt = /(=)\?(?=&|$)|\?\?/;
    k.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var e = Kt.pop() || k.expando + "_" + Tt.guid++;
            return this[e] = !0, e
        }
    }), k.ajaxPrefilter("json jsonp", (function(t, n, r) {
        var o, i, a, s = !1 !== t.jsonp && (Xt.test(t.url) ? "url" : "string" == typeof t.data && 0 === (t.contentType || "").indexOf("application/x-www-form-urlencoded") && Xt.test(t.data) && "data");
        if (s || "jsonp" === t.dataTypes[0]) return o = t.jsonpCallback = m(t.jsonpCallback) ? t.jsonpCallback() : t.jsonpCallback, s ? t[s] = t[s].replace(Xt, "$1" + o) : !1 !== t.jsonp && (t.url += (At.test(t.url) ? "&" : "?") + t.jsonp + "=" + o), t.converters["script json"] = function() {
            return a || k.error(o + " was not called"), a[0]
        }, t.dataTypes[0] = "json", i = e[o], e[o] = function() {
            a = arguments
        }, r.always((function() {
            void 0 === i ? k(e).removeProp(o) : e[o] = i, t[o] && (t.jsonpCallback = n.jsonpCallback, Kt.push(o)), a && m(i) && i(a[0]), a = i = void 0
        })), "script"
    })), f.createHTMLDocument = ((Jt = y.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>", 2 === Jt.childNodes.length), k.parseHTML = function(e, t, n) {
        return "string" != typeof e ? [] : ("boolean" == typeof t && (n = t, t = !1), t || (f.createHTMLDocument ? ((r = (t = y.implementation.createHTMLDocument("")).createElement("base")).href = y.location.href, t.head.appendChild(r)) : t = y), i = !n && [], (o = F.exec(e)) ? [t.createElement(o[1])] : (o = Oe([e], t, i), i && i.length && k(i).remove(), k.merge([], o.childNodes)));
        var r, o, i
    }, k.fn.load = function(e, t, n) {
        var r, o, i, a = this,
            s = e.indexOf(" ");
        return s > -1 && (r = wt(e.slice(s)), e = e.slice(0, s)), m(t) ? (n = t, t = void 0) : t && "object" == typeof t && (o = "POST"), a.length > 0 && k.ajax({
            url: e,
            type: o || "GET",
            dataType: "html",
            data: t
        }).done((function(e) {
            i = arguments, a.html(r ? k("<div>").append(k.parseHTML(e)).find(r) : e)
        })).always(n && function(e, t) {
            a.each((function() {
                n.apply(this, i || [e.responseText, t, e])
            }))
        }), this
    }, k.expr.pseudos.animated = function(e) {
        return k.grep(k.timers, (function(t) {
            return e === t.elem
        })).length
    }, k.offset = {
        setOffset: function(e, t, n) {
            var r, o, i, a, s, l, c = k.css(e, "position"),
                u = k(e),
                d = {};
            "static" === c && (e.style.position = "relative"), s = u.offset(), i = k.css(e, "top"), l = k.css(e, "left"), ("absolute" === c || "fixed" === c) && (i + l).indexOf("auto") > -1 ? (a = (r = u.position()).top, o = r.left) : (a = parseFloat(i) || 0, o = parseFloat(l) || 0), m(t) && (t = t.call(e, n, k.extend({}, s))), null != t.top && (d.top = t.top - s.top + a), null != t.left && (d.left = t.left - s.left + o), "using" in t ? t.using.call(e, d) : u.css(d)
        }
    }, k.fn.extend({
        offset: function(e) {
            if (arguments.length) return void 0 === e ? this : this.each((function(t) {
                k.offset.setOffset(this, e, t)
            }));
            var t, n, r = this[0];
            return r ? r.getClientRects().length ? (t = r.getBoundingClientRect(), n = r.ownerDocument.defaultView, {
                top: t.top + n.pageYOffset,
                left: t.left + n.pageXOffset
            }) : {
                top: 0,
                left: 0
            } : void 0
        },
        position: function() {
            if (this[0]) {
                var e, t, n, r = this[0],
                    o = {
                        top: 0,
                        left: 0
                    };
                if ("fixed" === k.css(r, "position")) t = r.getBoundingClientRect();
                else {
                    for (t = this.offset(), n = r.ownerDocument, e = r.offsetParent || n.documentElement; e && (e === n.body || e === n.documentElement) && "static" === k.css(e, "position");) e = e.parentNode;
                    e && e !== r && 1 === e.nodeType && ((o = k(e).offset()).top += k.css(e, "borderTopWidth", !0), o.left += k.css(e, "borderLeftWidth", !0))
                }
                return {
                    top: t.top - o.top - k.css(r, "marginTop", !0),
                    left: t.left - o.left - k.css(r, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map((function() {
                for (var e = this.offsetParent; e && "static" === k.css(e, "position");) e = e.offsetParent;
                return e || pe
            }))
        }
    }), k.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, (function(e, t) {
        var n = "pageYOffset" === t;
        k.fn[e] = function(r) {
            return K(this, (function(e, r, o) {
                var i;
                if (h(e) ? i = e : 9 === e.nodeType && (i = e.defaultView), void 0 === o) return i ? i[t] : e[r];
                i ? i.scrollTo(n ? i.pageXOffset : o, n ? o : i.pageYOffset) : e[r] = o
            }), e, r, arguments.length)
        }
    })), k.each(["top", "left"], (function(e, t) {
        k.cssHooks[t] = Je(f.pixelPosition, (function(e, n) {
            if (n) return n = Ye(e, t), Ue.test(n) ? k(e).position()[t] + "px" : n
        }))
    })), k.each({
        Height: "height",
        Width: "width"
    }, (function(e, t) {
        k.each({
            padding: "inner" + e,
            content: t,
            "": "outer" + e
        }, (function(n, r) {
            k.fn[r] = function(o, i) {
                var a = arguments.length && (n || "boolean" != typeof o),
                    s = n || (!0 === o || !0 === i ? "margin" : "border");
                return K(this, (function(t, n, o) {
                    var i;
                    return h(t) ? 0 === r.indexOf("outer") ? t["inner" + e] : t.document.documentElement["client" + e] : 9 === t.nodeType ? (i = t.documentElement, Math.max(t.body["scroll" + e], i["scroll" + e], t.body["offset" + e], i["offset" + e], i["client" + e])) : void 0 === o ? k.css(t, n, s) : k.style(t, n, o, s)
                }), t, a ? o : void 0, a)
            }
        }))
    })), k.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], (function(e, t) {
        k.fn[t] = function(e) {
            return this.on(t, e)
        }
    })), k.fn.extend({
        bind: function(e, t, n) {
            return this.on(e, null, t, n)
        },
        unbind: function(e, t) {
            return this.off(e, null, t)
        },
        delegate: function(e, t, n, r) {
            return this.on(t, e, n, r)
        },
        undelegate: function(e, t, n) {
            return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
        },
        hover: function(e, t) {
            return this.on("mouseenter", e).on("mouseleave", t || e)
        }
    }), k.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), (function(e, t) {
        k.fn[t] = function(e, n) {
            return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
        }
    }));
    var Qt = /^[\s\uFEFF\xA0]+|([^\s\uFEFF\xA0])[\s\uFEFF\xA0]+$/g;
    k.proxy = function(e, t) {
        var n, r, i;
        if ("string" == typeof t && (n = e[t], t = e, e = n), m(e)) return r = o.call(arguments, 2), i = function() {
            return e.apply(t || this, r.concat(o.call(arguments)))
        }, i.guid = e.guid = e.guid || k.guid++, i
    }, k.holdReady = function(e) {
        e ? k.readyWait++ : k.ready(!0)
    }, k.isArray = Array.isArray, k.parseJSON = JSON.parse, k.nodeName = C, k.isFunction = m, k.isWindow = h, k.camelCase = te, k.type = b, k.now = Date.now, k.isNumeric = function(e) {
        var t = k.type(e);
        return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e))
    }, k.trim = function(e) {
        return null == e ? "" : (e + "").replace(Qt, "$1")
    };
    var en = e.jQuery,
        tn = e.$;
    return k.noConflict = function(t) {
        return e.$ === k && (e.$ = tn), t && e.jQuery === k && (e.jQuery = en), k
    }, void 0 === t && (e.jQuery = e.$ = k), k
};
const Pp = v(Lp.exports = Ip.document ? jp(Ip, !0) : function(e) {
    if (!e.document) throw new Error("jQuery requires a window with a document");
    return jp(e)
});
var Mp = function(e, t, n, r) {
    this._datafeedURL = e, this.coin = t, this.stompClient = n, this.lastBar = null, this.currentBar = null, this.subscribe = !0, this.scale = r
};
Mp.prototype.onReady = function(e) {
    var t = {
        exchanges: [],
        supported_resolutions: ["1", "5", "15", "30", "60", "240", "1D", "1W", "1M"],
        supports_group_request: !1,
        supports_marks: !1,
        supports_search: !1,
        supports_time: !0,
        supports_timescale_marks: !1
    };
    Pp("#" + window.tvWidget.id).contents().on("click", ".date-range-list>a", (function() {
        window.tvWidget && ("分时" == Pp(this).html() ? (Pp(this).parent().addClass("real-op").removeClass("common-op"), window.tvWidget.chart().setChartType(3)) : (Pp(this).parent().addClass("common-op").removeClass("real-op"), window.tvWidget.chart().setChartType(1)))
    })), setTimeout((function() {
        e(t)
    }), 0)
}, Mp.prototype.subscribeBars = function(e, t, n, r, o) {
    var i = this;
    this.stompClient.subscribe("/topic/market/trade/" + e.name, (function(e) {
        var t = JSON.parse(e.body);
        if (null != i.lastBar && t.length > 0) {
            var r = t[t.length - 1].price;
            i.lastBar.close = r, r > i.lastBar.high && (i.lastBar.high = r), r < i.lastBar.low && (i.lastBar.low = r), n(i.lastBar)
        }
    })), this.stompClient.subscribe("/topic/market/kline/" + e.name, (function(e) {
        if ("1" == t) {
            null != i.currentBar && n(i.currentBar);
            var r = JSON.parse(e.body);
            i.lastBar = {
                time: r.time,
                open: r.openPrice,
                high: r.highestPrice,
                low: r.lowestPrice,
                close: r.closePrice,
                volume: r.volume
            }, i.currentBar = i.lastBar, n(i.lastBar)
        }
    }))
}, Mp.prototype.unsubscribeBars = function(e) {
    this.subscribe = !1
}, Mp.prototype.resolveSymbol = function(e, t, n) {
    var r = {
        name: this.coin.symbol,
        "exchange-traded": "",
        "exchange-listed": "",
        minmov: 1,
        volumescale: 1e4,
        has_daily: !0,
        has_weekly_and_monthly: !0,
        has_intraday: !0,
        description: this.coin.symbol,
        type: "bitcoin",
        session: "24x7",
        supported_resolutions: ["1", "5", "15", "30", "60", "1D", "1W", "1M"],
        pricescale: Math.pow(10, this.scale || 2),
        ticker: "",
        timezone: "Asia/Shanghai"
    };
    setTimeout((function() {
        t(r)
    }), 0)
}, Mp.prototype._send = function(e, t) {
    var n = e;
    if (t)
        for (var r = 0; r < Object.keys(t).length; ++r) {
            var o = Object.keys(t)[r];
            n += (0 === r ? "?" : "&") + o + "=" + encodeURIComponent(t[o])
        }
    return Pp.ajax({
        type: "GET",
        url: n,
        dataType: "json"
    })
}, Mp.prototype.getBars = function(e, t, n, r, o, i, a) {
    var s = [],
        l = this;
    this._send(this._datafeedURL + "/history", {
        symbol: e.name,
        from: 1e3 * n,
        to: a ? (new Date).getTime() : 1e3 * r,
        resolution: t
    }).done((function(e) {
        for (var t = e, n = 0; n < t.length; n++) {
            var r = t[n];
            s.push({
                time: r[0],
                open: r[1],
                high: r[2],
                low: r[3],
                close: r[4],
                volume: r[5]
            })
        }
        l.lastBar = s.length > 0 ? s[s.length - 1] : null, l.currentBar = l.lastBar;
        var i = 0 == s.length;
        o(s, {
            noData: i
        })
    })).fail((function(e) {
        i(e)
    }))
}, Mp.prototype.periodLengthSeconds = function(e, t) {
    return 24 * ("D" === e ? t : "M" === e ? 31 * t : "W" === e ? 7 * t : "H" === e ? t * e / 24 : t * e / 1440) * 60 * 60
};
const Np = Mp,
    Fp = {
        class: "drawerSettings"
    },
    Rp = ["alt"],
    Wp = {
        class: "flex flex-row justify-between align-center"
    },
    Vp = {
        class: "flex flex-row justify-between align-center"
    },
    Bp = {
        class: "flex flex-row justify-between align-center"
    },
    Hp = {
        class: "flex flex-row justify-between align-center"
    },
    qp = {
        class: "flex flex-row justify-between align-center"
    },
    Up = {
        class: "mt-2 align-center"
    },
    zp = e({
        __name: "ExchangeSettings",
        props: {
            isMobileWidth: {
                type: Boolean
            }
        },
        emits: ["settingsChange"],
        setup(e, {
            emit: n
        }) {
            const r = l(!1);
            l("Option 1"), l(!0), l(!0), l(!0), l(!0);
            const {
                t: s
            } = w(), c = async () => await Ie.confirm("Changing this setting requires a page refresh to take effect.", "Confirm Setting Changes", {
                confirmButtonText: "Refresh Page",
                cancelButtonText: "Cancel",
                type: "warning",
                customClass: "msg-dark sasfw",
                confirmButtonClass: "btn-prime-box",
                customStyle: {
                    "background-color": "black",
                    "border-color": "#1b1b1b",
                    "--el-button-bg-color": "#fff"
                }
            }).then((() => !0)).catch((() => !1)), p = x(), h = l(!1), y = l(p.isTradeAiMode ? "AI" : "Manual");
            k((() => p.isTradeAiMode), (e => {
                y.value = e ? "AI" : "Manual"
            }));
            const g = ["AI", "Manual"],
                v = l(),
                b = l(p.isShowTradeTour),
                S = e => {
                    "AI" === e ? p.onChange(!0, 7) : p.onChange(!1, 7)
                };
            return (e, n) => (o(), t(_, null, [i("div", Fp, [i("div", {
                onClick: n[1] || (n[1] = e => h.value = !0),
                class: "btn-ai-body"
            }, [u(m(J), {
                ref_key: "ref1",
                ref: v,
                onChange: S,
                modelValue: y.value,
                "onUpdate:modelValue": n[0] || (n[0] = e => y.value = e),
                options: g,
                size: e.isMobileWidth ? "small" : "default"
            }, null, 8, ["modelValue", "size"])]), u(m(Ae), {
                effect: "customized",
                placement: "top",
                "show-after": 369,
                trigger: "hover"
            }, {
                content: d((() => [a(f(m(s)("sett.settings")), 1)])),
                default: d((() => [i("img", {
                    class: "cursor-pointer",
                    src: "/images/svg/setting2.svg",
                    width: "18",
                    height: "18",
                    alt: m(s)("sett.settings"),
                    onClick: n[2] || (n[2] = e => r.value = !0)
                }, null, 8, Rp)])),
                _: 1
            }), u(m(we), {
                modelValue: r.value,
                "onUpdate:modelValue": n[13] || (n[13] = e => r.value = e),
                direction: "rtl",
                "destroy-on-close": !0,
                size: 400,
                "show-close": !0
            }, {
                header: d((() => n[17] || (n[17] = []))),
                default: d((() => [u(m(ce), {
                    "tab-position": "top",
                    style: {
                        height: "auto"
                    },
                    class: "demo-tabs"
                }, {
                    default: d((() => [u(m(le), {
                        label: m(s)("exh.preferences")
                    }, {
                        default: d((() => {
                            return [i("div", Wp, [n[18] || (n[18] = i("span", {
                                class: "mt-2 align-center"
                            }, "Show cancel all orders button", -1)), u(m(Ee), {
                                modelValue: m(p).isCancelAll,
                                "onUpdate:modelValue": n[3] || (n[3] = e => m(p).isCancelAll = e),
                                class: "mt-2",
                                style: {
                                    "margin-left": "24px"
                                },
                                "inline-prompt": "",
                                "active-icon": m(U),
                                "inactive-icon": m(z),
                                onChange: n[4] || (n[4] = e => m(p).onChange(e, 1))
                            }, null, 8, ["modelValue", "active-icon", "inactive-icon"])]), u(m(xe)), i("div", Vp, [n[19] || (n[19] = i("span", {
                                class: "mt-2 align-center"
                            }, "Require confirmation before placing order", -1)), u(m(Ee), {
                                modelValue: m(p).isConfirmOrder,
                                "onUpdate:modelValue": n[5] || (n[5] = e => m(p).isConfirmOrder = e),
                                class: "mt-2",
                                style: {
                                    "margin-left": "24px"
                                },
                                "inline-prompt": "",
                                "active-icon": m(U),
                                "inactive-icon": m(z),
                                onChange: n[6] || (n[6] = e => m(p).onChange(e, 2))
                            }, null, 8, ["modelValue", "active-icon", "inactive-icon"])]), u(m(xe)), i("div", Bp, [n[20] || (n[20] = i("span", {
                                class: "mt-2 align-center"
                            }, "Show relative price comparison indicator", -1)), u(m(Ee), {
                                modelValue: m(p).isPriceIndicator,
                                "onUpdate:modelValue": n[7] || (n[7] = e => m(p).isPriceIndicator = e),
                                class: "mt-2",
                                style: {
                                    "margin-left": "24px"
                                },
                                "inline-prompt": "",
                                "active-icon": m(U),
                                "inactive-icon": m(z),
                                onChange: n[8] || (n[8] = e => m(p).onChange(e, 4))
                            }, null, 8, ["modelValue", "active-icon", "inactive-icon"])]), u(m(xe)), i("div", Hp, [n[21] || (n[21] = i("span", {
                                class: "mt-2 align-center"
                            }, "Enable advanced trading chart", -1)), u(m(Ee), {
                                modelValue: m(p).isAdvancedChart,
                                "onUpdate:modelValue": n[9] || (n[9] = e => m(p).isAdvancedChart = e),
                                class: "mt-2",
                                style: {
                                    "margin-left": "24px"
                                },
                                "inline-prompt": "",
                                "active-icon": m(U),
                                "inactive-icon": m(z),
                                "before-change": c,
                                onChange: n[10] || (n[10] = e => m(p).onChange(e, 3))
                            }, null, 8, ["modelValue", "active-icon", "inactive-icon"])]), u(m(xe)), i("div", qp, [i("span", Up, f((e = m(s)("pga.show-balance"), e ? e.charAt(0).toUpperCase() + e.slice(1).toLowerCase() : "")), 1), u(m(Ee), {
                                modelValue: m(p).isShowWallet,
                                "onUpdate:modelValue": n[11] || (n[11] = e => m(p).isShowWallet = e),
                                class: "mt-2",
                                style: {
                                    "margin-left": "24px"
                                },
                                "inline-prompt": "",
                                "active-icon": m(U),
                                "inactive-icon": m(z),
                                onChange: n[12] || (n[12] = e => m(p).onChange(e, 0))
                            }, null, 8, ["modelValue", "active-icon", "inactive-icon"])])];
                            var e
                        })),
                        _: 1
                    }, 8, ["label"])])),
                    _: 1
                })])),
                footer: d((() => n[22] || (n[22] = []))),
                _: 1
            }, 8, ["modelValue"])]), u(m(De), {
                modelValue: b.value,
                "onUpdate:modelValue": n[14] || (n[14] = e => b.value = e),
                class: "tourTrade",
                onClose: n[15] || (n[15] = e => m(p).onChange(!1, 6)),
                onFinish: n[16] || (n[16] = e => m(p).onChange(!1, 6))
            }, {
                default: d((() => {
                    var e;
                    return [u(m(Oe), {
                        target: null == (e = v.value) ? void 0 : e.$el,
                        title: "AI/Manual Trade Mode",
                        class: "tourTradeStep"
                    }, {
                        default: d((() => n[23] || (n[23] = [i("div", null, " On the OPZ platform, you can choose between AI-powered trading with advanced analysis tools or manual trading to take full control of your strategies. ", -1)]))),
                        _: 1
                    }, 8, ["target"])]
                })),
                _: 1
            }, 8, ["modelValue"])], 64))
        }
    }),
    $p = q(zp, [
        ["__scopeId", "data-v-54a4c160"]
    ]),
    Zp = {
        class: "mb-0 text-fee text-bold text-10"
    },
    Gp = {
        class: "feeBox"
    },
    Yp = {
        class: "popBody"
    },
    Jp = {
        class: "feeTitleBody"
    },
    Kp = {
        class: "feeLvl"
    },
    Xp = {
        class: "feeBody"
    },
    Qp = {
        class: "feeText mb-2"
    },
    ef = {
        key: 0
    },
    tf = {
        class: "feeAmount"
    },
    nf = {
        class: "feeBlock"
    },
    rf = {
        class: "feeLeft"
    },
    of = {
        class: "feeRight"
    },
    af = {
        key: 0,
        class: "feeDiscount"
    },
    sf = {
        class: "feeBlock"
    },
    lf = {
        class: "feeLeft"
    },
    cf = {
        class: "feeRight"
    },
    uf = {
        key: 0,
        class: "feeDiscount"
    },
    df = {
        class: "feeBlock mt-4"
    },
    pf = {
        class: "feeLeft"
    },
    ff = {
        class: "feeRight"
    },
    mf = {
        key: 0,
        class: "feeDiscount"
    },
    hf = {
        class: "feeBlock"
    },
    yf = {
        class: "feeLeft"
    },
    gf = {
        class: "feeRight"
    },
    vf = {
        key: 0,
        class: "feeDiscount"
    },
    bf = q(e({
        __name: "Feelvl",
        setup(e) {
            const {
                t: n
            } = w(), r = T({
                feeGrade: {}
            }), u = E(), {
                Api: p
            } = s();
            u.isLoggedIn && p.getUserFeeLvl().then((e => {
                const t = e.data;
                0 == t.code && (r.feeGrade = t.data)
            }));
            const g = I(),
                v = x(),
                b = l(v.isAppOn);
            c((() => {}));
            return (e, s) => m(u).isLoggedIn ? (o(), h(m(Te), {
                key: 0,
                placement: "left",
                width: 320,
                trigger: "hover",
                "popper-class": "pop-symbols",
                persistent: !1
            }, {
                reference: d((() => [i("p", Zp, f(r.feeGrade.name), 1)])),
                default: d((() => [i("div", Gp, [i("div", Yp, [i("div", Jp, [s[2] || (s[2] = i("i", {
                    "aria-hidden": "true",
                    class: "first-icon fas fa-gem text-2xl w-8 text-center"
                }, null, -1)), i("a", {
                    class: "feeTitle",
                    target: "__blank",
                    onClick: s[0] || (s[0] = e => {
                        b.value ? window.ReactNativeWebView.postMessage(JSON.stringify({
                            opzkey: "fees"
                        })) : g.push({
                            name: "fees"
                        })
                    })
                }, [i("span", Kp, f(m(n)("dash.my-fee-level") + ":"), 1), a(" " + f(r.feeGrade.name) + " ", 1), s[1] || (s[1] = i("i", {
                    "aria-hidden": "true",
                    class: "last-icon fas fa-angle-double-right"
                }, null, -1))])]), i("div", Xp, [i("div", Qp, [r.feeGrade.extra > 0 ? (o(), t("span", ef, [a(f(m(n)("dash.lowest-fees-for-you")) + " (", 1), i("span", tf, f(r.feeGrade.extra + "% " + m(n)("ctm2.fee-discount")), 1), s[3] || (s[3] = a(")"))])) : y("", !0)]), i("div", nf, [i("span", rf, f(m(n)("dash.spot") + " " + m(n)("dash.taker")) + ":", 1), i("span", of , [r.feeGrade.extra > 0 ? (o(), t("span", af, f((100 * r.feeGrade.spotfr).toFixed(4)) + "%", 1)) : y("", !0), a(f((r.feeGrade.spotfr * (100 - r.feeGrade.extra)).toFixed(4)) + "%", 1)])]), i("div", sf, [i("span", lf, f(m(n)("dash.spot") + " " + m(n)("dash.maker")) + ":", 1), i("span", cf, [r.feeGrade.extra > 0 ? (o(), t("span", uf, f((100 * r.feeGrade.spotmfr).toFixed(4)) + "%", 1)) : y("", !0), a(f((r.feeGrade.spotmfr * (100 - r.feeGrade.extra)).toFixed(4)) + "%", 1)])]), i("div", df, [i("span", pf, f(m(n)("dash.derivates") + " " + m(n)("dash.taker")) + ":", 1), i("span", ff, [r.feeGrade.extra > 0 ? (o(), t("span", mf, f((100 * r.feeGrade.marginfr).toFixed(4)) + "%", 1)) : y("", !0), a(f((r.feeGrade.marginfr * (100 - r.feeGrade.extra)).toFixed(4)) + "%", 1)])]), i("div", hf, [i("span", yf, f(m(n)("dash.derivates") + " " + m(n)("dash.maker")) + ":", 1), i("span", gf, [r.feeGrade.extra > 0 ? (o(), t("span", vf, f((100 * r.feeGrade.marginmfr).toFixed(4)) + "%", 1)) : y("", !0), a(f((r.feeGrade.marginmfr * (100 - r.feeGrade.extra)).toFixed(4)) + "%", 1)])])])])])])),
                _: 1
            })) : y("", !0)
        }
    }), [
        ["__scopeId", "data-v-27cc8fe1"]
    ]),
    xf = {
        class: "area-height p-4 pr-7"
    },
    wf = {
        class: "flex items-center justify-between mb-4"
    },
    kf = {
        class: "flex items-center"
    },
    Sf = {
        class: "pb-4 bg-trade-border border-b border-solid text-bold"
    },
    Cf = {
        class: "flex border border-solid border-green-light rounded"
    },
    _f = {
        class: "flex justify-between items-center mb-3 -mt-px"
    },
    Tf = {
        class: "flex market-limit-tabs"
    },
    Af = {
        class: "flex mb-4 items-center flex"
    },
    Df = {
        class: "pr-1 text-gray-darken text-12 text-right w-full"
    },
    Of = {
        key: 0,
        class: "flex mb-4"
    },
    Ef = {
        class: "text-gray-darken text-12 text-left w-2/4"
    },
    If = {
        key: 0,
        class: "pr-2 text-gray-darken text-12 text-right ml-2 w-full"
    },
    jf = {
        class: "text-gray-darken text-12 text-right ml-2 text-ri-order ln-tx-pl"
    },
    Lf = {
        class: "ant-slider-mark"
    },
    Pf = {
        class: "pr-2 flex mb-2 flex-row justify-end"
    },
    Mf = {
        class: "text-gray-darken text-10 text-right"
    },
    Nf = {
        class: "text-gray-darken text-10 text-right curr-sym-ts"
    },
    Ff = {
        key: 0,
        "data-v-ea142894": "",
        class: "w-full py-2 rounded border-purple-darken text-10 block text-center text-bold mb-3 mt-5 btn-connect-wal",
        style: {
            opacity: "0.6",
            cursor: "default",
            border: "1px solid rgb(115, 3, 252)",
            color: "white"
        },
        disabled: ""
    },
    Rf = q(e({
        __name: "AiTradeMode",
        props: {
            currentCoin: Object,
            coin: Object,
            base: Object,
            isMobileWidth: Boolean,
            baseScale: Number,
            quoteScale: Number,
            balanceFirst: Boolean,
            price: Number
        },
        emits: ["refreshAccount", "closeDrawer"],
        setup(e, {
            emit: n
        }) {
            const s = e,
                p = n,
                {
                    t: g
                } = w(),
                v = E(),
                b = x();
            l(!1);
            const C = T({
                    purchaseBuy: !1,
                    selectedMarketTab: 0,
                    form: {
                        price: s.price,
                        amount: "",
                        amountRev: "",
                        triggerPrice: 0
                    },
                    wallet: {
                        base: 0,
                        coin: 0
                    },
                    sliderAmountPercent: 0
                }),
                A = I();
            k((() => s.price), (e => {
                0 != e && 0 != C.selectedMarketTab && (C.form.price = e, (() => {
                    const e = C.form.price;
                    C.form.amount && (C.sliderAmountPercent = Number(C.form.amount) * e / C.wallet.base * 100)
                })())
            }));
            const D = l(""),
                O = () => {
                    D.value = ""
                },
                P = l(s.base);
            c((() => {
                C.form.price = s.price, P.value = s.base
            }));
            const M = l(null);
            l(null);
            const N = l(!1),
                F = () => {
                    M.value && M.value.focus(), D.value = "amount", 0 == C.selectedMarketTab && C.purchaseBuy ? N.value = !1 : N.value = !0
                },
                R = (e, t) => {
                    const n = Number(C.form.amount);
                    isNaN(n) ? (C.form.amount = "", C.sliderAmountPercent = 0) : C.sliderAmountPercent = Number(((e, t = 8) => {
                        if (0 == new Number(e)) return 0;
                        let n = e + "";
                        if (n.indexOf("e") > -1 || n.indexOf("E") > -1) {
                            let n = new Number(e).toFixed(t + 1) + "";
                            return n.substring(0, n.length - 1)
                        }
                        return n.indexOf(".") > -1 ? 0 == t ? n.substring(0, n.indexOf(".")) : n.substring(0, n.indexOf(".") + t + 1) : n
                    })(n / C.wallet.base * 100))
                },
                W = () => {
                    const e = C.purchaseBuy ? s.quoteScale : s.baseScale,
                        t = Me((C.purchaseBuy ? s.base : s.coin) * C.sliderAmountPercent * .01, e);
                    C.form.amount = t.toString(), 0 === C.selectedMarketTab && (() => {
                        if (0 === C.selectedMarketTab) {
                            const e = C.purchaseBuy ? s.baseScale : s.quoteScale,
                                t = Me(C.purchaseBuy ? Number(C.form.amount) / s.currentCoin.price : Number(C.form.amount) * s.currentCoin.price, e);
                            C.form.amountRev = t.toString()
                        }
                    })()
                },
                V = e => e + "%",
                B = () => {
                    C.sliderAmountPercent = 0, C.purchaseBuy = !1, W()
                },
                H = () => {
                    C.sliderAmountPercent = 0, C.purchaseBuy = !0, W()
                };
            l(!1);
            const q = l(!1);
            return (e, n) => {
                const l = j("RouterLink");
                return o(), t(_, null, [i("div", xf, [i("div", wf, [n[13] || (n[13] = i("div", {
                    class: "flex align-center"
                }, [i("div", {
                    class: "block-ttl"
                }), i("p", {
                    class: "text-gray5 text-medium text-12 flex"
                }, [a(" Spot "), i("span", {
                    class: "text-gray1 help ml-1 p-0 m-0"
                }, " (DEMO TRADING) ")])], -1)), i("div", kf, [u(bf), s.isMobileWidth ? (o(), t("div", {
                    key: 0,
                    class: "ml-1 pl-2 pr-1 cursor-pointer",
                    onClick: n[0] || (n[0] = e => p("closeDrawer"))
                }, n[12] || (n[12] = [i("i", {
                    style: {
                        "font-size": "12px"
                    },
                    class: "fas fa-close text-gray-darken"
                }, null, -1)]))) : y("", !0)])]), i("div", Sf, [i("div", Cf, [i("button", {
                    class: r(["w-1/2 text-gray3 py-2 text-10 uppercase rounded-l", C.purchaseBuy ? "" : "bg-purple-lighten"]),
                    onClick: B
                }, f(s.currentCoin.coin), 3), i("button", {
                    class: r(["w-1/2 text-gray3 py-2 text-10 uppercase rounded-r sell-btn", C.purchaseBuy ? "bg-purple-lighten" : ""]),
                    onClick: H
                }, f(s.currentCoin.base), 3)])]), i("div", _f, [i("div", Tf, [i("div", {
                    class: r(["border-solid text-12 px-2 py-3 mr-4", "border-purple-darken"])
                }, " AI-Driven Adaptive Mode ")])]), i("div", null, [i("div", Af, [n[14] || (n[14] = i("p", {
                    class: "text-gray-darken text-12 text-left w-2/4"
                }, [i("i", {
                    class: "text-gray-darken fas fa-robot mr-1",
                    style: {
                        width: "15px"
                    }
                }), a(" AI ")], -1)), i("p", Df, [u(Q, {
                    ismobile: !1,
                    alwaysLarge: !0
                })])]), m(b).isShowWallet ? (o(), t("div", Of, [i("p", Ef, [n[15] || (n[15] = i("i", {
                    class: "text-gray-darken fas fa-wallet mr-1",
                    style: {
                        width: "15px",
                        "padding-left": "1px"
                    }
                }, null, -1)), a(" " + f(m(g)("exh.available")), 1)]), !m(v).isLoggedIn || s.balanceFirst ? (o(), t("p", If, f(C.purchaseBuy ? m(Me)(s.base, s.quoteScale).toLocaleString() + " " + s.currentCoin.base : m(Me)(s.coin, s.baseScale) + " " + s.currentCoin.coin), 1)) : y("", !0)])) : y("", !0), i("div", {
                    class: r(["border border-solid border-gray-lighter rounded py-2 px-4 flex mb-3 cursor-pointer", {
                        "focused-border": "amount" === D.value
                    }]),
                    onClick: F
                }, [n[16] || (n[16] = i("p", {
                    class: "text-gray-darken text-10 whitespace-nowrap ln-in-pl"
                }, f("Investment"), -1)), S(i("input", {
                    ref_key: "amountInput",
                    ref: M,
                    "onUpdate:modelValue": n[1] || (n[1] = e => C.form.amount = e),
                    pattern: "^\\d*(\\.\\d{0,2})?$",
                    type: "text",
                    onBlur: O,
                    class: "w-full text-white bg-transparent text-12 text-right outline-none",
                    onInput: R,
                    onKeydown: n[2] || (n[2] = e => (e => {
                        const t = e.keyCode;
                        t >= 48 && t <= 57 || [8, 37, 39, 46, 190, 110].includes(t) || e.preventDefault()
                    })(e))
                }, null, 544), [
                    [L, C.form.amount]
                ]), i("p", jf, f(C.purchaseBuy ? s.currentCoin.base : s.currentCoin.coin), 1)], 2), i("div", {
                    class: r(["control mt-4 mb-10 mx-1 custom-slider", "buy-slider"])
                }, [u(m(K), {
                    modelValue: C.sliderAmountPercent,
                    "onUpdate:modelValue": n[3] || (n[3] = e => C.sliderAmountPercent = e),
                    "tooltip-class": "sliderAmount",
                    size: "small",
                    "format-tooltip": V,
                    onInput: W
                }, null, 8, ["modelValue"]), i("div", Lf, [i("span", {
                    class: r(["ant-slider-mark-text ant-slider-mark-text-active", C.sliderAmountPercent >= 1 ? "text-green-darken" : ""]),
                    style: {
                        transform: "translateX(-50%)",
                        left: "0%"
                    },
                    onClick: n[4] || (n[4] = e => {
                        C.sliderAmountPercent = 0, W()
                    })
                }, "0%", 2), i("span", {
                    class: r(["ant-slider-mark-text", C.sliderAmountPercent >= 25 ? "text-green-darken" : ""]),
                    style: {
                        transform: "translateX(-50%)",
                        left: "25%"
                    },
                    onClick: n[5] || (n[5] = e => {
                        C.sliderAmountPercent = 25, W()
                    })
                }, "25%", 2), i("span", {
                    class: r(["ant-slider-mark-text", C.sliderAmountPercent >= 50 ? "text-green-darken" : ""]),
                    style: {
                        transform: "translateX(-50%)",
                        left: "50%"
                    },
                    onClick: n[6] || (n[6] = e => {
                        C.sliderAmountPercent = 50, W()
                    })
                }, "50%", 2), i("span", {
                    class: r(["ant-slider-mark-text", C.sliderAmountPercent >= 75 ? "text-green-darken" : ""]),
                    style: {
                        transform: "translateX(-50%)",
                        left: "75%"
                    },
                    onClick: n[7] || (n[7] = e => {
                        C.sliderAmountPercent = 75, W()
                    })
                }, "75%", 2), i("span", {
                    class: r(["ant-slider-mark-text pr-2", C.sliderAmountPercent >= 100 ? "text-green-darken" : ""]),
                    style: {
                        transform: "translateX(-50%)",
                        left: "100%"
                    },
                    onClick: n[8] || (n[8] = e => {
                        C.sliderAmountPercent = 100, W()
                    })
                }, "100%", 2)])])]), i("div", null, [i("div", Pf, [n[17] || (n[17] = i("p", {
                    class: "text-gray-darken text-10 whitespace-nowrap mr-auto"
                }, "Investment", -1)), i("p", Mf, f(C.purchaseBuy && 0 == C.selectedMarketTab ? (C.form.amount / s.currentCoin.price).toLocaleString(void 0, {
                    minimumFractionDigits: s.baseScale
                }) : (C.form.amount * s.currentCoin.price).toLocaleString(void 0, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })), 1), i("p", Nf, f(C.purchaseBuy && 0 == C.selectedMarketTab ? s.currentCoin.coin : s.currentCoin.base), 1)])]), i("div", null, [u(m(Ae), {
                    placement: "top",
                    effect: "customized"
                }, {
                    content: d((() => n[18] || (n[18] = [a(" Please log in with your Email/Mobile;"), i("br", null, null, -1), a("Connecting through Web3 wallets"), i("br", null, null, -1), a("is currently not available in Demo Trading. ")]))),
                    default: d((() => [m(v).isLoggedIn ? y("", !0) : (o(), t("a", Ff, f(m(g)("dash.connect-wallet")), 1))])),
                    _: 1
                }), i("div", {
                    class: r(["flex", (m(b).isAppOn, "mb-3")])
                }, [m(v).isLoggedIn ? y("", !0) : (o(), h(l, {
                    key: 0,
                    to: {
                        name: "auth",
                        query: {
                            redirect: "/trade"
                        }
                    },
                    class: r(["w-1/2 py-2 mb-0 mr-2 rounded text-10 block border text-center text-bold", "bg-green-lighten border-green-darken text-green-darken hover:bg-green-lighten"])
                }, {
                    default: d((() => [a(f(m(g)("auth.log-in")), 1)])),
                    _: 1
                })), m(v).isLoggedIn ? y("", !0) : (o(), t("button", {
                    key: 1,
                    class: r(["w-1/2 py-2 text-medium border-solid text-medium border text-10 rounded", "border-green-darken text-green-darken hover:bg-green-lighten"]),
                    onClick: n[9] || (n[9] = e => m(A).push({
                        name: "register",
                        query: {
                            redirect: "/trade"
                        }
                    }))
                }, f(m(g)("auth.register")), 1))], 2)]), m(v).isLoggedIn ? (o(), t("button", {
                    key: 0,
                    class: r(["w-full py-2 rounded text-gray3 text-10 text-bold", "bg-purple-lighten"]),
                    onClick: n[10] || (n[10] = e => q.value = !0)
                }, f(m(g)("sett.start")), 1)) : y("", !0)]), u(ee, {
                    modelValue: q.value,
                    "onUpdate:modelValue": n[11] || (n[11] = e => q.value = e),
                    btn: !1
                }, null, 8, ["modelValue"])], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-6ae2b2c9"]
    ]),
    Wf = {
        key: 0,
        class: "area-height p-4 pr-7"
    },
    Vf = {
        class: "flex items-center justify-between mb-4"
    },
    Bf = {
        class: "flex align-center"
    },
    Hf = {
        class: "text-gray5 text-medium text-12 flex"
    },
    qf = {
        class: "flex items-center"
    },
    Uf = {
        class: "pb-4 bg-trade-border border-b border-solid text-bold"
    },
    zf = {
        class: "flex border border-solid border-green-light rounded"
    },
    $f = {
        class: "flex justify-between items-center mb-3 -mt-px"
    },
    Zf = {
        class: "flex market-limit-tabs"
    },
    Gf = {
        class: "flex justify-between items-center"
    },
    Yf = {
        class: "flex items-center"
    },
    Jf = {
        class: "tif control"
    },
    Kf = {
        class: "mr-2",
        style: {
            float: "left"
        }
    },
    Xf = {
        key: 0,
        class: "flex mb-4"
    },
    Qf = {
        class: "text-gray-darken text-12 text-left w-2/4"
    },
    em = {
        key: 0,
        class: "pr-2 text-gray-darken text-12 text-right ml-2 w-full"
    },
    tm = {
        key: 1
    },
    nm = {
        class: "text-gray-darken text-10 ln-in-pl"
    },
    rm = {
        class: "text-gray-darken text-12 text-right ml-2 text-ri-order ln-tx-pl"
    },
    om = {
        key: 2
    },
    im = {
        class: "text-gray-darken text-10 ln-in-pl",
        style: {
            "min-width": "65px"
        }
    },
    am = {
        class: "text-gray-darken text-12 text-right ml-2 text-ri-order ln-tx-pl"
    },
    sm = {
        class: "text-gray-darken text-10 ln-in-pl"
    },
    lm = {
        class: "text-gray-darken text-12 text-right ln-tx-pl",
        style: {
            "min-width": "39px"
        }
    },
    cm = {
        class: "text-gray-darken text-10 whitespace-nowrap ln-in-pl"
    },
    um = {
        class: "text-gray-darken text-12 text-right ml-2 text-ri-order ln-tx-pl"
    },
    dm = {
        class: "ant-slider-mark"
    },
    pm = {
        key: 0,
        class: "pr-2 flex mb-2 flex-row justify-end"
    },
    fm = {
        class: "text-gray-darken text-10 whitespace-nowrap mr-auto"
    },
    mm = {
        class: "text-gray-darken text-10 text-right"
    },
    hm = {
        class: "text-gray-darken text-10 text-right curr-sym-ts"
    },
    ym = {
        key: 1
    },
    gm = {
        class: "text-gray-darken text-10 whitespace-nowrap ln-in-pl"
    },
    vm = {
        class: "text-gray-darken text-12 text-right ml-2 text-ri-order ln-tx-pl"
    },
    bm = {
        key: 2,
        class: "pr-2 flex mb-2 flex-row justify-end"
    },
    xm = {
        class: "text-gray-darken text-10 text-right"
    },
    wm = {
        class: "text-gray-darken text-10 text-right curr-sym-ts"
    },
    km = {
        key: 0,
        "data-v-ea142894": "",
        class: "w-full py-2 rounded border-purple-darken text-10 block text-center text-bold mb-3 mt-5 btn-connect-wal",
        style: {
            opacity: "0.6",
            cursor: "default",
            border: "1px solid rgb(115, 3, 252)",
            color: "white"
        },
        disabled: ""
    },
    Sm = {
        key: 1
    },
    Cm = {
        class: "p-4 pr-7 border-t border-solid bg-trade-border"
    },
    _m = {
        class: "flex justify-between"
    },
    Tm = {
        class: "text-white text-medium text-14 mb-4 pt-1"
    },
    Am = {
        class: "flex wallet-select control"
    },
    Dm = {
        class: "mr-2",
        style: {
            float: "left"
        }
    },
    Om = {
        key: 0
    },
    Em = {
        class: "flex justify-between mb-3"
    },
    Im = {
        class: "text-10 text-gray5 mb-0"
    },
    jm = {
        key: 0,
        class: "text-10 text-gray5 mb-0"
    },
    Lm = {
        class: "flex justify-between mb-3"
    },
    Pm = {
        class: "text-10 text-gray5 mb-0"
    },
    Mm = {
        key: 0,
        class: "text-10 text-gray5 mb-0"
    },
    Nm = q(e({
        __name: "BuySellTab",
        props: {
            currentCoin: {
                default: {}
            },
            addOrder: {
                type: Boolean
            },
            baseScale: {
                default: 6
            },
            quoteScale: {
                default: 6
            },
            buyBtn: {
                type: Boolean,
                default: !0
            },
            enableMarketSell: {
                type: Boolean,
                default: !0
            },
            enableMarketBuy: {
                type: Boolean,
                default: !0
            },
            enableTrading: {
                type: Boolean,
                default: !0
            },
            price: {
                default: 0
            }
        },
        emits: ["refreshAccount", "closeDrawer"],
        setup(e, {
            emit: n
        }) {
            const {
                Api: p
            } = s(), g = l(!1), v = I(), b = P(), A = E(), {
                t: D
            } = w(), O = e, R = l(window.innerWidth <= 767);
            k((() => O.price), ((e, t) => {
                0 != e && 0 != ie.selectedMarketTab && (ie.form.price = O.price, W())
            }));
            const W = e => {
                    const t = e ? e.target.value : O.price;
                    if (ce(ie.form.amount) && ie.purchaseBuy) {
                        Number(V(Number(ie.form.amount) * t / ie.wallet.base * 100)) > 100 ? (ie.sliderAmountPercent = 100, ie.form.amount = Me(ie.wallet.base / t, O.baseScale).toString()) : ie.sliderAmountPercent = Number(V(Number(ie.form.amount) * t / ie.wallet.base * 100))
                    }
                },
                V = (e, t = 8) => {
                    if (0 == new Number(e)) return 0;
                    let n = e + "";
                    if (n.indexOf("e") > -1 || n.indexOf("E") > -1) {
                        let n = new Number(e).toFixed(t + 1) + "";
                        return n.substring(0, n.length - 1)
                    }
                    return n.indexOf(".") > -1 ? 0 == t ? n.substring(0, n.indexOf(".")) : n.substring(0, n.indexOf(".") + t + 1) : n
                },
                B = l(!1),
                H = l(!1),
                q = l(!1),
                U = l(!1),
                z = l(!1),
                $ = l("Limit");
            l("");
            const Z = [{
                    value: "Market",
                    label: D("exh.market")
                }, {
                    value: "Limit",
                    label: D("exh.limit")
                }],
                G = x(),
                Y = l("GTC"),
                J = e => {
                    G.tradeWalletId = Number(e), B.value = !0, !G.isAppOn && "97" == e || !G.isAppOn && "98" == e ? (g.value = !0, G.tradeWalletId = 0, ae.value = 0) : X("97" == e || "98" == e ? 0 : e)
                },
                X = e => {
                    const t = new re;
                    t.append("subid", e), p.subAccountSelect(t).then((e => {
                        const t = e.data;
                        0 == t.code ? (b.success(t.message), ee("refreshAccount", !0), pe()) : b.error(t.message)
                    }))
                },
                Q = ["GTC", "IOC", "FOK"],
                ee = n,
                te = e => e + "%",
                ne = l(!1),
                oe = l(!1),
                ie = T({
                    allSubAcc: [],
                    wallet: {
                        base: 0,
                        coin: 0
                    },
                    form: {
                        amount: "",
                        amountRev: "",
                        price: O.currentCoin.price,
                        triggerPrice: 0
                    },
                    testuser: 1,
                    sliderAmountPercent: 0,
                    selectedMarketTab: 0,
                    purchaseBuy: O.buyBtn,
                    isUseBHB: !1
                });
            ie.allSubAcc.push({
                id: 0,
                name: "Demo",
                enabled: !0
            }), A.userData.mpcWallet && ie.allSubAcc.push({
                id: 98,
                name: D("dash.wallet"),
                enabled: !1
            }), l(!1);
            const ae = l(G.tradeWalletId);
            Fe();
            const se = e => {
                    !ie.purchaseBuy || 0 != ie.selectedMarketTab && 0 != e || (ie.form.amount = "", ie.form.amountRev = "", ie.sliderAmountPercent = 0), ie.selectedMarketTab = e
                },
                le = e => !(isNaN(e) || e <= 0),
                ce = e => {
                    const t = parseFloat(e);
                    return !isNaN(t) && isFinite(t) && t > 0
                },
                ue = async () => {
                    const {
                        enableTrading: e,
                        currentCoin: t
                    } = O, {
                        purchaseBuy: n,
                        isUseBHB: r,
                        form: o
                    } = ie, {
                        amount: i,
                        price: a,
                        triggerPrice: s
                    } = o;
                    if (!e) return void b.error(D("inx.request-failed-support"));
                    if (G.isConfirmOrder && !(await (async () => await Ie.confirm("Are you sure to add this order?", "Add Order Confirmation", {
                            confirmButtonText: D("sett.yes"),
                            cancelButtonText: D("wall.cancel"),
                            type: "warning",
                            customClass: "msg-dark sasfw"
                        }).then((() => !0)).catch((() => !1)))())) return;
                    const l = n ? "BUY" : "SELL",
                        c = r ? "1" : "0";
                    if ("" === String(i)) return void b.error(D("inx.please-input-amount"));
                    if (!ce(i)) return void b.error(D('please-input-correct-amount"'));
                    if (!le(s)) return void b.error(D("pga.input-correct-price"));
                    if ("Limit" === $.value && !le(a)) return void b.error(D("pga.input-correct-price"));
                    if (Number(i) > xe.value) return void b.error(D("depwi.low-balance-try-again"));
                    const u = new re;
                    u.append("symbol", t.symbol), u.append("price", "Limit" === $.value ? String(a) : "0"), u.append("amount", String(i)), u.append("triggerPrice", String(s)), u.append("direction", l), u.append("type", "CHECK_FULL_STOP"), u.append("userid", String(ie.testuser)), u.append("tif", Y.value), u.append("useDiscount", c), p.BuyAndSellTrigger(u).then((e => {
                        const t = e.data;
                        0 === t.code ? (b.success("submit success!"), ee("refreshAccount", !1), ie.form.amount = "", ie.form.amountRev = "", ie.form.price = 0) : b.error(t.message)
                    }))
                },
                de = l(!1),
                pe = async () => {
                    try {
                        let e = 0,
                            t = 0;
                        if (98 !== ae.value) {
                            const {
                                data: n
                            } = await p.getWallet(O.currentCoin.base);
                            e = n.data ? n.data.balance : 0;
                            const {
                                data: r
                            } = await p.getWallet(O.currentCoin.coin);
                            t = r.data ? r.data.balance : 0
                        }
                        if (97 === ae.value || 98 === ae.value) {
                            const {
                                data: n
                            } = await p.getWalletMpc(O.currentCoin.base);
                            e += n.data ? n.data.balance : 0;
                            const {
                                data: r
                            } = await p.getWalletMpc(O.currentCoin.coin);
                            t += r.data ? r.data.balance : 0
                        }
                        ie.wallet.coin = t, ie.wallet.base = e, 0 === ie.selectedMarketTab && ie.purchaseBuy && (xe.value = e), de.value = !0, B.value = !1
                    } catch (e) {
                        console.error(e), ie.wallet.coin = 0, ie.wallet.base = 0
                    }
                };
            M((() => (O.addOrder, void(A.isLoggedIn && !B.value && pe()))));
            const fe = () => {
                    ie.sliderAmountPercent = 0, ie.purchaseBuy = !1, ve()
                },
                me = () => {
                    ie.sliderAmountPercent = 0, ie.purchaseBuy = !0, ve()
                },
                he = l(!1),
                ye = e => {
                    const t = e.keyCode,
                        n = e.target,
                        r = n.value;
                    let o = he.value ? O.baseScale : O.quoteScale;
                    if (console.log(t), r.startsWith("0")) {
                        if (96 == t && !r.includes(".") && 190 != t && 110 != t) return e.preventDefault(), void console.log("prevent 1");
                        r.includes(".") || 190 == t || 110 == t || (n.value = r.slice(1))
                    }
                    return (190 == t || 110 == t) && n.value.indexOf(".") > 0 ? (e.preventDefault(), void console.log("prevent 12")) : t >= 48 && t <= 57 || t >= 96 && t <= 105 || [8, 37, 39, 46, 190, 110].includes(t) ? (console.log("inputValue", o), void requestAnimationFrame((() => {
                        const e = n.value.split(".");
                        e.length > 1 && e[1].length > o && (n.value = `${e[0]}.${e[1].slice(0,o)}`)
                    }))) : (e.preventDefault(), void console.log("prevent 13"))
                },
                ge = () => {
                    if (0 === ie.selectedMarketTab) {
                        const e = ie.purchaseBuy ? O.baseScale : O.quoteScale,
                            t = Me(ie.purchaseBuy ? Number(ie.form.amount) / O.currentCoin.price : Number(ie.form.amount) * O.currentCoin.price, e);
                        ie.form.amountRev = t.toString()
                    }
                },
                ve = () => {
                    const e = 0 === ie.selectedMarketTab ? O.quoteScale : O.baseScale,
                        t = Me(xe.value * ie.sliderAmountPercent * .01, e);
                    ie.form.amount = t.toString(), 0 === ie.selectedMarketTab && ge()
                },
                be = (e, t) => {
                    const n = Number(ie.form.amount);
                    ie.purchaseBuy ? isNaN(n) ? (ie.form.amount = "", ie.sliderAmountPercent = 0) : 0 == ie.selectedMarketTab ? (console.log("amoun1t2"), ie.sliderAmountPercent = Number(V(n / ie.wallet.base * 100))) : (console.log("amoun1t"), ie.sliderAmountPercent = Number(V(n * ie.form.price / ie.wallet.base * 100))) : isNaN(n) ? (ie.form.amount = "", ie.sliderAmountPercent = 0) : ie.sliderAmountPercent = Number(V(n / ie.wallet.coin * 100)), (0 == ie.selectedMarketTab && null == t || !t) && (isNaN(n) ? ie.form.amountRev = "" : ge())
                },
                xe = l(ie.wallet.base);
            k([() => ie.selectedMarketTab, () => ie.purchaseBuy, () => ie.wallet, () => ie.form.price], (([e, t, n, r]) => {
                r || (ie.form.price = O.currentCoin.price);
                const o = 0 === e,
                    i = 2 === e;
                xe.value = i ? t ? n.base / ie.form.price : n.coin : t && o ? n.base : t ? n.base / ie.form.price : n.coin
            }));
            c((() => {
                A.isLoggedIn
            }));
            const we = l(null),
                ke = l(null),
                Se = l(null),
                Ce = l(null),
                _e = l(null),
                Te = l(""),
                De = () => {
                    Te.value = ""
                },
                Oe = () => {
                    we.value && we.value.focus(), Te.value = "price", he.value = !1, console.log("amountInput.value3")
                },
                Ee = () => {
                    ke.value && ke.value.focus(), Te.value = "price2", he.value = !1, console.log("amountInput.value1")
                },
                Ve = () => {
                    Se.value && Se.value.focus(), he.value = !1, Te.value = "price3", console.log("amountInput.value1")
                },
                Be = () => {
                    Ce.value && Ce.value.focus(), console.log("amountInput.value"), Te.value = "amount", 0 == ie.selectedMarketTab && ie.purchaseBuy ? he.value = !1 : he.value = !0
                },
                He = () => {
                    _e.value && _e.value.focus(), Te.value = "amount2", 0 != ie.selectedMarketTab || ie.purchaseBuy ? he.value = !0 : he.value = !1
                };
            return (e, n) => {
                const s = j("RouterLink"),
                    l = Pe,
                    c = je,
                    x = Le;
                return o(), t("div", {
                    class: r(["price-item-content", [m(G).isTradeAiMode ? "bg-gradient-purple" : ie.purchaseBuy ? "bg-gradient-green" : "bg-gradient-red", m(G).isAppOn && "mobile"]])
                }, [m(G).isTradeAiMode ? (o(), t("div", Sm, [u(Rf, {
                    isMobileWidth: R.value,
                    balanceFirst: de.value,
                    currentCoin: O.currentCoin,
                    baseScale: O.baseScale,
                    quoteScale: O.quoteScale,
                    coin: ie.wallet.coin,
                    base: ie.wallet.base,
                    onCloseDrawer: n[26] || (n[26] = e => ee("closeDrawer"))
                }, null, 8, ["isMobileWidth", "balanceFirst", "currentCoin", "baseScale", "quoteScale", "coin", "base"])])) : (o(), t("div", Wf, [i("div", Vf, [i("div", Bf, [n[38] || (n[38] = i("div", {
                    class: "block-ttl"
                }, null, -1)), i("p", Hf, [a(f(m(D)("exh.spot")) + " ", 1), n[37] || (n[37] = i("span", {
                    class: "text-gray1 help ml-1 p-0 m-0",
                    style: {
                        "margin-top": "1px !important"
                    }
                }, "(DEMO TRADING)", -1))])]), i("div", qf, [u(bf), R.value ? (o(), t("div", {
                    key: 0,
                    class: "ml-1 pl-2 pr-1 cursor-pointer",
                    onClick: n[0] || (n[0] = e => ee("closeDrawer"))
                }, n[39] || (n[39] = [i("i", {
                    style: {
                        "font-size": "12px"
                    },
                    class: "fas fa-close text-gray-darken"
                }, null, -1)]))) : y("", !0)])]), i("div", Uf, [i("div", zf, [i("button", {
                    class: r(["w-1/2 text-green-darken py-2 text-10 uppercase rounded-l", ie.purchaseBuy ? "bg-green-lighten" : ""]),
                    onClick: me
                }, f(m(D)("exh.buy")), 3), i("button", {
                    class: r(["w-1/2 text-green-darken py-2 text-10 uppercase rounded-r sell-btn", ie.purchaseBuy ? "" : "bg-red-light-darken"]),
                    onClick: fe
                }, f(m(D)("exh.sell")), 3)])]), i("div", $f, [i("div", Zf, [i("div", {
                    class: r(["border-solid text-12 px-2 py-3 mr-4", 0 == ie.selectedMarketTab ? "border-purple-darken" : "border-transparent text-gray-darken"]),
                    onClick: n[1] || (n[1] = e => se(0))
                }, f(m(D)("exh.market-header")), 3), i("div", {
                    class: r(["text-12 border-solid px-2 py-3 mr-4", 1 == ie.selectedMarketTab ? "border-purple-darken" : "border-transparent text-gray-darken"]),
                    onClick: n[2] || (n[2] = e => se(1))
                }, f(m(D)("exh.limit")), 3), i("div", {
                    class: r(["text-12 border-solid px-2 py-3", 2 == ie.selectedMarketTab ? "border-purple-darken" : "border-transparent text-gray-darken"]),
                    onClick: n[3] || (n[3] = e => se(2))
                }, f(m(D)("exh.trigger")), 3)]), i("div", Gf, [i("div", Yf, [i("div", Jf, [1 == ie.selectedMarketTab || "Market" != $.value && 2 == ie.selectedMarketTab ? (o(), h(m(We), {
                    key: 0,
                    modelValue: Y.value,
                    "onUpdate:modelValue": n[4] || (n[4] = e => Y.value = e),
                    "suffix-icon": "",
                    class: "m-2",
                    placeholder: "Select",
                    size: "small"
                }, {
                    default: d((() => [(o(), t(_, null, C(Q, (e => u(m(Re), {
                        key: e,
                        value: e
                    }, {
                        default: d((() => [i("span", Kf, f(e), 1)])),
                        _: 2
                    }, 1032, ["value"]))), 64))])),
                    _: 1
                }, 8, ["modelValue"])) : y("", !0)])])])]), i("div", null, [m(G).isShowWallet ? (o(), t("div", Xf, [i("p", Qf, [n[40] || (n[40] = i("i", {
                    class: "text-gray-darken fas fa-wallet mr-1"
                }, null, -1)), a(" " + f(m(D)("exh.available")), 1)]), !m(A).isLoggedIn || de.value ? (o(), t("p", em, f(ie.purchaseBuy ? m(Me)(ie.wallet.base, O.quoteScale).toLocaleString() + " " + O.currentCoin.base : m(Me)(ie.wallet.coin, O.baseScale) + " " + O.currentCoin.coin), 1)) : y("", !0)])) : y("", !0), 1 == ie.selectedMarketTab ? (o(), t("div", tm, [i("div", {
                    class: r(["border border-solid border-gray-lighter rounded py-2 px-4 flex mb-3 cursor-pointer", {
                        "focused-border": "price" === Te.value
                    }]),
                    onClick: Oe
                }, [i("p", nm, f(m(D)("exh.price")), 1), S(i("input", {
                    ref_key: "priceInput1",
                    ref: we,
                    "onUpdate:modelValue": n[5] || (n[5] = e => ie.form.price = e),
                    onChange: W,
                    type: "text",
                    onBlur: De,
                    class: "w-full text-white bg-transparent text-12 text-right outline-none",
                    onKeydown: n[6] || (n[6] = e => ye(e))
                }, null, 544), [
                    [L, ie.form.price]
                ]), i("p", rm, f(O.currentCoin.base), 1)], 2)])) : y("", !0), 2 == ie.selectedMarketTab ? (o(), t("div", om, [i("div", {
                    class: r(["border border-solid border-gray-lighter rounded py-2 px-4 flex mb-4 cursor-pointer", {
                        "focused-border": "price3" === Te.value
                    }]),
                    onClick: Ve
                }, [i("p", im, f(m(D)("exh.trigger-price")), 1), S(i("input", {
                    ref_key: "priceTInput",
                    ref: Se,
                    "onUpdate:modelValue": n[7] || (n[7] = e => ie.form.triggerPrice = e),
                    type: "text",
                    class: "w-full text-white bg-transparent text-12 text-right outline-none",
                    onKeydown: n[8] || (n[8] = e => ye(e)),
                    onBlur: De
                }, null, 544), [
                    [L, ie.form.triggerPrice]
                ]), i("p", am, f(O.currentCoin.base), 1)], 2), i("div", {
                    class: r(["price-in border border-solid border-gray-lighter rounded py-2 pl-4 flex mb-3", ["Market" != $.value ? "cursor-pointer" : "", {
                        "focused-border": "price2" === Te.value
                    }]]),
                    onClick: Ee,
                    style: {
                        "justify-content": "space-between"
                    }
                }, [i("p", sm, f(m(D)("exh.price")), 1), S(i("input", {
                    ref_key: "priceInput2",
                    ref: ke,
                    "onUpdate:modelValue": n[9] || (n[9] = e => ie.form.price = e),
                    onChange: W,
                    type: "text",
                    onBlur: De,
                    class: "w-full text-white bg-transparent text-12 text-right outline-none",
                    onKeydown: n[10] || (n[10] = e => ye(e))
                }, null, 544), [
                    [N, "Market" != $.value],
                    [L, ie.form.price]
                ]), i("p", lm, f("Market" != $.value ? O.currentCoin.base + " |" : ""), 1), u(m(We), {
                    modelValue: $.value,
                    "onUpdate:modelValue": n[11] || (n[11] = e => $.value = e),
                    class: "m-2 price-market-select",
                    placeholder: "Select",
                    size: "small",
                    placement: "left",
                    onClick: n[12] || (n[12] = F((() => {}), ["stop"]))
                }, {
                    default: d((() => [(o(), t(_, null, C(Z, (e => u(m(Re), {
                        key: e.value,
                        label: e.label,
                        value: e.value
                    }, null, 8, ["label", "value"]))), 64))])),
                    _: 1
                }, 8, ["modelValue"])], 2)])) : y("", !0), i("div", {
                    class: r(["border border-solid border-gray-lighter rounded py-2 px-4 flex mb-3 cursor-pointer", {
                        "focused-border": "amount" === Te.value
                    }]),
                    onClick: Be
                }, [i("p", cm, f(0 == ie.selectedMarketTab && ie.purchaseBuy ? m(D)("exh.order-value") : m(D)("exh.amount")), 1), S(i("input", {
                    ref_key: "amountInput",
                    ref: Ce,
                    "onUpdate:modelValue": n[13] || (n[13] = e => ie.form.amount = e),
                    pattern: "^\\d*(\\.\\d{0,2})?$",
                    type: "text",
                    onBlur: De,
                    class: "w-full text-white bg-transparent text-12 text-right outline-none",
                    onInput: be,
                    onKeydown: n[14] || (n[14] = e => ye(e))
                }, null, 544), [
                    [L, ie.form.amount]
                ]), i("p", um, f(0 == ie.selectedMarketTab && ie.purchaseBuy ? O.currentCoin.base : O.currentCoin.coin), 1)], 2), i("div", {
                    class: r(["control mt-4 mb-10 mx-1 custom-slider", ie.purchaseBuy ? "buy-slider" : "sell-slider"])
                }, [u(m(K), {
                    modelValue: ie.sliderAmountPercent,
                    "onUpdate:modelValue": n[15] || (n[15] = e => ie.sliderAmountPercent = e),
                    "tooltip-class": "sliderAmount",
                    size: "small",
                    "format-tooltip": te,
                    onInput: ve
                }, null, 8, ["modelValue"]), i("div", dm, [i("span", {
                    class: r(["ant-slider-mark-text ant-slider-mark-text-active", ie.sliderAmountPercent >= 1 ? ie.purchaseBuy ? "text-green-darken" : "text-red-darken" : ""]),
                    style: {
                        transform: "translateX(-50%)",
                        left: "0%"
                    },
                    onClick: n[16] || (n[16] = e => {
                        ie.sliderAmountPercent = 0, ve()
                    })
                }, "0%", 2), i("span", {
                    class: r(["ant-slider-mark-text", ie.sliderAmountPercent >= 25 ? ie.purchaseBuy ? "text-green-darken" : "text-red-darken" : ""]),
                    style: {
                        transform: "translateX(-50%)",
                        left: "25%"
                    },
                    onClick: n[17] || (n[17] = e => {
                        ie.sliderAmountPercent = 25, ve()
                    })
                }, "25%", 2), i("span", {
                    class: r(["ant-slider-mark-text", ie.sliderAmountPercent >= 50 ? ie.purchaseBuy ? "text-green-darken" : "text-red-darken" : ""]),
                    style: {
                        transform: "translateX(-50%)",
                        left: "50%"
                    },
                    onClick: n[18] || (n[18] = e => {
                        ie.sliderAmountPercent = 50, ve()
                    })
                }, "50%", 2), i("span", {
                    class: r(["ant-slider-mark-text", ie.sliderAmountPercent >= 75 ? ie.purchaseBuy ? "text-green-darken" : "text-red-darken" : ""]),
                    style: {
                        transform: "translateX(-50%)",
                        left: "75%"
                    },
                    onClick: n[19] || (n[19] = e => {
                        ie.sliderAmountPercent = 75, ve()
                    })
                }, "75%", 2), i("span", {
                    class: r(["ant-slider-mark-text pr-2", ie.sliderAmountPercent >= 100 ? ie.purchaseBuy ? "text-green-darken" : "text-red-darken" : ""]),
                    style: {
                        transform: "translateX(-50%)",
                        left: "100%"
                    },
                    onClick: n[20] || (n[20] = e => {
                        ie.sliderAmountPercent = 100, ve()
                    })
                }, "100%", 2)])], 2), i("div", null, [2 === ie.selectedMarketTab && "Market" === $.value || 0 === ie.selectedMarketTab ? 2 !== ie.selectedMarketTab || "Market" !== $.value ? (o(), t("div", ym, [i("div", {
                    class: r(["border border-solid border-gray-lighter rounded py-2 px-4 flex mb-3 cursor-pointer", {
                        "focused-border": "amount2" === Te.value
                    }]),
                    onClick: He
                }, [i("p", gm, f(ie.purchaseBuy ? m(D)("exh.amount") : m(D)("exh.order-value")), 1), S(i("input", {
                    ref_key: "amountInput2",
                    ref: _e,
                    "onUpdate:modelValue": n[21] || (n[21] = e => ie.form.amountRev = e),
                    pattern: "^\\d*(\\.\\d{0,2})?$",
                    onBlur: De,
                    type: "text",
                    class: "w-full text-white bg-transparent text-12 text-right outline-none",
                    onInput: n[22] || (n[22] = e => (e => {
                        const t = ie.purchaseBuy ? O.quoteScale : O.baseScale,
                            n = Me(Number(ie.form.amountRev) * (ie.purchaseBuy ? O.currentCoin.price : 1 / O.currentCoin.price), t);
                        ie.form.amount = n.toString(), be(!1, e)
                    })(!0)),
                    onKeydown: n[23] || (n[23] = e => ye(e))
                }, null, 544), [
                    [L, ie.form.amountRev]
                ]), i("p", vm, f(ie.purchaseBuy ? O.currentCoin.coin : O.currentCoin.base), 1)], 2)])) : y("", !0) : (o(), t("div", pm, [i("p", fm, f(ie.purchaseBuy && 0 == ie.selectedMarketTab ? m(D)("exh.amount") : m(D)("exh.order-value")), 1), i("p", mm, f(ie.purchaseBuy && 0 == ie.selectedMarketTab ? (ie.form.amount / O.currentCoin.price).toLocaleString(void 0, {
                    minimumFractionDigits: O.baseScale
                }) : (ie.form.amount * (0 == ie.selectedMarketTab || "Market" == $.value && 2 == ie.selectedMarketTab ? O.currentCoin.price : ie.form.price)).toLocaleString(void 0, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })), 1), i("p", hm, f(ie.purchaseBuy && 0 == ie.selectedMarketTab ? O.currentCoin.coin : O.currentCoin.base), 1)])), 0 == ie.selectedMarketTab && 0 != ie.selectedMarketTab || "USD" == m(G).currency ? y("", !0) : (o(), t("div", bm, [i("p", xm, f((ie.purchaseBuy && ie.selectedMarketTab, (ie.form.amount / (ie.purchaseBuy && 0 == ie.selectedMarketTab ? O.currentCoin.price : 1) * (0 == ie.selectedMarketTab || "Market" == $.value && 2 == ie.selectedMarketTab ? O.currentCoin.price : ie.form.price) * m(G).currencyRate).toLocaleString(void 0, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }))), 1), i("p", wm, f(m(G).currency), 1)])), i("div", null, [u(m(Ae), {
                    placement: "top",
                    effect: "customized"
                }, {
                    content: d((() => n[41] || (n[41] = [a(" Please log in with your Email/Mobile;"), i("br", null, null, -1), a("Connecting through Web3 wallets"), i("br", null, null, -1), a("is currently not available in Demo Trading. ")]))),
                    default: d((() => [m(A).isLoggedIn ? y("", !0) : (o(), t("a", km, f(m(D)("dash.connect-wallet")), 1))])),
                    _: 1
                }), i("div", {
                    class: r(["flex", (m(G).isAppOn, "mb-3")])
                }, [m(A).isLoggedIn ? y("", !0) : (o(), h(s, {
                    key: 0,
                    to: {
                        name: "auth",
                        query: {
                            redirect: "/trade"
                        }
                    },
                    class: r(["w-1/2 py-2 mb-0 mr-2 rounded text-10 block border text-center text-bold", ie.purchaseBuy ? "bg-green-lighten border-green-darken text-green-darken hover:bg-green-lighten" : "bg-red-lighten border-red-darken text-red-darken"])
                }, {
                    default: d((() => [a(f(m(D)("auth.log-in")), 1)])),
                    _: 1
                }, 8, ["class"])), m(A).isLoggedIn ? y("", !0) : (o(), t("button", {
                    key: 1,
                    class: r(["w-1/2 py-2 text-medium border-solid text-medium border text-10 rounded", ie.purchaseBuy ? "border-green-darken text-green-darken hover:bg-green-lighten" : " hover:bg-red-lighten border-red-darken text-red-darken"]),
                    onClick: n[24] || (n[24] = e => m(v).push({
                        name: "register",
                        query: {
                            redirect: "/trade"
                        }
                    }))
                }, f(m(D)("auth.register")), 3))], 2)]), m(A).isLoggedIn ? (o(), t("button", {
                    key: 3,
                    class: r(["w-full py-2 rounded text-green-darken text-10 text-bold", ie.purchaseBuy ? "bg-green-lighten" : "sell-btn bg-red-light-darken"]),
                    onClick: n[25] || (n[25] = e => 2 == ie.selectedMarketTab ? ue() : (() => {
                        const {
                            enableTrading: e,
                            currentCoin: t,
                            baseScale: n
                        } = O, {
                            selectedMarketTab: r,
                            purchaseBuy: o,
                            isUseBHB: i,
                            form: a
                        } = ie, {
                            price: s
                        } = a, l = o && 0 == r ? a.amountRev : a.amount;
                        if (!e) return void b.error(D("inx.request-failed-support"));
                        const c = 0 === r ? "MARKET_PRICE" : "LIMIT_PRICE",
                            u = o ? "BUY" : "SELL",
                            d = i ? "1" : "0";
                        if ("" === String(l)) return void b.error(D("inx.please-input-amount"));
                        if (!ce(l)) return void b.error(D("inx.please-input-correct-amount"));
                        if ("LIMIT_PRICE" === c && !le(s)) return void b.error(D("pga.input-correct-price"));
                        if (Number(l) > xe.value) return void b.error(D("depwi.low-balance-try-again"));
                        const f = new re;
                        f.append("symbol", t.symbol), f.append("price", String(s)), f.append("amount", String(l)), f.append("direction", u), f.append("type", c), f.append("userid", String(ie.testuser)), f.append("tif", Y.value), f.append("useDiscount", d), p.BuyAndSell(f).then((e => {
                            const t = e.data;
                            0 === t.code ? (b.success(D("inx.submitted-successfully")), ee("refreshAccount", !1), ie.form.amount = "", ie.form.amountRev = "", ie.form.price = 0) : b.error(t.message)
                        }))
                    })())
                }, f(ie.purchaseBuy ? m(D)("exh.buy") : m(D)("exh.sell")) + " " + f(O.currentCoin.coin), 3)) : y("", !0)])])])), i("div", Cm, [i("div", _m, [i("p", Tm, f(m(D)("pga.account")) + ":", 1), i("div", Am, [m(A).isLoggedIn ? (o(), h(m(We), {
                    key: 0,
                    modelValue: ae.value,
                    "onUpdate:modelValue": n[27] || (n[27] = e => ae.value = e),
                    onChange: J,
                    placeholder: "Select",
                    size: "small"
                }, {
                    prefix: d((() => n[42] || (n[42] = [i("div", {
                        class: "flex"
                    }, [i("i", {
                        class: "text-gray-darken fas fa-wallet"
                    })], -1)]))),
                    default: d((() => [(o(!0), t(_, null, C(ie.allSubAcc, (e => (o(), h(m(Re), {
                        key: e.id,
                        label: e.name,
                        value: e.id
                    }, {
                        default: d((() => [i("span", Dm, f(e.name), 1)])),
                        _: 2
                    }, 1032, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue"])) : y("", !0)])]), i("div", {
                    class: r(["flex", m(G).isAppOn ? "mb-3" : "mb-5"])
                }, [i("button", {
                    class: r(["w-1/2 py-2 text-medium border-solid text-medium border text-10 mr-2 rounded", m(G).isTradeAiMode ? "text-gray3 hover:bg-purple-lighten border-purple-darken" : ie.purchaseBuy ? "border-green-darken text-green-darken hover:bg-green-lighten" : "hover:bg-red-lighten border-red-darken text-red-darken"]),
                    onClick: n[28] || (n[28] = e => m(A).isLoggedIn ? void(G.isAppOn ? window.ReactNativeWebView.postMessage(JSON.stringify({
                        opzkey: "deposit"
                    })) : (q.value = !0, H.value = !0)) : m(v).push({
                        name: "auth",
                        query: {
                            redirect: "/trade"
                        }
                    }))
                }, f(m(D)("dash.deposit")), 3), i("button", {
                    class: r(["w-1/2 py-2 text-medium border-solid text-medium border text-10 rounded", m(G).isTradeAiMode ? "text-gray3 hover:bg-purple-lighten border-purple-darken" : ie.purchaseBuy ? "border-green-darken text-green-darken hover:bg-green-lighten" : "hover:bg-red-lighten border-red-darken text-red-darken"]),
                    onClick: n[29] || (n[29] = e => m(A).isLoggedIn ? void(g.value = !0) : m(v).push({
                        name: "auth",
                        query: {
                            redirect: "/trade"
                        }
                    }))
                }, f(m(D)("hiss.transfer")), 3)], 2), m(G).isShowWallet ? (o(), t("div", Om, [i("div", Em, [i("p", Im, [a(f(O.currentCoin.coin) + " ", 1), i("span", {
                    class: r(m(G).isTradeAiMode ? "text-gray-darken" : ie.purchaseBuy ? "text-green-darken" : "text-red-darken")
                }, f(m(D)("dash.available-balance")), 3)]), !m(A).isLoggedIn || de.value ? (o(), t("p", jm, f(m(Me)(ie.wallet.coin, O.baseScale)), 1)) : y("", !0)]), i("div", Lm, [i("p", Pm, [a(f(O.currentCoin.base) + " ", 1), i("span", {
                    class: r(m(G).isTradeAiMode ? "text-gray-darken" : ie.purchaseBuy ? "text-green-darken" : "text-red-darken")
                }, f(m(D)("dash.available-balance")), 3)]), !m(A).isLoggedIn || de.value ? (o(), t("p", Mm, f(m(Me)(ie.wallet.base, O.quoteScale).toLocaleString()), 1)) : y("", !0)])])) : y("", !0)]), u(Ne, {
                    modelValue: g.value,
                    "onUpdate:modelValue": n[30] || (n[30] = e => g.value = e)
                }, null, 8, ["modelValue"]), oe.value ? (o(), h(l, {
                    key: 2,
                    modelValue: ne.value,
                    "onUpdate:modelValue": n[31] || (n[31] = e => ne.value = e),
                    single: !1,
                    onSuccessTransfer: e => null,
                    onCloseTransfer: n[32] || (n[32] = e => ne.value = !1)
                }, null, 8, ["modelValue"])) : y("", !0), q.value ? (o(), h(c, {
                    key: 3,
                    single: !1,
                    modelValue: H.value,
                    "onUpdate:modelValue": n[33] || (n[33] = e => H.value = e),
                    coinname: "",
                    "is-mpc": m(A).userData.mpcWallet,
                    onCancelAll: n[34] || (n[34] = e => H.value = !1)
                }, null, 8, ["modelValue", "is-mpc"])) : y("", !0), z.value ? (o(), h(x, {
                    key: 4,
                    single: !1,
                    coinname: "",
                    modelValue: U.value,
                    "onUpdate:modelValue": n[35] || (n[35] = e => U.value = e),
                    started: !0,
                    onSuccessWithdrawal: e => null,
                    onCloseWithdrawal: n[36] || (n[36] = e => U.value = !1)
                }, null, 8, ["modelValue"])) : y("", !0)], 2)
            }
        }
    }), [
        ["__scopeId", "data-v-3060550b"]
    ]),
    Fm = {
        class: "staking-dash ai-ts"
    },
    Rm = {
        class: "stdash-bottom ai-zs"
    },
    Wm = {
        class: "sdash-4252"
    },
    Vm = {
        class: "stads-4342 stadsg-4325 trade-ai scrollbar-flex-content scrollable-container",
        ref: "containerRef"
    },
    Bm = {
        class: "stdash-img-s21 flex items-center"
    },
    Hm = {
        class: "flex items-center"
    },
    qm = ["src"],
    Um = {
        class: "mr-1"
    },
    zm = {
        class: "item-ai-trade"
    },
    $m = {
        class: "text-gray5 text-medium text-12"
    },
    Zm = ["title"],
    Gm = {
        class: "item-ai-trade"
    },
    Ym = {
        class: "text-medium text-12 mb-1 text-green-darken"
    },
    Jm = {
        class: "item-ai-trade"
    },
    Km = {
        class: "text-gray-darken text-medium text-12 mb-1"
    },
    Xm = {
        class: "text-gray5 text-medium text-12 mb-1"
    },
    Qm = {
        class: "flex flex-col items-center m-3 justify-center"
    },
    eh = {
        class: "coin-info-container mb-2"
    },
    th = {
        class: "coin-info-point"
    },
    nh = {
        class: "value"
    },
    rh = {
        class: "coin-info-point"
    },
    oh = {
        class: "value"
    },
    ih = {
        class: "coin-info-point"
    },
    ah = {
        class: "value"
    },
    sh = {
        class: "coin-info-point"
    },
    lh = {
        class: "value"
    },
    ch = {
        class: "coin-info-point"
    },
    uh = {
        class: "value"
    },
    dh = {
        class: "coin-info-container mb-2"
    },
    ph = {
        class: "coin-info-point"
    },
    fh = {
        class: "value"
    },
    mh = {
        class: "coin-info-container"
    },
    hh = {
        class: "coin-info-point"
    },
    yh = {
        class: "value"
    },
    gh = {
        key: 1,
        class: "scrollbar-ai-item flex p-0",
        style: {
            background: "none"
        }
    },
    vh = q(e({
        __name: "AiTradeItems",
        props: {
            currentCoin: Object,
            isMobileWidth: Boolean,
            noBg: Boolean,
            maxItems: Number,
            disablePopover: Boolean
        },
        setup(e) {
            const n = e,
                {
                    Api: r
                } = s(),
                {
                    t: a
                } = w(),
                p = l(!0);
            T({
                allItems: []
            });
            const y = l([]),
                g = async () => {
                    var e, t;
                    if (null == (e = n.currentCoin) ? void 0 : e.symbol) {
                        p.value = !0;
                        try {
                            const e = await r.aiTradeEvent(n.currentCoin.symbol);
                            if (0 === e.data.code && (null == (t = null == e ? void 0 : e.data) ? void 0 : t.data)) {
                                const t = e.data.data.map((e => {
                                    const t = e.isBuy ? (e.closePrice - e.openPrice) / e.openPrice * 100 : (e.openPrice - e.closePrice) / e.openPrice * 100,
                                        n = (t / 100 * e.amount).toFixed(5);
                                    return { ...e,
                                        pnl: `${t.toFixed(1)}%`,
                                        pnlPer: t,
                                        amountPnl: `${n} ${e.symbol.split("/")[0]}`
                                    }
                                })).sort(((e, t) => t.openDate - e.openDate));
                                y.value = t.slice(0, n.maxItems)
                            }
                        } catch (o) {
                            console.error("Error fetching trade data:", o)
                        } finally {
                            p.value = !1
                        }
                    }
                };
            k((() => {
                var e;
                return null == (e = n.currentCoin) ? void 0 : e.symbol
            }), (() => {
                y.value = [], g()
            }));
            const v = e => `${e.getDate()} ${e.toLocaleString("en-US",{month:"short"})} ${e.getHours().toString().padStart(2,"0")}:${e.getMinutes().toString().padStart(2,"0")}:${e.getSeconds().toString().padStart(2,"0")}`,
                b = A((() => y.value.map((e => ({ ...e,
                    dateOpenString: v(new Date(e.openDate)),
                    dateCloseString: v(new Date(e.closeData))
                })))));
            return c((() => {
                g()
            })), (e, r) => {
                const s = Se;
                return o(), t("div", Fm, [i("div", Rm, [i("div", Wm, [i("div", Vm, [p.value ? (o(), t("div", gh, [(o(), t(_, null, C(5, (e => u(s, {
                    width: "303px",
                    height: "100.4px",
                    style: {
                        "border-radius": "6px"
                    }
                }))), 64))])) : (o(!0), t(_, {
                    key: 0
                }, C(b.value, (e => (o(), h(m(Te), {
                    placement: "bottom",
                    class: "scrollbar-ai-item",
                    trigger: "click",
                    "popper-class": "pop-symbols",
                    persistent: !1,
                    width: n.isMobileWidth ? "90vw" : 440,
                    key: e.id
                }, {
                    reference: d((() => [i("div", {
                        class: "stdasdh-3242",
                        ref_for: !0,
                        ref: "popover-" + e.id
                    }, [i("dt", null, [i("div", Bm, [i("div", Hm, [i("img", {
                        src: `/images/icons/coin/${e.symbol.split("/")[0].toLowerCase()}.svg`,
                        width: "18",
                        class: "mr-1",
                        style: {
                            "padding-top": "2px"
                        }
                    }, null, 8, qm), i("h4", Um, f(e.symbol), 1), r[0] || (r[0] = i("p", {
                        class: "text-gray3"
                    }, "|", -1)), r[1] || (r[1] = i("p", {
                        class: "ml-1 help text-gray-darken"
                    }, "OPZ-AI", -1))]), r[2] || (r[2] = i("div", {
                        class: "flex items-center"
                    }, [i("div", {
                        class: "ml-2 stdash-if2"
                    }, [i("i", {
                        class: "fas fa-crosshairs sdash-img"
                    })])], -1))])]), i("dd", null, [i("div", zm, [r[3] || (r[3] = i("p", {
                        class: "text-gray-darken text-medium text-12"
                    }, "PNL (%)", -1)), i("p", $m, [i("output", {
                        title: e.pnl,
                        class: "sdash-b13s stdash-21314 text-green-darken"
                    }, f(e.pnl), 9, Zm)])]), i("div", Gm, [r[4] || (r[4] = i("p", {
                        class: "text-gray-darken text-medium text-12 mb-1"
                    }, "PNL", -1)), i("p", Ym, f(e.amountPnl), 1)]), i("div", Jm, [i("p", Km, f(m(a)("hiss.date-time")), 1), i("p", Xm, f(e.dateOpenString), 1)])])], 512)])),
                    default: d((() => [i("div", Qm, [i("div", eh, [i("div", th, [r[5] || (r[5] = i("span", null, "Symbol", -1)), i("span", nh, f(e.symbol), 1)]), i("div", rh, [r[6] || (r[6] = i("span", null, "Direction", -1)), i("span", oh, f(e.isBuy ? m(a)("exh.buy") : m(a)("exh.sell")), 1)]), i("div", ih, [r[7] || (r[7] = i("span", null, "Open Price", -1)), i("span", ah, "$" + f(e.openPrice), 1)]), i("div", sh, [r[8] || (r[8] = i("span", null, "Close Price", -1)), i("span", lh, "$" + f(e.closePrice), 1)]), i("div", ch, [r[9] || (r[9] = i("span", null, "Close Date", -1)), i("span", uh, f(e.dateCloseString), 1)])]), i("div", dh, [i("div", ph, [r[10] || (r[10] = i("span", null, "OPZ-AI Insights", -1)), i("span", fh, f(e.actionAdvice), 1)])]), i("div", mh, [i("div", hh, [i("span", null, "Health Score (" + f(e.healthScore) + ")", 1), i("span", yh, f(e.detailsAi), 1)])])])])),
                    _: 2
                }, 1032, ["width"])))), 128))], 512)])])])
            }
        }
    }), [
        ["__scopeId", "data-v-adaa0152"]
    ]),
    bh = {
        key: 0,
        class: "border-b border-t border-solid bg-trade-border start-header"
    },
    xh = {
        class: "flex justify-between items-center p-5"
    },
    wh = {
        key: 1,
        class: "border-b border-t border-solid bg-trade-border start-header"
    },
    kh = {
        class: "flex justify-between items-center pr-4 pt-5 pb-4 pl-2"
    },
    Sh = {
        key: 2
    },
    Ch = {
        class: "border-b border-solid bg-trade-border"
    },
    _h = {
        class: "border-b border-solid bg-trade-border"
    },
    Th = {
        class: "chart-history-content flex-grow md:border-r border-solid bg-trade-border"
    },
    Ah = {
        class: "relative"
    },
    Dh = {
        class: "px-4 border-b md:border-transparent text-medium border-solid bg-trade-border htable"
    },
    Oh = {
        class: "overflow-x-auto"
    },
    Eh = {
        class: "price-history-content",
        style: {
            position: "relative"
        }
    },
    Ih = {
        class: "flex justify-between"
    },
    jh = {
        class: "tabs flex taborder"
    },
    Lh = {
        class: "history-tab flex"
    },
    Ph = ["onClick"],
    Mh = {
        key: 0,
        class: "ml-1 text-gray2"
    },
    Nh = {
        key: 1,
        class: "ml-1 text-gray2"
    },
    Fh = {
        key: 0,
        class: "center-login"
    },
    Rh = {
        class: "mx-1"
    },
    Wh = {
        key: 1,
        id: "HistoryTable",
        class: "pb-1 headerSiding has-slimscroll"
    },
    Vh = {
        key: 0,
        class: "flex mb-2 justify-between items-center w-100"
    },
    Bh = {
        class: "text-red-darken hover cnlBtn",
        style: {
            height: "24px"
        }
    },
    Hh = {
        key: 3,
        class: "h-full flex flex-col"
    },
    qh = {
        key: 4,
        class: "h-full flex flex-col"
    },
    Uh = {
        class: "flex"
    },
    zh = {
        class: "price-item-content border-r border-solid bg-trade-border"
    },
    $h = {
        class: "flex justify-between items-center mb-2 px-4"
    },
    Zh = {
        class: "flex"
    },
    Gh = {
        class: "selectprice"
    },
    Yh = {
        class: "tif control"
    },
    Jh = {
        class: "mr-2",
        style: {
            float: "left"
        }
    },
    Kh = {
        class: "w-100"
    },
    Xh = {
        class: "flex justify-between price-grid thead"
    },
    Qh = {
        class: "price-item text-gray-darken"
    },
    ey = {
        class: "price-item text-gray-darken"
    },
    ty = {
        key: 0,
        class: "price-item text-gray-darken"
    },
    ny = ["onClick"],
    ry = {
        class: "price-item text-red-darken"
    },
    oy = {
        class: "price-item text-gray5"
    },
    iy = {
        key: 0,
        class: "text-white text-center text-sm"
    },
    ay = {
        class: "text-14 text-medium py-2 flex items-center justify-center priceclose"
    },
    sy = {
        class: "text-12 py-2 flex items-center urate"
    },
    ly = {
        class: "w-100"
    },
    cy = {
        class: "flex justify-between price-grid thead"
    },
    uy = {
        class: "price-item text-gray-darken"
    },
    dy = {
        key: 0,
        class: "price-item text-gray-darken"
    },
    py = ["onClick"],
    fy = {
        class: "price-item text-gray5"
    },
    my = {
        key: 0,
        class: "price-item text-green-darken"
    },
    hy = {
        key: 0,
        class: "text-white text-center text-sm"
    },
    yy = {
        class: "text-14 text-medium py-2 flex items-center justify-center priceclose"
    },
    gy = {
        class: "text-12 text-bold py-2 flex items-center urate"
    },
    vy = {
        class: "colored-text__rise"
    },
    by = {
        class: "bidaskbar"
    },
    xy = {
        class: "colored-text__fall"
    },
    wy = {
        id: "table-wrapper",
        class: "py-4 pr-3"
    },
    ky = {
        id: "table-scroll",
        class: "has-slimscroll"
    },
    Sy = {
        class: "text-white text-medium text-14 ml-4 mb-2"
    },
    Cy = {
        class: "w-100 price-order"
    },
    _y = {
        class: "flex justify-between price-grid time-grid"
    },
    Ty = {
        class: "price-item text-gray-darken"
    },
    Ay = {
        class: "price-item text-gray-darken"
    },
    Dy = {
        class: "price-item text-gray-darken"
    },
    Oy = {
        class: "price-item text-gray5"
    },
    Ey = {
        class: "price-item text-gray5"
    },
    Iy = {
        key: 0,
        class: "text-white text-center text-sm"
    },
    jy = {
        class: "inline-block px-2"
    },
    Ly = {
        class: "inline-block px-2"
    },
    Py = {
        key: 2,
        style: {
            height: "60px",
            width: "100%"
        }
    },
    My = {
        key: 5,
        class: "buy-sell-btn"
    },
    Ny = q(e({
        __name: "[slug]",
        setup(e) {
            c((() => {
                const e = document.createElement("style");
                e.type = "text/css", e.setAttribute("id", "unique-style-id"), e.innerHTML = ".intercom-lightweight-app { display: none; }", document.head.appendChild(e);
                const t = document.createElement("style");
                t.type = "text/css", t.setAttribute("id", "unique-style-id2"), t.innerHTML = ".intercom-namespace { display: none; }", document.head.appendChild(t)
            })), R((() => {
                const e = document.getElementById("unique-style-id");
                e && document.head.removeChild(e);
                const t = document.getElementById("unique-style-id2");
                t && document.head.removeChild(t)
            }));
            const {
                Api: n
            } = s(), {
                t: g,
                locale: v
            } = w(), b = x(), O = E(), L = P(), F = l("chart"), q = l("BTC/USDT"), U = l(null), z = l(null), $ = l(!1), Z = l(!1), G = l(!0), Y = l(!0), J = l(null), K = l(null), X = l(null), Q = l(null), ee = l(null);
            l(null);
            const ae = l(null),
                se = l(),
                ue = l(!1),
                de = l(!1),
                me = l(!1),
                he = W(),
                ye = l(window.innerWidth <= 767),
                ge = l(he.params.slug);
            ge.value && ge.value.includes("-") ? q.value = ge.value.replace("-", "/") : ge.value = "BTC-USDT";
            const ve = l(b.isAppOn),
                be = I(),
                xe = {
                    name: "",
                    symbol: q.value,
                    open: 0,
                    high: 0,
                    low: 0,
                    close: 0,
                    chg: 0,
                    change: 0,
                    volume: 0,
                    turnover: 0,
                    usdRate: 0,
                    zone: 0,
                    base: q.value.split("/")[1],
                    price: 0,
                    rose: "0.00%",
                    coin: q.value.split("/")[0],
                    href: "btc_usdt",
                    isFavor: !1
                },
                ke = T({
                    skin: "day",
                    plate: {
                        maxPostion: ye.value ? 7 : b.isPriceIndicator ? 9 : 10,
                        askTotle: 0,
                        bidTotle: 0,
                        askRows: [],
                        bidRows: []
                    },
                    currentCoin: xe,
                    coins: {
                        _map: [],
                        USDT: [],
                        BTC: [],
                        ETH: [],
                        favor: []
                    },
                    dataIndex: [],
                    coinInfo: [],
                    trade: {
                        rows: []
                    },
                    openOrders: {
                        pageSize: 10,
                        total: 1,
                        page: 0,
                        rows: []
                    },
                    triggerOrders: {
                        pageSize: 10,
                        total: 1,
                        page: 0,
                        rows: []
                    },
                    openHistory: {
                        pageSize: 10,
                        total: 1,
                        page: 1,
                        rows: []
                    },
                    fullTrade: {},
                    wallet: {
                        base: 0,
                        coin: 0
                    },
                    form: {
                        amount: Number(0).toFixed(2),
                        price: 0,
                        triggerPrice: 0
                    },
                    baseScale: 6,
                    quoteScale: 6,
                    name: "",
                    symbolFee: .001,
                    enableMarketBuy: !0,
                    enableMarketSell: !0,
                    enableTrading: !0,
                    publishAmount: 0,
                    publishPrice: 0,
                    priceorder: 0,
                    selectedPriceTab: 0,
                    selectedKlineTime: 0,
                    selectedHistoryTab: 0,
                    selectedPlate: "all",
                    currentCoinIsFavor: !1,
                    showPopover: !1
                }),
                Se = A((() => (ke.currentCoin.change > 0 ? "⮝ " : "⮟ ") + ke.currentCoin.low.toFixed(2) + " " + ke.currentCoin.symbol + " | OPZ Spot Trading"));
            ne({
                title: Se
            });
            const Ce = l([{
                    value: g("wall.open-orders")
                }, {
                    value: g("exh.trigger")
                }, {
                    value: g("wall.order-history")
                }, {
                    value: g("wall.trade-history")
                }]),
                _e = l(b.isPriceIndicator ? 9 : 10);
            k(b, (() => {
                b.isPriceIndicator ? _e.value = 9 : _e.value = 10, 0 == ke.priceorder && (b.isPriceIndicator ? ke.plate.maxPostion = 9 : ke.plate.maxPostion = 10)
            })), k(v, (() => {
                if (Pe.value) {
                    document.querySelector("#depth-chart").textContent = "", Me()
                }
                Ce.value[0].value = g("wall.open-orders"), Ce.value[1].value = g("exh.trigger"), Ce.value[2].value = g("wall.order-history"), Ce.value[3].value = g("wall.trade-history")
            }));
            const De = l(.01),
                Oe = [.01, .1, 1, 10, 100],
                Ee = e => {
                    let t = [];
                    if (ke.plate.maxPostion == _e.value && "" != e || 19 == ke.plate.maxPostion && "" == e) {
                        for (let n = 0; n < ("" != e ? 19 : _e.value); n++) t.push({
                            price: 0,
                            amount: 0
                        });
                        ke.plate.askRows = ke.plate.bidRows = t
                    }
                    ke.plate.maxPostion = "" != e ? 19 : _e.value
                };
            if (ve) {
                const e = e => {
                    var t, n;
                    (null == (n = null == (t = null == e ? void 0 : e.data) ? void 0 : t.toString()) ? void 0 : n.includes("*opztrade*")) && Ie(e.data.replace("-", "/").replace("*opztrade*", ""))
                };
                navigator.userAgent.includes("Android") ? document.addEventListener("message", e, !1) : window.addEventListener("message", e, !1)
            }
            async function Ie(e) {
                if (e) q.value = e, location.hash.replace("#", "").replace("-", "/");
                else {
                    const e = l(he.params.slug);
                    se.value.hide(), q.value = e.value.replace("-", "/")
                }
                ke.currentCoin = {
                    symbol: q.value,
                    open: 0,
                    high: 0,
                    low: 0,
                    close: 0,
                    chg: 0,
                    change: 0,
                    volume: 0,
                    turnover: 0,
                    usdRate: 0,
                    zone: 0,
                    base: q.value.split("/")[1],
                    price: 0,
                    rose: "0.00%",
                    coin: q.value.split("/")[0],
                    href: "btc_usdt",
                    isFavor: !1
                }, bt()
            }
            b.isAppOn && k((() => he.fullPath), Ie);
            const je = l([]),
                Le = l([]),
                Pe = l(),
                Me = () => {
                    Pe.value = Ep(document.querySelector("#depth-chart"), {
                        priceFix: 2,
                        amountFix: ke.baseScale,
                        lang: "en",
                        theme: "hb-night",
                        color: "#61688A",
                        tipColor: "#CAD7E0",
                        bgColor: "rgba(0, 0, 0, 0.8)",
                        bidsLineColor: "rgba(65, 179, 125, 1)",
                        asksLineColor: "rgba(215, 78, 90, 1)",
                        axisColor: "rgba(97, 104, 138, .3)",
                        langMap: {
                            en: {
                                price: g("exh.price"),
                                amount: g("exh.amount")
                            }
                        }
                    })
                },
                Ne = e => {
                    const t = new re;
                    t.append("orderIds", e), 1 == ke.selectedHistoryTab ? n.orderCancelMultipleTrigger(t).then((t => {
                        const n = t.data;
                        0 == n.code ? (L.success(g("inx.submitted-successfully")), Fe(String(e))) : L.error(n.message)
                    })) : n.orderCancelMultiple(t).then((t => {
                        const n = t.data;
                        0 == n.code ? (L.success(g("inx.submitted-successfully")), Fe(String(e))) : L.error(n.message)
                    }))
                },
                Fe = e => {
                    e && "0" != e && (1 == ke.selectedHistoryTab ? ke.triggerOrders.rows = ke.triggerOrders.rows.filter((t => t.orderId != e)) : ke.openOrders.rows = ke.openOrders.rows.filter((t => t.orderId != e)))
                },
                He = () => {
                    const e = ke.selectedHistoryTab,
                        t = ke.openOrders.rows.filter((t => (0 == e && 4 != t.status || 1 == e && 4 == t.status) && 0 != t.type)).map((e => e.orderId));
                    if (t.length > 0) {
                        (e => {
                            const t = new re;
                            t.append("orderIds", e), 1 == ke.selectedHistoryTab ? n.orderCancelMultipleTrigger(t).then((e => {
                                const t = e.data;
                                0 == t.code ? (L.success(g("inx.submitted-successfully")), Ye()) : L.error(t.message)
                            })) : n.orderCancelMultiple(t).then((e => {
                                const t = e.data;
                                0 == t.code ? (L.success(g("inx.submitted-successfully")), Ye()) : L.error(t.message)
                            }))
                        })(t.join(","))
                    }
                },
                qe = l([]),
                Ue = () => {
                    n.getFavor().then((e => {
                        ke.coins.favor = [], ke.currentCoinIsFavor = !1;
                        const t = e.data;
                        for (const n in t) {
                            let e = Je(t[n].symbol);
                            null != e && (e.isFavor = !0, ke.coins.favor.push(e)), ke.currentCoin.symbol == t[n].symbol && (ke.currentCoinIsFavor = !0)
                        }
                    }))
                },
                ze = e => {
                    1 == e.isFavor ? Ze(e) : 0 == e.isFavor && $e(e)
                },
                $e = e => {
                    if (!O.isLoggedIn) return void L.error(g("inx.please-login"));
                    const t = new re;
                    t.append("symbol", e.symbol), n.addFavor(t).then((t => {
                        0 == t.data.code && (L.info(g("sett.key-successfully-added")), Je(e.symbol).isFavor = !0, e.isFavor = !0, ke.coins.favor.push(e), ke.currentCoin.symbol == e.symbol && (ke.currentCoinIsFavor = !0))
                    }))
                },
                Ze = e => {
                    if (!O.isLoggedIn) return void L.error(g("inx.please-login"));
                    const t = new re;
                    t.append("symbol", e.symbol), n.deleteFavor(t).then((t => {
                        if (0 == t.data.code) {
                            L.info(g("sett.successfully-off")), Je(e.symbol).isFavor = !1;
                            for (let t = 0; t < ke.coins.favor.length; t++) {
                                if (ke.coins.favor[t].symbol == e.symbol) {
                                    ke.coins.favor.splice(t, 1);
                                    break
                                }
                            }
                            ke.currentCoin.symbol == e.symbol && (ke.currentCoinIsFavor = !1)
                        }
                    }))
                },
                Ye = e => {
                    O.isLoggedIn && (() => {
                        Y.value = !0;
                        const e = new re;
                        e.append("pageNo", "1"), e.append("pageSize", "100"), Z.value || e.append("symbol", ke.currentCoin.symbol), ke.openOrders.rows = [], n.getOpenOrders(e).then((e => {
                            const t = e.data;
                            t.content && t.content.length > 0 && (ke.openOrders.rows = t.content.filter((e => 4 != e.status)), ke.triggerOrders.rows = t.content.filter((e => 2 == e.type && 4 == e.status)), Z.value) && t.content.filter((e => e.symbol != ke.currentCoin.symbol && !qe.value.includes(e.symbol))).forEach((function(e) {
                                dt(e.symbol), qe.value.push(e.symbol)
                            })), Y.value = !1
                        }))
                    })()
                },
                Je = e => ke.coins._map[e],
                Ke = () => {
                    J.value.classList.remove("button-gradient"), K.value.classList.remove("button-gradient"), X.value.classList.remove("button-gradient"), ae.value.classList.remove("button-gradient")
                },
                Xe = () => {
                    0 != ke.priceorder && (Ee(""), ke.priceorder = 0, Ke(), J.value.classList.add("button-gradient"))
                },
                Qe = () => {
                    1 != ke.priceorder && (Ee("all"), ke.priceorder = 1, Ke(), K.value.classList.add("button-gradient"))
                },
                et = () => {
                    2 != ke.priceorder && (Ee("buy"), ke.priceorder = 2, Ke(), X.value.classList.add("button-gradient"))
                },
                tt = () => {
                    3 != ke.priceorder && (Ee("sell"), ke.priceorder = 3, Ke(), ae.value.classList.add("button-gradient"))
                },
                nt = l(20);
            k(he, (e => {
                e.query.eth && (xe.symbol = "ETH/USDT", xe.base = "USDT", xe.coin = "ETH", rt(xe)), e.query.btc && (xe.symbol = "BTC/USDT", xe.base = "USDT", xe.coin = "BTC", rt(xe))
            }));
            const rt = e => {
                    se.value && se.value.hide(), e.symbol != ke.currentCoin.symbol && (be.push({
                        name: "trade-slug",
                        params: {
                            slug: e.symbol.replace("/", "-")
                        }
                    }), ke.currentCoin = e, q.value = e.symbol, bt())
                },
                it = (e, t) => {},
                at = (e, t) => {
                    var n = {};
                    return e.forEach((function(e) {
                        var r = t(e.price);
                        n[r] = (n[r] || []).concat(e)
                    })), Object.keys(n).map((function(e) {
                        return n[e]
                    }))
                },
                st = e => {
                    if ("SELL" == e.direction) {
                        let t = e.items;
                        ke.plate.askRows = [];
                        let n = 0;
                        if (.01 != De.value) {
                            const e = De.value,
                                n = at(t, (function(t) {
                                    return Math.floor(t / e)
                                }));
                            for (let t = 0; t < n.length && !(t >= ke.plate.maxPostion); t++) {
                                let r = {
                                    direction: "SELL",
                                    position: t + 1,
                                    price: Math.floor(n[t][0].price / e) * e + e,
                                    amount: 0,
                                    totalAmount: 0
                                };
                                for (let e = 0; e < n[t].length; e++) r.amount = r.amount + n[t][e].amount;
                                r.amount > 0 && ke.plate.askRows.push(r)
                            }
                            if (n.length < ke.plate.maxPostion)
                                for (let t = 0; t < ke.plate.maxPostion - n.length; t++) {
                                    let e = {
                                        direction: "SELL",
                                        position: n.length + t,
                                        price: 0,
                                        amount: 0,
                                        totalAmount: 0
                                    };
                                    ke.plate.askRows.push(e)
                                }
                            ke.plate.askRows.reverse()
                        } else
                            for (let e = ke.plate.maxPostion - 1; e >= 0; e--) {
                                let n = {
                                    direction: "",
                                    position: 0,
                                    price: 0,
                                    amount: 0,
                                    totalAmount: 0
                                };
                                e < t.length && (n = t[e]), n.direction = "SELL", n.position = e + 1, ke.plate.askRows.push(n)
                            }
                        for (let e = ke.plate.askRows.length - 1; e >= 0; e--) e == ke.plate.askRows.length - 1 || 0 == ke.plate.askRows[e].price ? ke.plate.askRows[e].totalAmount = ke.plate.askRows[e].amount : ke.plate.askRows[e].totalAmount = ke.plate.askRows[e + 1].totalAmount + ke.plate.askRows[e].amount, n += ke.plate.askRows[e].amount;
                        1 == ke.priceorder && ke.plate.askRows.reverse(), ke.plate.askTotle = n
                    } else {
                        let t = e.items;
                        ke.plate.bidRows = [];
                        let n = 0;
                        if (.01 != De.value) {
                            const e = De.value,
                                n = at(t, (function(t) {
                                    return Math.floor(t / e)
                                })).reverse();
                            for (let t = 0; t < n.length && !(t >= ke.plate.maxPostion); t++) {
                                let r = {
                                    direction: "BUY",
                                    position: t + 1,
                                    price: Math.floor(n[t][0].price / e) * e,
                                    amount: 0,
                                    totalAmount: 0
                                };
                                for (let e = 0; e < n[t].length; e++) r.amount = r.amount + n[t][e].amount;
                                r.amount > 0 && ke.plate.bidRows.push(r)
                            }
                            if (n.length < ke.plate.maxPostion)
                                for (let t = 0; t < ke.plate.maxPostion - n.length; t++) {
                                    let e = {
                                        direction: "BUY",
                                        position: n.length + t,
                                        price: 0,
                                        amount: 0,
                                        totalAmount: 0
                                    };
                                    ke.plate.bidRows.push(e)
                                }
                        } else
                            for (let e = 0; e < ke.plate.maxPostion; e++) {
                                let n = {
                                    direction: "",
                                    position: 0,
                                    price: 0,
                                    amount: 0,
                                    totalAmount: 0
                                };
                                e < t.length && (n = t[e]), n.direction = "BUY", n.position = e + 1, ke.plate.bidRows.push(n)
                            }
                        for (let e = 0; e < ke.plate.bidRows.length; e++) 0 == e || 0 == ke.plate.bidRows[e].amount ? ke.plate.bidRows[e].totalAmount = ke.plate.bidRows[e].amount : ke.plate.bidRows[e].totalAmount = ke.plate.bidRows[e - 1].totalAmount + ke.plate.bidRows[e].amount, n += ke.plate.bidRows[e].amount;
                        ke.plate.bidTotle = n
                    }
                },
                lt = l(""),
                ct = l(""),
                ut = console,
                dt = e => {
                    z.value.subscribe("/topic/market/order-canceled/" + e + "/" + O.userData.id, (e => {
                        let t = JSON.parse(e.body);
                        t.status && 5 == t.status ? L.error(g("exh.order-failed")) : t.status && 1 == t.status && L.success(g("exh.order-partially-filled")), Fe(t.orderId), ke.openOrders.rows, ue.value = !ue.value
                    })), z.value.subscribe("/topic/market/order-completed/" + e + "/" + O.userData.id, (e => {
                        JSON.parse(e.body), Ye()
                    })), z.value.subscribe("/topic/market/order-trade/" + e + "/" + O.userData.id, (e => {
                        JSON.parse(e.body), Ye()
                    }))
                },
                pt = e => {
                    e && "" != ct.value ? (z.value.unsubscribe(ct.value), ct.value = "", z.value.subscribe("/topic/market/trade-depth/" + ke.currentCoin.symbol, (e => {
                        lt.value = e.headers.subscription;
                        let t = JSON.parse(e.body);
                        if (Q.value.depths) {
                            "SELL" == t.direction ? Le.value = t.items : je.value = t.items;
                            let e = {
                                asks: Le.value.map((e => Object.values(e))),
                                bids: je.value.map((e => Object.values(e))),
                                version: Date.now()
                            };
                            e.asks.length > 2 && e.bids.length > 2 && Pe.value.putData(e)
                        }
                        st(t)
                    }))) : e || "" == lt.value || (z.value.unsubscribe(lt.value), lt.value = "", z.value.subscribe("/topic/market/trade-plate/" + ke.currentCoin.symbol, (e => {
                        ct.value = e.headers.subscription;
                        let t = JSON.parse(e.body);
                        st(t)
                    })))
                };
            let ft;
            const mt = l(!1),
                ht = e => {
                    mt.value || (mt.value = !0, Me(), window.addEventListener("resize", oe.throttle((() => {
                        document.querySelector("#depth-chart").textContent = "", Me()
                    }), 500))), Q.value.depths = e, 1 != e && .01 != De.value || pt(1 == e)
                },
                yt = l(50),
                gt = l(50),
                vt = l(0);
            M((() => {
                const {
                    askRows: e,
                    bidRows: t
                } = ke.plate;
                e.length > 0 && t.length > 0 && vt.value + 3e3 < (new Date).getTime() && (((e, t) => {
                    const n = (t[0].price + e[e.length - 1].price) / 2,
                        r = ke.plate.bidTotle,
                        o = ke.plate.askTotle;
                    let i = 0,
                        a = 0;
                    for (let s = 0; s < t.length; s++) {
                        const e = t[s];
                        if (0 !== e.price) {
                            const t = Math.abs(n - e.price);
                            i += e.amount / r * r * t
                        }
                    }
                    for (let s = 0; s < e.length; s++) {
                        const t = e[s];
                        if (0 !== t.price) {
                            const e = Math.abs(n - t.price);
                            a += t.amount / o * o * e
                        }
                    }
                    yt.value = i / (a + i) * 100 || 50, gt.value = a / (a + i) * 100 || 50
                })(e, t), vt.value = (new Date).getTime())
            }));
            const bt = () => {
                var e;
                n.getSymbolInfo(ke.currentCoin.symbol).then((e => {
                    let t = e.data;
                    null != t && (ke.quoteScale = t.quoteScale, ke.baseScale = t.baseScale, ke.name = t.name, ke.symbolFee = t.fee, ke.enableMarketBuy = t.enableMarketBuy, ke.enableMarketSell = t.enableMarketSell, ke.enableTrading = t.enableTrading)
                })), n.getSymbol().then((e => {
                    let t = e.data;
                    for (let n in t) t[n].base = t[n].symbol.split("/")[1], ke.coins._map = [], ke.coins.favor = [], ke.coins.USDT = [], ke.coins.BTC = [], ke.coins.ETH = [];
                    for (let n in t) {
                        let e = t[n];
                        e.price = t[n].close = Number(t[n].close.toFixed(ke.quoteScale)), e.rose = t[n].chg > 0 ? "+" + (100 * t[n].chg).toFixed(2) + "%" : (100 * t[n].chg).toFixed(2) + "%", e.coin = t[n].symbol.split("/")[0], e.base = t[n].symbol.split("/")[1], e.icon = "/images/icons/coin/" + e.coin.toLowerCase() + ".svg", e.href = (e.coin + "_" + e.base).toLowerCase(), ke.coins._map[e.symbol] = e, ke.coins[e.base].push(e), e.symbol == ke.currentCoin.symbol && (ke.currentCoin = e, ke.form.price = e.price)
                    }
                    O.isLoggedIn && Ue()
                })), ((e = "") => {
                    n.getPlate(ke.currentCoin.symbol).then((t => {
                        var n;
                        ke.plate.askRows = [], ke.plate.bidRows = [];
                        let r = t.data;
                        if (r.ask && r.ask.items) {
                            for (let e = 0; e < r.ask.items.length; e++) r.ask.items[e].totalAmount = 0 == e ? r.ask.items[e].amount : r.ask.items[e - 1].totalAmount + r.ask.items[e].amount;
                            if (r.ask.items.length >= ke.plate.maxPostion) {
                                for (let n = ke.plate.maxPostion; n > 0; n--) {
                                    let e = r.ask.items[n - 1];
                                    e.direction = "SELL", e.position = n, ke.plate.askRows.push(e)
                                }
                                const e = ke.plate.askRows;
                                e.length;
                                const t = e[0].totalAmount;
                                ke.plate.askTotle = t
                            } else {
                                let e;
                                if (1 != ke.priceorder) {
                                    for (let e = ke.plate.maxPostion; e > r.ask.items.length; e--) {
                                        let t = {
                                            price: 0,
                                            amount: 0,
                                            direction: "SELL",
                                            position: e,
                                            totalAmount: 0
                                        };
                                        t.totalAmount = t.amount, ke.plate.askRows.push(t)
                                    }
                                    for (let e = r.ask.items.length; e > 0; e--) {
                                        let t = r.ask.items[e - 1];
                                        t.direction = "SELL", t.position = e, ke.plate.askRows.push(t)
                                    }
                                    e = r.ask.items.length - 1 > 0 ? ke.plate.maxPostion - r.ask.items.length : ke.plate.maxPostion
                                } else {
                                    for (let e = 0; e < r.ask.items.length; e++) {
                                        let t = r.ask.items[e];
                                        if (t.direction = "SELL", t.position = e + 1, ke.plate.askRows.push(t), e == ke.plate.maxPostion - 1) break
                                    }
                                    for (let e = ke.plate.maxPostion; e > r.ask.items.length; e--) {
                                        let t = {
                                            price: 0,
                                            amount: 0,
                                            direction: "SELL",
                                            position: e,
                                            totalAmount: 0
                                        };
                                        t.totalAmount = t.amount, ke.plate.askRows.push(t)
                                    }
                                    e = r.ask.items.length - 1 > 0 ? r.ask.items.length - 1 : 0
                                }
                                const t = ke.plate.askRows;
                                t.length;
                                const o = null == (n = t[e]) ? void 0 : n.totalAmount;
                                ke.plate.askTotle = o
                            }
                            ke.priceorder
                        }
                        if (r.bid && r.bid.items) {
                            for (let e = 0; e < r.bid.items.length; e++) r.bid.items[e].totalAmount = 0 == e ? r.bid.items[e].amount : r.bid.items[e - 1].totalAmount + r.bid.items[e].amount;
                            for (let e = 0; e < r.bid.items.length; e++) {
                                let t = r.bid.items[e];
                                if (t.direction = "BUY", t.position = e + 1, ke.plate.bidRows.push(t), e == ke.plate.maxPostion - 1) break
                            }
                            if (r.bid.items.length < ke.plate.maxPostion) {
                                for (let o = r.bid.items.length; o < ke.plate.maxPostion; o++) {
                                    let e = {
                                        price: 0,
                                        amount: 0,
                                        direction: "BUY",
                                        position: o + 1,
                                        totalAmount: 0
                                    };
                                    ke.plate.bidRows.push(e)
                                }
                                let e = r.bid.items.length - 1 > 0 ? r.bid.items.length - 1 : 0;
                                const t = ke.plate.bidRows;
                                t.length;
                                const n = t[e].totalAmount;
                                ke.plate.bidTotle = n
                            } else {
                                const e = ke.plate.bidRows,
                                    t = e[e.length - 1].totalAmount;
                                ke.plate.bidTotle = t
                            }
                        }
                        "" != e && (ke.selectedPlate = e)
                    }))
                })(), n.getTrade(ke.currentCoin.symbol, 20).then((e => {
                    ke.trade.rows = [];
                    let t = e.data;
                    if (t && (null == t ? void 0 : t.length))
                        for (let n in t) ke.trade.rows.push(t[n])
                })), Ye(), e = n.wsMarket, z.value && z.value.deactivate(), z.value = null, z.value = new V({
                    brokerURL: e,
                    logRawCommunication: !1,
                    webSocketFactory: () => B(e),
                    onStompError: e => {
                        n.isDev && ut.log("Stomp Error", e)
                    },
                    onConnect: e => {
                        n.isDev && ut.log("Stomp Connect", e), U.value = new Np(n.wsMarket, ke.currentCoin, z.value, ke.quoteScale), de.value && Q.value.setSymbol(ke.currentCoin.symbol), de.value = !0, z.value.subscribe("/topic/market/thumb", (e => {
                            let t = JSON.parse(e.body),
                                n = Je(t.symbol);
                            null != n && (n.price = t.close, n.rose = t.chg > 0 ? "+" + (100 * t.chg).toFixed(2) + "%" : (100 * t.chg).toFixed(2) + "%", n.close = t.close, n.high = t.high, n.low = t.low, n.turnover = parseInt(t.volume), n.volume = t.volume, n.usdRate = t.usdRate)
                        })), z.value.subscribe("/topic/market/trade/" + ke.currentCoin.symbol, (e => {
                            let t = JSON.parse(e.body);
                            if (t.length > 0)
                                for (let n in t) ke.trade.rows.unshift(t[n]);
                            ke.trade.rows.length > 30 && (ke.trade.rows = ke.trade.rows.slice(0, 30))
                        })), z.value.subscribe("/topic/market/trade-plate/" + ke.currentCoin.symbol, (e => {
                            ct.value = e.headers.subscription;
                            let t = JSON.parse(e.body);
                            st(t)
                        })), O.isLoggedIn && dt(ke.currentCoin.symbol)
                    },
                    onDisconnect: e => {
                        n.isDev && ut.log("Stomp Disconnect", e)
                    },
                    onWebSocketClose: e => {
                        n.isDev && ut.log("Stomp WebSocket Closed", e)
                    },
                    onWebSocketError: e => {
                        n.isDev && ut.log("Stomp WebSocket Error", e)
                    }
                }), z.value.activate()
            };
            return c((async () => {
                ft = oe.throttle((() => {
                    ye.value = window.innerWidth <= 767, 19 != ke.plate.maxPostion && (ke.plate.maxPostion = ye.value ? 7 : 9), _e.value = ke.plate.maxPostion
                }), 100), window.addEventListener("resize", ft), bt()
            })), D((() => {
                window.removeEventListener("resize", ft), z.value && (z.value.deactivate(), z.value = null)
            })), (e, n) => {
                const s = te,
                    l = zl,
                    c = j("RouterLink"),
                    v = ot,
                    x = Ge,
                    w = H,
                    k = Be;
                return o(), t("div", null, [u(k, {
                    theme: "light"
                }, {
                    default: d((() => {
                        var e, k, T;
                        return [ve.value ? y("", !0) : (o(), h(s, {
                            key: 0,
                            style: {
                                background: "var(--bg-trade)"
                            },
                            full: !0
                        })), i("div", {
                            class: r(["landing-page-wrapper", ve.value && "is-app"])
                        }, [i("div", {
                            class: r(["bg-trade root", ye.value && "mobile"])
                        }, [ye.value ? (o(), t("div", wh, [i("div", kh, [u(Xd, {
                            scoins: ke.coins,
                            name: ke.name,
                            "current-coin": ke.currentCoin,
                            onEnableDetails: n[3] || (n[3] = e => me.value = !0),
                            onSelectCoin: n[4] || (n[4] = e => rt(e)),
                            onOnFavor: n[5] || (n[5] = e => ze(e))
                        }, null, 8, ["scoins", "name", "current-coin"])])])) : (o(), t("div", bh, [i("div", xh, [u(Dp, {
                            scoins: ke.coins,
                            name: ke.name,
                            "current-coin": ke.currentCoin,
                            onEnableDetails: n[0] || (n[0] = e => me.value = !0),
                            onSelectCoin: n[1] || (n[1] = e => rt(e)),
                            onOnFavor: n[2] || (n[2] = e => ze(e))
                        }, null, 8, ["scoins", "name", "current-coin"])])])), ye.value ? (o(), t("div", Sh, [u(m(ce), {
                            modelValue: F.value,
                            "onUpdate:modelValue": n[6] || (n[6] = e => F.value = e),
                            "tab-position": "top",
                            class: "mobile-trade-tabs"
                        }, {
                            default: d((() => [u(m(le), {
                                label: "Chart",
                                name: "chart"
                            }), u(m(le), {
                                label: "AI",
                                name: "ai"
                            }), u(m(le), {
                                label: "Order Book",
                                name: "orderbook"
                            }), u(m(le), {
                                label: "Trades",
                                name: "trades"
                            })])),
                            _: 1
                        }, 8, ["modelValue"])])) : y("", !0), S(i("div", Ch, [i("div", {
                            class: r(["flex md:flex-row", !ye.value || ye.value && "chart" == F.value ? "flex-col" : "flex-col-rev"])
                        }, [i("div", {
                            class: r(["flex items-center", ye.value ? "pl-0 ml-0 pb-1" : "pt-2 pb-2"])
                        }, [u(vh, {
                            currentCoin: ke.currentCoin,
                            isMobileWidth: ye.value,
                            maxItems: 5
                        }, null, 8, ["currentCoin", "isMobileWidth"])], 2)], 2)], 512), [
                            [N, m(b).isTradeAiMode]
                        ]), S(i("div", _h, [i("div", {
                            class: r(["flex md:flex-row", !ye.value || ye.value && "chart" == F.value ? "flex-col" : "flex-col-rev"])
                        }, [i("div", Th, [S(i("div", {
                            class: r([!ye.value && "p-3", "chart-graph area-height border-b border-solid bg-trade-border"])
                        }, [i("div", {
                            class: r(["flex justify-end", 1 == (null == (e = Q.value) ? void 0 : e.depths) ? "opacity-1" : "opacity-0"])
                        }, [i("button", {
                            class: "btn-chart",
                            onClick: n[7] || (n[7] = () => ht(0))
                        }, f(m(g)("exh.chart") + " "), 1)], 2), i("div", Ah, [de.value ? (o(), h(l, {
                            key: 0,
                            id: "kline_container",
                            ref_key: "kLineRef",
                            ref: Q,
                            class: r(1 == (null == (k = Q.value) ? void 0 : k.depths) ? "opacity-0" : "opacity-1"),
                            basep: ke.quoteScale,
                            pricep: ke.baseScale,
                            "symbol-info": [],
                            "stomp-client": z.value,
                            mobileWidth: ye.value,
                            symbol: ke.currentCoin.symbol.toLocaleUpperCase(),
                            onDepth: n[8] || (n[8] = e => ht(1))
                        }, null, 8, ["class", "basep", "pricep", "stomp-client", "mobileWidth", "symbol"])) : y("", !0), i("div", {
                            id: "depth-chart",
                            class: r(1 == (null == (T = Q.value) ? void 0 : T.depths) ? "opacity-1" : "opacity-0")
                        }, null, 2)])], 2), [
                            [N, !ye.value || ye.value && "chart" == F.value]
                        ]), i("div", Dh, [i("div", Oh, [i("div", Eh, [i("div", Ih, [i("div", jh, [u(m(ce), {
                            "tab-position": "top",
                            class: "demo-tabs"
                        }, {
                            default: d((() => [(o(!0), t(_, null, C(Ce.value, ((e, n) => (o(), h(m(le), {
                                disabled: Y.value,
                                key: n
                            }, {
                                label: d((() => [i("div", Lh, [i("div", {
                                    class: "tab",
                                    onClick: e => (e => {
                                        switch (ke.selectedHistoryTab = e, e) {
                                            case 0:
                                            case 3:
                                            default:
                                                nt.value = 20;
                                                break;
                                            case 1:
                                                nt.value = 130;
                                                break;
                                            case 2:
                                                nt.value = 220
                                        }
                                    })(n)
                                }, [a(f(e.value) + " ", 1), 0 == n ? (o(), t("span", Mh, f(ke.openOrders.rows.length), 1)) : y("", !0), 1 == n ? (o(), t("span", Nh, f(ke.triggerOrders.rows.length), 1)) : y("", !0)], 8, Ph)])])),
                                _: 2
                            }, 1032, ["disabled"])))), 128))])),
                            _: 1
                        }), ye.value || 0 != ke.selectedHistoryTab && 1 != ke.selectedHistoryTab ? ve.value || ye.value && 0 == ke.selectedHistoryTab ? y("", !0) : (o(), h(c, {
                            key: 1,
                            class: "checkShowAll",
                            router: "",
                            style: {
                                "font-size": "12px",
                                border: "0"
                            },
                            tar: "",
                            to: {
                                name: "user-center-dashboard-orders"
                            },
                            target: "_blank"
                        }, {
                            default: d((() => [a(f(m(g)("dash.show-all")), 1)])),
                            _: 1
                        })) : (o(), h(m(pe), {
                            key: 0,
                            modelValue: Z.value,
                            "onUpdate:modelValue": n[9] || (n[9] = e => Z.value = e),
                            class: "checkShowAll",
                            onChange: Ye,
                            label: m(g)("dash.show-all") + " " + m(g)("exh.pairs"),
                            size: "small"
                        }, null, 8, ["modelValue", "label"]))])]), m(O).isLoggedIn ? (o(), t("div", Wh, [!ye.value || 0 != ke.selectedHistoryTab && 1 != ke.selectedHistoryTab ? y("", !0) : (o(), t("div", Vh, [u(m(pe), {
                            modelValue: Z.value,
                            "onUpdate:modelValue": n[12] || (n[12] = e => Z.value = e),
                            class: "checkShowAll",
                            onChange: Ye,
                            label: m(g)("dash.show-all") + " " + m(g)("exh.pairs"),
                            size: "small"
                        }, null, 8, ["modelValue", "label"]), ke.openOrders.rows.length > 0 && m(b).isCancelAll ? (o(), h(m(fe), {
                            key: 0,
                            width: 200,
                            "confirm-button-text": m(g)("sett.yes"),
                            "cancel-button-text": m(g)("sett.no"),
                            "icon-color": "red",
                            title: m(g)("exh.cancel-all-orders-sure"),
                            onConfirm: He
                        }, {
                            reference: d((() => [i("span", Bh, f(m(g)("wall.cancel-all")), 1)])),
                            _: 1
                        }, 8, ["confirm-button-text", "cancel-button-text", "title"])) : y("", !0)])), 0 == ke.selectedHistoryTab ? (o(), t("div", {
                            key: 1,
                            class: r(["h-full flex items-center justify-center scrollPane", ye.value && "flex-col"])
                        }, [u(Hc, {
                            modelValue: Y.value,
                            "onUpdate:modelValue": n[13] || (n[13] = e => Y.value = e),
                            rows: ke.openOrders.rows,
                            trigger: !1,
                            "mobile-width": ye.value,
                            "base-scale": ke.baseScale,
                            onOrderCancel: Ne,
                            onCancelAll: He
                        }, null, 8, ["modelValue", "rows", "mobile-width", "base-scale"])], 2)) : y("", !0), 1 == ke.selectedHistoryTab ? (o(), t("div", {
                            key: 2,
                            class: r(["h-full flex items-center justify-center scrollPane", ye.value && "flex-col"])
                        }, [u(Hc, {
                            modelValue: Y.value,
                            "onUpdate:modelValue": n[14] || (n[14] = e => Y.value = e),
                            rows: ke.triggerOrders.rows,
                            trigger: !0,
                            "mobile-width": ye.value,
                            "base-scale": ke.baseScale,
                            onOrderCancel: Ne,
                            onCancelAll: He
                        }, null, 8, ["modelValue", "rows", "mobile-width", "base-scale"])], 2)) : y("", !0), 2 == ke.selectedHistoryTab ? (o(), t("div", Hh, [u(Du, {
                            "mobile-width": ye.value,
                            symbol: ke.currentCoin.symbol,
                            "base-scale": ke.baseScale
                        }, null, 8, ["mobile-width", "symbol", "base-scale"])])) : y("", !0), 3 == ke.selectedHistoryTab ? (o(), t("div", qh, [u(ed, {
                            "mobile-width": ye.value,
                            symbol: ke.currentCoin.symbol,
                            "base-scale": ke.baseScale
                        }, null, 8, ["mobile-width", "symbol", "base-scale"])])) : y("", !0)])) : (o(), t("div", Fh, [u(m(Ve), {
                            onClick: n[10] || (n[10] = e => m(be).push({
                                name: "auth",
                                query: {
                                    redirect: "/trade"
                                }
                            }))
                        }, {
                            default: d((() => [a(f(m(g)("auth.log-in")), 1)])),
                            _: 1
                        }), i("span", Rh, f(m(g)("exh.or")), 1), u(m(Ve), {
                            onClick: n[11] || (n[11] = e => m(be).push({
                                name: "register",
                                query: {
                                    redirect: "/trade"
                                }
                            }))
                        }, {
                            default: d((() => [a(f(m(g)("auth.register-now")), 1)])),
                            _: 1
                        })]))])])])]), i("div", Uh, [i("div", zh, [S(i("div", {
                            id: "ptable",
                            class: r(["area-height pt-4 border-b border-solid bg-trade-border price-order", 0 != ke.priceorder || m(b).isPriceIndicator ? "pb-4" : "pb-0"])
                        }, [i("div", $h, [i("div", Zh, [u(m(Ae), {
                            class: "box-item",
                            effect: "customized",
                            content: "Order Book",
                            placement: "top",
                            "show-after": 200
                        }, {
                            default: d((() => [i("div", {
                                class: "orders-book orders-default",
                                onClick: Xe,
                                onKeydown: Xe
                            }, n[23] || (n[23] = [i("div", {
                                class: "orders-book-sh"
                            }, null, -1)]), 32)])),
                            _: 1
                        }), u(m(Ae), {
                            class: "box-item",
                            "show-after": 200,
                            effect: "customized",
                            content: "Order Book Split",
                            placement: "top"
                        }, {
                            default: d((() => [i("div", {
                                class: "orders-book orders-rev",
                                onClick: Qe,
                                onKeydown: Qe
                            }, n[24] || (n[24] = [i("div", {
                                class: "orders-book-sh"
                            }, null, -1)]), 32)])),
                            _: 1
                        }), u(m(Ae), {
                            class: "box-item",
                            effect: "customized",
                            "show-after": 200,
                            content: "Buy Orders",
                            placement: "top"
                        }, {
                            default: d((() => [i("div", {
                                class: "orders-book orders-buy",
                                onClick: et,
                                onKeydown: et
                            }, n[25] || (n[25] = [i("div", {
                                class: "orders-book-sh"
                            }, null, -1)]), 32)])),
                            _: 1
                        }), u(m(Ae), {
                            class: "box-item",
                            effect: "customized",
                            "show-after": 200,
                            content: "Sell Orders",
                            placement: "top"
                        }, {
                            default: d((() => [i("div", {
                                class: "orders-book orders-sell",
                                onClick: tt,
                                onKeydown: tt
                            }, n[26] || (n[26] = [i("div", {
                                class: "orders-book-sh"
                            }, null, -1)]), 32)])),
                            _: 1
                        })]), i("div", Gh, [i("div", Yh, [u(m(We), {
                            modelValue: De.value,
                            "onUpdate:modelValue": n[15] || (n[15] = e => De.value = e),
                            "suffix-icon": "",
                            class: "m-2",
                            placeholder: "Select",
                            size: "small",
                            onChange: n[16] || (n[16] = e => {
                                Q.value.depths || pt(.01 != De.value)
                            })
                        }, {
                            default: d((() => [(o(), t(_, null, C(Oe, (e => u(m(Re), {
                                key: e,
                                value: e
                            }, {
                                default: d((() => [i("span", Jh, f(e), 1)])),
                                _: 2
                            }, 1032, ["value"]))), 64))])),
                            _: 1
                        }, 8, ["modelValue"])])])]), i("div", {
                            class: r(0 != ke.priceorder ? "flex-column" : "")
                        }, [i("div", {
                            class: r(1 == ke.priceorder ? "flex" : 3 == ke.priceorder ? "flex flex-col" : "")
                        }, [2 != ke.priceorder ? (o(), t("div", {
                            key: 0,
                            class: r(1 == ke.priceorder ? "w-1/2" : "")
                        }, [i("div", Kh, [i("div", Xh, [i("div", Qh, f(m(g)("exh.price")), 1), i("div", ey, f(m(g)("exh.amount")), 1), 1 != ke.priceorder ? (o(), t("div", ty, f(m(g)("exh.total")), 1)) : y("", !0)]), i("div", null, [(o(!0), t(_, null, C(ke.plate.askRows, ((e, n) => S((o(), t("div", {
                            key: n,
                            class: "flex justify-between price-grid",
                            style: p(1 == ke.priceorder ? "background-image: linear-gradient(to left, rgba(224, 64, 64, 0.10), rgba(224, 64, 64, 0.06) " + 100 * (e.totalAmount / ke.plate.askTotle).toFixed(4) + "%, rgba(0, 0, 0, 0) 5%)" : ""),
                            onClick: t => ke.form.price = e.price
                        }, [i("div", ry, f(0 == e.price ? "--" : e.price.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 1), i("div", oy, f(0 == e.amount ? "--" : e.amount.toFixed(ke.baseScale)), 1), 1 != ke.priceorder ? (o(), t("div", {
                            key: 0,
                            class: "price-item text-gray5",
                            style: p("background-image: linear-gradient(to right, rgba(224, 64, 64, 0.10), rgba(224, 64, 64, 0.06) " + 100 * (e.totalAmount / ke.plate.askTotle).toFixed(4) + "%, rgba(0, 0, 0, 0) 5%)")
                        }, f(0 == e.amount || 0 == e.totalAmount ? "--" : e.totalAmount.toFixed(ke.baseScale)), 5)) : y("", !0)], 12, ny)), [
                            [N, "buy" != ke.selectedPlate]
                        ]))), 128))])]), "" == ke.plate.askRows ? (o(), t("p", iy, f(m(g)("exh.no-records-found")), 1)) : y("", !0)], 2)) : y("", !0), 1 != ke.priceorder ? (o(), t("div", {
                            key: 1,
                            class: r(["flex pricet1", 0 != ke.priceorder ? "my-2" : ""])
                        }, [i("div", ay, [i("span", {
                            class: r(["mb-0 close", ke.currentCoin.change > 0 ? "text-green-darken" : "text-red-darken"])
                        }, f(ke.currentCoin.close.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 3), i("span", {
                            class: r(["arrow", ke.currentCoin.change > 0 ? "text-green-darken" : "text-red-darken"]),
                            style: p([ke.currentCoin.change < 0 ? {} : {
                                transform: "rotate(180deg)"
                            }])
                        }, n[27] || (n[27] = [i("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 25 25",
                            class: "arrow-icon status-buy css-3kwgah"
                        }, [i("path", {
                            d: "M5 13.5l1.41-1.41 5.1 5.1V3h1.99v14.15l5.09-5.09L20 14l-7.5 7.5-7.5-7.5z",
                            fill: "currentColor"
                        })], -1)]), 6)]), i("div", sy, " $" + f(ke.currentCoin.usdRate.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 1)], 2)) : y("", !0), 3 != ke.priceorder ? (o(), t("div", {
                            key: 2,
                            class: r(1 == ke.priceorder ? "w-1/2" : "")
                        }, [i("div", ly, [S(i("div", cy, [S(i("div", {
                            class: "price-item text-gray-darken"
                        }, f(m(g)("exh.price")), 513), [
                            [N, 1 != ke.priceorder]
                        ]), i("div", uy, f(m(g)("exh.amount")), 1), S(i("div", {
                            class: "price-item text-gray-darken"
                        }, f(m(g)("exh.price")), 513), [
                            [N, 1 == ke.priceorder]
                        ]), 1 != ke.priceorder ? (o(), t("div", dy, f(m(g)("exh.total")), 1)) : y("", !0)], 512), [
                            [N, 2 == ke.priceorder || 1 == ke.priceorder]
                        ]), i("div", null, [(o(!0), t(_, null, C(ke.plate.bidRows, ((e, n) => S((o(), t("div", {
                            key: n,
                            class: "flex justify-between price-grid",
                            style: p(1 == ke.priceorder ? "background-image: linear-gradient(to right, rgba(36, 174, 100, 0.10), rgba(36, 174, 100, 0.06) " + 100 * (e.totalAmount / ke.plate.bidTotle).toFixed(4) + "%, rgba(0, 0, 0, 0) 5%)" : ""),
                            onClick: t => ke.form.price = e.price
                        }, [S(i("div", {
                            class: "price-item text-green-darken"
                        }, f(0 == e.price ? "--" : e.price.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 513), [
                            [N, 1 != ke.priceorder]
                        ]), i("div", fy, f(0 == e.amount ? "--" : e.amount.toFixed(ke.baseScale)), 1), 1 == ke.priceorder ? (o(), t("div", my, f(0 == e.price ? "--" : e.price.toFixed(ke.quoteScale)), 1)) : y("", !0), 1 != ke.priceorder ? (o(), t("div", {
                            key: 1,
                            class: "price-item text-gray5",
                            style: p("background-image: linear-gradient(to right, rgba(36, 174, 100, 0.10), rgba(36, 174, 100, 0.06) " + 100 * (e.totalAmount / ke.plate.bidTotle).toFixed(4) + "%, rgba(0, 0, 0, 0) 5%)")
                        }, f(0 == e.amount || 0 == e.totalAmount ? "--" : e.totalAmount.toFixed(ke.baseScale)), 5)) : y("", !0)], 12, py)), [
                            [N, 3 != ke.priceorder]
                        ]))), 128))])]), "" == ke.plate.bidRows ? (o(), t("p", hy, f(m(g)("exh.no-records-found")), 1)) : y("", !0)], 2)) : y("", !0)], 2), 1 == ke.priceorder ? (o(), t("div", {
                            key: 0,
                            class: r(["flex pricet1", 0 != ke.priceorder ? "my-2" : ""])
                        }, [i("div", yy, [i("span", {
                            class: r(["mb-0 close", ke.currentCoin.change > 0 ? "text-green-darken" : "text-red-darken"])
                        }, f(ke.currentCoin.close), 3), i("span", {
                            class: r(["arrow", ke.currentCoin.change > 0 ? "text-green-darken" : "text-red-darken"]),
                            style: p([ke.currentCoin.change < 0 ? {} : {
                                transform: "rotate(180deg)"
                            }])
                        }, n[28] || (n[28] = [i("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 25 25",
                            class: "arrow-icon status-buy css-3kwgah"
                        }, [i("path", {
                            d: "M5 13.5l1.41-1.41 5.1 5.1V3h1.99v14.15l5.09-5.09L20 14l-7.5 7.5-7.5-7.5z",
                            fill: "currentColor"
                        })], -1)]), 6)]), i("div", gy, " $" + f(ke.currentCoin.usdRate), 1)], 2)) : y("", !0), i("div", null, [u(m(Te), {
                            placement: "top",
                            trigger: "hover",
                            width: 222,
                            persistent: !1
                        }, {
                            reference: d((() => [ke.plate.maxPostion == _e.value && m(b).isPriceIndicator && !ve.value ? (o(), t("div", {
                                key: 0,
                                class: r(["betweenbar", ye.value && "mb-4"])
                            }, [i("span", vy, f(m(g)("exh.buy")), 1), i("div", by, [i("div", {
                                class: "buysidePR",
                                style: p("width:" + (yt.value < 15 ? 15 : (yt.value > 85 ? 85 : yt.value) + 2).toFixed(2) + "%")
                            }, [i("span", {
                                class: r(yt.value < 15 && "pl-1")
                            }, f(yt.value.toFixed(0)) + "%", 3)], 4), i("div", {
                                class: "sellsidePR",
                                style: p("width:" + (gt.value < 15 ? 15 : (gt.value > 85 ? 85 : gt.value) + 1).toFixed(2) + "%")
                            }, [i("span", {
                                class: r(gt.value < 15 && "pr-1")
                            }, f(gt.value.toFixed(0)) + "%", 3)], 4)]), i("span", xy, f(m(g)("exh.sell")), 1)], 2)) : y("", !0)])),
                            default: d((() => [n[29] || (n[29] = i("div", {
                                class: "flex flex-col align-baseline price-indi"
                            }, [i("p", {
                                class: "text-12 text-gray-darken"
                            }, " Relative Price Comparison Indicator "), i("p", {
                                class: "text-12 text-gray5 price-indi-desc mt-1"
                            }, " The calculation we are performing can be described as a weighted average of 9 bid and 9 ask distances. ")], -1))])),
                            _: 1
                        })])], 2)], 2), [
                            [N, !ye.value || ye.value && "orderbook" == F.value]
                        ]), S(i("div", wy, [i("div", ky, [i("p", Sy, f(m(g)("exh.recent-trades")), 1), i("div", Cy, [i("div", _y, [i("div", Ty, f(m(g)("exh.price")), 1), i("div", Ay, f(m(g)("exh.amount")), 1), i("div", Dy, f(m(g)("sett.time")), 1)]), i("div", null, [(o(!0), t(_, null, C(ke.trade.rows, ((e, s) => (o(), t("div", {
                            key: s,
                            class: "flex justify-between price-grid"
                        }, [i("div", {
                            class: r(["price-item", "BUY" == e.direction ? "text-green-darken" : "text-red-darken"])
                        }, f(e.price.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 3), i("div", Oy, f(e.amount.toFixed(ke.baseScale)), 1), i("div", Ey, [a(f(m(ie)(e.time).format("HH:mm:ss")) + " ", 1), n[30] || (n[30] = i("div", {
                            class: "s-back",
                            style: {
                                width: "0%"
                            }
                        }, null, -1))])])))), 128))])]), "" == ke.trade.rows ? (o(), t("p", Iy, f(m(g)("exh.no-records-found")), 1)) : y("", !0)])], 512), [
                            [N, !ye.value || ye.value && "trades" == F.value]
                        ])]), ye.value ? y("", !0) : (o(), h(Nm, {
                            key: 0,
                            ref_key: "buySellRef",
                            ref: ee,
                            "current-coin": ke.currentCoin,
                            "enabled-market-buy": ke.enableMarketBuy,
                            "enabled-market-sell": ke.enableMarketSell,
                            "enabled-trading": ke.enableTrading,
                            "add-order": ue.value,
                            price: ke.form.price,
                            "quote-scale": ke.quoteScale,
                            "base-scale": ke.baseScale,
                            onRefreshAccount: Ye
                        }, null, 8, ["current-coin", "enabled-market-buy", "enabled-market-sell", "enabled-trading", "add-order", "price", "quote-scale", "base-scale"]))])], 2)], 512), [
                            [N, !ye.value || "ai" !== F.value]
                        ]), S(i("div", null, [(o(), h(v, {
                            coin: "BTC",
                            key: "pricing-tabbed-BTC",
                            isMobileWidth: ye.value
                        }, null, 8, ["isMobileWidth"]))], 512), [
                            [N, ye.value && "ai" == F.value]
                        ])], 2)], 2), ve.value ? (o(), t("div", Py)) : (o(), h(x, {
                            key: 1,
                            class: r(ye.value && "mobile")
                        }, {
                            links: d((() => [i("li", jy, [u(c, {
                                to: {
                                    name: "announcements"
                                },
                                class: "footer-link"
                            }, {
                                default: d((() => [a(f(m(g)("pga.announcements")), 1)])),
                                _: 1
                            })]), i("li", Ly, [u(c, {
                                to: {
                                    name: "help-desk-center"
                                },
                                class: "footer-link"
                            }, {
                                default: d((() => [a(f(m(g)("pga.help-center")), 1)])),
                                _: 1
                            })])])),
                            _: 1
                        }, 8, ["class"])), me.value ? (o(), h(w, {
                            key: 3,
                            single: !1,
                            coinname: ke.currentCoin.coin,
                            modelValue: me.value,
                            "onUpdate:modelValue": n[17] || (n[17] = e => me.value = e)
                        }, null, 8, ["coinname", "modelValue"])) : y("", !0), ye.value ? (o(), h(m(we), {
                            key: 4,
                            modelValue: $.value,
                            "onUpdate:modelValue": n[19] || (n[19] = e => $.value = e),
                            class: "drawerBuySell",
                            direction: "btt",
                            "with-header": !1,
                            "lock-scroll": !0,
                            "destroy-on-close": !0,
                            size: ve.value && m(b).isShowWallet ? "83%" : ""
                        }, {
                            header: d((() => n[31] || (n[31] = []))),
                            default: d((() => [u(Nm, {
                                ref_key: "buySellRef",
                                ref: ee,
                                "current-coin": ke.currentCoin,
                                "enabled-market-buy": ke.enableMarketBuy,
                                "enabled-market-sell": ke.enableMarketSell,
                                price: ke.form.price,
                                "enabled-trading": ke.enableTrading,
                                "add-order": ue.value,
                                "quote-scale": ke.quoteScale,
                                "base-scale": ke.baseScale,
                                "buy-btn": G.value,
                                onRefreshAccount: Ye,
                                onCloseDrawer: n[18] || (n[18] = e => $.value = !1)
                            }, null, 8, ["current-coin", "enabled-market-buy", "enabled-market-sell", "price", "enabled-trading", "add-order", "quote-scale", "base-scale", "buy-btn"])])),
                            _: 1
                        }, 8, ["modelValue", "size"])) : y("", !0), ye.value ? (o(), t("div", My, [m(b).isTradeAiMode ? (o(), t("button", {
                            key: 0,
                            class: "btn-ai-trade",
                            onClick: n[20] || (n[20] = e => {
                                G.value = !0, $.value = !0
                            })
                        }, " AutoTrade AI ")) : y("", !0), m(b).isTradeAiMode ? y("", !0) : (o(), t("button", {
                            key: 1,
                            class: "btn-buy",
                            onClick: n[21] || (n[21] = e => {
                                G.value = !0, $.value = !0
                            })
                        }, f(m(g)("exh.buy")), 1)), m(b).isTradeAiMode ? y("", !0) : (o(), t("button", {
                            key: 2,
                            class: "btn-sell",
                            onClick: n[22] || (n[22] = e => {
                                G.value = !1, $.value = !0
                            })
                        }, f(m(g)("exh.sell")), 1))])) : y("", !0)]
                    })),
                    _: 1
                }), i("div", {
                    class: r(["setDrawer", ve.value && "is-app"])
                }, [u($p, {
                    onSettingsChange: it,
                    isMobileWidth: ye.value
                }, null, 8, ["isMobileWidth"])], 2)])
            }
        }
    }), [
        ["__scopeId", "data-v-425061f9"]
    ]);
export {
    Ny as
    default
};