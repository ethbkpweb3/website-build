import {
    _ as e,
    A as a,
    a as t,
    b as s,
    c as l
} from "./AiTradeItems2-CR7EgUZC.js";
import {
    _ as i,
    f as n
} from "./index-BPv_7EZ9.js";
import {
    _ as o
} from "./CaseStudy-DQNeIYfq.js";
import {
    _ as r
} from "./Blob-B8YNKMyz.js";
import {
    _ as c
} from "./ButtonGR-CCzD27Qk.js";
import {
    _ as d
} from "./Title-B_xB6icS.js";
import {
    _ as u
} from "./Subtitle-C6oUzL5I.js";
import {
    V as p
} from "./vue3-lottie.es-CiYK4lOh.js";
import {
    m,
    h as v,
    o as h,
    j as g,
    l as f,
    v as b,
    w as y,
    t as x,
    q as w,
    p as k,
    r as q,
    n as j,
    s as _,
    X as z,
    Y as C,
    G as P,
    cD as T,
    dg as B,
    P as S,
    cB as E,
    y as I,
    dm as D,
    K as O,
    a as N,
    H as F,
    dn as A,
    dp as U,
    dD as L,
    u as Z,
    du as V,
    I as M,
    N as R,
    B as W,
    ck as H,
    d8 as $,
    i as G
} from "./index-CQfCy4Xm.js";
import {
    _ as K
} from "./_plugin-vue_export-helper-BCo6x5W8.js";
import {
    E as J
} from "./index-DxHJyswS.js";
import {
    _ as Y
} from "./SectionTitle.vue_vue_type_script_setup_true_lang-C7hy-prY.js";
import {
    _ as Q
} from "./Hero.vue_vue_type_style_index_0_lang-DHspTRKr.js";
import {
    _ as X
} from "./AvatarSimple-DIs6U3iF.js";
import {
    _ as ee
} from "./Section-DPQWt_EU.js";
import {
    _ as ae
} from "./DarkImage-CKYmncsD.js";
import {
    _ as te
} from "./Navbar2-Cx1AKm6v.js";
import {
    _ as se,
    a as le
} from "./google-play-BbEUCb8h.js";
import {
    t as ie
} from "./index-CaRD-WAZ.js";
import {
    _ as ne
} from "./lodash-Bm6t9hsB.js";
import {
    b as oe
} from "./index-BSBG2tux.js";
import {
    _ as re
} from "./VPlaceload-DcvQMSN9.js";
import {
    u as ce
} from "./vue.8fc199ce-DBDcZ0BB.js";
import {
    u as de
} from "./useNotyfLong-unFWQDox.js";
import {
    F as ue
} from "./browser-Cv63Auap.js";
import {
    r as pe
} from "./calcs-C2mNVRpW.js";
import "./index-DZwhim7i.js";
import {
    C as me,
    S as ve
} from "./carousel.es-BlHzsVLl.js";
import {
    i as he
} from "./vue-qrcode.esm-C-BWAPbN.js";
import {
    E as ge,
    a as fe
} from "./index-38aUouWI.js";
import {
    E as be
} from "./index-CB5HUA9W.js";
import {
    E as ye
} from "./index-BaPl-dvV.js";
import {
    a as xe,
    E as we
} from "./index-DI0c3Das.js";
import {
    E as ke
} from "./index-DhHA3mFI.js";
import {
    E as qe
} from "./index-5N62XIoj.js";
import {
    u as je
} from "./useSeoMeta-DJrBtPw8.js";
import {
    s as _e
} from "./sleep-MiAo3PcT.js";
import {
    p as ze
} from "./units-DFlkXKBd.js";
import {
    E as Ce
} from "./index-CteOOV_f.js";
import {
    E as Pe
} from "./index-DWyf7GKU.js";
import {
    a as Te,
    E as Be
} from "./index-CBmmRNm0.js";
import {
    E as Se,
    a as Ee
} from "./index-D45OIXsf.js";
import {
    E as Ie
} from "./index-DPclT-tF.js";
import {
    B as De,
    C as Oe
} from "./provider-browser-D4UahRA7.js";
import {
    b as Ne
} from "./route-block-B_A1xBdJ.js";
import "./Collapse.vue_vue_type_style_index_0_lang-jEeEeRhV.js";
import "./AppPop-DXr7YMXx.js";
import "./index-DPTDKB4o.js";
import "./index-wV0BwLDn.js";
import "./google-play-0W6tGWt8.js";
import "./via-placeholder-csI6CdwS.js";
import "./Button-C_PMcYdl.js";
import "./user-qMNVzsWD.js";
import "./sett-Dbwu6PJ1.js";
import "./avatarSettings-C1kj7zSJ.js";
import "./vue3-avataaars-DO56oOZp.js";
import "./logo-DqlCWKKL.js";
import "./index-D21_sbBM.js";
import "./aria-C-hsWcn7.js";
import "./index-CreMjc0E.js";
import "./typescript-CRqm1_SZ.js";
import "./browser-ZWSpNtBY.js";
import "./_baseClone-CNNEnxsr.js";
import "./_initCloneObject-DqrhPNyg.js";
import "./use-global-config-CYuHb1FB.js";
import "./index-DYh1qtlV.js";
import "./use-dialog-CC6CVfkB.js";
import "./index-BR6qnryQ.js";
import "./isPlainObject-BkooXA2Q.js";
import "./validator-Kt7cHrwc.js";
import "./sha256-o0pdH_sn.js";
import "./secp256k1-LeYlzbB0.js";
const Fe = {
        class: "columns is-vcentered"
    },
    Ae = {
        class: "column is-5"
    },
    Ue = {
        class: "text-gradient"
    },
    Le = {
        class: "flex"
    },
    Ze = {
        class: "action-link pl-4 flex items-center"
    },
    Ve = {
        class: "column is-6 has-text-centered is-relative is-offset-1"
    },
    Me = K(m({
        __name: "SideSectionOPZ",
        props: {
            title: {},
            subtitle: {},
            content: {},
            to: {
                default: void 0
            },
            cta: {
                default: void 0
            },
            image: {},
            darkImage: {
                default: void 0
            },
            imageWidth: {
                default: "800"
            },
            imageHeight: {
                default: "600"
            },
            legend: {
                default: void 0
            },
            bordered: {
                type: Boolean,
                default: !1
            },
            inverted: {
                type: Boolean,
                default: !1
            },
            blob: {
                type: Boolean,
                default: !1
            },
            reverse: {
                type: Boolean,
                default: !1
            },
            opacity: {}
        },
        setup(e) {
            const a = e,
                t = v((() => [a.bordered && "is-bordered", a.inverted && "is-inverted", a.reverse && "is-reverse"])),
                s = v((() => [a.inverted && "is-inverted"]));
            return (e, l) => {
                const i = u,
                    n = d,
                    o = c,
                    m = r;
                return h(), g("div", {
                    class: k(["side-section mobile:py-0 small:py-6 z-1", t.value])
                }, [f("div", Fe, [f("div", Ae, [b(i, {
                    tag: "h3",
                    size: 6,
                    weight: "bold",
                    class: "pb-4",
                    leading: ""
                }, {
                    default: y((() => [f("span", Ue, x(e.subtitle), 1)])),
                    _: 1
                }), b(n, {
                    tag: "h2",
                    size: 2,
                    weight: "bold",
                    inverted: a.inverted
                }, {
                    default: y((() => [w(x(e.title), 1)])),
                    _: 1
                }, 8, ["inverted"]), f("p", {
                    class: k(["paragraph rem-115 mb-4", s.value])
                }, x(a.content), 3), f("div", Le, [b(o, {
                    href: "https://gleam.io/kIsy5/159k-opz-giveaway",
                    blank: ""
                }, {
                    default: y((() => [f("span", Ze, [w(x(a.cta) + " ", 1), l[0] || (l[0] = f("i", {
                        class: "fas fa-arrow-right pl-2 text-12"
                    }, null, -1))])])),
                    _: 1
                })]), q(e.$slots, "content", {}, void 0, !0)]), f("div", Ve, [a.blob ? (h(), j(m, {
                    key: 0
                })) : _("", !0), a.legend ? (h(), j(n, {
                    key: 1,
                    tag: "h3",
                    size: 5,
                    weight: "bold",
                    inverted: a.inverted
                }, {
                    default: y((() => [w(x(a.legend), 1)])),
                    _: 1
                }, 8, ["inverted"])) : _("", !0), b(z(p), {
                    animationLink: "/assets/animated/droneopz.json",
                    height: 360,
                    width: 360
                })])])], 2)
            }
        }
    }), [
        ["__scopeId", "data-v-5c67b2f5"]
    ]),
    Re = {
        class: "pb-6"
    },
    We = {
        class: "globe-stats"
    },
    He = {
        class: "stats-block"
    },
    $e = {
        class: "stat-block"
    },
    Ge = {
        class: "block-inner mx-5",
        style: {
            "text-align": "left"
        }
    },
    Ke = {
        class: "stat-block"
    },
    Je = {
        class: "block-inner"
    },
    Ye = {
        class: "stat-block"
    },
    Qe = {
        class: "block-inner"
    },
    Xe = {
        class: "stat-block"
    },
    ea = {
        class: "block-inner"
    },
    aa = K(m({
        __name: "TokenContract",
        setup: e => (e, a) => {
            const t = d;
            return h(), g("div", Re, [f("div", We, [f("div", He, [f("div", $e, [f("div", Ge, [b(t, {
                tag: "h3",
                size: 3,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[0] || (a[0] = [f("span", null, null, -1), f("span", null, "Address", -1)]))),
                _: 1
            }), a[2] || (a[2] = f("div", {
                class: "flex items-center"
            }, [f("p", {
                class: "paragraph mr-2",
                style: {
                    "text-transform": "none !important"
                }
            }, "0x18E1B6AA7ef866Eba192f2817D43bAE92D75c817")], -1)), a[3] || (a[3] = f("p", {
                class: "text-gray1 small-label small-text text-help",
                style: {
                    "font-size": "12px",
                    "line-height": "12px",
                    "text-transform": "none"
                }
            }, "(Do not send any tokens to this address)", -1)), b(z(J), {
                type: "primary",
                href: "https://skynet.certik.com/projects/opz#code-security",
                target: "_blank"
            }, {
                default: y((() => a[1] || (a[1] = [w("Audit")]))),
                _: 1
            })])]), f("div", Ke, [f("div", Je, [b(t, {
                tag: "h3",
                size: 3,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[4] || (a[4] = [f("span", null, null, -1), f("span", null, "18", -1)]))),
                _: 1
            }), a[5] || (a[5] = f("p", {
                class: "paragraph is-upper"
            }, "Decimal", -1))])]), f("div", Ye, [f("div", Qe, [b(t, {
                tag: "h3",
                size: 3,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[6] || (a[6] = [f("span", null, null, -1), f("span", null, "ERC20", -1)]))),
                _: 1
            }), a[7] || (a[7] = f("p", {
                class: "paragraph is-upper"
            }, "Network", -1))])]), f("div", Xe, [f("div", ea, [b(t, {
                tag: "h3",
                size: 3,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[8] || (a[8] = [f("span", null, null, -1), f("span", null, "OPZ", -1)]))),
                _: 1
            }), a[9] || (a[9] = f("p", {
                class: "paragraph is-upper"
            }, " Symbol", -1))])])])])])
        }
    }), [
        ["__scopeId", "data-v-4196887d"]
    ]),
    ta = {
        class: "pb-6"
    },
    sa = {
        class: "globe-stats"
    },
    la = {
        class: "stats-block"
    },
    ia = {
        class: "stat-block"
    },
    na = {
        class: "block-inner"
    },
    oa = {
        class: "stat-block"
    },
    ra = {
        class: "block-inner"
    },
    ca = {
        class: "stat-block"
    },
    da = {
        class: "block-inner"
    },
    ua = {
        class: "stat-block"
    },
    pa = {
        class: "block-inner"
    },
    ma = {
        class: "stat-block"
    },
    va = {
        class: "block-inner"
    },
    ha = {
        class: "stat-block mob-box2"
    },
    ga = {
        class: "block-inner"
    },
    fa = {
        class: "stats-block"
    },
    ba = {
        class: "stat-block mob-box3"
    },
    ya = {
        class: "block-inner"
    },
    xa = {
        class: "stat-block"
    },
    wa = {
        class: "block-inner"
    },
    ka = {
        class: "stat-block"
    },
    qa = {
        class: "block-inner"
    },
    ja = {
        class: "stat-block"
    },
    _a = {
        class: "block-inner"
    },
    za = {
        class: "stat-block"
    },
    Ca = {
        class: "block-inner"
    };
const Pa = K({}, [
        ["render", function(e, a) {
            const t = d;
            return h(), g("div", ta, [f("div", sa, [f("div", la, [f("div", ia, [f("div", na, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[0] || (a[0] = [f("span", null, null, -1), f("span", null, "8.0%", -1)]))),
                _: 1
            }), a[1] || (a[1] = f("p", {
                class: "paragraph is-upper"
            }, "Staking Rewards", -1))])]), f("div", oa, [f("div", ra, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[2] || (a[2] = [f("span", null, null, -1), f("span", null, "15.0%", -1)]))),
                _: 1
            }), a[3] || (a[3] = f("p", {
                class: "paragraph is-upper"
            }, "Liquidity Providers", -1))])]), f("div", ca, [f("div", da, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[4] || (a[4] = [f("span", null, null, -1), f("span", null, "14.0%", -1)]))),
                _: 1
            }), a[5] || (a[5] = f("p", {
                class: "paragraph is-upper"
            }, "Trading Rewards", -1))])]), f("div", ua, [f("div", pa, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[6] || (a[6] = [f("span", null, null, -1), f("span", null, "12%", -1)]))),
                _: 1
            }), a[7] || (a[7] = f("p", {
                class: "paragraph is-upper"
            }, "Investors", -1))])]), f("div", ma, [f("div", va, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[8] || (a[8] = [f("span", null, null, -1), f("span", null, "15%", -1)]))),
                _: 1
            }), a[9] || (a[9] = f("p", {
                class: "paragraph is-upper"
            }, "Community Treasury", -1))])]), f("div", ha, [f("div", ga, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[10] || (a[10] = [f("span", null, null, -1), f("span", null, "6.0%", -1)]))),
                _: 1
            }), a[11] || (a[11] = f("p", {
                class: "paragraph is-upper"
            }, "Airdrops", -1))])])]), f("div", fa, [f("div", ba, [f("div", ya, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[12] || (a[12] = [f("span", null, null, -1), f("span", null, "6.0%", -1)]))),
                _: 1
            }), a[13] || (a[13] = f("p", {
                class: "paragraph is-upper"
            }, "Airdrops", -1))])]), f("div", xa, [f("div", wa, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[14] || (a[14] = [f("span", null, null, -1), f("span", null, "7.2%", -1)]))),
                _: 1
            }), a[15] || (a[15] = f("p", {
                class: "paragraph is-upper"
            }, "Strategic Investments", -1))])]), f("div", ka, [f("div", qa, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[16] || (a[16] = [f("span", null, null, -1), f("span", null, "2.0%", -1)]))),
                _: 1
            }), a[17] || (a[17] = f("p", {
                class: "paragraph is-upper"
            }, "EIP", -1))])]), f("div", ja, [f("div", _a, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[18] || (a[18] = [f("span", null, null, -1), f("span", null, "20.0%", -1)]))),
                _: 1
            }), a[19] || (a[19] = f("p", {
                class: "paragraph is-upper"
            }, "Presale", -1))])]), f("div", za, [f("div", Ca, [b(t, {
                tag: "h3",
                size: 1,
                weight: "bold",
                narrow: ""
            }, {
                default: y((() => a[20] || (a[20] = [f("span", null, null, -1), f("span", null, "8%", -1)]))),
                _: 1
            }), a[21] || (a[21] = f("p", {
                class: "paragraph is-upper"
            }, "Team", -1))])])])])])
        }],
        ["__scopeId", "data-v-4cd4acb2"]
    ]),
    Ta = {
        name: "ScrollParallax",
        props: {
            speed: {
                type: Number,
                required: !0,
                default: .15
            },
            down: {
                type: Boolean,
                default: !1,
                required: !1
            },
            up: {
                type: Boolean,
                default: !0,
                required: !1
            },
            right: {
                type: Boolean,
                default: !0,
                required: !1
            },
            left: {
                type: Boolean,
                default: !1,
                requiredequired: !1
            },
            direction: {
                type: String,
                default: "y",
                required: !1
            }
        },
        data: () => ({
            el: null,
            axes: null,
            speedCoeff: null
        }),
        methods: {
            loadParallax() {
                this.initDirection(), this.el = this.$refs.scrollParallax, window.addEventListener("scroll", (() => {
                    this.el.style.transform = `translate${this.axes}(${window.pageYOffset*this.speedCoeff}px)`
                }))
            },
            initDirection() {
                "x" === this.direction ? (this.axes = "X", this.left ? this.speedCoeff = -this.speed : this.speedCoeff = this.speed) : "y" === this.direction && (this.axes = "Y", this.down ? this.speedCoeff = -this.speed : this.speedCoeff = this.speed)
            }
        },
        mounted() {
            this.loadParallax()
        }
    },
    Ba = {
        ref: "scrollParallax"
    };
const Sa = K(Ta, [
        ["render", function(e, a, t, s, l, i) {
            return h(), g("div", Ba, [q(e.$slots, "default")], 512)
        }]
    ]),
    Ea = {
        class: "columns is-vcentered"
    },
    Ia = {
        class: "column is-6"
    },
    Da = {
        class: "hero-composition"
    },
    Oa = {
        class: "floating-avatar floating-avatar-1"
    },
    Na = {
        class: "floating-avatar floating-avatar-2"
    },
    Fa = {
        class: "floating-avatar floating-avatar-4"
    },
    Aa = {
        class: "column is-5 is-offset-1",
        style: {
            "z-index": "2"
        }
    },
    Ua = {
        class: "hero-caption mt-2"
    },
    La = {
        class: "buttons is-relative z-1"
    },
    Za = K(m({
        __name: "HeroH",
        setup(e) {
            const {
                t: a
            } = C(), t = {
                opacity: 1,
                y: 0,
                transition: {
                    type: "spring",
                    stiffness: 300,
                    damping: 14,
                    delay: 150
                }
            };
            return P(), (e, s) => {
                const l = X,
                    i = d,
                    n = u,
                    o = c,
                    r = Q,
                    p = T("motion");
                return h(), j(r, {
                    color: "grey",
                    class: "opz-dex",
                    size: "fullheight"
                }, {
                    body: y((() => [f("div", Ea, [f("div", Ia, [f("div", Da, [s[0] || (s[0] = f("div", {
                        class: "featured-bg-circle"
                    }, null, -1)), b(Sa, {
                        direction: "y",
                        class: "image-wrap",
                        speed: .06
                    }, {
                        default: y((() => [B(f("img", {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            visibleOnce: t,
                            delay: 100,
                            class: "img-card mb-6",
                            src: "/images/trade-banner.png"
                        }, null, 512), [
                            [p]
                        ]), f("div", Oa, [b(l, {
                            picture: "/images/coinsnew/btc.png",
                            size: "large"
                        })]), f("div", Na, [b(l, {
                            picture: "/images/coinsnew/eth.png",
                            size: "medium"
                        })]), f("div", Fa, [b(l, {
                            picture: "/images/coinsnew/tether.png",
                            size: "medium"
                        })])])),
                        _: 1
                    })])]), f("div", Aa, [f("div", Ua, [b(i, {
                        tag: "h1",
                        size: 2,
                        weight: "bold"
                    }, {
                        default: y((() => s[1] || (s[1] = [w(" Decentralized "), f("span", {
                            style: {
                                color: "#7303fc"
                            }
                        }, "Spot", -1), w(" and "), f("span", {
                            style: {
                                color: "#7303fc"
                            }
                        }, "Perpetual", -1), w(" Trading ")]))),
                        _: 1
                    }), b(n, {
                        tag: "p",
                        size: 5,
                        classes: "b-centered-tablet-p text-medium",
                        style: {
                            "margin-bottom": "9px",
                            "margin-top": "3px"
                        }
                    }, {
                        default: y((() => [w(x(z(a)("presale.presale-dex1")), 1)])),
                        _: 1
                    }), b(n, {
                        tag: "p",
                        size: 5,
                        classes: "b-centered-tablet-p text-medium"
                    }, {
                        default: y((() => [w(x(z(a)("presale.presale-dex2")), 1)])),
                        _: 1
                    }), s[3] || (s[3] = f("hr", null, null, -1)), s[4] || (s[4] = f("div", {
                        class: "benefit mb-2"
                    }, [f("i", {
                        class: "iconify",
                        "data-icon": "feather:check"
                    }), f("span", {
                        class: "is-weight-500 pl-2 pr-4"
                    }, [f("b", null, "Off-Chain Chronicle Matching Engine:"), w(" High-Speed Trading and Low Latency.")])], -1)), s[5] || (s[5] = f("div", {
                        class: "benefit mb-2"
                    }, [f("i", {
                        class: "iconify",
                        "data-icon": "feather:check"
                    }), f("span", {
                        class: "is-weight-500 pl-2 pr-4"
                    }, [f("b", null, "OPZ-AI:"), w(" Our DEX is enhanced with AI capabilities.")])], -1)), s[6] || (s[6] = f("div", {
                        class: "benefit mb-4"
                    }, [f("i", {
                        class: "iconify",
                        "data-icon": "feather:check"
                    }), f("span", {
                        class: "is-weight-500 pl-2 pr-4"
                    }, [f("b", null, "Low Slippage & High Liquidity:"), w(" Various liquidity pools and institutional market makers.")])], -1)), f("div", La, [b(o, {
                        href: "/trade",
                        blank: ""
                    }, {
                        default: y((() => s[2] || (s[2] = [w(" Demo ")]))),
                        _: 1
                    }), b(o, {
                        href: "https://whitepaper.opz.com/opz/opz-dex-beta/opz-dex",
                        blank: "",
                        class: "ml-4"
                    }, {
                        default: y((() => [w(x(z(a)("ctm.documentation")), 1)])),
                        _: 1
                    })])])])])])),
                    _: 1
                })
            }
        }
    }), [
        ["__scopeId", "data-v-92be8f49"]
    ]),
    Va = {
        class: "py-6 mx-auto"
    },
    Ma = {
        class: "columns is-multiline b-columns-half-tablet-p"
    },
    Ra = {
        class: "paragraph rem-95 mb-1"
    },
    Wa = {
        key: 0,
        class: "box-shape box-shape-1"
    },
    Ha = {
        key: 1,
        class: "box-shape box-shape-2"
    },
    $a = {
        key: 2,
        class: "box-shape box-shape-3"
    },
    Ga = {
        key: 3,
        class: "box-shape box-shape-4"
    },
    Ka = {
        key: 4,
        class: "box-shape box-shape-5"
    },
    Ja = {
        key: 5,
        class: "box-shape box-shape-6"
    },
    Ya = K(m({
        __name: "FeatureBlockD",
        props: {
            features: {},
            limit: {
                default: 3
            },
            size: {
                default: void 0
            },
            links: {
                type: Boolean,
                default: !1
            },
            animated: {
                type: Boolean,
                default: !1
            },
            horizontal: {
                type: Boolean,
                default: !1
            },
            shapes: {
                type: Boolean,
                default: !1
            }
        },
        setup(e) {
            const {
                t: a
            } = C(), t = e, s = v((() => [t.horizontal ? "is-6" : "is-4"])), l = v((() => [t.animated && "is-animated", !t.horizontal && "has-text-centered p-4 large:p-10"])), i = v((() => [t.size && `is-${t.size}`])), n = v((() => ["small" === t.size && "rem-90", t.links && "mb-4", !t.horizontal && "mx-auto max-w-2"]));
            return (e, o) => {
                const r = ae,
                    c = d,
                    u = T("motion");
                return h(), g("div", Va, [f("div", Ma, [(h(!0), g(S, null, E(t.features.slice(0, t.limit), ((o, d) => (h(), g("div", {
                    key: d,
                    class: k(["column", s.value])
                }, [f("div", {
                    class: k(["box is-boxed", l.value])
                }, [q(e.$slots, "column", {
                    feature: o,
                    index: d
                }, (() => [f("span", {
                    class: k(n.value)
                }, [B(b(r, {
                    src: o.image,
                    "src-dark": o.darkImage,
                    class: k(["feature-block-image", ...i.value]),
                    alt: "featured image",
                    initial: {
                        opacity: 0,
                        y: 30
                    },
                    visibleOnce: {
                        opacity: 1,
                        y: 0,
                        transition: {
                            type: "spring",
                            stiffness: 90,
                            damping: 9,
                            delay: 150 + 100 * d
                        }
                    }
                }, null, 8, ["src", "src-dark", "class", "visibleOnce"]), [
                    [u]
                ]), b(c, {
                    tag: "h3",
                    size: 6,
                    weight: "semi",
                    leading: ""
                }, {
                    default: y((() => [f("span", null, x(z(a)(o.title)), 1)])),
                    _: 2
                }, 1024), f("p", Ra, x(z(a)(o.text)), 1)], 2), t.shapes ? (h(), g("div", Wa)) : _("", !0), t.shapes ? (h(), g("div", Ha)) : _("", !0), t.shapes ? (h(), g("div", $a)) : _("", !0), t.shapes ? (h(), g("div", Ga)) : _("", !0), t.shapes ? (h(), g("div", Ka)) : _("", !0), t.shapes ? (h(), g("div", Ja)) : _("", !0)]), !0)], 2)], 2)))), 128))])])
            }
        }
    }), [
        ["__scopeId", "data-v-ea2308fe"]
    ]),
    Qa = {
        key: 0,
        class: "paragraph text-upper rem-80 weight-6 has-text-centered"
    },
    Xa = K(m({
        __name: "TimelineTitle",
        props: {
            title: {
                default: void 0
            },
            subtitle: {
                default: void 0
            },
            minititle: {
                default: void 0
            },
            inverted: {
                type: Boolean,
                default: !1
            },
            spaced: {
                type: Boolean,
                default: !1
            },
            color: {
                default: "primary"
            },
            step: {}
        },
        setup(e) {
            const a = e,
                t = v((() => [a.inverted && "is-inverted"])),
                s = v((() => [a.spaced && "mb-16"])),
                l = v((() => [a.color && "text-gradient"])),
                i = v((() => [a.color && `bg-gradient-${a.color}-fade`])),
                n = v((() => [a.color && `bg-gradient-${a.color}`]));
            return (e, o) => {
                const r = u,
                    c = d;
                return h(), g("div", null, [f("div", {
                    class: k(["has-text-centered", s.value])
                }, [a.minititle ? (h(), g("p", Qa, x(a.minititle), 1)) : _("", !0), q(e.$slots, "subheading", {}, void 0, !0), f("div", {
                    class: k(["line", i.value])
                }, null, 2), f("div", {
                    class: k(["step", n.value])
                }, [f("span", null, x(a.step), 1)], 2), a.subtitle ? (h(), j(r, {
                    key: 1,
                    tag: "h3",
                    size: 5,
                    weight: "bold"
                }, {
                    default: y((() => [f("span", {
                        class: k(l.value)
                    }, [q(e.$slots, "subtitle", {}, (() => [w(x(a.subtitle), 1)]), !0)], 2)])),
                    _: 3
                })) : _("", !0), b(c, {
                    tag: "h2",
                    size: 3,
                    weight: "bold",
                    class: k(t.value)
                }, {
                    default: y((() => [f("span", null, [q(e.$slots, "default", {}, (() => [w(x(a.title), 1)]), !0)])])),
                    _: 3
                }, 8, ["class"])], 2), q(e.$slots, "content", {}, void 0, !0)])
            }
        }
    }), [
        ["__scopeId", "data-v-a596fb09"]
    ]),
    et = {
        key: 0,
        class: "has-text-centered pb-6"
    },
    at = {
        class: "track"
    },
    tt = ["src"],
    st = K(m({
        __name: "LogoMarquee",
        props: {
            logos: {
                default: () => []
            },
            inverted: {
                type: Boolean,
                default: !1
            },
            compact: {
                type: Boolean,
                default: !1
            }
        },
        setup(a) {
            const t = a;
            return (a, s) => {
                const l = u,
                    i = e;
                return h(), g("div", {
                    class: k(["logo-marquee", t.compact && "is-compact"])
                }, [t.compact ? _("", !0) : (h(), g("div", et, [b(l, {
                    tag: "h3",
                    size: 6,
                    weight: "bold"
                }, {
                    default: y((() => s[0] || (s[0] = [f("span", {
                        class: "text-gradient px-2"
                    }, " WE DRIVE RESULTS FOR ENTREPRENEURS TO THE FORTUNE 500 ", -1)]))),
                    _: 1
                })])), f("div", at, [b(i, {
                    repeat: 10,
                    duration: 40
                }, {
                    default: y((() => [f("div", {
                        class: k(["marquee-logos", t.inverted && "is-inverted"])
                    }, [(h(!0), g(S, null, E(t.logos, ((e, a) => (h(), g("div", {
                        key: a
                    }, [f("img", {
                        class: "is-relative mx-6",
                        src: e.logo,
                        alt: "Customer logo",
                        width: "110",
                        height: "52"
                    }, null, 8, tt)])))), 128))], 2)])),
                    _: 1
                })])], 2)
            }
        }
    }), [
        ["__scopeId", "data-v-a701c6f6"]
    ]),
    lt = "/images/banner4.png",
    it = [{
        id: 1,
        logo: "/images/svg/finbold.svg"
    }, {
        id: 2,
        logo: "/images/svg/cryptodaily.svg"
    }, {
        id: 3,
        logo: "/images/svg/businessinsider.svg"
    }, {
        id: 4,
        logo: "/images/svg/decrypt.svg"
    }, {
        id: 5,
        logo: "/images/svg/investing.svg"
    }, {
        id: 6,
        logo: "/images/certik.png"
    }, {
        id: 7,
        logo: "/images/svg/bitcoininsider.svg"
    }, {
        id: 8,
        logo: "/images/svg/cointelegraph.svg"
    }],
    nt = ["bc1qsnadz894g5fmhvjwcdtlwecxh9a294q8ent3h5", "bc1qvfwkyrxur7vceagnncdma3jek59ev5y69wtxqw", "bc1qg6cz3tccm5kuanunv2ap0gzclmm0rq5d54r2vn", "bc1q44vm9kcc6lew20a3jndye2yhna7hdp7dtc5e87", "bc1qnxx59vw3n6huy35y66gdgc4fs7gh9k78r688af", "bc1qvfh5yqm247sqsxc5q9vhh0u7qugdd896fd9c83", "bc1qk382prnnrtfjzt6z9z5j4dvh6swe29fscjyp9k", "bc1q0tgvpapjecguy2xjam0hlh7cm5yh7lgnzr7el5", "bc1q806kk7ryrcyv6gg38m7xkycrj9gyrw37t9k5n3", "bc1q3m3qvk7292zrkmfymkvupzuuq8xcfv7amm3sum", "bc1qfyfsaq5nnz4vlyh9g86wgvq93suza29gxjaexc", "bc1qdjwflej5kvntrx0jectjj4zfpwr07lmvngsmxr", "bc1q5sjaqesrw6dzzgj8gyrjrnv6cf3guq9mjf6sl8", "bc1qhgdj2d80zefen3f9x5z4242fe03gen4uxzvacu", "bc1qlnp4y8putrf23tc3xr3k669uh9ettpgfuxxwh4", "bc1qjx2yl4rwkvd33cftc0q3ltfl5sl3xvfzuc63ku", "bc1qqgp9063347fm36peszavlqjg6ds9j9grng99al", "bc1q2hvd5pqujxqgg3jshptk43h06mf6xy8yvzuvz5", "bc1qchqj7n793qx6vqupr60khmeytjj03g3fy3twdp", "bc1qvcpp7kued89llf45z660dqn8cvvmnf92y2f25t", "bc1q938422997cgczrjnnp3g7tqtps5f7u7c5yfnkg", "bc1qzpf7l3tpxs7j3wspclymfsx43ap5cu7f2allur", "bc1qv0jptxswcpxs7tczx8cxzhqk4ks8pyklfyszs6", "bc1qlas0w6xvrspwx5estajmtqsymtppd7ktp5cg94", "bc1qq4lnl6fx3nvsjklyym6ukkdsk4f4e0sj3ngf68", "bc1q27520gme99uw2423483c4hag0f9su6vvrqfq30", "bc1qqurdt6unp5cjhurrlyj3raxtwkrl20w8wr2ky7", "bc1qz0w23zep3my5p4kt8rae9sgc9n48007rfx7n2u", "bc1qwqyxd352c7csvv2v00vj5mhrevph2z57s59exq", "bc1qf0q8j4290d2plzzyl4fa3jyh6v42fnsqvdf5x4", "bc1q9wxle3c965kaw4cv7dj83f075azaszksmcut46", "bc1qzxzx3h96ly898mh93emswhmdpggh2h9ugrjdfz", "bc1q6l53qq3ydddt6wfkf64r48tmt3h4nvqfh4xzsf", "bc1qhmf8t3wrv20lmyt2hmh44hjpecvau0awfve2ym", "bc1qr79g4m5fspeqkptfwpqfj24wd6ry8me5s99kqg", "bc1qavnhem2pq4zskw7jkwy2xcm5veht6algy9p539", "bc1qd3j54cwvztursdfvpekkfa6xstytvwcvp3q45q", "bc1qlgs5m3ltey9n8dk9a0rca5fjarafr56fkxpgxk", "bc1qmzhdgmcheyjlf40sg3tnvqntwt7xj3jcvwzzww", "bc1qxe0557286mtycgr6u8qkgw2ewt8tv7ttcvyylf", "bc1qnamzsqngve7ym36jxhleu2dc64uzhg2a082wj2", "bc1q45sxm93y2krp4j8qdpvvc4y9u3t5pz46k25cwm", "bc1qevrlkf5rzvnj6ag9w3ze3hjy5d7k3m5unky7jg", "bc1qz6cm9lwj689hjlx3h0km0y99catnmga5dm3sg3", "bc1q5xpqzdsz0875jnk80yy2al5tjr6mjhk7x7ezsw", "bc1qdc9yh5e98tm7jf4slntrqt4u6rnkq2umjghjy8", "bc1qrafnvhhgd56276um36gdhjkx0cte709lj4lq4u", "bc1qjeeldph08c7fszemgqtyq8mt8mvqerqkl4xxvd", "bc1qjyfr4cenceakcss9dtsllr5qgaf4fts6hsv5s8", "bc1qh4k6qevu888mr6z2r7fwsdynx5gv8aklgz8xn0", "bc1qcn8leny27495wj5l5jwe7mzw6e0j97ljth7qhh", "bc1qaryhuuysphjpzw7kywwucwxdesaazdsamjpzeh", "bc1qsnwtpa7pmsnquthcsvqc5zmrpr8gxnq34mpx3k", "bc1qm5msfpnlfu4v5jq7heu7ghm02ecnvh2uxd37g7", "bc1qhunguxm5fknwmugp47mj4k853ur3kwhswvaqu6", "bc1qmqeky9z472jfle35tx3lqzfe7zqktfzdz0et4a", "bc1q0t5pcen77jd80j5u3hjfc42s4lrfln9df8d4mm", "bc1q5lt66qvgmgmcqslglnyknrsxk68vwueaw7yl9w", "bc1qhwddx9d348cxwplpycj6c62es3lhhdvnpt07te", "bc1qudexh8vxrquqsq8zfrqhg7km7dj9elytf7n0am", "bc1qhc9whw7lwweg8yrsrr7lxs44cmfl9wkk6m5wcg", "bc1q5j2addk5s8esc4vcm0cckcglkzqr7yk8h4erjd", "bc1qhz928f0exjdvvxektn7y37eqh9pxmkphyekeyx", "bc1qpyxj027cvqr2me63764t3qka0ukfahp3pu7tef", "bc1qlfhv47d50s88fgz6l9aarctwtdp06t30c9t80y", "bc1qct6z44pucfypt4qhplhsyafe3whwxw4t6rquyc", "bc1qy0flu3sdhpakwexq5kaq7pqge84xvpcsscls72", "bc1qt8jlygwq6g78aru8h5zskvnq3tzs493za65nh3", "bc1qettpwvh4may70zyjl2ekty3jafyz00qfmeylae", "bc1qkgmkwwd0lqr7dhfkkpstk0h64tmysrvhplsxhx", "bc1q4k630m8wlrvd9wv0nxkkqyrw5d0x2s4t7yhz8n", "bc1qyv7jj6aqgr2f3kfhwhflq2j3a6laenxq8cw7xr", "bc1q4r3kymeck3w80a7m6klg5u3vnwgx28kp7rhuju", "bc1qsql4v7h2xqwsn4cqswesvvclgcmfrj57fxm43u", "bc1qfzh2z83ts6pmuwe4f6d38jxkhulcgt0n8tujkh", "bc1qhlw3k4nv77h4fl9v93jmcsf02jw6hrgjfdnhk2", "bc1qqsj9p6r3vpxrsq8u6jr4hcttc9577df06vdvz9", "bc1q22fx3gs8yt3mtghl89rjfe02qx9mh49f7lztly", "bc1qzxnzygnn8v9cs2m6cu7ug0vutedg9rcae0hzcv", "bc1qe0dxhvadmc78lwtctujvn23u35m20ra7qt9470", "bc1qvvp3d8ppgs5uhkwer7fpcshd6txcj6tfukjrnh", "bc1qfpexnmkfut8dg6f23mfs59p84kcj0673t6357m", "bc1qes3pfaqjq22nzklwqywyc30mhaqj2a0xx6vmdh", "bc1qfnhy9u9gwx34ffk6ckpa7sp73mfxf0qtmhsqzj", "bc1qqntj944l3fe54y699mgst2alzhs4ht3jjzctxd", "bc1qcpffm495gy9yxd9tvpjls8thqfwk9t0lx89njl", "bc1qlls4qpf0kwyxamcftwc0jz2a2kq8wve3nwwugx", "bc1qpkerrcc7qa4mahar4696k0uaydpartk48qdx9g", "bc1q90nu06j87yvfljmljxdvv7hyhhwwf7vzzq7ykj", "bc1qzf6nx08ej74g39kmut45gerg4z6y0l6levw5u0", "bc1qejznzd68vf6pj9rahkq5cxeerkytsx84l56yrq", "bc1qakkf5vq5z3vgs5xs7q7s7du0cw2c89p7vg20kg", "bc1qhamv38ec9pfanxfm0auwy8st2p95yahvuyhkcq", "bc1qqtf9had58l65rnm3wg7wfd55y8sjflzfn0dg5h", "bc1qm6mgd8u78hq8mfdc0pqtdwv7ffqcy4w59manh6", "bc1q7leg033yxqxzmst7kq6zfygljs9dl4n723hqp2", "bc1quedfvqaeru9r4anuttzxm8mp477fgls8enk2ds", "bc1q3n4myecqj97qw9myztnrthwpuvynxm4f8ng840", "bc1qhz4y52ata4t2p8ql9v8hwxapvn87nagh7z7wvr", "bc1q9rmfx9zmagfk382m93rakqszd9ljgev39xm9d6"];
const ot = {
        class: "title-input"
    },
    rt = {
        key: 0,
        src: "/images/icons/coin/btc.svg",
        width: "20",
        class: "ml-1"
    },
    ct = {
        key: 0
    },
    dt = {
        role: "row",
        class: "order-buy my-3"
    },
    ut = {
        role: "cell",
        class: "order-buy-cell justify-start"
    },
    pt = {
        class: "img-start"
    },
    mt = {
        class: "img-data"
    },
    vt = ["src", "alt"],
    ht = ["src"],
    gt = ["src"],
    ft = {
        role: "cell",
        class: "order-buy-cell justify-center text-end"
    },
    bt = {
        class: "pl-3 flex"
    },
    yt = {
        class: "show-qrcode",
        style: {
            "text-align": "center",
            "padding-top": "5px",
            "border-radius": "10px"
        }
    },
    xt = {
        class: "qrcode"
    },
    wt = {
        class: "help text-medium mb-2"
    },
    kt = {
        role: "row",
        class: "order-buy my-3"
    },
    qt = {
        role: "cell",
        class: "order-buy-cell justify-center text-mid"
    },
    jt = {
        class: "pl-3"
    },
    _t = {
        role: "cell",
        class: "order-buy-cell justify-center text-end"
    },
    zt = {
        class: "pl-3 flex"
    },
    Ct = {
        key: 0,
        role: "row",
        class: "order-buy my-3"
    },
    Pt = {
        key: 1,
        class: "mt-2 mb-5 line-hz"
    },
    Tt = K(m({
        __name: "BuyOPZToken",
        props: {
            btn: {
                type: Boolean,
                default: !1
            },
            modelValue: {
                type: Boolean,
                default: !0
            },
            amount: {
                default: "0"
            },
            amountOPZ: {
                default: "0"
            },
            address: {
                default: ""
            },
            adId: {
                default: null
            },
            memberId: {
                default: 0
            }
        },
        emits: ["update:modelValue", "addSuccess", "close"],
        setup(e, {
            emit: a
        }) {
            const t = I(!1),
                {
                    t: s
                } = C(),
                {
                    Api: l
                } = D(),
                i = I(),
                n = a,
                o = e,
                r = v({
                    get: () => o.modelValue,
                    set: e => n("update:modelValue", e)
                }),
                d = O({
                    allCards: []
                });
            d.allCards.push({
                name: "BTC",
                price: "25",
                img: "/images/opz/opz.png",
                img2: "/images/opz/opz.png"
            });
            const u = O({
                    txid: ""
                }),
                p = N(),
                m = I(!1),
                k = I(function() {
                    if (!Array.isArray(nt) || 0 === nt.length) throw new Error("Input must be a non-empty array of addresses.");
                    const e = Math.floor(Math.random() * nt.length);
                    return nt[e]
                }()),
                q = I("BTC"),
                P = () => {
                    n("update:modelValue", !1), n("close")
                };
            return (e, a) => {
                const v = c,
                    C = re;
                return h(), g(S, null, [o.btn ? (h(), j(v, {
                    key: 0,
                    class: "btn-buy-card",
                    onClick: a[0] || (a[0] = e => {})
                }, {
                    default: y((() => a[10] || (a[10] = [w("Order")]))),
                    _: 1
                })) : _("", !0), b(z(qe), {
                    modelValue: r.value,
                    "onUpdate:modelValue": a[8] || (a[8] = e => r.value = e),
                    "append-to-body": "",
                    class: "dialogw cdetail buy-card-pop heads2",
                    "destroy-on-close": "",
                    onClose: P,
                    onOpen: a[9] || (a[9] = e => {})
                }, {
                    header: y((() => a[11] || (a[11] = [f("div", {
                        class: "flex text-gray4 head-title items-center mb-1"
                    }, [f("i", {
                        class: "fas fa-cicle"
                    }), w(" " + x("OPZ Token Presale"))], -1)]))),
                    default: y((() => [f("div", null, [f("p", ot, x(z(s)("inx.payment-method")) + ":", 1), b(z(ge), {
                        modelValue: q.value,
                        "onUpdate:modelValue": a[1] || (a[1] = e => q.value = e),
                        class: "text-medium",
                        style: {
                            width: "100%"
                        },
                        placeholder: "Select"
                    }, {
                        prefix: y((() => [q.value ? (h(), g("img", rt)) : _("", !0)])),
                        default: y((() => [(h(), j(z(fe), {
                            key: "BTC",
                            label: "Bitcoin",
                            value: "BTC"
                        }, {
                            default: y((() => a[12] || (a[12] = [f("span", {
                                class: "imgParent"
                            }, [f("img", {
                                class: "imgSelect",
                                src: "/images/icons/coin/btc.svg"
                            })], -1), f("span", {
                                style: {
                                    float: "left"
                                }
                            }, x("Bitcoin"), -1), f("span", {
                                style: {
                                    float: "right",
                                    color: "var(--el-text-color-secondary)",
                                    "font-size": "13px"
                                }
                            }, x("BTC"), -1)]))),
                            _: 1
                        }))])),
                        _: 1
                    }, 8, ["modelValue"]), q.value ? (h(), g("div", ct, [a[18] || (a[18] = f("hr", {
                        class: "mt-4 mb-0 line-hz"
                    }, null, -1)), f("div", dt, [f("div", ut, [f("div", pt, [f("div", mt, [b(z(be), {
                        placement: "bottom",
                        width: 300,
                        trigger: "click"
                    }, {
                        reference: y((() => {
                            var e;
                            return [f("img", {
                                src: null == (e = d.allCards.find((e => e.name == q.value))) ? void 0 : e.img,
                                alt: q.value,
                                class: "img-data"
                            }, null, 8, vt)]
                        })),
                        default: y((() => [b(z(me), {
                            "items-to-show": 1,
                            autoplay: 2e3,
                            wrapAround: "",
                            pauseAutoplayOnHover: ""
                        }, {
                            default: y((() => [(h(), j(z(ve), {
                                key: 1
                            }, {
                                default: y((() => {
                                    var e;
                                    return [f("img", {
                                        src: null == (e = d.allCards.find((e => e.name == q.value))) ? void 0 : e.img,
                                        style: {
                                            "border-radius": "9px"
                                        },
                                        alt: ""
                                    }, null, 8, ht)]
                                })),
                                _: 1
                            })), (h(), j(z(ve), {
                                key: 2
                            }, {
                                default: y((() => {
                                    var e;
                                    return [f("img", {
                                        src: null == (e = d.allCards.find((e => e.name == q.value))) ? void 0 : e.img2,
                                        alt: ""
                                    }, null, 8, gt)]
                                })),
                                _: 1
                            }))])),
                            _: 1
                        })])),
                        _: 1
                    })])])]), a[14] || (a[14] = f("div", {
                        role: "cell",
                        class: "order-buy-cell justify-center text-mid"
                    }, [f("p", {
                        class: "pl-3"
                    }, x("OPZ"))], -1)), f("div", ft, [f("span", bt, [w(x(o.amountOPZ) + " ", 1), a[13] || (a[13] = f("p", {
                        class: "ml-1 qt-item"
                    }, " OPZ", -1))])])]), a[19] || (a[19] = f("hr", {
                        class: "mt-0 mb-2 line-hz"
                    }, null, -1)), f("div", yt, [f("figure", xt, [b(z(he), {
                        value: k.value,
                        options: {
                            width: 150,
                            errorCorrectionLevel: "Q"
                        },
                        tag: "svg"
                    }, null, 8, ["value"]), a[15] || (a[15] = f("img", {
                        class: "qrcode__image",
                        src: "/images/icons/coin/btc.svg",
                        alt: "Bitcoin"
                    }, null, -1))]), f("p", wt, x(z(s)("inx.send-only").replace(":", "BTC")), 1), b(z(ye), {
                        modelValue: k.value,
                        "onUpdate:modelValue": a[3] || (a[3] = e => k.value = e),
                        class: "addressInput text-medium btnChain",
                        placeholder: k.value,
                        readonly: ""
                    }, {
                        suffix: y((() => [f("i", {
                            class: "copy-link fas fa-copy",
                            onClick: a[2] || (a[2] = e => (e => {
                                try {
                                    navigator.clipboard.writeText(e), p.success(s("depwi.copied-successfully"))
                                } catch (a) {
                                    p.error(s("depwi.error"))
                                }
                            })(k.value))
                        })])),
                        _: 1
                    }, 8, ["modelValue", "placeholder"])]), f("div", kt, [f("div", qt, [f("p", jt, x(z(s)("exh.total")) + ": ", 1)]), f("div", _t, [f("span", zt, [w(x(o.amount) + " ", 1), a[16] || (a[16] = f("p", {
                        class: "ml-1 qt-item"
                    }, " BTC", -1))])])]), a[20] || (a[20] = f("hr", {
                        class: "mt-2 mb-5 line-hz"
                    }, null, -1)), t.value ? (h(), g("div", Ct, a[17] || (a[17] = [f("div", {
                        role: "cell",
                        class: "order-buy-cell justify-center text-mid"
                    }, [f("p", {
                        class: "pl-3"
                    }, " Enter the transaction ID below. We will process your payment and activate your order. Please check back in 12 hours. ")], -1), f("div", {
                        role: "cell",
                        class: "order-buy-cell justify-center text-end"
                    }, [f("p", {
                        class: "pl-3 flex"
                    })], -1)]))) : _("", !0), t.value ? (h(), g("hr", Pt)) : _("", !0), t.value ? (h(), j(z(we), {
                        key: 3,
                        "label-position": "left",
                        "label-width": "150px",
                        style: {
                            "max-width": "460px"
                        },
                        model: u,
                        ref_key: "formRef",
                        ref: i,
                        class: "form-buy-card"
                    }, {
                        default: y((() => [b(z(xe), {
                            label: z(s)("inx.txid"),
                            prop: "txid",
                            rules: [{
                                required: !0,
                                message: "Incorrect format",
                                trigger: "blur"
                            }, {
                                min: 64,
                                max: 64,
                                message: "Incorrect format",
                                trigger: "blur"
                            }]
                        }, {
                            default: y((() => [b(z(ye), {
                                placeholder: z(s)("inx.enter-txid"),
                                modelValue: u.txid,
                                "onUpdate:modelValue": a[5] || (a[5] = e => u.txid = e)
                            }, null, 8, ["placeholder", "modelValue"])])),
                            _: 1
                        }, 8, ["label"]), b(z(xe), null, {
                            default: y((() => [m.value ? (h(), j(C, {
                                key: 1,
                                height: "32px",
                                width: "120px"
                            })) : (h(), j(z(ke), {
                                key: 0,
                                type: "primary",
                                onClick: a[6] || (a[6] = e => {
                                    var a;
                                    (a = i.value) && a.validate((e => {
                                        if (!e) return !1; {
                                            const e = new ue;
                                            e.append("hash", u.txid), e.append("address", o.address), e.append("btcAddress", k.value), o.memberId && e.append("memberId", Number(o.memberId)), o.adId && e.append("adId", Number(o.adId));
                                            const t = o.amount.replaceAll(",", ""),
                                                i = o.amountOPZ.replaceAll(",", "");
                                            console.log("coinTo", t, o.amount), console.log("coinFrom", i, o.amountOPZ), e.append("amount", Number(t)), e.append("amountOPZ", Number(i)), m.value = !0, l.setBuyMore(e).then((({
                                                data: e
                                            }) => {
                                                "2" == e ? p.error("Order already exists") : "0" == e ? p.error(s("depwi.incorrect-format-try-again")) : (e = "1") ? (n("update:modelValue", !1), n("addSuccess"), a.resetFields(), p.success(s("inx.submitted-successfully"))) : p.error(s("pga.contact-customer-support")), m.value = !1
                                            }))
                                        }
                                    }))
                                })
                            }, {
                                default: y((() => [w(x(z(s)("sett.confirm")), 1)])),
                                _: 1
                            })), m.value ? _("", !0) : (h(), j(z(ke), {
                                key: 2,
                                onClick: a[7] || (a[7] = e => {
                                    var a;
                                    (a = i.value) && a.resetFields()
                                })
                            }, {
                                default: y((() => [w(x(z(s)("wall.reset")), 1)])),
                                _: 1
                            }))])),
                            _: 1
                        })])),
                        _: 1
                    }, 8, ["model"])) : (h(), j(z(we), {
                        key: 2
                    }, {
                        default: y((() => [b(z(xe), null, {
                            default: y((() => [m.value ? _("", !0) : (h(), j(z(ke), {
                                key: 0,
                                type: "primary",
                                onClick: a[4] || (a[4] = e => t.value = !0)
                            }, {
                                default: y((() => [w(x(z(s)("sett.confirm")), 1)])),
                                _: 1
                            }))])),
                            _: 1
                        })])),
                        _: 1
                    }))])) : _("", !0)])])),
                    _: 1
                }, 8, ["modelValue"])], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-b18b82f9"]
    ]);
const Bt = F(class {
        constructor(e) {
            this.options = e, this.iframe = document.createElement("iframe"), this.widgetWindow = null, this.widget_layout_mode = "Modal", this.await_data = !1, this.onMessage = e => {
                var a, t, s, l, i, n, o, r, c, d;
                const u = e.source === this.widgetWindow,
                    p = "object" == typeof e.data;
                if (u && p) switch (e.data.type) {
                    case "loaded":
                        this.sendEvent("allow-redirect", {
                            redirectAllowed: !1
                        }), this.sendEvent("extra", this.options.extra), null === (t = null === (a = this.options.listeners) || void 0 === a ? void 0 : a[e.data.type]) || void 0 === t || t.call(a);
                        break;
                    case "payment-status":
                        null === (l = null === (s = this.options.listeners) || void 0 === s ? void 0 : s[e.data.type]) || void 0 === l || l.call(s, e.data.data);
                        break;
                    case "position":
                        null === (n = null === (i = this.options.listeners) || void 0 === i ? void 0 : i[e.data.type]) || void 0 === n || n.call(i, e.data.data);
                        break;
                    case "rate-update":
                        null === (r = null === (o = this.options.listeners) || void 0 === o ? void 0 : o[e.data.type]) || void 0 === r || r.call(o, e.data.data);
                        break;
                    case "close":
                        this.close();
                        break;
                    case "error":
                        null === (d = null === (c = this.options.listeners) || void 0 === c ? void 0 : c[e.data.type]) || void 0 === d || d.call(c, e.data.data);
                        break;
                    case "3ds-start":
                        this.iframe.style.background = "#fff";
                        break;
                    case "3ds-end":
                        this.iframe.style.background = "transparent"
                }
            }, this.validateOptions(e), this.options.origin || (this.options.origin = "https://widget.wert.io"), this.options.extra && (this.await_data = !0)
        }
        open() {
            this.iframe.style.border = "none", this.iframe.style.width = "100%", this.iframe.style.height = "100%", this.iframe.style.bottom = "0", this.iframe.style.right = "0", this.iframe.style.position = "fixed", this.iframe.style.zIndex = "10000", document.body.style.overflow = "hidden", this.iframe.setAttribute("src", this.getEmbedUrl()), this.iframe.setAttribute("allow", "camera *; microphone *"), this.iframe.setAttribute("sandbox", "allow-scripts allow-forms allow-popups allow-same-origin"), document.body.appendChild(this.iframe), this.widgetWindow = this.iframe.contentWindow, this.listenWidget()
        }
        addEventListeners(e) {
            this.options.listeners = Object.assign(Object.assign({}, this.options.listeners), e)
        }
        removeEventListeners(e) {
            var a, t;
            if (void 0 === e) delete this.options.listeners;
            else if ("string" == typeof e) null === (a = this.options.listeners) || void 0 === a || delete a[e];
            else
                for (const s of e) null === (t = this.options.listeners) || void 0 === t || delete t[s]
        }
        updateTheme(e) {
            e && Object.keys(e).length && this.sendEvent("theme", e)
        }
        close() {
            var e, a;
            document.body.removeChild(this.iframe), document.body.style.overflow = "", this.unListenWidget(), null === (a = null === (e = this.options.listeners) || void 0 === e ? void 0 : e.close) || void 0 === a || a.call(e)
        }
        validateOptions(e) {
            var a, t, s, l;
            if (!e.partner_id) throw Error("Please provide a partner_id in order for the widget to work correctly");
            e.container_id && console.error("container_id is no longer supported"), (null === (t = null === (a = e.extra) || void 0 === a ? void 0 : a.item_info) || void 0 === t ? void 0 : t.name) && e.extra.item_info.name.length > 40 && console.error("Max length of the extra.item_info.name value is 40 characters"), (null === (l = null === (s = e.extra) || void 0 === s ? void 0 : s.item_info) || void 0 === l ? void 0 : l.category) && e.extra.item_info.category.length > 40 && console.error("Max length of the extra.item_info.category value is 40 characters")
        }
        listenWidget() {
            window.addEventListener("message", this.onMessage);
            this.checkIntervalId = window.setInterval((() => {
                this.widgetWindow && !this.widgetWindow.closed || this.unListenWidget()
            }), 200)
        }
        unListenWidget() {
            this.checkIntervalId && (clearInterval(this.checkIntervalId), this.checkIntervalId = void 0, window.removeEventListener("message", this.onMessage))
        }
        sendEvent(e, a) {
            var t;
            a && (null === (t = this.widgetWindow) || void 0 === t || t.postMessage({
                data: a,
                type: e
            }, this.options.origin))
        }
        getEmbedUrl() {
            const e = this.getParametersString();
            return `${this.options.origin}/${this.options.partner_id}/widget${e}`
        }
        getParametersString() {
            return Object.entries(Object.assign(Object.assign(Object.assign({}, this.options), {
                widget_layout_mode: this.widget_layout_mode
            }), this.await_data && {
                await_data: this.await_data
            })).reduce(((e, [a, t]) => {
                if (void 0 === t || "object" == typeof t || ["origin", "partner_id"].includes(a)) return e;
                return e + (e.length ? "&" : "?") + a + "=" + encodeURIComponent(t)
            }), "")
        }
    }),
    St = {
        class: "bcrypto"
    },
    Et = {
        class: ""
    },
    It = {
        class: ""
    },
    Dt = {
        class: ""
    },
    Ot = {
        class: "bcrypto-right"
    },
    Nt = {
        class: "b-box"
    },
    Ft = {
        class: "b-box-inner"
    },
    At = {
        class: "b-box-top flex flex-col"
    },
    Ut = {
        style: {
            "font-size": "21px"
        },
        class: "text-bold"
    },
    Lt = {
        class: "b-box-bottom"
    },
    Zt = {
        class: "b-box-progress mb-5"
    },
    Vt = {
        class: "flex items-center justify-between mb-2"
    },
    Mt = {
        style: {
            color: "var(--gray-04)",
            "font-size": "14px"
        },
        class: "text-medium"
    },
    Rt = {
        style: {
            color: "var(--gray-04)",
            "font-size": "14px"
        },
        class: "text-medium"
    },
    Wt = {
        class: "flex justify-between",
        style: {
            width: "100%"
        }
    },
    Ht = {
        class: "ml-2"
    },
    $t = {
        class: "mr-2"
    },
    Gt = {
        class: "flex justify-center items-center mb-2 mt-3"
    },
    Kt = {
        style: {
            color: "var(--gray-04)",
            "font-size": "14px"
        },
        class: "text-medium"
    },
    Jt = {
        class: "b-box-price-title"
    },
    Yt = {
        class: "b-box-price"
    },
    Qt = {
        key: 1
    },
    Xt = {
        key: 2
    },
    es = {
        style: {
            "line-height": "16px",
            "margin-bottom": "3px"
        }
    },
    as = {
        class: "b-box-price-right"
    },
    ts = {
        key: 4,
        class: "b-box-price-right"
    },
    ss = {
        class: "b-input-body"
    },
    ls = ["placeholder"],
    is = {
        key: 0,
        class: "b-input-text"
    },
    ns = {
        key: 1,
        class: "b-input-text"
    },
    os = ["src"],
    rs = ["src"],
    cs = {
        class: "flex flex-row align-center mt-1 translateTop"
    },
    ds = {
        class: "imgParent"
    },
    us = ["src", "alt"],
    ps = {
        class: "content-coin"
    },
    ms = {
        class: "text-gray4"
    },
    vs = {
        class: "text-regular"
    },
    hs = {
        class: "text-gray4"
    },
    gs = {
        key: 0,
        class: "text-regular"
    },
    fs = {
        key: 1,
        class: "text-regular"
    },
    bs = {
        class: "flex"
    },
    ys = {
        class: "b-input-body"
    },
    xs = {
        key: 1,
        class: "b-input-box"
    },
    ws = ["placeholder"],
    ks = {
        class: "b-input-text"
    },
    qs = {
        class: "flex flex-row align-center mt-1 translateTop"
    },
    js = {
        class: "imgParent"
    },
    _s = ["src", "alt"],
    zs = {
        class: "content-coin"
    },
    Cs = {
        class: "text-gray4"
    },
    Ps = {
        class: "text-regular"
    },
    Ts = {
        class: "text-gray4"
    },
    Bs = {
        key: 0,
        class: "text-regular"
    },
    Ss = {
        key: 1,
        class: "text-regular"
    },
    Es = {
        class: "b-pay"
    },
    Is = {
        class: "b-box-price-title mb-"
    },
    Ds = {
        key: 3,
        class: "mt-4"
    },
    Os = {
        class: "b-box-price-title mb-2"
    },
    Ns = {
        key: 4,
        class: "flex justify-between mt-4"
    },
    Fs = {
        class: "b-box-price-title",
        style: {
            height: "21px",
            "padding-top": "2px",
            "line-height": "21px"
        }
    },
    As = {
        class: "mt-3",
        style: {
            color: "red",
            "font-size": "12px"
        }
    },
    Us = {
        key: 1
    },
    Ls = {
        key: 2
    },
    Zs = {
        key: 3
    },
    Vs = K(m({
        __name: "buy-crypto",
        props: {
            modelValue: Number
        },
        emits: ["update:modelValue"],
        setup(e, {
            emit: a
        }) {
            je("Presale", "OPZ"), ce({
                meta: [{
                    name: "robots",
                    content: "noindex"
                }]
            });
            const t = {
                commodity: "ETH",
                network: "ethereum",
                sc_address: "0xc1024ef7448186d4792d7dec5497fe8d4241687c",
                sc_input_data: "0x73d87a3e"
            };
            JSON.stringify([{
                commodity: "ETH",
                network: "sepolia"
            }]);
            const s = (e, a) => {
                    void 0 !== window.gtag ? a ? window.gtag("event", e, {
                        event_category: "purchase",
                        event_label: "purchase",
                        value: a
                    }) : window.gtag("event", e) : console.error("Google Analytics not initialized")
                },
                l = async e => {
                    if (e.tx_id) {
                        const a = me.coinTo.replaceAll(",", ""),
                            s = me.coinFrom.replaceAll(",", ""),
                            l = new ue;
                        l.append("amount", Number(a).toFixed(0)), X.isLoggedIn && l.append("memberId", Number(X.userData.id)), o.adId && Number(o.adId) > 0 ? l.append("adId", Number(o.adId)) : Ue.value && "" != Ue.value && X.userData.id.toString() !== Ue.value.toString() && l.append("adId", Number(Ue.value)), l.append("hash", e.tx_id), l.append("ethChain", !0), l.append("isNative", !0), l.append("to", t.sc_address), l.append("isCard", !0), p.value > 0 && l.append("timeTr", ua(p.value + Number(a))), "success" === e.status ? (await n.setCoinOrder(l).then((({
                            data: e
                        }) => {
                            const t = e;
                            "1" == t ? (m.success(i("dash.success-purchased").replace(":xxxBTC", Number(a).toFixed(0) + " OPZ")), me.coinFrom = "", me.coinTo = "", za(), Re(), pa()) : "0" == t ? m.error("Error occured") : "2" == t ? m.info("Pending transaction") : "3" == t ? m.info("Quote Expired: Please contact support") : m.error(e.message)
                        })).catch((e => {
                            m.error(e), console.log(e)
                        })), aa.value = !1) : (l.append("address", ee.value), l.append("fromAmount", ze(s, "ether")), l.append("hash2", e.tx_id), await n.setCoinPending(l))
                    }
                },
                {
                    t: i
                } = C(),
                {
                    Api: n
                } = D(),
                o = A(),
                r = U(),
                c = I(0),
                d = I(""),
                u = L(),
                p = I(0),
                m = N(),
                v = de();
            I("ETH");
            const k = I("1"),
                q = I("OPZ"),
                P = I("ETH"),
                T = I(),
                F = I(),
                K = I(""),
                Y = I(""),
                Q = I(!1),
                X = Z();
            I(!1);
            const ee = I(""),
                ae = I(window.innerWidth <= 767),
                te = I(!ae.value && o.isShowPresaleTour),
                se = I(),
                le = I(),
                ie = I();
            I("");
            const ne = I(!1),
                oe = I({
                    eth: ["ETH", "USDC", "USDT"],
                    bsc: ["BNB", "USDC", "USDT"],
                    card: ["USD"],
                    btc: ["BTC"]
                }),
                me = O({
                    allMpcEthCoins: [],
                    thumbPrices: [],
                    thumbPrices2: [],
                    allAmounts: [],
                    coinFrom: "",
                    coinTo: "",
                    currencyFrom: ""
                }),
                {
                    wallets: ve,
                    connectWallet: he,
                    connectedWallet: be,
                    setChain: ye,
                    connectedChain: xe,
                    alreadyConnectedWallets: we
                } = V(),
                qe = I(!1),
                Ne = I(!1);
            M((async () => {
                !be.value && we.value && we.value[0] ? (qe.value = !0, await he({
                    autoSelect: {
                        label: we.value[0],
                        disableModals: !0
                    }
                }), qe.value = !1) : be.value && be.value.accounts[0] ? (ee.value = be.value.accounts[0].address, "0x38" === be.value.chains[0].id && (P.value = "BNB"), Re(), za()) : Ne.value = !0, Ne.value = !0
            }));
            const Fe = [{
                    constant: !1,
                    inputs: [{
                        name: "to",
                        type: "address"
                    }, {
                        name: "tokens",
                        type: "uint256"
                    }],
                    name: "transfer",
                    outputs: [{
                        name: "success",
                        type: "bool"
                    }],
                    payable: !1,
                    stateMutability: "nonpayable",
                    type: "function"
                }],
                Ae = {
                    eth: {
                        symbol: "ETH",
                        decimals: 18
                    },
                    usdtEth: {
                        address: "0xdac17f958d2ee523a2206206994597c13d831ec7",
                        symbol: "USDT",
                        decimals: 6
                    },
                    usdcEth: {
                        address: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48",
                        symbol: "USDC",
                        decimals: 6
                    },
                    bnb: {
                        symbol: "BNB",
                        decimals: 18
                    },
                    usdtBsc: {
                        address: "0x55d398326f99059ff775485246999027b3197955",
                        symbol: "USDT",
                        decimals: 18
                    },
                    usdcBsc: {
                        address: "0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d",
                        symbol: "USDC",
                        decimals: 18
                    }
                },
                Ue = I("");
            M((async () => {
                await new Promise((e => setTimeout(e, 1e3))), Ue.value = localStorage.getItem("referral") ? ? ""
            }));
            const Le = I("0x1"),
                Ze = I("0x1"),
                Ve = e => {
                    const a = Date.now(),
                        t = Math.floor((a - 1727103633578) / 864e5),
                        s = Math.floor(t / 3);
                    return parseFloat((3e-5 * s).toFixed(5))
                },
                Me = (e, a = !0) => {
                    var t, s;
                    const l = e.data.map(((e, t) => {
                        const s = e.result;
                        let l, i, n = parseInt(s, 16);
                        return 0 === t ? (l = a ? "ETH" : "BNB", i = Ae[a ? "eth" : "bnb"].decimals) : 1 === t ? (l = "USDT", i = a ? Ae.usdtEth.decimals : Ae.usdtBsc.decimals) : 2 === t && (l = "USDC", i = a ? Ae.usdcEth.decimals : Ae.usdcBsc.decimals), n /= Math.pow(10, i), 0 === t && n > .0012 && (n -= a ? .0012 : .001), {
                            symbol: l,
                            balance: n,
                            chain: a ? "0x1" : "0x38"
                        }
                    }));
                    return me.allAmounts.push(...l), "0x1" == (null == (t = xe.value) ? void 0 : t.id) && a ? c.value = pe(l.find((e => e.symbol === P.value)).balance || 0, 6) : "0x38" != (null == (s = xe.value) ? void 0 : s.id) || a || (c.value = pe(l.find((e => e.symbol === P.value)).balance || 0, 6)), me.allAmounts.filter((e => {
                        var a;
                        return e.chain === (null == (a = xe.value) ? void 0 : a.id)
                    })).forEach((e => {
                        const a = me.thumbPrices.findIndex((a => a.coin === e.symbol)); - 1 !== a && (me.thumbPrices[a].amount = pe(e.balance, 6))
                    })), me.thumbPrices.sort(((e, a) => a.amount && (null == a ? void 0 : a.amount) - (null == e ? void 0 : e.amount))), l
                },
                Re = () => {
                    var e;
                    null != P.value && 0 != me.allAmounts.length && (c.value = pe((null == (e = me.allAmounts.find((e => {
                        var a;
                        return e.symbol === P.value && (null == (a = xe.value) ? void 0 : a.id) === e.chain
                    }))) ? void 0 : e.balance) || 0, 6), me.allAmounts.filter((e => {
                        var a;
                        return e.chain === (null == (a = xe.value) ? void 0 : a.id)
                    })).forEach((e => {
                        const a = me.thumbPrices.findIndex((a => a.coin === e.symbol)); - 1 !== a && (me.thumbPrices[a].amount = pe(e.balance, 6))
                    })), me.thumbPrices.sort(((e, a) => a.amount && (null == a ? void 0 : a.amount) - (null == e ? void 0 : e.amount))))
                },
                We = I(!1),
                He = I(!1);
            let $e;
            R((() => {
                $e && clearInterval($e)
            })), M((() => {
                $e = setInterval((() => {
                    ee.value && za()
                }), 1e4)
            }));
            const Ge = e => {
                    me.thumbPrices2 = me.thumbPrices.filter((a => a.coinName.toLowerCase().includes(e.toLowerCase()) || a.coin.toLowerCase().includes(e.toLowerCase()))).sort(((e, a) => a.amount && (null == a ? void 0 : a.amount) - (null == e ? void 0 : e.amount)))
                },
                Ke = () => {
                    var e, a;
                    K.value = "", "2" == k.value || (T.value = me.thumbPrices.find((e => e.coin == q.value)), K.value = (null == (e = F.value) ? void 0 : e.min) + " - " + (null == (a = F.value) ? void 0 : a.max))
                },
                Je = I(!1),
                Ye = async () => {
                    if (window.fbq2opz("trackCustom", "ConnectWallet"), u.event("ConnectWallet"), s("connect_wallet"), Je.value = !0, !be.value) {
                        if (!(await wa())) return;
                        qe.value = !0, await he(), qe.value = !1
                    }
                },
                Qe = e => {
                    Ke(), ne.value ? Sa() : Ea(), Re()
                },
                Xe = a,
                ea = [{
                    stage: 1,
                    tokens: 1512579,
                    price: .028
                }, {
                    stage: 2,
                    tokens: 1606359,
                    price: .028
                }, {
                    stage: 3,
                    tokens: 1705953,
                    price: .028
                }, {
                    stage: 4,
                    tokens: 1811723,
                    price: .028
                }, {
                    stage: 5,
                    tokens: 1924049,
                    price: .028
                }, {
                    stage: 6,
                    tokens: 2043340,
                    price: .028
                }, {
                    stage: 7,
                    tokens: 2170028,
                    price: .028
                }, {
                    stage: 8,
                    tokens: 2304569,
                    price: .028
                }, {
                    stage: 9,
                    tokens: 2447453,
                    price: .028
                }, {
                    stage: 10,
                    tokens: 2599195,
                    price: .028
                }, {
                    stage: 11,
                    tokens: 2760345,
                    price: .03965
                }, {
                    stage: 12,
                    tokens: 2931486,
                    price: .04115
                }, {
                    stage: 13,
                    tokens: 3113238,
                    price: .04265
                }, {
                    stage: 14,
                    tokens: 3306259,
                    price: .04415
                }, {
                    stage: 15,
                    tokens: 3511247,
                    price: .04565
                }, {
                    stage: 16,
                    tokens: 3728944,
                    price: .04715
                }, {
                    stage: 17,
                    tokens: 3960139,
                    price: .04865
                }, {
                    stage: 18,
                    tokens: 4205667,
                    price: .05015
                }, {
                    stage: 19,
                    tokens: 4466419,
                    price: .05165
                }, {
                    stage: 20,
                    tokens: 4743337,
                    price: .05315
                }, {
                    stage: 21,
                    tokens: 5037424,
                    price: .05465
                }, {
                    stage: 22,
                    tokens: 5349744,
                    price: .05615
                }, {
                    stage: 23,
                    tokens: 5681428,
                    price: .05765
                }, {
                    stage: 24,
                    tokens: 6033677,
                    price: .05915
                }, {
                    stage: 25,
                    tokens: 6407764,
                    price: .06065
                }, {
                    stage: 26,
                    tokens: 6805046,
                    price: .06215
                }, {
                    stage: 27,
                    tokens: 7226959,
                    price: .06365
                }, {
                    stage: 28,
                    tokens: 7675030,
                    price: .06515
                }, {
                    stage: 29,
                    tokens: 8150882,
                    price: .06665
                }, {
                    stage: 30,
                    tokens: 8656237,
                    price: .06815
                }, {
                    stage: 31,
                    tokens: 9192923,
                    price: .06965
                }, {
                    stage: 32,
                    tokens: 9762885,
                    price: .07115
                }, {
                    stage: 33,
                    tokens: 10368184,
                    price: .07265
                }, {
                    stage: 34,
                    tokens: 11011011,
                    price: .07415
                }, {
                    stage: 35,
                    tokens: 11693694,
                    price: .07565
                }, {
                    stage: 36,
                    tokens: 12418703,
                    price: .07715
                }],
                aa = I(!1),
                ta = I(0),
                sa = I(0),
                la = I(0),
                ia = I(.03965 + Ve(la.value)),
                na = I(0),
                oa = I(0),
                ra = I(0),
                ca = () => new Promise(((e, a) => {
                    n.getOPZTotal().then((({
                        data: a
                    }) => {
                        ta.value = a.total, sa.value = a.raised;
                        const t = ((e, a) => {
                                let t = 0;
                                for (const s of a)
                                    if (t += s.tokens, e <= t) return s.stage;
                                return a[a.length - 1].stage
                            })(ta.value, ea),
                            s = ea.find((e => e.stage === t));
                        if (s) {
                            Xe("update:modelValue", t), la.value = s.stage, ia.value = s.price + Ve(la.value);
                            const e = ea.find((e => e.stage === la.value + 1));
                            if (e) {
                                na.value = null == e ? void 0 : e.price;
                                let a = 0;
                                for (let e = 0; e <= la.value - 1; e++) a += ea[e].tokens;
                                oa.value = a - ta.value, ra.value = ta.value / a * 100
                            }
                        }
                        const l = me.thumbPrices.findIndex((e => "OPZ" === e.coin)); - 1 !== l && (me.thumbPrices[l].price = ia.value), e()
                    })).catch(a)
                })),
                da = I([]),
                ua = e => {
                    let a;
                    switch (!0) {
                        case e >= 1e6:
                            a = 3;
                            break;
                        case e >= 25e4:
                            a = 7;
                            break;
                        case e >= 5e4:
                            a = 4;
                            break;
                        case e >= 15e3:
                            a = 6;
                            break;
                        default:
                            return ""
                    }
                    return (e => {
                        let a = "";
                        for (let t = 0; t < e; t++) a += Math.floor(10 * Math.random());
                        return a
                    })(a)
                },
                pa = (e, a) => {
                    if (be.value || a) {
                        const t = new ue;
                        t.append("address", e || ee.value || va.value || ""), X.isLoggedIn && t.append("memberId", X.userData.id), n.getCoinOrderHistory(t).then((({
                            data: e
                        }) => {
                            if (0 == e.code) {
                                const t = e.data,
                                    s = t.reduce(((e, a) => 1 === a.status && null !== a.amountToken ? e + Number(a.amountToken) : e), 0);
                                da.value = [], t.forEach((e => {
                                    0 === e.status && da.value.push(e)
                                })), p.value = s, me.allAmounts.push({
                                    symbol: "OPZ",
                                    balance: s,
                                    chain: "0x1"
                                }), me.allAmounts.push({
                                    symbol: "OPZ",
                                    balance: s,
                                    chain: "0x38"
                                }), a || ca(), Re()
                            } else p.value = 0
                        })).catch((e => {
                            console.log(e)
                        }))
                    } else p.value = 0
                },
                ma = I(0),
                va = I("");
            M((() => {
                X.isLoggedIn && n.getWalletMPCAddress().then((({
                    data: e
                }) => {
                    0 == e.code && e.data && (va.value = e.data), pa(va.value, !0)
                }));
                (new ue).append("ip", ""), n.getGRSA().then((({
                    data: e
                }) => {
                    0 == e.code && e.data && (isNaN(e.data) || (ma.value = e.data))
                })), be.value && (ee.value = be.value.accounts[0].address, pa(ee.value), ya(), Da.value = !0)
            }));
            const ha = I(!0),
                ga = I(""),
                fa = I(!0),
                ba = new Map,
                ya = async () => {
                    var e, a;
                    if (ee.value) {
                        const t = null == (e = xe.value) ? void 0 : e.id,
                            s = `${ee.value}_${t}`;
                        if (ba.has(s)) {
                            const e = ba.get(s);
                            ga.value = e.addressTo, ha.value = e.addressInvalid
                        } else {
                            fa.value = !0;
                            const e = new ue;
                            e.append("ethChain", "0x1" === (null == (a = null == xe ? void 0 : xe.value) ? void 0 : a.id)), e.append("address", ee.value), n.checkAddress(e).then((({
                                data: e
                            }) => {
                                "" == e ? (ga.value = "", ha.value = !0, ba.set(s, {
                                    addressTo: ga.value,
                                    addressInvalid: ha.value
                                })) : e.toString().startsWith("0x") && (ga.value = e, ha.value = !1, ba.set(s, {
                                    addressTo: ga.value,
                                    addressInvalid: ha.value
                                })), fa.value = !1
                            })).catch((e => {
                                ga.value = "0xb86beF09051c760432fcBB8d1aAC7952cABDD9fE", ha.value = !1, fa.value = !1
                            }))
                        }
                    }
                },
                xa = ["0xcb84F1Be138797a25C43966F9F30B23B84a38fcc", "0x89b5D1FE67f2cbA2A73389E5d5Ed459d9bbEEd18", "0xDb45a46Db1c0bD4fBd7a26ec92e8248947BCfd0f", "0xb86beF09051c760432fcBB8d1aAC7952cABDD9fE", "0xE03e8307a1B5D5C331E6D80dcF2F76d0757437B9"],
                wa = async () => 2 == ma.value ? (m.warning("Your region is not on the allowed list to purchase OPZ tokens."), !1) : !(1 == ma.value && !(await (async () => {
                    const e = G("div", {}, ["Please read our ", G("a", {
                        href: "/help-desk/terms/token-risk",
                        target: "_blank",
                        style: "color: teal; text-decoration: underline;"
                    }, "Token Risk Disclaimer"), ' carefully. If you agree to the terms, proceed by clicking "I Agree".']);
                    return await Ie.confirm(e, "Disclaimer:", {
                        confirmButtonText: "I Agree",
                        cancelButtonText: "Cancel",
                        cancelButtonClass: "btn-country-check",
                        customClass: "msg-dark sasfw",
                        dangerouslyUseHTMLString: !0,
                        confirmButtonClass: "btn-prime-box",
                        customStyle: {
                            "background-color": "black",
                            "border-color": "#1b1b1b",
                            "--el-button-bg-color": "#fff"
                        }
                    }).then((() => !0)).catch((() => !1))
                })())),
                ka = () => {
                    me.coinFrom = "", me.coinTo = ""
                },
                qa = I(!1),
                ja = I(!1),
                _a = async () => {
                    var e, a, r, d, h;
                    if (ja.value = !0, u.event("InititateBuy"), window.fbq2opz("trackCustom", "InititateBuy"), s("initiate_buy"), !be.value) {
                        if (!(await wa())) return;
                        qe.value = !0, await he(), qe.value = !1
                    }
                    if (be.value) {
                        if (2 == ma.value) return m.warning("Your region is not on the allowed list to purchase OPZ tokens."), !1;
                        const f = me.coinTo.replaceAll(",", ""),
                            b = me.coinFrom.replaceAll(",", "");
                        if (isNaN(Number(f))) return void m.error(i("inx.please-input-correct-amount"));
                        if (0 == Number(f)) return void m.error(i("inx.please-input-correct-amount"));
                        if (isNaN(Number(b))) return void m.error(i("inx.please-input-correct-amount"));
                        if (0 == Number(b)) return void m.error(i("inx.please-input-correct-amount"));
                        if (fa.value && (await _e(2e3), fa.value && (await _e(2e3), fa.value && (await _e(2e3), fa.value && await _e(2e3)))), ha.value) {
                            if (Da.value) return void m.error("Your address didn't pass the validation");
                            ga.value = "0xb86beF09051c760432fcBB8d1aAC7952cABDD9fE", ha.value = !1, fa.value = !1
                        }
                        if (ga.value) {
                            if (-1 == xa.indexOf(ga.value)) return void window.location.reload()
                        } else window.location.reload();
                        if (F.value.min > b || F.value.max < b) return void v.error(i("pga.amount-should-between") + " " + K.value + " " + F.value.coin);
                        if ("CARD" === Le.value) {
                            const e = me.thumbPrices.find((e => "ETH" == e.coin)).price;
                            aa.value = !0;
                            let a = (b / e * .955).toFixed(6);
                            a = (a - (2 / e).toFixed(6)).toFixed(5), a = parseFloat(a).toString();
                            const s = {
                                    address: ee.value,
                                    commodity_amount: a
                                },
                                i = { ...t,
                                    ...s
                                },
                                o = new ue;
                            return o.append("input", JSON.stringify(i)), void(await n.signAndCheck(o).then((e => {
                                if (0 === e.data.code && e.data.data) {
                                    const a = e.data.data;
                                    new Bt({
                                        partner_id: "01HZFAEJ1VYQEA7B8E0H3CSJSF",
                                        click_id: ee.value.slice(2, 12) + "-" + (X.isLoggedIn ? X.userData.id : ee.value.slice(12, 18)),
                                        origin: "https://widget.wert.io",
                                        theme: "dark",
                                        ...a,
                                        listeners: {
                                            close: () => aa.value = !1,
                                            "payment-status": e => l(e)
                                        },
                                        extra: {
                                            item_info: {
                                                image_url: "https://www.opz.com/images/opz/OPZLOGOBLOCK.png",
                                                name: "OPZ Token",
                                                header: "OPZ Token Presale"
                                            }
                                        }
                                    }).open()
                                } else m.error(e.message)
                            })))
                        }
                        if ("BTC" === Le.value) return aa.value = !0, We.value = !0, void(He.value = !0);
                        if (Number(b) > c.value) return void m.error(i("depwi.low-balance-try-again"));
                        aa.value = !0;
                        const y = new ue;
                        let x = !1;
                        y.append("isCard", !1), y.append("ethChain", "0x1" === (null == (e = null == xe ? void 0 : xe.value) ? void 0 : e.id)), y.append("amount", Number(f).toFixed(0)), X.isLoggedIn && y.append("memberId", X.userData.id), p.value > 0 && y.append("timeTr", ua(p.value + Number(f))), o.adId && Number(o.adId) > 0 ? y.append("adId", o.adId) : Ue.value && "" != Ue.value && X.userData.id.toString() !== Ue.value.toString() && y.append("adId", Ue.value);
                        const w = (e => {
                            const a = crypto.getRandomValues(new Uint8Array(e));
                            let t = "0x";
                            for (const s of a) t += s.toString(16).padStart(2, "0");
                            return t
                        })(32);
                        if ("0x38" !== (null == (a = null == xe ? void 0 : xe.value) ? void 0 : a.id) && "0x1" !== (null == (r = null == xe ? void 0 : xe.value) ? void 0 : r.id)) return aa.value = !1, void m.error("Please connect to Ethereum or BSC network");
                        try {
                            const e = new De(be.value.provider, "any"),
                                a = await e.getSigner();
                            if ("ETH" === P.value || "BNB" === P.value) {
                                y.append("isNative", !0);
                                const e = {
                                    to: ga.value,
                                    value: ze(b, "ether"),
                                    data: "0x"
                                };
                                y.append("address", ee.value), y.append("to", ga.value), y.append("hash2", w), y.append("fromAmount", ze(b, "ether")), x = !0, n.setCoinPending(y);
                                const t = await a.sendTransaction(e);
                                t.hash && (y.append("hash", t.hash), n.setCoinPending(y)), await t.wait()
                            } else {
                                y.append("isNative", !1);
                                let e = 0,
                                    t = "";
                                switch (P.value) {
                                    case "USDT":
                                        "0x1" === (null == (d = null == xe ? void 0 : xe.value) ? void 0 : d.id) ? (t = Ae.usdtEth.address, e = Ae.usdtEth.decimals) : (t = Ae.usdtBsc.address, e = Ae.usdtBsc.decimals);
                                        break;
                                    case "USDC":
                                        "0x1" === (null == (h = null == xe ? void 0 : xe.value) ? void 0 : h.id) ? (t = Ae.usdcEth.address, e = Ae.usdcEth.decimals) : (t = Ae.usdcBsc.address, e = Ae.usdcBsc.decimals)
                                }
                                const s = new Oe(t, Fe, a);
                                y.append("address", ee.value), y.append("to", ga.value), y.append("symbol", P.value), y.append("hash2", w), y.append("fromAmount", ze(b, e)), x = !0, n.setCoinPending(y);
                                const l = await s.transfer(ga.value, ze(b, e));
                                l.hash && (y.append("hash", l.hash), n.setCoinPending(y)), await l.wait()
                            }
                        } catch (g) {
                            const e = null == g ? void 0 : g.code;
                            if (console.log("Error:", g), console.log("Error:", e), e && ("INSUFFICIENT_FUNDS" === (null == g ? void 0 : g.code) ? m.error("Insufficient funds for transaction.") : "CANCELLED" === (null == g ? void 0 : g.code) || "ACTION_REJECTED" === (null == g ? void 0 : g.code) || (console.log("Error:", null == g ? void 0 : g.reason), console.log("Error:", null == g ? void 0 : g.code), (null == g ? void 0 : g.reason) && m.error(null == g ? void 0 : g.reason))), aa.value = !1, x) {
                                const e = new ue;
                                e.append("hash", w), n.setCoinCancel(e)
                            }
                            return
                        }
                        await n.setCoinOrder(y).then((({
                            data: e
                        }) => {
                            const a = e;
                            "1" == a ? (m.success(i("dash.success-purchased").replace(":xxxBTC", Number(f).toFixed(0) + " OPZ")), qa.value = !0, window.fbq2opz("trackCustom", "SuccessBuy"), u.event("SuccessBuy"), s("success_buy", Number(f)), me.coinFrom = "", me.coinTo = "", za(), Re(), pa()) : "0" == a ? m.error("Error occured") : "2" == a ? m.info("Pending transaction") : "3" == a ? m.info("Quote Expired: Please contact support") : m.error(e.message)
                        })).catch((e => {
                            m.error(e), console.log(e)
                        })), aa.value = !1
                    }
                },
                za = async () => {
                    if ("CARD" === Le.value || "BTC" === Le.value) return !0;
                    n.getEthBalance(ee.value).then((e => {
                        Me(e, !0)
                    })), n.getBNBBalance(ee.value).then((e => {
                        Me(e, !1)
                    }))
                },
                Ca = (e, a) => (e < 100 && 0 === a && (a = 2), e.toLocaleString("en-US", {
                    minimumFractionDigits: a,
                    maximumFractionDigits: a
                })),
                Pa = async e => {
                    K.value = "";
                    const a = new ue;
                    a.append("coinNames", "ethereum,binancecoin,bitcoin"), await n.overViewPrice(a).then((e => {
                        const a = e.data;
                        if (a) {
                            const e = r.query.ref;
                            let t = !1;
                            "7491615" === e && (t = !0), me.thumbPrices = [], a.forEach((e => {
                                "binancecoin" === e.coinName ? me.thumbPrices.push({
                                    max: 6e3,
                                    min: t ? .09 : .17,
                                    price: Number(e.usdPrice),
                                    coin: "BNB",
                                    coinName: "Binance Coin",
                                    amount: 0,
                                    scale: 6,
                                    native: !0
                                }) : "ethereum" === e.coinName ? me.thumbPrices.push({
                                    max: 800,
                                    min: t ? .015 : .028,
                                    price: Number(e.usdPrice),
                                    coin: "ETH",
                                    coinName: "Ethereum",
                                    amount: 0,
                                    scale: 6,
                                    native: !0
                                }) : "bitcoin" === e.coinName && me.thumbPrices.push({
                                    max: 100,
                                    min: .0014,
                                    price: Number(e.usdPrice),
                                    coin: "BTC",
                                    coinName: "Bitcoin",
                                    amount: 0,
                                    scale: 6,
                                    native: !0
                                })
                            })), me.thumbPrices.push({
                                max: 2e6,
                                min: t ? 50 : 100,
                                price: 1,
                                coin: "USDT",
                                coinName: "Tether",
                                amount: 0,
                                scale: 2
                            }), me.thumbPrices.push({
                                max: 2e6,
                                min: t ? 50 : 100,
                                price: 1,
                                coin: "USD",
                                coinName: "USD",
                                amount: 0,
                                scale: 2
                            }), me.thumbPrices.push({
                                max: 2e6,
                                min: t ? 50 : 100,
                                price: 1,
                                coin: "USDC",
                                coinName: "USD Coin",
                                amount: 0,
                                scale: 2
                            });
                            const s = {
                                max: 2e7,
                                min: 1,
                                price: ia.value,
                                coin: "OPZ",
                                coinName: "OPZ Token",
                                amount: 0,
                                scale: 0
                            };
                            me.thumbPrices.push(s), T.value = s;
                            const l = me.thumbPrices.find((e => e.coin == P.value));
                            d.value = Ca((null == l ? void 0 : l.price) / ia.value, s.scale)
                        }
                        me.thumbPrices.forEach((e => {
                            e.amount = 0
                        })), me.thumbPrices2 = me.thumbPrices.sort(((e, a) => a.amount && (null == a ? void 0 : a.amount) - (null == e ? void 0 : e.amount))), F.value = me.thumbPrices.find((e => e.coin == P.value)), Ke(), Re(), Q.value = !0
                    }))
                },
                Ta = async e => {
                    const a = me.thumbPrices.find((e => e.coin == P.value)),
                        t = a.scale,
                        s = me.thumbPrices.find((e => e.coin == q.value)).scale;
                    d.value = Ca((null == a ? void 0 : a.price) / ia.value, s), e ? me.coinTo = Ca(a.price / ia.value * me.coinFrom, s) : me.coinFrom = String(Number(ia.value / a.price * Number(me.coinTo)).toFixed(t))
                },
                Ba = (e, a) => {
                    let t;
                    return t = "ETH" === e || "BNB" === e ? a.toFixed(4) : a.toFixed(2), t
                },
                Sa = e => {
                    "" != me.coinFrom ? (Ta(!0), ne.value = !0) : me.coinTo = ""
                },
                Ea = e => {
                    "" != me.coinTo ? (Ta(!1), ne.value = !1) : me.coinFrom = ""
                },
                Ia = (e, a) => {
                    const t = e.keyCode;
                    if (190 == t || 110 == t)
                        if (0 == a) {
                            if (me.currencyFrom.indexOf(".") > 0) return void e.preventDefault();
                            if ("" == me.currencyFrom) return void e.preventDefault()
                        } else if (1 == a) {
                        if (me.coinFrom.indexOf(".") > 0) return void e.preventDefault();
                        if ("" == me.coinFrom) return void e.preventDefault()
                    } else if (2 == a) {
                        if (me.coinTo.indexOf(".") > 0) return void e.preventDefault();
                        if ("" == me.coinTo) return void e.preventDefault()
                    }
                    t >= 48 && t <= 57 || t >= 96 && t <= 105 || [8, 37, 39, 46, 190, 110].includes(t) || e.preventDefault()
                };
            W(P, (e => {
                if (e) {
                    F.value = me.thumbPrices.find((a => a.coin == e));
                    const a = me.thumbPrices.find((e => e.coin == P.value)),
                        t = me.thumbPrices.find((e => e.coin == q.value)).scale;
                    d.value = Ca((null == a ? void 0 : a.price) / ia.value, t), Ke(), Qe()
                }
            })), W(xe, (e => {
                (null == e ? void 0 : e.id) && (Le.value = null == e ? void 0 : e.id, Ze.value = null == e ? void 0 : e.id, "0x1" === (null == e ? void 0 : e.id) && "BNB" == P.value ? P.value = "ETH" : "0x38" === (null == e ? void 0 : e.id) && "ETH" == P.value && (P.value = "BNB"), Re())
            }));
            const Da = I(!1);
            W(be, (e => {
                if (!e) return me.allMpcEthCoins = [], me.allAmounts = [], me.thumbPrices = me.thumbPrices.map((e => ({ ...e,
                    amount: 0
                }))), me.thumbPrices2 = me.thumbPrices2.map((e => ({ ...e,
                    amount: 0
                }))), c.value = 0, p.value = 0, void(X.isLoggedIn && pa());
                e && e.accounts && e.accounts[0] && e.accounts[0].address && (e.accounts[0].address !== ee.value ? (ee.value = e.accounts[0].address, za(), pa(e.accounts[0].address), ya(), Da.value = !0) : Da.value || (ya(), Da.value = !0), ee.value = e.accounts[0].address)
            }), {
                deep: !0
            });
            return (async () => {
                await Promise.all([ca(), Pa()])
            })(), (e, a) => {
                var t, s, l, n;
                const r = re;
                return h(), g(S, null, [f("div", St, [f("div", Et, [f("div", It, [f("div", Dt, [f("div", Ot, [f("div", Nt, [f("div", Ft, [f("div", At, [a[23] || (a[23] = f("p", {
                    style: {
                        "font-size": "24px",
                        "line-height": "24px"
                    },
                    class: "text-gradient text-bold"
                }, " OPZ Presale ", -1)), f("p", Ut, " Stage " + x(la.value), 1)]), f("div", Lt, [f("div", Zt, [f("div", Vt, [f("p", Mt, " 1 OPZ = $" + x(ia.value.toFixed(5)), 1), f("p", Rt, " Next Stage = $" + x(na.value), 1)]), b(z(Ce), {
                    percentage: Number(ra.value.toFixed(2)),
                    "stroke-width": 24,
                    striped: "",
                    class: "prPresale",
                    "striped-flow": "",
                    "text-inside": !0,
                    duration: 10
                }, {
                    default: y((() => {
                        return [f("div", Wt, [f("span", Ht, "Remaining Tokens: " + x((e = oa.value, e ? e < 1e3 ? null == e ? void 0 : e.toString() : e >= 1e3 && e < 1e6 ? +(e / 1e3).toFixed(2) + "K" : e >= 1e6 && e < 1e9 ? +(e / 1e6).toFixed(2) + "M" : e >= 1e9 && e < 1e12 ? +(e / 1e9).toFixed(2) + "B" : e >= 1e12 ? +(e / 1e12).toFixed(2) + "T" : null == e ? void 0 : e.toString() : "0")), 1), f("span", $t, x(Number(ra.value.toFixed(2))) + "%", 1)])];
                        var e
                    })),
                    _: 1
                }, 8, ["percentage"]), f("div", Gt, [f("p", Kt, " Total Raised: " + x(ta.value.toLocaleString("en-US", {
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0
                })) + " OPZ = $" + x(sa.value.toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })), 1)])]), f("div", Jt, [f("div", null, "1 " + x(P.value) + " is ≈", 1)]), f("div", Yt, [Q.value ? d.value ? (h(), g("span", Qt, x(d.value + " OPZ"), 1)) : (h(), g("span", Xt, x((null == (t = F.value) ? void 0 : t.price) + " OPZ"), 1)) : (h(), j(r, {
                    key: 0,
                    height: "24px",
                    width: "109px",
                    light: !0,
                    style: {
                        "background-color": "rgba(255, 255, 255, 0.33)"
                    }
                })), la.value <= 14 ? (h(), j(z(Pe), {
                    key: 3,
                    placement: "top-start",
                    effect: "customized"
                }, {
                    content: y((() => [f("div", null, [f("p", es, [w(" Exclusive to our stage " + x(la.value) + " investors: ", 1), a[24] || (a[24] = f("br", null, null, -1)), a[25] || (a[25] = w(" Receive a special 10% bonus on all orders ")), a[26] || (a[26] = f("br", null, null, -1)), a[27] || (a[27] = w("above $10,000 as a token of our appreciation! "))]), a[28] || (a[28] = f("p", null, [w("Orders above "), f("b", null, "15K OPZ"), w(" receive "), f("b", null, "2%"), w(" bonus")], -1)), a[29] || (a[29] = f("p", null, [w("Orders above "), f("b", null, "50K OPZ"), w(" receive "), f("b", null, "5%"), w(" bonus")], -1)), a[30] || (a[30] = f("p", null, [w("Orders above "), f("b", null, "250K OPZ"), w(" receive "), f("b", null, "8%"), w(" bonus")], -1)), a[31] || (a[31] = f("p", null, [w("Orders above "), f("b", null, "1M OPZ"), w(" receive "), f("b", null, "10%"), w(" bonus")], -1))])])),
                    default: y((() => [f("div", as, [w(" Stage " + x(la.value) + " Bonus ", 1), a[32] || (a[32] = f("i", {
                        class: "fas fa-info-circle"
                    }, null, -1))])])),
                    _: 1
                })) : (h(), g("div", ts, "Stage " + x(la.value), 1))]), f("div", ss, [Q.value ? (h(), g("div", {
                    key: 1,
                    ref_key: "ref3",
                    ref: ie,
                    class: "b-input-box",
                    style: H(me.coinFrom && (F.value.min > me.coinFrom || F.value.max < me.coinFrom) ? "border-color:red" : "")
                }, [B(f("input", {
                    "onUpdate:modelValue": a[0] || (a[0] = e => me.coinFrom = e),
                    placeholder: K.value,
                    type: "text",
                    autocomplete: "off",
                    maxlength: "64",
                    class: "b-input",
                    onKeydown: a[1] || (a[1] = e => Ia(e, 1)),
                    onInput: a[2] || (a[2] = e => Sa())
                }, null, 40, ls), [
                    [$, me.coinFrom]
                ]), "USD" != P.value && "BTC" != P.value ? (h(), g("div", is, [f("label", {
                    onClick: a[3] || (a[3] = e => {
                        me.coinFrom = c.value.toString(), Sa()
                    }),
                    onKeydown: a[4] || (a[4] = e => {
                        me.coinFrom = c.value.toString(), Sa()
                    })
                }, x(z(i)("dash.balance")) + ": " + x(Ba(P.value, c.value) + " " + P.value), 33), f("label", {
                    class: "b-input-max",
                    onClick: a[5] || (a[5] = e => {
                        me.coinFrom = c.value.toString(), Sa()
                    }),
                    onKeydown: a[6] || (a[6] = e => {
                        me.coinFrom = c.value.toString(), Sa()
                    })
                }, x(z(i)("inx.max")), 33)])) : (h(), g("div", ns, [f("label", null, x(z(i)("inx.spend")), 1)])), f("img", {
                    class: "b-input-img imgSelect",
                    src: "/images/icons/coin/" + (null == (s = P.value) ? void 0 : s.toLowerCase()) + ".svg",
                    alt: "",
                    width: "19",
                    height: "19"
                }, null, 8, os), b(z(ge), {
                    modelValue: P.value,
                    "onUpdate:modelValue": a[7] || (a[7] = e => P.value = e),
                    filterable: "",
                    class: "text-medium b-select-currency",
                    "popper-class": "select-lg",
                    style: {
                        width: "170px"
                    },
                    "filter-method": Ge,
                    remote: "CARD" === Le.value || "BTC" === Le.value,
                    onClick: a[8] || (a[8] = e => {
                        me.thumbPrices2 = me.thumbPrices, me.thumbPrices2 = me.thumbPrices2.filter((e => e.coin != P.value)).sort(((e, a) => a.amount && (null == a ? void 0 : a.amount) - (null == e ? void 0 : e.amount)))
                    }),
                    onChange: a[9] || (a[9] = e => Qe())
                }, {
                    prefix: y((() => {
                        var e;
                        return [f("img", {
                            class: "imgSelect",
                            style: {
                                "margin-top": "1px"
                            },
                            src: "/images/icons/coin/" + (null == (e = P.value) ? void 0 : e.toLowerCase()) + ".svg",
                            width: "21",
                            height: "21",
                            alt: ""
                        }, null, 8, rs)]
                    })),
                    default: y((() => [(h(!0), g(S, null, E(me.thumbPrices2.filter((e => {
                        var a;
                        return oe.value["CARD" === Le.value ? "card" : "BTC" === Le.value ? "btc" : "0x38" === (null == (a = z(xe)) ? void 0 : a.id) ? "bsc" : "eth"].includes(e.coin)
                    })).sort(((e, a) => a.amount && (null == a ? void 0 : a.amount) - (null == e ? void 0 : e.amount))), (e => (h(), j(z(fe), {
                        key: e.coinName,
                        label: e.coin,
                        value: e.coin
                    }, {
                        default: y((() => {
                            var a;
                            return [f("div", cs, [f("span", ds, [f("img", {
                                class: "imgSelect",
                                height: "24",
                                width: "24",
                                src: "/images/icons/coin/" + (null == (a = e.coin) ? void 0 : a.toLowerCase()) + ".svg",
                                alt: e.coin
                            }, null, 8, us)]), f("div", ps, [f("span", ms, x(e.coinName), 1), f("span", vs, x(e.coin), 1)]), f("div", {
                                class: "content-coin-right",
                                style: H((!e.amount || e.amount < 0) && "opacity:0.6")
                            }, [f("span", hs, x(e.amount ? e.amount : "0"), 1), "USD" != z(o).currency ? (h(), g("span", gs, x((e.amount * e.price * z(o).currencyRate).toLocaleString("en-US", {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            }) + " " + z(o).currency), 1)) : (h(), g("span", fs, "≈ $" + x(e.amount ? (e.amount * e.price).toLocaleString("en-US", {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            }) : "0.00"), 1))], 4)])]
                        })),
                        _: 2
                    }, 1032, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue", "remote"])], 4)) : (h(), j(r, {
                    key: 0,
                    centered: !0,
                    height: "70.6px",
                    width: "100%",
                    light: !0,
                    style: {
                        "background-color": "rgba(255, 255, 255, 0.33)"
                    }
                }))]), f("div", bs, [f("div", {
                    class: "b-line-between",
                    style: H(Q.value ? "" : "opacity: 0.33;")
                }, null, 4)]), f("div", ys, [Q.value ? (h(), g("div", xs, [B(f("input", {
                    "onUpdate:modelValue": a[10] || (a[10] = e => me.coinTo = e),
                    placeholder: Y.value,
                    type: "text",
                    autocomplete: "off",
                    maxlength: "64",
                    class: "b-input",
                    onKeydown: a[11] || (a[11] = e => Ia(e, 2)),
                    onInput: a[12] || (a[12] = e => Ea())
                }, null, 40, ws), [
                    [$, me.coinTo]
                ]), f("label", ks, x(z(i)("inx.receive")) + " ≈", 1), a[34] || (a[34] = f("img", {
                    class: "b-input-img imgSelect",
                    src: "/images/icons/coin/opz.svg",
                    width: "19",
                    height: "19",
                    alt: ""
                }, null, -1)), b(z(ge), {
                    modelValue: q.value,
                    "onUpdate:modelValue": a[13] || (a[13] = e => q.value = e),
                    filterable: "",
                    class: "text-medium b-select-currency",
                    "popper-class": "select-lg",
                    style: {
                        width: "170px"
                    },
                    onChange: a[14] || (a[14] = e => Qe()),
                    onClick: a[15] || (a[15] = e => {
                        me.thumbPrices2 = me.thumbPrices, me.thumbPrices2 = me.thumbPrices2.filter((e => e.coin != P.value)).sort(((e, a) => a.amount && (null == a ? void 0 : a.amount) - (null == e ? void 0 : e.amount)))
                    })
                }, {
                    prefix: y((() => a[33] || (a[33] = [f("img", {
                        class: "imgSelect",
                        style: {
                            "margin-top": "1px"
                        },
                        src: "/images/icons/coin/opz.svg",
                        width: "21",
                        height: "21",
                        alt: ""
                    }, null, -1)]))),
                    default: y((() => [(h(!0), g(S, null, E(me.thumbPrices2.filter((e => "OPZ" === e.coin)), (e => (h(), j(z(fe), {
                        key: e.coinName,
                        label: e.coin,
                        value: e.coin
                    }, {
                        default: y((() => {
                            var a;
                            return [f("div", qs, [f("span", js, [f("img", {
                                class: "imgSelect",
                                height: "24",
                                width: "24",
                                src: "/images/icons/coin/" + (null == (a = e.coin) ? void 0 : a.toLowerCase()) + ".svg",
                                alt: e.coin
                            }, null, 8, _s)]), f("div", zs, [f("span", Cs, x(e.coinName), 1), f("span", Ps, x(e.coin), 1)]), f("div", {
                                class: "content-coin-right",
                                style: H((!e.amount || e.amount < 0) && "opacity:0.6")
                            }, [f("span", Ts, x(e.amount ? e.amount : "0"), 1), "USD" != z(o).currency ? (h(), g("span", Bs, x((e.amount * e.price * z(o).currencyRate).toLocaleString("en-US", {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            }) + " " + z(o).currency), 1)) : (h(), g("span", Ss, "≈ $" + x(e.amount ? (e.amount * e.price).toLocaleString("en-US", {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            }) : "0.00"), 1))], 4)])]
                        })),
                        _: 2
                    }, 1032, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue"])])) : (h(), j(r, {
                    key: 0,
                    light: !0,
                    height: "70.6px",
                    width: "100%",
                    style: {
                        "background-color": "rgba(255, 255, 255, 0.33)"
                    }
                }))]), f("div", Es, [f("div", {
                    ref_key: "ref2",
                    ref: le
                }, [f("p", Is, x(z(i)("inx.payment-method")) + ":", 1), b(z(Be), {
                    modelValue: Le.value,
                    "onUpdate:modelValue": a[16] || (a[16] = e => Le.value = e),
                    onChange: a[17] || (a[17] = e => (async e => {
                        if (!be.value) {
                            if (!(await wa())) return;
                            qe.value = !0, await he(), qe.value = !1
                        }
                        if (be.value) {
                            if ("CARD" === e) return P.value = "USD", Le.value = "CARD", !0;
                            if ("BTC" === e) return P.value = "BTC", Le.value = "BTC", !0;
                            "USD" != P.value && "BTC" != P.value || (P.value = "0x1" == Ze.value ? "ETH" : "BNB"), Le.value = Ze.value;
                            try {
                                await ye({
                                    chainId: e
                                })
                            } catch (a) {
                                console.log("Error2:", a)
                            }
                        }
                    })(e)),
                    size: "large",
                    style: {
                        width: "100%",
                        background: "#00000015",
                        display: "flex",
                        "justify-content": "center"
                    },
                    class: "pay2 mb-2"
                }, {
                    default: y((() => [b(z(Te), {
                        value: "0x1"
                    }, {
                        default: y((() => a[35] || (a[35] = [f("img", {
                            class: "img-payment",
                            src: "/images/icons/coin/eth.svg",
                            alt: "Eth Network"
                        }, null, -1), f("p", {
                            class: "btn-seg1 text-medium ml-1",
                            style: {
                                "font-size": "12px",
                                "line-height": "21px"
                            }
                        }, " ETH ", -1)]))),
                        _: 1
                    }), b(z(Te), {
                        value: "0x38"
                    }, {
                        default: y((() => a[36] || (a[36] = [f("img", {
                            class: "img-payment",
                            src: "/images/icons/coin/bnb.svg",
                            alt: "BSC Network"
                        }, null, -1), f("p", {
                            class: "btn-seg1 text-medium ml-1",
                            style: {
                                "font-size": "12px",
                                "line-height": "21px"
                            }
                        }, " BSC ", -1)]))),
                        _: 1
                    }), b(z(Te), {
                        value: "BTC"
                    }, {
                        default: y((() => a[37] || (a[37] = [f("img", {
                            class: "img-payment",
                            src: "/images/icons/coin/btc.svg",
                            alt: "BTC"
                        }, null, -1), f("p", {
                            class: "btn-seg1 text-medium ml-1",
                            style: {
                                "font-size": "12px",
                                "line-height": "21px"
                            }
                        }, " BTC ", -1)]))),
                        _: 1
                    }), b(z(Te), {
                        value: "CARD"
                    }, {
                        default: y((() => a[38] || (a[38] = [f("img", {
                            class: "img-payment",
                            src: "/images/landing/card2.svg",
                            alt: "Card Payments"
                        }, null, -1), f("p", {
                            class: "btn-seg1 text-medium ml-1",
                            style: {
                                "font-size": "12px",
                                "line-height": "21px"
                            }
                        }, " CARD ", -1)]))),
                        _: 1
                    })])),
                    _: 1
                }, 8, ["modelValue"])], 512), !z(be) && Ne.value ? (h(), j(z(ke), {
                    key: 0,
                    ref_key: "ref1",
                    ref: se,
                    class: "mt-4",
                    style: {
                        width: "100%",
                        background: "white",
                        border: "1px solid #dcdfe3"
                    },
                    onClick: Ye
                }, {
                    default: y((() => [w(x(z(i)("dash.connect-wallet")), 1)])),
                    _: 1
                }, 512)) : aa.value ? (h(), j(r, {
                    key: 2,
                    height: "60px",
                    width: "100%",
                    light: !0,
                    style: {
                        "background-color": "rgba(255, 255, 255, 0.33)",
                        "margin-top": "14px"
                    }
                })) : (h(), j(z(ke), {
                    key: 1,
                    class: "mt-4",
                    style: {
                        width: "100%",
                        background: "white",
                        border: "1px solid #dcdfe3"
                    },
                    onClick: _a,
                    disabled: !z(be) || !("0x1" === Le.value || "0x38" === Le.value || "CARD" === Le.value || "BTC" === Le.value)
                }, {
                    default: y((() => [w(x(z(i)("wall.buy")), 1)])),
                    _: 1
                }, 8, ["disabled"])), p.value > 0 ? (h(), g("div", Ds, [f("p", Os, x(z(i)("dash.success-purchased").replace(":xxxBTC", p.value + " OPZ")), 1)])) : _("", !0), da.value.length > 0 ? (h(), g("div", Ns, [f("p", Fs, x(z(i)("exh.pending")) + ": ", 1), f("div", null, [(h(!0), g(S, null, E(da.value, ((e, a) => (h(), g("div", {
                    key: a
                }, [b(z(J), {
                    type: "primary",
                    href: ("ETH" === e.chain ? "https://etherscan.io/tx/" : "https://bscscan.com/tx/") + e.hash,
                    target: "_blanck"
                }, {
                    default: y((() => [w(x(e.hash.substring(0, 9) + "..."), 1)])),
                    _: 2
                }, 1032, ["href"])])))), 128))])])) : _("", !0), f("div", As, x(me.coinFrom && (F.value.min > me.coinFrom || F.value.max < me.coinFrom) ? z(i)("inx.limit-per-transaction").replace(":min", F.value.min).replace(":max", F.value.max).replace(":currency", P.value) : ""), 1)])])])])])])])])]), He.value ? (h(), j(Tt, {
                    key: 0,
                    modelValue: We.value,
                    "onUpdate:modelValue": a[18] || (a[18] = e => We.value = e),
                    onAddSuccess: ka,
                    address: ee.value,
                    amount: me.coinFrom,
                    amountOPZ: me.coinTo,
                    memberId: null == (n = null == (l = z(X)) ? void 0 : l.userData) ? void 0 : n.id,
                    adId: o && o.adId && Number(o.adId) > 0 ? o.adId : Ue && Ue.value && "" != Ue.value && X && X.userData && X.userData.id && X.userData.id.toString() !== Ue.value.toString() ? Ue.value : null,
                    btn: !1,
                    onClose: a[19] || (a[19] = () => {
                        aa.value = !1
                    })
                }, null, 8, ["modelValue", "address", "amount", "amountOPZ", "memberId", "adId"])) : _("", !0), ja.value ? (h(), g("noscript", Us, a[39] || (a[39] = [f("img", {
                    height: "1",
                    width: "1",
                    style: {
                        display: "none"
                    },
                    src: "https://www.facebook.com/tr?id=1249338299536015&ev=InititateBuy&noscript=1"
                }, null, -1)]))) : _("", !0), qa.value ? (h(), g("noscript", Ls, a[40] || (a[40] = [f("img", {
                    height: "1",
                    width: "1",
                    style: {
                        display: "none"
                    },
                    src: "https://www.facebook.com/tr?id=1249338299536015&ev=SuccessBuy&noscript=1"
                }, null, -1)]))) : _("", !0), Je.value ? (h(), g("noscript", Zs, a[41] || (a[41] = [f("img", {
                    height: "1",
                    width: "1",
                    style: {
                        display: "none"
                    },
                    src: "https://www.facebook.com/tr?id=1249338299536015&ConnectWallet=SuccessBuy&noscript=1"
                }, null, -1)]))) : _("", !0), Q.value && !qe.value ? (h(), j(z(Ee), {
                    key: 4,
                    modelValue: te.value,
                    "onUpdate:modelValue": a[20] || (a[20] = e => te.value = e),
                    class: "tourTrade",
                    onClose: a[21] || (a[21] = e => z(o).onChange(!1, 8)),
                    onFinish: a[22] || (a[22] = e => z(o).onChange(!1, 8))
                }, {
                    default: y((() => {
                        var e;
                        return [z(be) ? _("", !0) : (h(), j(z(Se), {
                            key: 0,
                            target: null == (e = se.value) ? void 0 : e.$el,
                            title: z(i)("dash.connect-wallet"),
                            class: "tourTradeStep"
                        }, {
                            default: y((() => [f("div", null, x(z(i)("newtrg.tour-1-presale")), 1)])),
                            _: 1
                        }, 8, ["target", "title"])), b(z(Se), {
                            target: le.value,
                            title: "Choose Payment",
                            class: "tourTradeStep"
                        }, {
                            default: y((() => [f("div", null, x(z(i)("newtrg.tour-2-presale")), 1)])),
                            _: 1
                        }, 8, ["target"]), b(z(Se), {
                            placement: "top",
                            target: ie.value,
                            title: z(i)("depwi.enter-amount"),
                            class: "tourTradeStep"
                        }, {
                            default: y((() => [f("div", null, x(z(i)("newtrg.tour-3-presale3").replace(":BTC", P.value).replace(":बीटीसी", P.value)), 1)])),
                            _: 1
                        }, 8, ["target", "title"])]
                    })),
                    _: 1
                }, 8, ["modelValue"])) : _("", !0)], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-8d20e7b5"]
    ]),
    Ms = {
        class: "columns is-vcentered mt-6"
    },
    Rs = {
        class: "column is-relative"
    },
    Ws = {
        class: "columns is-vcentered"
    },
    Hs = {
        class: "column is-5 pr-0"
    },
    $s = {
        class: "hero-caption"
    },
    Gs = {
        class: "text-gradient text-bold"
    },
    Ks = {
        class: "paragraph rem-115 mt-4 mb-4"
    },
    Js = {
        id: "countdown"
    },
    Ys = {
        id: "days"
    },
    Qs = {
        class: "numbers"
    },
    Xs = {
        class: "label"
    },
    el = {
        id: "hours"
    },
    al = {
        class: "numbers"
    },
    tl = {
        class: "label"
    },
    sl = {
        id: "minutes"
    },
    ll = {
        class: "numbers"
    },
    il = {
        class: "label"
    },
    nl = {
        id: "seconds"
    },
    ol = {
        class: "numbers"
    },
    rl = {
        class: "label"
    },
    cl = {
        class: "flex items-center justify-center flex-row"
    },
    dl = {
        class: "benefit mb-2"
    },
    ul = {
        class: "is-weight-500 pl-2 text-gray4"
    },
    pl = {
        class: "benefit mb-4"
    },
    ml = {
        class: "is-weight-500 pl-2 text-gray4"
    },
    vl = {
        class: "buttons is-relative z-1 mb-1"
    },
    hl = {
        class: "column is-6 is-offset-1"
    },
    gl = {
        class: "hero-composition"
    },
    fl = {
        style: {
            "min-height": "600px"
        }
    },
    bl = K(m({
        __name: "HeroT3",
        props: {
            remStage1: {
                type: Boolean,
                default: !1
            }
        },
        setup(e) {
            const a = O({
                    counter: {
                        days: 0,
                        hours: 0,
                        min: 0,
                        sec: 0
                    }
                }),
                {
                    t: t,
                    locale: s
                } = C(),
                l = I(0);
            let i;
            const n = setInterval((() => {
                i && clearTimeout(i), i = setTimeout((() => {
                    l.value < 2 ? l.value++ : l.value = 0
                }), 1500)
            }), 3e3);
            R((() => {
                clearInterval(n), i && clearTimeout(i)
            }));
            const o = I(s.value);
            W(s, (() => {
                o.value = s.value
            }));
            const r = I("ethereum"),
                p = I(0);
            let m;
            W(r, (e => {}));
            return R((() => {
                m && clearInterval(m)
            })), M((() => {
                (() => {
                    const e = (new Date).getTime();
                    let t = 0;
                    for (;;) {
                        const a = 1727103633578 + 3 * t * 24 * 60 * 60 * 1e3;
                        if (a > e) {
                            var s = new Date(a);
                            break
                        }
                        t++
                    }
                    const l = s.getTime() - e,
                        i = Math.floor(l / 864e5),
                        n = Math.floor(l % 864e5 / 36e5),
                        o = Math.floor(l % 36e5 / 6e4),
                        r = Math.floor(l % 6e4 / 1e3);
                    a.counter.hours = n, a.counter.min = o, a.counter.sec = r, a.counter.days = i, m = setInterval((() => {
                        a.counter.hours - 1 == -1 && a.counter.min - 1 == -1 && a.counter.sec - 1 == -1 && (a.counter.days -= 1, a.counter.hours = 23, a.counter.min = 59, a.counter.sec = 59), a.counter.min - 1 == -1 && a.counter.sec - 1 == -1 ? (a.counter.hours -= 1, a.counter.min = 59, a.counter.sec = 59) : a.counter.sec - 1 == -1 ? (a.counter.min -= 1, a.counter.sec = 59) : a.counter.sec -= 1, 0 === a.counter.min && 0 == a.counter.sec && 0 == a.counter.hours && 0 == a.counter.days && clearInterval(m)
                    }), 1e3)
                })()
            })), (e, s) => {
                const l = u,
                    i = d,
                    n = c,
                    o = Q;
                return h(), j(o, {
                    class: "illustration-hero",
                    overflow: "",
                    size: "fullheight",
                    color: "grey",
                    style: {
                        "z-index": "1",
                        position: "relative",
                        background: "transparent"
                    }
                }, {
                    body: y((() => [f("div", Ms, [f("div", Rs, [f("div", Ws, [f("div", Hs, [f("div", $s, [b(l, {
                        tag: "h3",
                        size: 5,
                        weight: "bold",
                        class: "pb-0"
                    }, {
                        default: y((() => [f("span", Gs, x(z(t)("presale.presale-join")), 1)])),
                        _: 1
                    }), b(i, {
                        class: "h1-ai",
                        tag: "h1",
                        size: 2,
                        weight: "bold",
                        leading: "",
                        style: {
                            "font-weight": "500"
                        }
                    }, {
                        default: y((() => s[1] || (s[1] = [w(" World's First "), f("span", {
                            class: "text-gradient text-bold2",
                            style: {
                                display: "inline"
                            }
                        }, "AI", -1), f("span", {
                            class: "sda-rw"
                        }, [w(" Powered "), f("span", {
                            class: "text-gradient text-bold3",
                            style: {
                                display: "inline"
                            }
                        }, "Wallet"), w(" & "), f("span", {
                            class: "text-gradient text-bold3",
                            style: {
                                display: "inline"
                            }
                        }, "DEX,")], -1), f("span", {
                            class: "sda-rw"
                        }, [w(" Up To "), f("span", {
                            class: "text-gradient text-bold3",
                            style: {
                                display: "inline"
                            }
                        }, "97%"), w(" APY")], -1)]))),
                        _: 1
                    }), f("p", Ks, x(z(t)("presale.presale-desc1")), 1), f("ul", Js, [f("li", Ys, [f("div", Qs, x((a.counter.days > 9 ? "" : "0") + a.counter.days), 1), f("div", Xs, x(z(t)("inx.days")), 1)]), f("li", el, [f("div", al, x((a.counter.hours > 9 ? "" : "0") + a.counter.hours), 1), f("div", tl, x(z(t)("inx.hours")), 1)]), f("li", sl, [f("div", ll, x((a.counter.min > 9 ? "" : "0") + a.counter.min), 1), f("div", il, x(z(t)("inx.minutes")), 1)]), f("li", nl, [f("div", ol, x((a.counter.sec > 9 ? "" : "0") + a.counter.sec), 1), f("div", rl, x(z(t)("inx.seconds")), 1)])]), f("div", cl, [f("b", null, x(z(t)("presale.presale-pincr")), 1), b(z(Pe), {
                        effect: "customized",
                        width: "300px",
                        placement: "top"
                    }, {
                        content: y((() => s[2] || (s[2] = [f("p", null, [w(" The token price within each stage will also increase based on time. "), f("br"), w(" Separate from the stage-based price increase, but will never exceed "), f("br"), w(" the price of the next stage. This flexible pricing ensures early"), f("br"), w(" adopters gain value as the project evolves. ")], -1)]))),
                        default: y((() => [s[3] || (s[3] = f("i", {
                            class: "fas fa-info-circle text-gray1 ml-1",
                            style: {
                                "font-size": "12px"
                            }
                        }, null, -1))])),
                        _: 1
                    })]), s[9] || (s[9] = f("hr", {
                        style: {
                            "background-color": "#7303fc"
                        }
                    }, null, -1)), f("div", dl, [s[5] || (s[5] = f("i", {
                        class: "iconify",
                        "data-icon": "feather:check",
                        style: {
                            color: "#7303fc"
                        }
                    }, null, -1)), f("span", ul, [s[4] || (s[4] = f("b", null, "OPZ-AI:", -1)), w(" " + x(z(t)("presale.presale-ai1")), 1)])]), f("div", pl, [s[7] || (s[7] = f("i", {
                        class: "iconify",
                        "data-icon": "feather:check",
                        style: {
                            color: "#7303fc"
                        }
                    }, null, -1)), f("span", ml, [s[6] || (s[6] = f("b", null, "OPZ-DEX:", -1)), w(" " + x(z(t)("presale.presale-ai2")), 1)])]), f("div", vl, [b(n, {
                        blank: "",
                        href: "https://whitepaper.opz.com/"
                    }, {
                        default: y((() => [w(x(z(t)("exh.white-paper")), 1)])),
                        _: 1
                    }), b(n, {
                        blank: "",
                        href: "/pitch",
                        class: "ml-4"
                    }, {
                        default: y((() => s[8] || (s[8] = [w(" Pitch Deck ")]))),
                        _: 1
                    })]), s[10] || (s[10] = f("div", null, [f("p", {
                        class: "text-bold mb-1",
                        style: {
                            "font-size": "12px"
                        }
                    }, "AUDIT BY:"), f("a", {
                        href: "https://skynet.certik.com/projects/opz#code-security",
                        target: "_blank"
                    }, [f("img", {
                        src: "/images/svg/certik2.svg",
                        width: "150",
                        alt: "s"
                    })])], -1))])]), f("div", hl, [f("div", gl, [s[11] || (s[11] = f("div", {
                        class: "featured-bg-circle"
                    }, null, -1)), b(Sa, {
                        direction: "y",
                        class: "image-wrap",
                        speed: .06
                    }, {
                        default: y((() => [f("div", fl, [b(Vs, {
                            modelValue: p.value,
                            "onUpdate:modelValue": s[0] || (s[0] = e => p.value = e)
                        }, null, 8, ["modelValue"])])])),
                        _: 1
                    })])])]), s[12] || (s[12] = f("div", {
                        class: "hero-image-composition mb-5"
                    }, null, -1))])])])),
                    _: 1
                })
            }
        }
    }), [
        ["__scopeId", "data-v-1764681d"]
    ]),
    yl = {
        class: "main-page"
    },
    xl = {
        style: {
            "background-color": "#010609"
        },
        class: "eco-opz"
    },
    wl = {
        initial: {
            y: -60,
            opacity: 0
        },
        enter: {
            y: -0,
            opacity: 1,
            transition: {
                type: "spring",
                stiffness: 150,
                damping: 12,
                delay: 600
            }
        },
        class: "buttons is-relative z-1 btn-lnd"
    },
    kl = {
        class: "btn-app-tri"
    },
    ql = {
        key: 0,
        class: "img-banner pt-5",
        ref: "container",
        initial: {
            y: 100,
            opacity: 0
        },
        enter: {
            y: 0,
            opacity: 1,
            transition: {
                duration: 600,
                type: "keyframes",
                ease: "easeIn"
            }
        },
        src: lt
    },
    jl = {
        class: "img-banner pt-5",
        ref: "container",
        initial: {
            y: 100,
            opacity: 0
        },
        enter: {
            y: 0,
            opacity: 1,
            transition: {
                duration: 600,
                type: "keyframes",
                ease: "easeIn"
            }
        },
        src: lt
    },
    _l = {
        class: "container"
    },
    zl = {
        class: "container mt-4"
    },
    Cl = {
        class: "ai-pr-trade",
        style: {
            position: "absolute",
            "max-width": "100vw",
            right: "0"
        }
    },
    Pl = {
        style: {
            background: "#0a0a14"
        }
    },
    Tl = {
        class: "container"
    },
    Bl = {
        class: "container"
    },
    Sl = {
        class: "mb-5 flex items-center justify-center"
    },
    El = {
        class: "container"
    },
    Il = {
        class: "container"
    },
    Dl = m({
        __name: "index",
        setup(e) {
            const r = v((() => ({
                    columns: n.columns,
                    socials: n.socials,
                    links: n.links,
                    cta: n.cta,
                    copyright: n.copyright
                }))),
                d = A();
            C();
            const u = I(window.innerWidth <= 500);
            let p;
            M((() => {
                d.onChange(!0, 5), d.isShowPresale = !0, d.showPresale = !0;
                (() => {
                    const e = new URL(window.location.href),
                        a = new URLSearchParams(window.location.search),
                        t = a.get("id");
                    if (t) {
                        const s = Number(t);
                        isNaN(s) || (d.adId = s, d.adIdData = s, a.delete("id"), window.history.replaceState({}, "", `${e.pathname}?${a}`))
                    }
                })(), p = ne.throttle((() => {
                    u.value = window.innerWidth <= 500
                }), 100), window.addEventListener("resize", p)
            })), R((() => {
                window.removeEventListener("resize", p)
            }));
            const m = e => {
                e ? window.open("https://play.google.com/store/apps/details?id=com.opz.dev") : window.open("https://testflight.apple.com/join/Oxsd9WMO")
            };
            return (e, n) => {
                const d = te,
                    p = t,
                    v = st,
                    x = Xa,
                    k = Ya,
                    q = ee,
                    _ = Za,
                    C = Pa,
                    P = Y,
                    E = aa,
                    I = c,
                    D = Me,
                    O = o,
                    N = s,
                    F = i,
                    A = l,
                    U = T("motion");
                return h(), g(S, null, [b(d), b(p), f("div", yl, [b(bl), b(v, {
                    logos: z(it),
                    compact: !0
                }, null, 8, ["logos"]), b(Sa, {
                    direction: "y",
                    down: !0,
                    class: "pu-dark1",
                    speed: .66
                }, {
                    default: y((() => n[2] || (n[2] = [f("img", {
                        src: "/assets/shapes/dark-pu4.svg",
                        alt: "",
                        class: "dark-pu4"
                    }, null, -1)]))),
                    _: 1
                }), f("div", xl, [b(x, {
                    minititle: "OPZ Ecosystem",
                    title: "OPZ APP",
                    subtitle: "All-in-One Wallet",
                    color: "primary",
                    step: 1
                }, {
                    content: y((() => [B((h(), g("div", wl, [f("div", kl, [f("div", {
                        onClick: n[0] || (n[0] = e => m()),
                        class: "btn-left btn-add1"
                    }, n[3] || (n[3] = [f("div", {
                        class: "btn-left-body"
                    }, [f("img", {
                        width: "20",
                        class: "mr-2",
                        src: se,
                        alt: "Apple Store Download Link"
                    }), f("div", {
                        class: "btn-txt"
                    }, "OPZ BETA")], -1)])), f("div", {
                        onClick: n[1] || (n[1] = e => m(!0)),
                        class: "btn-right btn-add1"
                    }, n[4] || (n[4] = [f("div", {
                        class: "btn-right-body"
                    }, [f("img", {
                        width: "20",
                        class: "mr-2",
                        src: le,
                        alt: "Google Play Download Link"
                    }), f("div", {
                        class: "btn-txt"
                    }, "GOOGLE PLAY")], -1)]))])])), [
                        [U]
                    ])])),
                    _: 1
                }), u.value ? (h(), j(Sa, {
                    key: 1,
                    direction: "x",
                    left: !0,
                    class: "image-wrap",
                    speed: .53
                }, {
                    default: y((() => [B(f("img", jl, null, 512), [
                        [U]
                    ])])),
                    _: 1
                })) : B((h(), g("img", ql, null, 512)), [
                    [U]
                ])]), b(q, {
                    color: "gradient",
                    wave: "wave-2",
                    "shape-color": "footer-dark",
                    bottomNarrowMobile: ""
                }, {
                    default: y((() => [f("div", _l, [b(k, {
                        features: z(oe),
                        class: "features-block",
                        limit: 6,
                        size: "medium",
                        animated: "",
                        shapes: ""
                    }, null, 8, ["features"])])])),
                    _: 1
                }), b(q, {
                    class: "sct-trd",
                    color: "grey",
                    wave: "wave-2",
                    "shape-color": "white",
                    "top-narrow": "",
                    "top-narrow-mobile": ""
                }, {
                    default: y((() => [f("div", zl, [b(x, {
                        subtitle: "Bitcoin Layer 2",
                        minititle: "OPZ-DEX",
                        title: "Revolutionizing Bitcoin DeFi",
                        color: "primary",
                        step: 2
                    }, {
                        content: y((() => [b(_, {
                            class: "lowheight",
                            style: {
                                "min-height": "60vh"
                            }
                        })])),
                        _: 1
                    })]), f("div", Cl, [b(a, {
                        maxItems: 5
                    })])])),
                    _: 1
                }), f("div", Pl, [b(q, {
                    "shape-color": "white",
                    "bottom-narrow": "",
                    "bottom-narrow-mobile": "",
                    "top-narrow": "",
                    "top-narrow-mobile": "",
                    class: "token-overview"
                }, {
                    default: y((() => [f("div", Tl, [b(x, {
                        subtitle: "OPZ Token Overview",
                        minititle: "$OPZ",
                        title: "Tokenomics",
                        color: "primary",
                        step: 3
                    }, {
                        content: y((() => n[5] || (n[5] = []))),
                        _: 1
                    })])])),
                    _: 1
                }), n[7] || (n[7] = f("div", {
                    style: {
                        "background-color": "#0a0a14"
                    },
                    class: "flex justify-center items-center"
                }, [f("img", {
                    class: "img-tokenomics",
                    src: "/images/tokenomics3.png"
                })], -1)), b(q, {
                    "shape-color": "white",
                    "top-narrow": "",
                    "bottom-narrow": "",
                    "bottom-narrow-mobile": "",
                    "top-narrow-mobile": ""
                }, {
                    default: y((() => [f("div", Bl, [b(C), b(P, {
                        class: "mt-4 mb-6",
                        title: "Token Contract",
                        subtitle: "Use the contract information below to add the OPZ token to your wallet."
                    }), b(E), f("div", Sl, [b(I, {
                        href: "/staking",
                        style: {
                            "min-width": "390px"
                        },
                        blank: ""
                    }, {
                        default: y((() => n[6] || (n[6] = [w("Visit Staking & Token Management Dashboard")]))),
                        _: 1
                    })])])])),
                    _: 1
                })]), b(q, {
                    "shape-color": "grey",
                    wave: "wave-2",
                    "top-narrow": "",
                    "top-narrow-mobile": ""
                }, {
                    default: y((() => [f("div", El, [b(O, null, {
                        default: y((() => [b(D, {
                            subtitle: "$159K OPZ Giveaway",
                            title: "Join The Giveaway!",
                            content: "Ready to Win Big? Join the $159K OPZ Giveaway! Participate and complete all the entries for your shot at claiming the prize. Don't miss out on this chance!",
                            cta: "Join the Giveaway",
                            inverted: "",
                            to: "jobs"
                        })])),
                        _: 1
                    })])])),
                    _: 1
                }), b(q, {
                    color: "grey",
                    wave: "wave-2",
                    "shape-color": "footer-dark",
                    topNarrow: "",
                    topNarrowMobile: "",
                    "bottom-narrow-mobile": "",
                    bottomNarrow: ""
                }, {
                    default: y((() => [f("div", Il, [b(x, {
                        subtitle: "Frequently Asked",
                        minititle: "FAQ",
                        color: "primary",
                        title: "Take the time to read our FAQs",
                        step: 1
                    }, {
                        content: y((() => [b(N, {
                            left: z(ie).slice(0, 3),
                            right: z(ie).slice(3, 6),
                            chevrons: ""
                        }, null, 8, ["left", "right"])])),
                        _: 1
                    })])])),
                    _: 1
                }), b(F, {
                    token: !0,
                    content: r.value,
                    color: "dark",
                    cta: !0
                }, null, 8, ["content"]), n[8] || (n[8] = f("div", {
                    class: "flex items-center justify-center w-100 text-center"
                }, [f("p", {
                    class: "paragraph medium:text-right",
                    style: {
                        "font-size": "16px",
                        position: "relative",
                        top: "-52px"
                    }
                }, [w(" Disclaimer: Cryptocurrency might not be regulated in your area. "), f("br"), w(" Its value can fluctuate, and profits could be taxed according to your local laws. ")])], -1))]), b(A)], 64)
            }
        }
    });
"function" == typeof Ne && Ne(Dl);
const Ol = K(Dl, [
    ["__scopeId", "data-v-263e01f7"]
]);
export {
    Ol as
    default
};