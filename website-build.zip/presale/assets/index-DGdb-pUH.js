import {
    m as a,
    dp as e,
    cC as s,
    n as t,
    w as n,
    o,
    v as u,
    cE as d,
    X as r,
    bw as f
} from "./index-CQfCy4Xm.js";
const l = a({
    __name: "index",
    setup(a) {
        const l = e();
        return (a, e) => {
            const m = s("RouterView");
            return o(), t(m, null, {
                default: n((({
                    Component: a
                }) => [u(f, {
                    name: "fade-fast",
                    mode: "out-in"
                }, {
                    default: n((() => [(o(), t(d(a), {
                        key: r(l).fullPath
                    }))])),
                    _: 2
                }, 1024)])),
                _: 1
            })
        }
    }
});
export {
    l as
    default
};