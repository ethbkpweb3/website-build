import {
    dl as e
} from "./index-CQfCy4Xm.js";
const o = e(Object.freeze(Object.defineProperty({
    __proto__: null,
    default: {}
}, Symbol.toStringTag, {
    value: "Module"
})));
export {
    o as r
};