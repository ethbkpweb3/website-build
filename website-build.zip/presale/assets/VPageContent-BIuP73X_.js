import {
    _ as e
} from "./_plugin-vue_export-helper-BCo6x5W8.js";
import {
    o as s,
    j as t,
    r
} from "./index-CQfCy4Xm.js";
const n = {
    class: "page-content-wrapper"
};
const o = e({}, [
        ["render", function(e, o) {
            return s(), t("div", n, [r(e.$slots, "default")])
        }]
    ]),
    a = {
        class: "page-content"
    };
const p = e({}, [
    ["render", function(e, n) {
        return s(), t("div", a, [r(e.$slots, "default")])
    }]
]);
export {
    p as _, o as a
};