import {
    f as e,
    _ as a
} from "./index-BPv_7EZ9.js";
import {
    _ as t
} from "./ButtonGR-CCzD27Qk.js";
import {
    _ as l
} from "./Navbar2-Cx1AKm6v.js";
import {
    m as i,
    u as s,
    Y as o,
    y as r,
    h as n,
    a as d,
    j as c,
    l as m,
    t as u,
    X as f,
    v,
    w as p,
    P as g,
    cB as b,
    k as h,
    o as y,
    q as w,
    p as D,
    s as x,
    dm as T,
    G as k,
    dn as S,
    K as C,
    e as H,
    I as E,
    du as U,
    B as j,
    n as _,
    ck as L
} from "./index-CQfCy4Xm.js";
import "./index-DZwhim7i.js";
import {
    m as O
} from "./vue3-apexcharts-DWxdUF6r.js";
import {
    F as I
} from "./browser-Cv63Auap.js";
import {
    M
} from "./vue3-markdown-it.umd.min-h-q_g2pl.js";
import {
    E as B
} from "./index-DWyf7GKU.js";
import {
    E as P
} from "./index-BaPl-dvV.js";
import {
    _ as R
} from "./_plugin-vue_export-helper-BCo6x5W8.js";
import {
    u as F
} from "./useSeoMeta-DJrBtPw8.js";
import {
    a as z,
    E as V
} from "./index-D21_sbBM.js";
import {
    E as A,
    a as N
} from "./index-CBmmRNm0.js";
import {
    E as Y
} from "./index-CwZ3pmKF.js";
import {
    E as q,
    a as Z
} from "./index-BUqPiGKl.js";
import {
    E as W
} from "./index-CRtkyuT7.js";
import {
    E as G
} from "./index-DxHJyswS.js";
import {
    E as K
} from "./index-DPclT-tF.js";
import "./Subtitle-C6oUzL5I.js";
import "./Title-B_xB6icS.js";
import "./AppPop-DXr7YMXx.js";
import "./index-DPTDKB4o.js";
import "./index-wV0BwLDn.js";
import "./index-CB5HUA9W.js";
import "./google-play-0W6tGWt8.js";
import "./VPlaceload-DcvQMSN9.js";
import "./Button-C_PMcYdl.js";
import "./AvatarSimple-DIs6U3iF.js";
import "./via-placeholder-csI6CdwS.js";
import "./user-qMNVzsWD.js";
import "./sett-Dbwu6PJ1.js";
import "./avatarSettings-C1kj7zSJ.js";
import "./vue3-avataaars-DO56oOZp.js";
import "./index-38aUouWI.js";
import "./index-5N62XIoj.js";
import "./index-DYh1qtlV.js";
import "./index-CreMjc0E.js";
import "./use-dialog-CC6CVfkB.js";
import "./use-global-config-CYuHb1FB.js";
import "./index-BR6qnryQ.js";
import "./logo-DqlCWKKL.js";
import "./vue.runtime.esm-bundler-BbVV3g-V.js";
import "./typescript-CRqm1_SZ.js";
import "./vue.8fc199ce-DBDcZ0BB.js";
import "./aria-C-hsWcn7.js";
import "./dayjs.min-CoMKM3gL.js";
import "./index-DhHA3mFI.js";
import "./index-CIJievV_.js";
import "./_initCloneObject-DqrhPNyg.js";
import "./isPlainObject-BkooXA2Q.js";
import "./validator-Kt7cHrwc.js";
const $ = {
        class: "flex"
    },
    J = {
        class: "card reffbox reffbox-bordered",
        style: {
            width: "100%"
        }
    },
    X = {
        class: "nk-refwg"
    },
    Q = {
        class: "nk-refwg-invite reffbox-inner"
    },
    ee = {
        class: "nk-refwg-head g-3"
    },
    ae = {
        class: "nk-refwg-reff-title",
        style: {
            position: "relative",
            top: "-1px"
        }
    },
    te = {
        class: "reff-title mb-1"
    },
    le = {
        class: "reff-title-sub"
    },
    ie = {
        class: "flex",
        style: {
            position: "relative",
            top: "-1px"
        }
    },
    se = {
        class: "nk-refwg-action mr-4"
    },
    oe = {
        class: "reff-title-sub text-gray2"
    },
    re = {
        class: "nk-refwg-action mr-5"
    },
    ne = {
        class: "reff-title-sub text-gray2 mb-1"
    },
    de = {
        class: "nk-refwg-action mr-5"
    },
    ce = {
        class: "reff-title-sub text-gray2 mb-1"
    },
    me = {
        class: "nk-refwg-action"
    },
    ue = {
        class: "reff-title-sub text-bold flex"
    },
    fe = {
        class: "text-medium",
        style: {
            "font-size": "12px"
        }
    },
    ve = {
        class: "b-box-price-right"
    },
    pe = {
        class: "nk-refwg-url"
    },
    ge = {
        class: "form-control-wrap flex justify-between"
    },
    be = {
        style: "width: 33%"
    },
    he = {
        class: "help text-medium mb-2"
    },
    ye = {
        style: {
            width: "33%"
        }
    },
    we = {
        style: {
            width: "33%"
        }
    },
    De = {
        class: "help text-medium mb-2"
    },
    xe = {
        class: "nk-refwg-stats reffbox-inner bg-lighter"
    },
    Te = {
        class: ""
    },
    ke = {
        class: ""
    },
    Se = {
        class: "flex fw-bold small"
    },
    Ce = {
        class: "flex-grow-1 text-medium"
    },
    He = {
        class: "row align-items-center mb-2"
    },
    Ee = {
        class: "col-7"
    },
    Ue = {
        class: "mb-0 font-big-1"
    },
    je = {
        class: "col-5"
    },
    _e = {
        class: "mt-n3 mb-n2"
    },
    Le = {
        class: "small text-white text-opacity-50 text-truncate"
    },
    Oe = {
        key: 0,
        class: "flex mt-2"
    },
    Ie = R(i({
        __name: "ReffBox",
        props: {
            reffData: {
                default: {}
            },
            addressRef: {
                default: 0
            },
            thumbPrices: {}
        },
        setup(e) {
            const a = e,
                t = new Set([601287, 601457, 601757]),
                l = s(),
                {
                    t: i
                } = o(),
                T = r(l.isLoggedIn ? l.userData.promotionCode : ""),
                k = r(l.isLoggedIn ? i("ctm.refurl") + String(T.value) : i("inx.please-login")),
                S = n((() => l.isLoggedIn ? "https://www.opz.com/presale?ref=" + String(T.value) : 0 === a.addressRef ? i("inx.please-login") : "https://www.opz.com/presale?ref=" + String(a.addressRef))),
                C = d(),
                H = e => {
                    try {
                        navigator.clipboard.writeText(e), C.success(i("depwi.copied-successfully"))
                    } catch (a) {
                        C.error(i("depwi.error"))
                    }
                },
                E = e => {
                    for (var a = e.toLowerCase().split(" "), t = 0; t < a.length; t++) a[t] = a[t].charAt(0).toUpperCase() + a[t].substring(1);
                    return a.join(" ")
                };
            return (e, s) => {
                return y(), c("div", $, [m("div", J, [m("div", X, [m("div", Q, [m("div", ee, [m("div", ae, [m("h5", te, u(E(f(i)("pga.refer-friends-to-earn"))), 1), m("div", le, u(f(i)("pga.share-link-with-friends")), 1)]), m("div", ie, [m("div", se, [s[6] || (s[6] = m("div", {
                    class: "reff-title-sub text-gray2 mb-1"
                }, " ", -1)), m("div", oe, u(f(i)("pga.commission")) + ":", 1)]), m("div", re, [m("div", ne, u(f(i)("exh.spot")), 1), s[7] || (s[7] = m("div", {
                    class: "reff-title-sub text-bold"
                }, "65%", -1))]), m("div", de, [m("div", ce, u(f(i)("dash.derivates")), 1), s[8] || (s[8] = m("div", {
                    class: "reff-title-sub text-bold"
                }, "50%", -1))]), m("div", me, [s[10] || (s[10] = m("div", {
                    class: "reff-title-sub text-gray2 mb-1"
                }, "Presale", -1)), m("div", ue, [v(f(B), {
                    placement: "top-start",
                    effect: "customized"
                }, {
                    content: p((() => [m("p", fe, u(f(t).has(f(l).userData.id) ? "15% USDT" : "10% USDT + 10% OPZ"), 1)])),
                    default: p((() => [m("div", ve, [w(u(f(t).has(f(l).userData.id) ? "15%" : "20%") + " ", 1), s[9] || (s[9] = m("i", {
                        class: "fas fa-info-circle",
                        style: {
                            color: "gray",
                            "margin-left": "2px",
                            "font-size": "12px"
                        }
                    }, null, -1))])])),
                    _: 1
                })])])])]), m("div", pe, [m("div", ge, [m("div", be, [m("p", he, u(f(i)("pga.your-referral-link")), 1), v(f(P), {
                    modelValue: k.value,
                    "onUpdate:modelValue": s[1] || (s[1] = e => k.value = e),
                    class: "addressInput text-medium btnChain",
                    placeholder: k.value,
                    readonly: !0
                }, {
                    prefix: p((() => s[11] || (s[11] = [m("i", {
                        class: "fas fa-link"
                    }, null, -1)]))),
                    suffix: p((() => [m("i", {
                        class: "copy-link fas fa-copy",
                        onClick: s[0] || (s[0] = e => H(k.value))
                    })])),
                    _: 1
                }, 8, ["modelValue", "placeholder"])]), m("div", ye, [s[13] || (s[13] = m("p", {
                    class: "help text-medium mb-2"
                }, u("Presale Link"), -1)), v(f(P), {
                    modelValue: S.value,
                    "onUpdate:modelValue": s[3] || (s[3] = e => S.value = e),
                    class: "addressInput text-medium btnChain",
                    placeholder: S.value,
                    readonly: !0
                }, {
                    prefix: p((() => s[12] || (s[12] = [m("i", {
                        class: "fas fa-link"
                    }, null, -1)]))),
                    suffix: p((() => [m("i", {
                        class: "copy-link fas fa-copy",
                        onClick: s[2] || (s[2] = e => H(S.value))
                    })])),
                    _: 1
                }, 8, ["modelValue", "placeholder"])]), m("div", we, [m("p", De, u(f(i)("pga.referral-code")), 1), v(f(P), {
                    modelValue: T.value,
                    "onUpdate:modelValue": s[5] || (s[5] = e => T.value = e),
                    class: "addressInput text-medium btnChain",
                    placeholder: T.value,
                    readonly: !0
                }, {
                    prefix: p((() => s[14] || (s[14] = [m("i", {
                        class: "fas fa-user-tag"
                    }, null, -1)]))),
                    suffix: p((() => [m("i", {
                        class: "copy-link fas fa-copy",
                        onClick: s[4] || (s[4] = e => H(T.value))
                    })])),
                    _: 1
                }, 8, ["modelValue", "placeholder"])])])])]), m("div", xe, [(y(!0), c(g, null, b([{
                    title: i("pga.total-referrals"),
                    total: a.reffData.lvlOne + a.reffData.lvlTwo,
                    info: [{
                        icon: "fa fa-users fa-fw me-1",
                        text: "*" + i("dash.today") + ":* " + (a.reffData.lvlOne24H + a.reffData.lvlTwo24H) + " " + i("pga.referrals")
                    }, {
                        icon: "fa fa-calendar-week fa-fw me-1",
                        text: "*" + i("pga.commission") + " (" + i("dash.today") + "):* " + (a.reffData.USDT24H + a.reffData.BTC24H * ((null == (r = null == (o = null == a ? void 0 : a.thumbPrices) ? void 0 : o.find((e => "BTC/USDT" == e.symbol))) ? void 0 : r.price) || 0) + a.reffData.ETH24H * ((null == (d = null == (n = null == a ? void 0 : a.thumbPrices) ? void 0 : n.find((e => "ETH/USDT" == e.symbol))) ? void 0 : d.price) || 0)).toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        }) + " **USDT**",
                        disableMore: a.reffData.USDT > 0
                    }, {
                        icon: "fa fa-calendar-alt fa-fw me-1",
                        text: "*" + i("pga.commission") + " (" + i("dash.all") + "):* " + (a.reffData.USDT + a.reffData.BTC * ((null == (U = null == (C = null == a ? void 0 : a.thumbPrices) ? void 0 : C.find((e => "BTC/USDT" == e.symbol))) ? void 0 : U.price) || 0) + a.reffData.ETH * ((null == (_ = null == (j = null == a ? void 0 : a.thumbPrices) ? void 0 : j.find((e => "ETH/USDT" == e.symbol))) ? void 0 : _.price) || 0)).toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        }) + (0 === a.reffData.USDT || t.has(l.userData.id) ? " **USDT**" : " **OPZ**")
                    }],
                    chart: {
                        height: 60,
                        options: {
                            chart: {
                                type: "donut",
                                sparkline: {
                                    enabled: !0
                                }
                            },
                            colors: ["rgba(115,3,252, 1)", "rgba(115,3,252, 0.75)"],
                            labels: ["Level One", "Level Two"],
                            stroke: {
                                show: !1
                            },
                            tooltip: {
                                enabled: l.isLoggedIn
                            }
                        },
                        series: l.isLoggedIn ? [a.reffData.lvlOne, a.reffData.lvlTwo] : [1, 1]
                    }
                }], (e => (y(), c("div", null, [m("div", Te, [m("div", ke, [m("div", Se, [m("span", Ce, u(e.title), 1)]), m("div", He, [m("div", Ee, [m("h3", Ue, u(e.total), 1)]), m("div", je, [m("div", _e, [v(f(O), {
                    height: e.chart.height,
                    options: e.chart.options,
                    series: e.chart.series
                }, null, 8, ["height", "options", "series"])])])]), m("div", Le, [(y(!0), c(g, null, b(e.info, (e => (y(), c(g, null, [e.disableMore ? x("", !0) : (y(), c("div", Oe, [m("i", {
                    class: D(e.icon)
                }, null, 2), v(f(M), {
                    source: e.text,
                    class: "mk-earnings2",
                    breaks: !0
                }, null, 8, ["source"])]))], 64)))), 256))])])])])))), 256))])]), s[15] || (s[15] = h('<div class="card-arrow" data-v-80e100c6><div class="card-arrow-top-left" data-v-80e100c6></div><div class="card-arrow-top-right" data-v-80e100c6></div><div class="card-arrow-bottom-left" data-v-80e100c6></div><div class="card-arrow-bottom-right" data-v-80e100c6></div></div>', 1))])]);
                var o, r, n, d, C, U, j, _
            }
        }
    }), [
        ["__scopeId", "data-v-80e100c6"]
    ]),
    Me = {
        class: "staking-head"
    },
    Be = {
        class: "staking-top"
    },
    Pe = {
        class: "staking-top-body",
        style: {
            width: "100%",
            "max-width": "inherit",
            "justify-content": "center"
        }
    },
    Re = {
        class: "staking-top-middle",
        style: {
            "max-width": "1200px"
        }
    },
    Fe = {
        class: "staking-top-bar"
    },
    ze = {
        class: "staking-bar-body"
    },
    Ve = {
        class: "staking-body"
    },
    Ae = {
        class: "row justify-between mt-3"
    },
    Ne = {
        class: "col-xl-3 col-lg-6"
    },
    Ye = {
        class: "card-body"
    },
    qe = {
        class: "flex fw-bold small mb-2"
    },
    Ze = {
        class: "flex-grow-1 text-medium text-gray2"
    },
    We = {
        class: "row align-items-center mb-2"
    },
    Ge = {
        class: "col-7"
    },
    Ke = {
        class: "mb-0 font-big-1 flex flex-row"
    },
    $e = {
        key: 0,
        class: "mr-1 text-gray3"
    },
    Je = {
        class: "ml-1 text-gray3"
    },
    Xe = {
        class: "col-5"
    },
    Qe = {
        class: "mt-n3 mb-n2"
    },
    ea = {
        class: "small text-white text-opacity-50 text-truncate"
    },
    aa = {
        key: 0,
        class: "flex items-center",
        style: {
            "margin-bottom": "2px"
        }
    },
    ta = {
        style: {
            "min-width": "18px"
        }
    },
    la = ["src"],
    ia = {
        class: "text-gray2 mr-1",
        style: {
            "min-width": "36%"
        }
    },
    sa = {
        class: "text-medium mr-1 text-gray3"
    },
    oa = {
        class: "text-medium"
    },
    ra = {
        class: "text-medium ml-1 text-gray3"
    },
    na = {
        key: 0,
        class: "mt-3"
    },
    da = {
        key: 0,
        class: "filter-items"
    },
    ca = {
        key: 1,
        class: "content-stake"
    },
    ma = {
        key: 0
    },
    ua = {
        key: 1
    },
    fa = {
        class: "center-login"
    },
    va = {
        class: "mx-1"
    },
    pa = {
        class: "imgParent"
    },
    ga = ["src"],
    ba = {
        class: "mt-1"
    },
    ha = {
        key: 2,
        class: "content-history"
    },
    ya = {
        key: 0
    },
    wa = {
        key: 1,
        class: "center-login"
    },
    Da = {
        class: "mx-1"
    },
    xa = {
        class: "mt-1"
    },
    Ta = R(i({
        __name: "index",
        setup(i) {
            const {
                Api: n
            } = T(), {
                t: M
            } = o(), B = k(), P = d(), R = s(), $ = r("1"), J = r(1), X = r(1), Q = r(!1), ee = S(), ae = e => new Date((new Date).setDate((new Date).getDate() - e)).toDateString();
            F(M("pga.referrals"), "Manage and track your affiliate rewards and referrals on your OPZ dashboard. Start growing your income with our trusted affiliate network today!");
            const te = C({
                    refferalData: {
                        lvlOne: 0,
                        lvlTwo: 0,
                        lvlOne24H: 0,
                        lvlTwo24H: 0,
                        USDT24H: 0,
                        ETH24H: 0,
                        BTC24H: 0,
                        BTC: 0,
                        ETH: 0,
                        USDT: 0,
                        TotalUSDT: 0
                    },
                    thumbPrices: [],
                    coinOrderRef: {},
                    HistoryUSDT: {
                        0: 0,
                        1: 0,
                        2: 0,
                        3: 0,
                        4: 0,
                        5: 0,
                        6: 0,
                        7: 0
                    },
                    HistoryBTC: {
                        0: 0,
                        1: 0,
                        2: 0,
                        3: 0,
                        4: 0,
                        5: 0,
                        6: 0,
                        7: 0
                    },
                    HistoryETH: {
                        0: 0,
                        1: 0,
                        2: 0,
                        3: 0,
                        4: 0,
                        5: 0,
                        6: 0,
                        7: 0
                    },
                    dateMin: {
                        0: ae(0),
                        1: ae(1),
                        2: ae(2),
                        3: ae(3),
                        4: ae(4),
                        5: ae(5),
                        6: ae(6),
                        7: ae(7)
                    },
                    availableStaking: [{}],
                    allInvites: {
                        pageSize: 1e3,
                        total: 1,
                        rows: [],
                        time: ""
                    },
                    allCommission: {
                        pageSize: 1e3,
                        total: 1,
                        rows: [],
                        time: ""
                    }
                }),
                le = [{
                    text: M("pga.last-7-days"),
                    value: () => {
                        const e = new Date,
                            a = new Date;
                        return a.setTime(a.getTime() - 6048e5), [a, e]
                    }
                }, {
                    text: M("pga.last-30-days"),
                    value: () => {
                        const e = new Date,
                            a = new Date;
                        return a.setTime(a.getTime() - 2592e6), [a, e]
                    }
                }, {
                    text: M("pga.last-90-days"),
                    value: () => {
                        const e = new Date,
                            a = new Date;
                        return a.setTime(a.getTime() - 7776e6), [a, e]
                    }
                }],
                ie = e => {
                    R.isLoggedIn && (e && e[0] && e[1] ? (oe.value = "null", re.value = e[0], ne.value = e[1], "1" == $.value ? (te.allCommission.time = "null", me()) : (te.allInvites.time = "null", ce())) : (re.value = "", ne.value = ""))
                },
                se = r("");
            r(1);
            const oe = r(""),
                re = r(""),
                ne = r(""),
                de = e => {
                    oe.value = "1" == e ? te.allCommission.time : te.allInvites.time, $.value = e, "2" == e && 0 == te.allInvites.rows.length && R.isLoggedIn && ce()
                },
                ce = () => {
                    te.allInvites = {
                        pageSize: 1e3,
                        total: 1,
                        rows: [],
                        time: te.allInvites.time
                    };
                    const e = new I;
                    e.append("pageNo", String(J.value)), e.append("pageSize", String(te.allInvites.pageSize)), re.value && e.append("startTime", re.value), ne.value && e.append("endTime", ne.value), n.getPromotionRecord(e).then((e => {
                        const a = e.data.data;
                        a.content && a.content.length > 0 && (te.allInvites.total = a.totalElements, J.value = a.number, te.allInvites.rows = a.content)
                    }))
                },
                me = () => {
                    var e, a;
                    te.allCommission = {
                        pageSize: 1e3,
                        total: 1,
                        rows: [],
                        time: te.allCommission.time
                    };
                    const t = new I;
                    t.append("pageNo", String(X.value)), t.append("pageSize", String(te.allCommission.pageSize)), te.coinOrderRef && (null == (e = te.coinOrderRef) ? void 0 : e.address) && t.append("address", null == (a = te.coinOrderRef) ? void 0 : a.address), re.value && t.append("startTime", re.value), ne.value && t.append("endTime", ne.value), n.getAllCommission(t).then((e => {
                        const a = e.data.data;
                        if (a && a.content && a.content.length > 0) {
                            const e = a.content.map((e => ({ ...e,
                                    amount: e.amount * fe.value,
                                    total: e.total * ve.value
                                }))),
                                t = e.reduce(((e, a) => e + (0 === fe.value ? a.total : a.amount)), 0);
                            if (0 !== fe.value) {
                                const a = e.reduce(((e, a) => e + a.total), 0);
                                te.refferalData.TotalUSDT = a
                            }
                            te.refferalData.USDT = t, te.allCommission.total = a.totalElements, X.value = a.number, te.allCommission.rows = e
                        }
                    }))
                },
                ue = new Set([601287, 601457, 601757]),
                fe = r(ue.has(R.userData.id) ? 0 : .1),
                ve = r(ue.has(R.userData.id) ? .15 : .1),
                pe = e => {
                    let a = 0;
                    for (let t = 0; t < 8; t++) a += e[t];
                    return a
                };
            H();
            const ge = e => {
                    if (!R.isLoggedIn) return;
                    const a = new Date((new Date).setHours(0, 0, 0, 0));
                    switch (ne.value = a.getTime(), e) {
                        case "":
                            re.value = "", ne.value = "";
                            break;
                        case "yesterday":
                            re.value = a.getTime() - 864e5;
                            break;
                        case "thisweek":
                            re.value = (l = a, i = (l = new Date(l)).getDay(), s = l.getDate() - i + (0 == i ? -6 : 1), new Date(l.setDate(s)).getTime()), ne.value = (new Date).getTime();
                            break;
                        case "thismonth":
                            var t = new Date(a.getFullYear(), a.getMonth(), 1);
                            re.value = t.getTime(), ne.value = (new Date).getTime();
                            break;
                        default:
                            return
                    }
                    var l, i, s;
                    "1" == $.value ? (te.allCommission.time = e.toString(), me()) : (te.allInvites.time = e, ce())
                },
                be = () => {
                    var e, a, t, l, i, s, o, r, n, d, c, m, u, f, v, p, g;
                    return [{
                        title: "Total Earnings",
                        symbol: ue.has(R.userData.id) ? "USDT" : "OPZ",
                        total: null == (a = null == (e = te.refferalData) ? void 0 : e.USDT) ? void 0 : a.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        }),
                        btnClaim: !0,
                        info: [{
                            icon: "fa fa-coins fa-fw me-1",
                            text: "Total " + (ue.has(R.userData.id) ? "USDT" : "OPZ") + " Earnings:",
                            value: null == (l = null == (t = te.refferalData) ? void 0 : t.USDT) ? void 0 : l.toLocaleString(void 0, {
                                minimumFractionDigits: 2
                            })
                        }, {
                            icon: "fa fa-calendar-week fa-fw me-1",
                            text: "Total USDT Earnings:",
                            value: null == (s = null == (i = te.refferalData) ? void 0 : i.TotalUSDT) ? void 0 : s.toLocaleString(void 0, {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            }),
                            disableMore: (null == (o = te.refferalData) ? void 0 : o.TotalUSDT) <= 0
                        }, {
                            icon: "fa fa-calendar-week fa-fw me-1",
                            text: "Last 7 Days Earnings:",
                            value: pe(te.HistoryUSDT),
                            disableMore: (null == (r = te.refferalData) ? void 0 : r.USDT) > 0
                        }, {
                            icon: "fa fa-clock-rotate-left fa-fw me-1",
                            text: "Yesterday Earnings:",
                            value: te.HistoryUSDT[6],
                            disableMore: (null == (n = te.refferalData) ? void 0 : n.USDT) > 0
                        }],
                        chart: {
                            height: 30,
                            options: {
                                chart: {
                                    type: "bar",
                                    sparkline: {
                                        enabled: !0
                                    }
                                },
                                colors: ["rgba(115,3,252, 1)"],
                                plotOptions: {
                                    bar: {
                                        horizontal: !1,
                                        columnWidth: "65%",
                                        endingShape: "rounded"
                                    }
                                },
                                labels: [te.dateMin[7], te.dateMin[6], te.dateMin[5], te.dateMin[4], te.dateMin[3], te.dateMin[2], te.dateMin[1], te.dateMin[0]],
                                tooltip: {
                                    enabled: R.isLoggedIn,
                                    theme: "dark",
                                    style: {
                                        fontSize: "12px",
                                        fontFamily: "DINPRO-Medium"
                                    }
                                }
                            },
                            series: [{
                                name: "USD",
                                data: R.isLoggedIn ? [te.HistoryUSDT[0], te.HistoryUSDT[1], te.HistoryUSDT[2], te.HistoryUSDT[3], te.HistoryUSDT[4], te.HistoryUSDT[5], te.HistoryUSDT[6], te.HistoryUSDT[7]] : [1, 2, 3, 4, 5, 6, 7, 8]
                            }]
                        }
                    }, {
                        title: "Today BTC Earnings",
                        symbol: "BTC",
                        total: null == (c = null == (d = te.refferalData) ? void 0 : d.BTC24H) ? void 0 : c.toLocaleString(void 0, {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 5
                        }),
                        info: [{
                            icon: "fa fa-coins fa-fw me-1",
                            text: "Total BTC Earnings: ",
                            value: null == (u = null == (m = te.refferalData) ? void 0 : m.BTC) ? void 0 : u.toLocaleString(void 0, {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 5
                            })
                        }, {
                            icon: "fa fa-calendar-week fa-fw me-1",
                            text: "Last 7 Days Earnings:",
                            value: pe(te.HistoryBTC).toLocaleString(void 0, {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 5
                            })
                        }, {
                            icon: "fa fa-clock-rotate-left fa-fw me-1",
                            text: "Yesterday Earnings:",
                            value: te.HistoryBTC[6].toLocaleString(void 0, {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 5
                            })
                        }],
                        chart: {
                            height: 30,
                            options: {
                                chart: {
                                    type: "line",
                                    sparkline: {
                                        enabled: !0
                                    }
                                },
                                colors: ["rgba(115,3,252, 1)"],
                                stroke: {
                                    curve: "straight",
                                    width: 2
                                },
                                labels: [te.dateMin[7], te.dateMin[6], te.dateMin[5], te.dateMin[4], te.dateMin[3], te.dateMin[2], te.dateMin[1], te.dateMin[0]],
                                tooltip: {
                                    enabled: R.isLoggedIn,
                                    theme: "dark",
                                    style: {
                                        fontSize: "12px",
                                        fontFamily: "DINPRO-Medium"
                                    }
                                }
                            },
                            series: [{
                                name: "BTC",
                                data: [te.HistoryBTC[0], te.HistoryBTC[1], te.HistoryBTC[2], te.HistoryBTC[3], te.HistoryBTC[4], te.HistoryBTC[5], te.HistoryBTC[6], te.HistoryBTC[7]]
                            }]
                        }
                    }, {
                        title: "Today ETH Earnings",
                        symbol: "ETH",
                        total: null == (v = null == (f = te.refferalData) ? void 0 : f.ETH24H) ? void 0 : v.toLocaleString(void 0, {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 4
                        }),
                        info: [{
                            icon: "fa fa-coins fa-fw me-1",
                            text: "Total ETH Earnings:",
                            value: null == (g = null == (p = te.refferalData) ? void 0 : p.ETH) ? void 0 : g.toLocaleString(void 0, {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 4
                            })
                        }, {
                            icon: "fa fa-calendar-week fa-fw me-1",
                            text: "Last 7 Days Earnings:",
                            value: pe(te.HistoryETH).toLocaleString(void 0, {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 4
                            })
                        }, {
                            icon: "fa fa-clock-rotate-left fa-fw me-1",
                            text: "Yesterday Earnings:",
                            value: te.HistoryETH[6].toLocaleString(void 0, {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 4
                            })
                        }],
                        chart: {
                            height: 30,
                            options: {
                                chart: {
                                    type: "line",
                                    sparkline: {
                                        enabled: !0
                                    }
                                },
                                colors: ["rgba(115,3,252, 1)"],
                                stroke: {
                                    curve: "straight",
                                    width: 2
                                },
                                labels: [te.dateMin[7], te.dateMin[6], te.dateMin[5], te.dateMin[4], te.dateMin[3], te.dateMin[2], te.dateMin[1], te.dateMin[0]],
                                tooltip: {
                                    enabled: R.isLoggedIn,
                                    theme: "dark",
                                    style: {
                                        fontSize: "12px",
                                        fontFamily: "DINPRO-Medium"
                                    }
                                }
                            },
                            series: [{
                                name: "ETH",
                                data: [te.HistoryETH[0], te.HistoryETH[1], te.HistoryETH[2], te.HistoryETH[3], te.HistoryETH[4], te.HistoryETH[5], te.HistoryETH[6], te.HistoryETH[7]]
                            }]
                        }
                    }]
                };
            E((async () => {
                R.isLoggedIn && (n.getRefferalEarnings().then((e => {
                    200 == e.status && (e.data.USDT24H = 0, e.data.ETH24H = 0, e.data.BTC24H = 0, e.data.USDT = 0, e.data.ETH = 0, e.data.BTC = 0, te.refferalData.lvlOne = e.data.lvlOne, te.refferalData.lvlTwo = e.data.lvlTwo, te.refferalData.lvlOne24H = e.data.lvlOne24H, te.refferalData.lvlTwo24H = e.data.lvlTwo24H, Q.value = !0)
                })), n.getAllReffEarnings().then((e => {
                    const a = e.data,
                        t = new Date;
                    0 == a.code ? a.data.content.forEach(((e, a) => {
                        const l = new Date(e.createTime);
                        console.log(l);
                        for (let i = 0; i < 7; i++) new Date((new Date).setDate(t.getDate() - (i + 1))).toDateString() == l.toDateString() && ("USDT" == e.unit ? te.HistoryUSDT[6 - i] = e.amount : "BTC" == e.unit ? te.HistoryBTC[6 - i] = e.amount : "ETH" == e.unit && (te.HistoryETH[6 - i] = e.amount))
                    })) : P.error(a.message)
                })))
            })), r("");
            const he = r(""),
                {
                    wallets: ye,
                    connectWallet: we,
                    connectedWallet: De,
                    setChain: xe,
                    connectedChain: Te,
                    alreadyConnectedWallets: ke
                } = U(),
                Se = r(!1);
            E((async () => {
                !De.value && ke.value && ke.value[0] ? await we({
                    autoSelect: {
                        label: ke.value[0],
                        disableModals: !0
                    }
                }) : De.value && De.value.accounts[0] ? (he.value = De.value.accounts[0].address, Ce(he.value)) : R.isLoggedIn && me(), Se.value = !0
            })), j(De, (e => {
                e && e && e.accounts && e.accounts[0] && e.accounts[0].address && (e.accounts[0].address !== he.value && (he.value = e.accounts[0].address, Ce(he.value)), he.value = e.accounts[0].address)
            }), {
                deep: !0
            });
            const Ce = e => {
                    if (De.value) {
                        const a = new I;
                        a.append("address", e), n.coinRefGet(a).then((({
                            data: e
                        }) => {
                            if (0 == e.code) {
                                {
                                    const a = e.data;
                                    te.coinOrderRef = a
                                }
                                R.isLoggedIn ? me() : (() => {
                                    var e, a;
                                    te.allCommission = {
                                        pageSize: 1e3,
                                        total: 1,
                                        rows: [],
                                        time: te.allCommission.time
                                    };
                                    const t = new I;
                                    t.append("pageNo", String(X.value)), t.append("pageSize", String(te.allCommission.pageSize)), te.coinOrderRef && (null == (e = te.coinOrderRef) ? void 0 : e.address) && (t.append("address", null == (a = te.coinOrderRef) ? void 0 : a.address), re.value && t.append("startTime", re.value), ne.value && t.append("endTime", ne.value), n.coinRefRecord(t).then((e => {
                                        const a = e.data.data;
                                        if (a && a.content && a.content.length > 0) {
                                            const e = a.content.map((e => ({ ...e,
                                                    amount: e.amount * fe.value,
                                                    total: e.total * ve.value
                                                }))),
                                                t = e.reduce(((e, a) => e + (0 === fe.value ? a.total : a.amount)), 0),
                                                l = e.reduce(((e, a) => e + a.total), 0);
                                            te.refferalData.USDT = t, te.refferalData.USD = l, te.allCommission.total = a.totalElements, X.value = a.number, te.allCommission.rows = e
                                        }
                                    })))
                                })()
                            }
                        })).catch((e => {
                            R.isLoggedIn && me(), console.log(e)
                        }))
                    }
                },
                He = async () => {
                    De.value || await we()
                };
            return (i, s) => {
                var o;
                const r = l,
                    d = t,
                    T = a;
                return y(), c(g, null, [f(ee).isAppOn ? x("", !0) : (y(), _(r, {
                    key: 0
                })), m("div", {
                    class: D(["staking aff-dash", f(ee).isAppOn && "is-app"])
                }, [m("div", Me, [m("div", Be, [m("div", Pe, [m("div", Re, [v(Ie, {
                    "reff-data": te.refferalData,
                    thumbPrices: te.thumbPrices,
                    "onUpdate:thumbPrices": s[0] || (s[0] = e => te.thumbPrices = e),
                    "address-ref": null == (o = te.coinOrderRef) ? void 0 : o.affId
                }, null, 8, ["reff-data", "thumbPrices", "address-ref"])])])]), m("div", Fe, [m("div", ze, [v(f(z), {
                    "default-active": $.value,
                    class: "el-menu-demo",
                    style: {
                        "min-width": "100%",
                        "margin-bottom": "1px"
                    },
                    mode: "horizontal",
                    "text-color": "white",
                    collapse: !1,
                    ellipsis: !1,
                    onSelect: de
                }, {
                    default: p((() => [v(f(V), {
                        index: "1"
                    }, {
                        default: p((() => [w(u(f(M)("pga.commission-history")), 1)])),
                        _: 1
                    }), v(f(V), {
                        index: "2",
                        class: "mobz2"
                    }, {
                        default: p((() => [w(u(f(M)("pga.my-referrals")), 1)])),
                        _: 1
                    }), s[14] || (s[14] = m("div", {
                        class: "flex-grow"
                    }, null, -1)), v(f(V), {
                        class: "mobz1"
                    }, {
                        default: p((() => [!f(De) && Se.value ? (y(), c("a", {
                            key: 0,
                            onClick: s[1] || (s[1] = () => {
                                He()
                            }),
                            class: "w-full rounded border-purple-darken text-10 block text-center text-bold btn-connect-wal moboff"
                        }, u(f(M)("dash.connect-wallet")), 1)) : x("", !0)])),
                        _: 1
                    })])),
                    _: 1
                }, 8, ["default-active"])])])]), m("div", Ve, [m("div", Ae, [(y(!0), c(g, null, b(be(), (e => {
                    var a, t, l;
                    return y(), c("div", Ne, [m("div", {
                        class: "card mb-5",
                        ref_for: !0,
                        ref: "card"
                    }, [m("div", Ye, [m("div", qe, [m("span", Ze, u(e.title), 1)]), m("div", We, [m("div", Ge, [m("h3", Ke, [(null == e ? void 0 : e.curr) ? (y(), c("p", $e, u(null == e ? void 0 : e.curr), 1)) : x("", !0), w(" " + u(e.total) + " ", 1), m("p", Je, u(e.symbol), 1)])]), m("div", Xe, [m("div", Qe, [v(f(O), {
                        height: e.chart.height,
                        options: e.chart.options,
                        series: e.chart.series
                    }, null, 8, ["height", "options", "series"])])])]), m("div", ea, [(y(!0), c(g, null, b(e.info, ((a, t) => (y(), c("div", null, [a.disableMore ? x("", !0) : (y(), c("div", aa, [m("div", ta, [a.image ? (y(), c("img", {
                        key: 0,
                        src: a.image,
                        class: "fa-fw2 me-1"
                    }, null, 8, la)) : (y(), c("i", {
                        key: 1,
                        class: D(a.icon)
                    }, null, 2))]), m("span", ia, u(a.text), 1), m("span", sa, u(null == e ? void 0 : e.curr), 1), m("span", oa, u(a.value), 1), m("span", ra, u(e.btnClaim && 1 === t ? "USDT" : e.symbol), 1)]))])))), 256)), e.btnClaim && e.info[2].disableMore ? (y(), c("div", na, [v(d, {
                        size: "small",
                        style: {
                            "flex-grow": "1"
                        },
                        onClick: s[2] || (s[2] = e => (async () => {
                            var e, a;
                            (null == (e = te.refferalData) ? void 0 : e.TotalUSDT) < 25 ? K.alert("You need to have at least 25 USDT in earnings to claim rewards.", "Claim Rewards", {
                                confirmButtonText: "OK",
                                customClass: "msg-dark",
                                confirmButtonClass: "btn-prime-box",
                                customStyle: {
                                    "background-color": "black",
                                    "border-color": "#1b1b1b",
                                    "--el-button-bg-color": "#fff"
                                }
                            }) : K.prompt('We will send your reward to your address "' + (null == (a = te.coinOrderRef) ? void 0 : a.address) + '" within 24 hours. Please type "ERC20" or "BEP20" to confirm the network you want to receive USDT on. Thank you for your patience!', "Confirm Claim Rewards", {
                                confirmButtonText: "OK",
                                cancelButtonText: "Cancel",
                                inputPattern: /^(ERC20|BEP20)$/,
                                inputErrorMessage: "Invalid Network",
                                customClass: "msg-dark sasfw gasda",
                                confirmButtonClass: "btn-prime-box",
                                customStyle: {
                                    "background-color": "black",
                                    "border-color": "#1b1b1b",
                                    "--el-button-bg-color": "#fff"
                                }
                            }).then((({
                                value: e
                            }) => {
                                var a;
                                const t = new I;
                                t.append("address", null == (a = te.coinOrderRef) ? void 0 : a.address), t.append("chain", e), R.isLoggedIn ? n.coinRefMemSet(t).then((({
                                    data: e
                                }) => {
                                    0 == e.code && (te.coinOrderRef = e.data, P.success(M("depwi.withdrawal-submitted-success")))
                                })).catch((e => {
                                    console.log(e)
                                })) : n.coinRefSet(t).then((({
                                    data: e
                                }) => {
                                    0 == e.code && (te.coinOrderRef = e.data, P.success(M("depwi.withdrawal-submitted-success")))
                                })).catch((e => {
                                    console.log(e)
                                }))
                            })).catch((() => {}))
                        })()),
                        disabled: (null == (a = te.refferalData) ? void 0 : a.USDT) <= 0 || !f(De) || !(null == (t = te.coinOrderRef) ? void 0 : t.address) || 0 != (null == (l = te.coinOrderRef) ? void 0 : l.status)
                    }, {
                        default: p((() => {
                            var e;
                            return [w(u(1 === (null == (e = te.coinOrderRef) ? void 0 : e.status) ? f(M)("hiss.processing") : f(M)("inx.claim")), 1)]
                        })),
                        _: 1
                    }, 8, ["disabled"])])) : x("", !0)])]), s[15] || (s[15] = h('<div class="card-arrow" data-v-d1c23b4b><div class="card-arrow-top-left" data-v-d1c23b4b></div><div class="card-arrow-top-right" data-v-d1c23b4b></div><div class="card-arrow-bottom-left" data-v-d1c23b4b></div><div class="card-arrow-bottom-right" data-v-d1c23b4b></div></div>', 1))], 512)])
                })), 256))]), 0 == te.allCommission.rows.length ? (y(), c("div", da, [v(f(A), {
                    id: "scrollRight",
                    modelValue: oe.value,
                    "onUpdate:modelValue": s[3] || (s[3] = e => oe.value = e),
                    onChange: ge,
                    class: "text-medium light-radio-group"
                }, {
                    default: p((() => [v(f(N), {
                        value: ""
                    }, {
                        default: p((() => [w(u(f(M)("dash.all")), 1)])),
                        _: 1
                    }), v(f(N), {
                        value: "yesterday"
                    }, {
                        default: p((() => [w(u(f(M)("pga.yesterday")), 1)])),
                        _: 1
                    }), v(f(N), {
                        value: "thisweek"
                    }, {
                        default: p((() => [w(u(f(M)("pga.this-week")), 1)])),
                        _: 1
                    }), v(f(N), {
                        value: "thismonth"
                    }, {
                        default: p((() => [w(u(f(M)("pga.this-month")), 1)])),
                        _: 1
                    })])),
                    _: 1
                }, 8, ["modelValue"]), v(f(Y), {
                    modelValue: se.value,
                    "onUpdate:modelValue": s[4] || (s[4] = e => se.value = e),
                    type: "daterange",
                    "unlink-panels": "",
                    class: "datepick datepick-small",
                    style: L("null" == oe.value && "border: 1px solid var(--el-border-color-hover);"),
                    "range-separator": f(M)("wall.to"),
                    "start-placeholder": f(M)("wall.start-date"),
                    "end-placeholder": f(M)("wall.end-date"),
                    shortcuts: le,
                    "value-format": "x",
                    onChange: ie
                }, null, 8, ["modelValue", "style", "range-separator", "start-placeholder", "end-placeholder"])])) : x("", !0), "1" == $.value ? (y(), c("div", ca, [v(f(q), {
                    class: "slim-table",
                    data: te.allCommission.rows,
                    "table-layout": "fixed",
                    style: {
                        width: "100%"
                    },
                    "show-summary": f(ue).has(f(R).userData.id) || te.allCommission.rows.length > 0
                }, {
                    empty: p((() => {
                        var e;
                        return [f(R).isLoggedIn || (null == (e = te.coinOrderRef) ? void 0 : e.address) ? (y(), c("div", ma, u(f(M)("exh.no-records-found")), 1)) : (y(), c("div", ua, [m("div", fa, [v(f(G), {
                            type: "primary",
                            class: "text-green-darken",
                            onClick: s[5] || (s[5] = e => f(B).push({
                                name: "auth",
                                query: {
                                    redirect: "/referral"
                                }
                            }))
                        }, {
                            default: p((() => [w(u(f(M)("auth.log-in")), 1)])),
                            _: 1
                        }), m("span", va, u(f(M)("exh.or")), 1), v(f(G), {
                            type: "primary",
                            class: "text-green-darken",
                            onClick: s[6] || (s[6] = e => f(B).push({
                                name: "register",
                                query: {
                                    redirect: "/referral"
                                }
                            }))
                        }, {
                            default: p((() => [w(u(f(M)("auth.register-now")), 1)])),
                            _: 1
                        })]), !f(De) && Se.value ? (y(), c("a", {
                            key: 0,
                            onClick: s[7] || (s[7] = () => {
                                He()
                            }),
                            class: "w-full rounded border-purple-darken text-10 block text-center text-bold btn-connect-wal mobon mb-6"
                        }, u(f(M)("dash.connect-wallet")), 1)) : x("", !0)]))]
                    })),
                    default: p((() => [v(f(Z), {
                        label: f(M)("depwi.coin"),
                        width: "160"
                    }, {
                        default: p((e => [m("span", pa, [m("img", {
                            class: "imgSelect",
                            src: "/images/icons/coin/" + e.row.symbol.toLowerCase() + ".svg"
                        }, null, 8, ga)]), w(" " + u(e.row.symbol), 1)])),
                        _: 1
                    }, 8, ["label"]), 0 == te.allCommission.rows.length ? (y(), _(f(Z), {
                        key: 0,
                        label: f(M)("hiss.date-time")
                    }, {
                        default: p((e => [w(u(new Date(e.row.time).toLocaleString("en-UK")), 1)])),
                        _: 1
                    }, 8, ["label"])) : x("", !0), v(f(Z), {
                        label: f(M)("pga.account")
                    }, {
                        default: p((e => [w(u(e.row.orderMember), 1)])),
                        _: 1
                    }, 8, ["label"]), 0 == te.allCommission.rows.length ? (y(), _(f(Z), {
                        key: 1,
                        label: f(M)("pga.level"),
                        "class-name": "timeColumn"
                    }, {
                        default: p((e => [w(u(f(M)("pga.level-lvl").replace(":level", 1 == e.row.lvlOne ? "1" : "2")), 1)])),
                        _: 1
                    }, 8, ["label"])) : x("", !0), v(f(Z), {
                        label: f(M)("pga.commission") + " (%)"
                    }, {
                        default: p((e => [w(u(1 == e.row.lvlOne ? "50%" : f(ue).has(f(R).userData.id) ? "15%" : "10%"), 1)])),
                        _: 1
                    }, 8, ["label"]), 0 != te.allCommission.rows.length ? (y(), _(f(Z), {
                        key: 2,
                        prop: "total",
                        label: "USDT Earned",
                        align: "right"
                    }, {
                        default: p((e => [w(u(e.row.total.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        }) + " USDT"), 1)])),
                        _: 1
                    })) : x("", !0), v(f(Z), {
                        prop: "amount",
                        label: 0 == te.allCommission.rows.length ? f(M)("pga.commission-earned") : "OPZ Earned",
                        align: "right"
                    }, {
                        default: p((e => [w(u(e.row.amount.toLocaleString(void 0, {
                            minimumFractionDigits: "USDT" == e.row.symbol ? 2 : 0
                        }) + " " + (f(ue).has(f(R).userData.id) ? "USDT" : e.row.symbol)), 1)])),
                        _: 1
                    }, 8, ["label"])])),
                    _: 1
                }, 8, ["data", "show-summary"]), m("div", ba, [f(R).isLoggedIn ? (y(), _(f(W), {
                    key: 0,
                    currentPage: X.value,
                    "onUpdate:currentPage": s[8] || (s[8] = e => X.value = e),
                    background: "",
                    size: "small",
                    layout: "prev, pager, next",
                    total: te.allCommission.total,
                    onCurrentChange: s[9] || (s[9] = e => me())
                }, null, 8, ["currentPage", "total"])) : x("", !0)])])) : x("", !0), "2" == $.value ? (y(), c("div", ha, [v(f(q), {
                    class: "slim-table",
                    data: te.allInvites.rows,
                    "table-layout": "fixed",
                    style: {
                        width: "100%"
                    }
                }, {
                    empty: p((() => [f(R).isLoggedIn ? (y(), c("div", ya, u(f(M)("exh.no-records-found")), 1)) : (y(), c("div", wa, [v(f(G), {
                        type: "primary",
                        class: "text-green-darken",
                        onClick: s[10] || (s[10] = e => f(B).push({
                            name: "auth",
                            query: {
                                redirect: "/referral"
                            }
                        }))
                    }, {
                        default: p((() => [w(u(f(M)("auth.log-in")), 1)])),
                        _: 1
                    }), m("span", Da, u(f(M)("exh.or")), 1), v(f(G), {
                        type: "primary",
                        class: "text-green-darken",
                        onClick: s[11] || (s[11] = e => f(B).push({
                            name: "register",
                            query: {
                                redirect: "/referral"
                            }
                        }))
                    }, {
                        default: p((() => [w(u(f(M)("auth.register-now")), 1)])),
                        _: 1
                    })]))])),
                    default: p((() => [v(f(Z), {
                        label: f(M)("pga.registration-time")
                    }, {
                        default: p((e => [w(u(e.row.createTime), 1)])),
                        _: 1
                    }, 8, ["label"]), v(f(Z), {
                        label: f(M)("pga.account")
                    }, {
                        default: p((e => [w(u(e.row.username), 1)])),
                        _: 1
                    }, 8, ["label"]), v(f(Z), {
                        label: f(M)("sett.country-region"),
                        "class-name": "timeColumn"
                    }, {
                        default: p((e => [w(u(e.row.country), 1)])),
                        _: 1
                    }, 8, ["label"]), v(f(Z), {
                        label: f(M)("pga.level"),
                        "class-name": "timeColumn"
                    }, {
                        default: p((e => [w(u(f(M)("pga.level-lvl").replace(":level", 1 == e.row.level ? "1" : "2")), 1)])),
                        _: 1
                    }, 8, ["label"]), v(f(Z), {
                        label: f(M)("pga.commission") + " (%)"
                    }, {
                        default: p((e => [w(u(1 == e.row.level ? "50%" : "10%"), 1)])),
                        _: 1
                    }, 8, ["label"]), v(f(Z), {
                        label: f(M)("pga.current-total-deposit"),
                        align: "right"
                    }, {
                        default: p((e => [w(" $" + u(e.row.deposit.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 1)])),
                        _: 1
                    }, 8, ["label"])])),
                    _: 1
                }, 8, ["data"]), m("div", xa, [f(R).isLoggedIn ? (y(), _(f(W), {
                    key: 0,
                    currentPage: J.value,
                    "onUpdate:currentPage": s[12] || (s[12] = e => J.value = e),
                    background: "",
                    size: "small",
                    layout: "prev, pager, next",
                    total: te.allInvites.total,
                    onCurrentChange: s[13] || (s[13] = e => ce())
                }, null, 8, ["currentPage", "total"])) : x("", !0)])])) : x("", !0)])], 2), f(ee).isAppOn ? x("", !0) : (y(), _(T, {
                    key: 1,
                    content: f(e),
                    color: "dark",
                    cta: !1
                }, null, 8, ["content"]))], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-d1c23b4b"]
    ]);
export {
    Ta as
    default
};