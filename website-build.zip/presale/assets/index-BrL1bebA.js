import {
    m as e,
    G as a,
    I as s,
    j as r,
    o as t
} from "./index-CQfCy4Xm.js";
const n = e({
    __name: "index",
    setup(e) {
        const n = a();
        return n.push({
            name: "user-center-dashboard-wallet"
        }), s((() => {
            n.push({
                name: "user-center-dashboard-wallet"
            })
        })), (e, a) => (t(), r("div"))
    }
});
export {
    n as
    default
};