import {
    m as s,
    o as a,
    j as o,
    l as t,
    r as e
} from "./index-CQfCy4Xm.js";
import {
    _ as d
} from "./_plugin-vue_export-helper-BCo6x5W8.js";
const p = {
        class: "gr-bg"
    },
    r = {
        class: "case-study"
    },
    c = {
        class: "case-study-content"
    },
    i = d(s({
        __name: "CaseStudy",
        props: {
            background: {},
            opacity: {}
        },
        setup: s => (s, d) => (a(), o("div", p, [t("div", r, [t("div", c, [e(s.$slots, "default", {}, void 0, !0)])])]))
    }), [
        ["__scopeId", "data-v-1a008055"]
    ]);
export {
    i as _
};