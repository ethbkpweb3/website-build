import {
    _ as s
} from "./FooterB-DIvyuXCZ.js";
import {
    _ as t
} from "./Navbar2-Cx1AKm6v.js";
import {
    m as o,
    Y as e,
    dp as i,
    dn as r,
    cC as a,
    j as n,
    X as p,
    n as m,
    s as l,
    v as j,
    w as d,
    P as u,
    o as c,
    bw as x,
    cE as f,
    l as g,
    q as k,
    t as _
} from "./index-CQfCy4Xm.js";
import {
    u as v
} from "./vue.8fc199ce-DBDcZ0BB.js";
import {
    u as b
} from "./useSeoMeta-DJrBtPw8.js";
import "./_plugin-vue_export-helper-BCo6x5W8.js";
import "./AppPop-DXr7YMXx.js";
import "./index-DZwhim7i.js";
import "./browser-Cv63Auap.js";
import "./index-DPTDKB4o.js";
import "./index-wV0BwLDn.js";
import "./index-DWyf7GKU.js";
import "./index-CB5HUA9W.js";
import "./google-play-0W6tGWt8.js";
import "./VPlaceload-DcvQMSN9.js";
import "./Button-C_PMcYdl.js";
import "./AvatarSimple-DIs6U3iF.js";
import "./via-placeholder-csI6CdwS.js";
import "./user-qMNVzsWD.js";
import "./sett-Dbwu6PJ1.js";
import "./avatarSettings-C1kj7zSJ.js";
import "./vue3-avataaars-DO56oOZp.js";
import "./index-38aUouWI.js";
import "./ButtonGR-CCzD27Qk.js";
import "./index-5N62XIoj.js";
import "./index-DYh1qtlV.js";
import "./index-CreMjc0E.js";
import "./use-dialog-CC6CVfkB.js";
import "./use-global-config-CYuHb1FB.js";
import "./index-BR6qnryQ.js";
import "./index-BaPl-dvV.js";
import "./typescript-CRqm1_SZ.js";
import "./logo-DqlCWKKL.js";
import "./index-D21_sbBM.js";
import "./aria-C-hsWcn7.js";
const y = {
        class: "inline-block px-2"
    },
    h = {
        class: "inline-block px-2"
    },
    w = o({
        __name: "terms",
        setup(o) {
            const {
                t: w
            } = e();
            b(w("inx.terms-conditions"), "OPZ " + w("inx.terms-conditions"));
            const A = i(),
                B = r(),
                P = !!A.query.mobile;
            return v({
                meta: [{
                    name: "robots",
                    content: "noindex"
                }]
            }), (o, e) => {
                const i = t,
                    r = a("RouterView"),
                    v = a("RouterLink"),
                    b = s;
                return c(), n(u, null, [p(B).isAppOn || p(P) ? l("", !0) : (c(), m(i, {
                    key: 0
                })), j(r, null, {
                    default: d((({
                        Component: s
                    }) => [j(x, {
                        name: "fade-fast",
                        mode: "out-in"
                    }, {
                        default: d((() => [(c(), m(f(s), {
                            key: p(A).fullPath
                        }))])),
                        _: 2
                    }, 1024)])),
                    _: 1
                }), p(B).isAppOn || p(P) ? l("", !0) : (c(), m(b, {
                    key: 1
                }, {
                    links: d((() => [g("li", y, [j(v, {
                        to: {
                            name: "index"
                        },
                        class: "footer-link"
                    }, {
                        default: d((() => [k(_(p(w)("pga.home")), 1)])),
                        _: 1
                    })]), g("li", h, [j(v, {
                        to: {
                            name: "help-desk-center"
                        },
                        class: "footer-link"
                    }, {
                        default: d((() => [k(_(p(w)("pga.help-center")), 1)])),
                        _: 1
                    })])])),
                    _: 1
                }))], 64)
            }
        }
    });
export {
    w as
    default
};