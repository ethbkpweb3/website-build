import {
    H as o
} from "./index-CQfCy4Xm.js";
const t = o("object" == typeof self ? self.FormData : window.FormData);
export {
    t as F
};