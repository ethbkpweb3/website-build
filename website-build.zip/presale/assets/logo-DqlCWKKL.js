const o="/assets/logo/logo.svg";export{o as _};
