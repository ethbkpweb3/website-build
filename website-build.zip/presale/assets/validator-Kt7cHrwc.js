import {
    c as s
} from "./index-wV0BwLDn.js";
const i = i => ["", ...s].includes(i);
export {
    i
};