const s="/assets/appstore/app-store.svg",a="/assets/appstore/google-play.svg";export{s as _,a};
