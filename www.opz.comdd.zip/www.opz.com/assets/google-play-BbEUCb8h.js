const s="/images/svg/apple.svg",g="/images/svg/google-play.svg";export{s as _,g as a};
