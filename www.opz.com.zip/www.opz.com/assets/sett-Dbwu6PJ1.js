const s = "/images/icons/menus/api.svg",
    a = "/images/svg/sett.svg";
export {
    a as _, s as a
};