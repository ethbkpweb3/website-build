import {
    m as e,
    dm as l,
    y as a,
    dn as t,
    Y as s,
    a as i,
    I as o,
    N as r,
    h as d,
    K as n,
    B as u,
    o as m,
    j as c,
    l as p,
    v,
    w as b,
    X as g,
    t as y,
    q as h,
    n as w,
    P as f,
    cB as x,
    s as k,
    dg as L,
    p as S,
    ck as C
} from "./index-jdACH0Rc.js";
import "./index-Dwv4qbXN.js";
import {
    l as _
} from "./loadingSvg-B2DNNGSL.js";
import {
    _ as j
} from "./lodash-Bck59wt3.js";
import {
    a as V,
    E as U,
    v as D
} from "./directive-LFHXp42y.js";
import {
    E as F,
    a as E
} from "./index-CYOIannN.js";
import {
    E as z
} from "./index-D66pxSbk.js";
import {
    E as N,
    a as T
} from "./index-cRGdv3RN.js";
import {
    E as q
} from "./index-D4R9Vjdp.js";
import {
    a as P,
    E as I
} from "./index-DZsnwgZr.js";
import {
    E as B
} from "./index-CCs2guro.js";
import {
    E as A
} from "./index-Dq1-XyVz.js";
import {
    E as O
} from "./index-CI0d8yek.js";
import {
    _ as Y
} from "./_plugin-vue_export-helper-BCo6x5W8.js";
import {
    u as W
} from "./usePageTitle-BxNzo3__.js";
import "./index-Citk0ABi.js";
import "./typescript-CRqm1_SZ.js";
import "./index-BahOysPn.js";
import "./index-Cg9BJciP.js";
import "./use-global-config-Dm8LyY4T.js";
import "./dayjs.min-BNm5Luvd.js";
import "./index-DBFvTDaE.js";
import "./index-DyCSbSlA.js";
import "./_initCloneObject-CyvZF8uk.js";
import "./isPlainObject--3V5F7Ei.js";
import "./index-B1yvdImc.js";
import "./use-dialog-CmZNE833.js";
import "./vue.8fc199ce-D3bCrqKA.js";
import "./viewWrapper-Dh8gOQC5.js";
const $ = {
        class: "history-dashboard orders"
    },
    G = {
        class: "columns is-multiline"
    },
    K = {
        class: "column is-12 py-2"
    },
    M = {
        class: "history-header ord-tab"
    },
    R = {
        class: "history-tab flex"
    },
    H = {
        class: "tab"
    },
    X = {
        class: "history-tab flex"
    },
    Z = {
        class: "tab"
    },
    J = {
        class: "history-tab flex"
    },
    Q = {
        class: "tab"
    },
    ee = {
        key: 1,
        class: "mr-2"
    },
    le = {
        class: "history-body"
    },
    ae = {
        class: "history-filter"
    },
    te = {
        class: "filter-item"
    },
    se = {
        class: "flex items-center filter-item"
    },
    ie = {
        class: "text-medium"
    },
    oe = {
        class: "flex items-center filter-item"
    },
    re = {
        class: "text-medium"
    },
    de = {
        class: "flex items-center filter-item"
    },
    ne = {
        class: "text-medium"
    },
    ue = {
        class: "text-gray2"
    },
    me = {
        key: 0
    },
    ce = {
        key: 1
    },
    pe = {
        class: "text-gray2"
    },
    ve = {
        key: 0
    },
    be = {
        class: "text-gray2"
    },
    ge = {
        class: "text-gray2"
    },
    ye = {
        class: "text-gray2"
    },
    he = {
        key: 0,
        class: "text-gray2"
    },
    we = {
        key: 0
    },
    fe = {
        class: "text-gray2"
    },
    xe = {
        key: 1
    },
    ke = {
        key: 0
    },
    Le = {
        key: 1
    },
    Se = {
        class: "text-gray2"
    },
    Ce = {
        class: "mob-table-header"
    },
    _e = {
        class: "mob-t-text"
    },
    je = ["id"],
    Ve = {
        class: "mob-data-top"
    },
    Ue = {
        class: "mob-data-top-left"
    },
    De = {
        class: "mob-data-top-right"
    },
    Fe = {
        class: "mob-data-top"
    },
    Ee = {
        class: "mob-data-top-left"
    },
    ze = {
        class: "mob-data-top-right"
    },
    Ne = {
        class: "text-gray1"
    },
    Te = {
        class: "mob-data-top"
    },
    qe = {
        class: "mob-data-top-left"
    },
    Pe = {
        class: "mob-data-top-right"
    },
    Ie = {
        key: 0
    },
    Be = {
        class: "text-gray1"
    },
    Ae = {
        key: 1
    },
    Oe = {
        key: 0,
        class: "mob-data-top"
    },
    Ye = {
        class: "mob-data-top-left"
    },
    We = {
        class: "mob-data-top-right"
    },
    $e = {
        class: "text-gray1"
    },
    Ge = {
        key: 1,
        class: "mob-data-top"
    },
    Ke = {
        class: "mob-data-top-left"
    },
    Me = {
        class: "mob-data-top-right"
    },
    Re = {
        class: "text-gray1"
    },
    He = {
        key: 0,
        class: "block-dis e864twd10"
    },
    Xe = {
        class: "text-gray1"
    },
    Ze = {
        "aria-hidden": "true",
        class: "mob-data-bottom"
    },
    Je = {
        class: "mob-data-bottom2"
    },
    Qe = {
        key: 0,
        class: "mob-data-top"
    },
    el = {
        class: "mob-data-top-left"
    },
    ll = {
        class: "mob-data-top-right"
    },
    al = {
        class: "text-gray1"
    },
    tl = {
        key: 1,
        class: "mob-data-top"
    },
    sl = {
        class: "mob-data-top-left"
    },
    il = {
        direction: "buy",
        class: "mob-data-top-right"
    },
    ol = {
        class: "text-gray1"
    },
    rl = {
        key: 2,
        class: "mob-data-top"
    },
    dl = {
        class: "mob-data-top-left"
    },
    nl = {
        class: "mob-data-top-right"
    },
    ul = {
        class: "mob-data-top-right"
    },
    ml = {
        class: "text-gray2"
    },
    cl = {
        key: 3,
        class: "mob-data-top"
    },
    pl = {
        class: "mob-data-top-left"
    },
    vl = {
        class: "mob-data-top-right"
    },
    bl = {
        class: "text-gray1"
    },
    gl = {
        key: 4,
        class: "mob-data-top"
    },
    yl = {
        class: "mob-data-top-left"
    },
    hl = {
        class: "mob-data-top-right"
    },
    wl = {
        key: 5,
        class: "mob-data-top"
    },
    fl = {
        class: "mob-data-top-right"
    },
    xl = ["onClick"],
    kl = {
        class: "view-more"
    },
    Ll = {
        key: 3,
        class: "text-center text-gray-300"
    },
    Sl = {
        class: "history-filter"
    },
    Cl = {
        class: "filter-item flex items-center"
    },
    _l = {
        class: "text-medium"
    },
    jl = {
        class: "flex items-center filter-item"
    },
    Vl = {
        class: "text-medium"
    },
    Ul = {
        class: "flex"
    },
    Dl = {
        class: "flex items-center filter-item"
    },
    Fl = {
        class: "text-medium"
    },
    El = {
        class: "flex items-center filter-item"
    },
    zl = {
        class: "text-medium"
    },
    Nl = {
        class: "flex items-center filter-item justify-end"
    },
    Tl = Y(e({
        __name: "OrdersDashboard",
        setup(e) {
            const {
                Api: Y
            } = l(), W = a(window.innerWidth <= 767), Tl = t(), ql = a(!1), {
                t: Pl,
                locale: Il
            } = s(), Bl = i(), Al = a(""), Ol = a(""), Yl = a(""), Wl = a(""), $l = a(""), Gl = a(""), Kl = a(""), Ml = a(""), Rl = a(1), Hl = a(!0), Xl = a(0), Zl = {
                minimumFractionDigits: 0,
                maximumFractionDigits: 8
            }, Jl = a(""), Ql = e => {
                let l = 0;
                return e.detail.forEach((e => {
                    l += e.price
                })), l > 0 ? l / e.detail.length : 0
            };
            let ea;
            o((() => {
                ea = j.throttle((() => {
                    W.value = window.innerWidth <= 767
                }), 100), window.addEventListener("resize", ea)
            })), r((() => {
                window.removeEventListener("resize", ea)
            }));
            const la = [{
                text: Pl("pga.last-7-days"),
                value: () => {
                    const e = new Date,
                        l = new Date;
                    return l.setTime(l.getTime() - 6048e5), [l, e]
                }
            }, {
                text: Pl("pga.last-30-days"),
                value: () => {
                    const e = new Date,
                        l = new Date;
                    return l.setTime(l.getTime() - 2592e6), [l, e]
                }
            }, {
                text: Pl("pga.last-90-days"),
                value: () => {
                    const e = new Date,
                        l = new Date;
                    return l.setTime(l.getTime() - 7776e6), [l, e]
                }
            }];
            let aa = window.location.search.substring(1);
            "" != aa && aa.toLowerCase().includes("page") && (aa.includes("open") || (aa.includes("order") ? Xl.value = 1 : aa.includes("trade") && (Xl.value = 2)));
            const ta = d((() => ia.tableData.filter((e => !Jl.value || e.symbol.toLowerCase().includes(Jl.value.toLowerCase()))))),
                sa = (e, l) => {
                    const a = new FormData;
                    a.append("orderIds", String(l.orderId)), 2 == l.type ? Y.orderCancelMultipleTrigger(a).then((e => {
                        const l = e.data;
                        0 == l.code ? Bl.success(Pl("pga.order-canceled")) : Bl.error(l.message)
                    })) : Y.orderCancelMultiple(a).then((e => {
                        const l = e.data;
                        0 == l.code ? Bl.success(Pl("pga.order-canceled")) : Bl.error(l.message)
                    }))
                },
                ia = n({
                    tableData: [],
                    baseList: [],
                    coinList: [],
                    typeList: [{}],
                    directionList: [{}]
                }),
                oa = e => {
                    Hl.value = !0, e && (Rl.value = 1), (2 != Xl.value || e) && (ia.tableData = []);
                    const l = new FormData;
                    Wl.value && l.append("quoteSymbol", Wl.value), Ol.value && l.append("baseSymbol", Ol.value), Gl.value && l.append("direction", Gl.value), $l.value && l.append("type", $l.value), Kl.value && l.append("startTime", Kl.value), Ml.value && l.append("endTime", Ml.value), l.append("pageNo", Rl.value.toString()), l.append("pageSize", 2 == Xl.value ? "15" : "10"), 0 == Xl.value ? Y.PersonalCurrrent(l).then((e => {
                        Hl.value = !1, Yl.value = e.data.totalElements;
                        for (let l = 0; l < e.data.content.length; l++)
                            if (e.data.content[l]) {
                                const a = e.data.content[l];
                                ia.tableData.push(a)
                            }
                    })) : Xl.value > 0 && Y.PersonalHistory(l).then((e => {
                        var l;
                        Hl.value = !1, Yl.value = e.data.totalElements;
                        for (let a = 0; a < e.data.content.length; a++)
                            if (e.data.content[a]) {
                                const t = e.data.content[a];
                                if (2 == Xl.value)
                                    for (let e = 0; e < (null == (l = t.detail) ? void 0 : l.length); e++) t.detail[e].symbol = t.symbol, t.detail[e].quoteSymbol = t.quoteSymbol, t.detail[e].baseSymbol = t.baseSymbol, t.detail[e].direction = t.direction, ia.tableData.push(t.detail[e]);
                                else ia.tableData.push(t)
                            }
                    }))
                };
            oa(!1);
            const ra = e => {
                    e && e[0] && e[1] ? (Kl.value = e[0], Ml.value = e[1]) : (Kl.value = "", Ml.value = "")
                },
                da = () => {
                    Number(Yl.value) > 15 * Rl.value && (Rl.value = Rl.value + 1, oa(!1))
                };

            function na(e) {
                return new Intl.DateTimeFormat("en-GB", {
                    timeStyle: "medium",
                    dateStyle: "short",
                    timeZone: "UTC"
                }).format(new Date(e))
            }
            const ua = e => {
                const l = "string" == typeof e ? parseFloat(e) : e;
                if (isNaN(l) || !isFinite(l)) return "";
                const a = l.toString();
                if (/e/i.test(a)) {
                    const e = a.match(/e(?:\+|-)(\d+)$/);
                    if (e && e[1]) {
                        const a = parseInt(e[1], 10);
                        return l.toFixed(a + 1).replace(/\.?0+$/, "")
                    }
                }
                return l.toString()
            };
            Y.getSymbolPrice().then((e => {
                if (e.data.length > 0) {
                    const l = e.data;
                    ia.coinList.push({
                        value: "",
                        label: Pl("dash.all").toUpperCase()
                    }), ia.baseList.push({
                        value: "",
                        label: Pl("dash.all").toUpperCase()
                    });
                    for (let e = 0; e < l.length; e++) {
                        const a = l[e].symbol.split("/");
                        ia.coinList.some((e => e.value == a[0])) || ia.coinList.push({
                            value: a[0],
                            label: a[0]
                        }), ia.baseList.some((e => e.value == a[1])) || ia.baseList.push({
                            value: a[1],
                            label: a[1]
                        })
                    }
                }
            }));
            const ma = () => {
                    Al.value = "", (Ol.value || Wl.value || $l.value || Gl.value || Kl.value || Ml.value) && (Ol.value = "", Wl.value = "", $l.value = "", Gl.value = "", Kl.value = "", Ml.value = "", Rl.value = 1, oa(!0))
                },
                ca = () => {
                    ia.typeList = [{
                        value: "",
                        label: Pl("dash.all").toUpperCase()
                    }, {
                        value: "0",
                        label: Pl("exh.limit").toUpperCase()
                    }, {
                        value: "1",
                        label: Pl("exh.market").toUpperCase()
                    }], ia.directionList = [{
                        value: "",
                        label: Pl("dash.all").toUpperCase()
                    }, {
                        value: "BUY",
                        label: Pl("wall.buy").toUpperCase()
                    }, {
                        value: "SELL",
                        label: Pl("wall.sell").toUpperCase()
                    }]
                };
            ca(), u(Il, (() => {
                ca(), ia.coinList.find((e => "" == e.value)).label = Pl("dash.all").toUpperCase(), ia.baseList.find((e => "" == e.value)).label = Pl("dash.all").toUpperCase()
            }));
            return (e, l) => (m(), c(f, null, [p("div", $, [p("div", null, [p("div", G, [p("div", K, [p("div", M, [v(g(U), {
                modelValue: Xl.value,
                "onUpdate:modelValue": l[0] || (l[0] = e => Xl.value = e),
                class: "filter-tabs",
                onTabChange: l[1] || (l[1] = e => oa(!0))
            }, {
                default: b((() => [v(g(V), {
                    name: 0,
                    disabled: Hl.value
                }, {
                    label: b((() => [p("div", R, [p("div", H, y(g(Pl)("wall.open-orders")), 1)])])),
                    _: 1
                }, 8, ["disabled"]), v(g(V), {
                    name: 1,
                    disabled: Hl.value
                }, {
                    label: b((() => [p("div", X, [p("div", Z, y(g(Pl)("wall.order-history")), 1)])])),
                    _: 1
                }, 8, ["disabled"]), v(g(V), {
                    name: 2,
                    disabled: Hl.value
                }, {
                    label: b((() => [p("div", J, [p("div", Q, y(g(Pl)("wall.trade-history")), 1)])])),
                    _: 1
                }, 8, ["disabled"])])),
                _: 1
            }, 8, ["modelValue"]), W.value ? (m(), c("div", {
                key: 0,
                class: "ml-5",
                onClick: l[2] || (l[2] = e => {
                    ql.value = !0
                })
            }, l[20] || (l[20] = [p("img", {
                class: "img-fnl",
                src: "/images/svg/funnel.svg",
                width: "12",
                height: "12",
                alt: ""
            }, null, -1)]))) : (m(), c("div", ee, [v(g(E), null, {
                default: b((() => [v(g(F), {
                    type: "primary",
                    size: "small",
                    class: "btn-order-header",
                    onClick: l[3] || (l[3] = e => ma())
                }, {
                    default: b((() => [l[21] || (l[21] = p("i", {
                        class: "lnir lnir-reload mr-2",
                        "aria-hidden": "true"
                    }, null, -1)), h(y(g(Pl)("wall.reset")), 1)])),
                    _: 1
                }), v(g(F), {
                    type: "primary",
                    size: "small",
                    class: "btn-order-header",
                    onClick: l[4] || (l[4] = e => oa(!0))
                }, {
                    default: b((() => [h(y(g(Pl)("wall.search")) + " ", 1), l[22] || (l[22] = p("i", {
                        class: "lnir lnir-search-alt ml-2",
                        "aria-hidden": "true"
                    }, null, -1))])),
                    _: 1
                })])),
                _: 1
            })]))]), p("div", le, [W.value ? k("", !0) : (m(), w(g(q), {
                key: 0,
                class: "scroll-filter"
            }, {
                default: b((() => [p("div", ae, [p("div", te, [v(g(z), {
                    modelValue: Al.value,
                    "onUpdate:modelValue": l[5] || (l[5] = e => Al.value = e),
                    type: "daterange",
                    "unlink-panels": "",
                    class: "datepick-small light-radio-group",
                    "range-separator": g(Pl)("wall.to"),
                    "start-placeholder": g(Pl)("wall.start-date"),
                    "end-placeholder": g(Pl)("wall.end-date"),
                    shortcuts: la,
                    "value-format": "x",
                    onChange: ra
                }, null, 8, ["modelValue", "range-separator", "start-placeholder", "end-placeholder"])]), p("div", se, [p("div", ie, y(g(Pl)("wall.symbol") + " "), 1), v(g(N), {
                    modelValue: Ol.value,
                    "onUpdate:modelValue": l[6] || (l[6] = e => Ol.value = e),
                    class: "mr-2 ml-2",
                    size: "small",
                    placeholder: g(Pl)("dash.all").toUpperCase(),
                    style: {
                        "max-width": "85px",
                        "min-width": "75px"
                    }
                }, {
                    default: b((() => [(m(!0), c(f, null, x(ia.coinList, (e => (m(), w(g(T), {
                        key: e.value,
                        label: e.label,
                        value: e.value
                    }, null, 8, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue", "placeholder"]), l[23] || (l[23] = h("/ ")), v(g(N), {
                    modelValue: Wl.value,
                    "onUpdate:modelValue": l[7] || (l[7] = e => Wl.value = e),
                    class: "mx-1",
                    size: "small",
                    placeholder: g(Pl)("dash.all").toUpperCase(),
                    style: {
                        "max-width": "85px",
                        "min-width": "75px"
                    }
                }, {
                    default: b((() => [(m(!0), c(f, null, x(ia.baseList, (e => (m(), w(g(T), {
                        key: e.value,
                        label: e.label,
                        value: e.value
                    }, null, 8, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue", "placeholder"])]), p("div", oe, [p("div", re, y(g(Pl)("wall.type") + " "), 1), v(g(N), {
                    modelValue: $l.value,
                    "onUpdate:modelValue": l[8] || (l[8] = e => $l.value = e),
                    size: "small",
                    class: "mr-2 ml-2",
                    placeholder: g(Pl)("dash.all").toUpperCase(),
                    style: {
                        "max-width": "100px",
                        "min-width": "90px"
                    }
                }, {
                    default: b((() => [(m(!0), c(f, null, x(ia.typeList, (e => (m(), w(g(T), {
                        key: e.value,
                        label: e.label,
                        value: e.value
                    }, null, 8, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue", "placeholder"])]), p("div", de, [p("div", ne, y(g(Pl)("wall.direction") + " "), 1), v(g(N), {
                    modelValue: Gl.value,
                    "onUpdate:modelValue": l[9] || (l[9] = e => Gl.value = e),
                    class: "mr-2 ml-2",
                    size: "small",
                    placeholder: g(Pl)("dash.all").toUpperCase(),
                    style: {
                        "max-width": "90px",
                        "min-width": "80px"
                    }
                }, {
                    default: b((() => [(m(!0), c(f, null, x(ia.directionList, (e => (m(), w(g(T), {
                        key: e.value,
                        label: e.label,
                        value: e.value
                    }, null, 8, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue", "placeholder"])])])])),
                _: 1
            })), W.value ? (m(!0), c(f, {
                key: 2
            }, x(ta.value, ((e, a) => {
                var t, s;
                return m(), c("div", {
                    key: a,
                    class: "mob-table"
                }, [p("div", Ce, [p("div", {
                    class: "mob-t-img",
                    style: C("background-image: url(/images/icons/coin/" + (null == (t = e.baseSymbol) ? void 0 : t.toLowerCase()) + ".svg")
                }, null, 4), p("div", _e, y(e.symbol), 1), p("div", {
                    class: S(["mob-t-text-end", "SELL" == e.direction ? "red-txt" : "green-txt"])
                }, y(("SELL" == e.direction ? g(Pl)("wall.sell") : g(Pl)("wall.buy")) + " " + (2 == e.type ? g(Pl)("exh.trigger") + " " : "") + (1 == e.type || 2 == e.type && Number(e.price) > 0 ? g(Pl)("wall.limit-order") : g(Pl)("wall.market-order"))), 3)]), p("div", {
                    id: "mob-table-" + a,
                    class: "mob-table-body"
                }, [p("div", Ve, [p("div", Ue, [p("span", null, y(g(Pl)("wall.order-time")), 1)]), p("div", De, y(na(e.time)), 1)]), p("div", Fe, [p("div", Ee, [p("span", null, y(g(Pl)("depwi.amount")), 1)]), p("div", ze, [h(y(e.amount) + " ", 1), p("span", Ne, y(e.baseSymbol), 1)])]), p("div", Te, [p("div", qe, [p("span", null, y(g(Pl)("wall.price")), 1)]), p("div", Pe, [1 == e.type || 2 == e.type && Number(e.price) > 0 ? (m(), c("div", Ie, [h(y(e.price.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), p("span", Be, y(e.quoteSymbol), 1)])) : (m(), c("div", Ae, y(g(Pl)("wall.market-order")), 1))])]), 2 == e.type ? (m(), c("div", Oe, [p("div", Ye, [p("span", null, y(g(Pl)("wall.trigger-price")), 1)]), p("div", We, [p("div", null, [h(y(e.triggerPrice.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), p("span", $e, y(e.quoteSymbol), 1)])])])) : k("", !0), 2 != e.type || 0 != Number(e.price) ? (m(), c("div", Ge, [p("div", Ke, [p("span", null, y(g(Pl)("wall.total")), 1)]), p("div", Me, [h(y((e.amount * (Number(e.price) || Ql(e))).toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), p("span", Re, y(e.quoteSymbol), 1), "USD" != g(Tl).currency ? (m(), c("div", He, [p("span", null, [h(y(" = " + (e.amount * Ql(e) * Number(g(Tl).currencyRate.toString())).toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), p("span", Xe, y(" " + g(Tl).currency), 1)])])) : k("", !0)])])) : k("", !0), p("div", Ze, [p("div", Je, [2 != Xl.value ? (m(), c("div", Qe, [p("div", el, [p("span", null, y(g(Pl)("wall.filled")), 1)]), p("div", ll, [h(y(e.tradedAmount.toLocaleString(void 0, { ...Zl
                })) + " ", 1), p("span", al, y(e.baseSymbol), 1)])])) : k("", !0), 0 == Xl.value ? (m(), c("div", tl, [p("div", sl, [p("span", null, y(g(Pl)("dash.in-c-order")), 1)]), p("div", il, [h(y((e.amount - e.tradedAmount).toLocaleString(void 0, { ...Zl
                })) + " ", 1), p("span", ol, y(e.baseSymbol), 1)])])) : k("", !0), 2 == Xl.value ? (m(), c("div", rl, [p("div", dl, [p("span", null, y(g(Pl)("wall.fee")), 1)]), p("div", nl, [p("div", ul, [h(y(ua(e.fee)) + " ", 1), p("span", ml, y(e.feeSymbol), 1)])])])) : k("", !0), 1 == Xl.value ? (m(), c("div", cl, [p("div", pl, [p("span", null, y(g(Pl)("wall.avg-filled-price")), 1)]), p("div", vl, [h(y(null == (s = Ql(e)) ? void 0 : s.toLocaleString(void 0, {
                    minimumFractionDigits: 2
                })) + " ", 1), p("span", bl, y(e.quoteSymbol), 1)])])) : k("", !0), 1 == Xl.value ? (m(), c("div", gl, [p("div", yl, [p("span", null, y(g(Pl)("wall.status")), 1)]), p("div", hl, y(1 == e.status ? "Completed" : 2 == e.status ? "Canceled" : "Overtimed"), 1)])) : k("", !0), 0 == Xl.value ? (m(), c("div", wl, [l[25] || (l[25] = p("div", {
                    class: "mob-data-top-left"
                }, [p("span")], -1)), p("div", fl, [v(g(B), {
                    class: "text-10",
                    type: "primary",
                    onClick: l => sa(0, e)
                }, {
                    default: b((() => [h(y(g(Pl)("wall.cancel")), 1)])),
                    _: 2
                }, 1032, ["onClick"])])])) : k("", !0)])]), p("div", {
                    class: "more-info",
                    onClick: e => (e => {
                        const l = document.getElementById(e);
                        if (null != l) {
                            const e = document.getElementsByClassName("enabled-dc");
                            if (l.classList.toString().includes("enabled-dc")) return void l.classList.remove("enabled-dc");
                            null != e && null != e[0] && e[0].classList.remove("enabled-dc"), l.classList.add("enabled-dc")
                        }
                    })("mob-table-" + a)
                }, [p("span", kl, y(g(Pl)("wall.view-more")), 1), l[26] || (l[26] = p("span", {
                    class: "view-less"
                }, y("View Less"), -1)), l[27] || (l[27] = p("button", {
                    class: "btn-more"
                }, null, -1))], 8, xl)], 8, je)])
            })), 128)) : L((m(), w(g(I), {
                key: 1,
                class: "slim-table",
                "element-loading-background": "rgba(0, 0, 0, 0.8)",
                "element-loading-text": g(Pl)("pga.loading"),
                "element-loading-spinner": g(_),
                "element-loading-svg-view-box": "-10, -10, 50, 50",
                data: ta.value,
                "max-height": "435",
                "tooltip-effect": "dark",
                "default-sort": {
                    prop: "time",
                    order: "descending"
                }
            }, {
                default: b((() => [v(g(P), {
                    label: g(Pl)("wall.order-time"),
                    prop: "time",
                    width: "165",
                    "class-name": "timeColumn",
                    sortable: ""
                }, {
                    default: b((e => [h(y(na(e.row.time)), 1)])),
                    _: 1
                }, 8, ["label"]), v(g(P), {
                    label: g(Pl)("wall.symbol"),
                    width: "120",
                    prop: "symbol",
                    sortable: ""
                }, null, 8, ["label"]), v(g(P), {
                    label: g(Pl)("wall.direction"),
                    width: "105"
                }, {
                    default: b((e => [p("div", {
                        class: S("SELL" == e.row.direction ? "text-red-darken" : "text-green-darken")
                    }, y(e.row.direction), 3)])),
                    _: 1
                }, 8, ["label"]), 2 !== Xl.value ? (m(), w(g(P), {
                    key: 0,
                    label: g(Pl)("wall.type"),
                    width: "105"
                }, {
                    default: b((e => [h(y(1 == e.row.type ? g(Pl)("exh.limit") : 0 == e.row.type ? g(Pl)("exh.market") : g(Pl)("exh.trigger")), 1)])),
                    _: 1
                }, 8, ["label"])) : k("", !0), v(g(P), {
                    label: g(Pl)("depwi.amount"),
                    align: "right"
                }, {
                    default: b((e => [h(y(e.row.amount.toLocaleString(void 0, { ...Zl
                    })) + " ", 1), p("span", ue, y(e.row.baseSymbol), 1)])),
                    _: 1
                }, 8, ["label"]), v(g(P), {
                    label: g(Pl)("wall.total"),
                    align: "right",
                    "min-width": "100"
                }, {
                    default: b((e => [0 == e.row.price && 0 === Ql(e.row) ? (m(), c("div", me, y(g(Pl)("exh.market-price")), 1)) : (m(), c("div", ce, [h(y((e.row.amount * (e.row.price || Ql(e.row))).toLocaleString(void 0, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    })) + " ", 1), p("span", pe, y(e.row.quoteSymbol), 1), "USD" != g(Tl).currency ? (m(), c("span", ve, [h(y(" = " + (e.row.amount * e.row.price * Number(g(Tl).currencyRate.toString())).toLocaleString(void 0, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    })) + " ", 1), p("span", be, y(" " + g(Tl).currency), 1)])) : k("", !0)]))])),
                    _: 1
                }, 8, ["label"]), 2 != Xl.value ? (m(), w(g(P), {
                    key: 1,
                    label: g(Pl)("wall.filled"),
                    align: "right"
                }, {
                    default: b((e => [h(y(e.row.tradedAmount.toLocaleString(void 0, { ...Zl
                    })) + " ", 1), p("span", ge, y(e.row.baseSymbol), 1)])),
                    _: 1
                }, 8, ["label"])) : k("", !0), 0 == Xl.value ? (m(), w(g(P), {
                    key: 2,
                    label: g(Pl)("dash.in-c-order"),
                    align: "right"
                }, {
                    default: b((e => [h(y((e.row.amount - e.row.tradedAmount).toLocaleString(void 0, { ...Zl
                    })) + " ", 1), p("span", ye, y(e.row.baseSymbol), 1)])),
                    _: 1
                }, 8, ["label"])) : k("", !0), v(g(P), {
                    label: g(Pl)("wall.price"),
                    align: "right",
                    prop: "price",
                    sortable: ""
                }, {
                    default: b((e => [h(y(0 === e.row.type || 0 == e.row.price ? g(Pl)("exh.market-price") : e.row.price.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })) + " ", 1), 0 !== e.row.type && 0 != e.row.price ? (m(), c("span", he, y(e.row.quoteSymbol), 1)) : k("", !0)])),
                    _: 1
                }, 8, ["label"]), 2 == Xl.value ? (m(), w(g(P), {
                    key: 3,
                    label: g(Pl)("wall.fee"),
                    align: "right",
                    prop: "price",
                    sortable: ""
                }, {
                    default: b((e => [1 != e.row.type ? (m(), c("div", we, [h(y(ua(e.row.fee)) + " ", 1), p("span", fe, y(e.row.feeSymbol), 1)])) : (m(), c("div", xe, y(g(Pl)("wall.market-order")), 1))])),
                    _: 1
                }, 8, ["label"])) : k("", !0), 1 == Xl.value ? (m(), w(g(P), {
                    key: 4,
                    label: g(Pl)("wall.avg-filled-price"),
                    align: "right"
                }, {
                    default: b((e => {
                        var l;
                        return [0 === Ql(e.row) ? (m(), c("div", ke, "-")) : (m(), c("div", Le, [h(y(null == (l = Ql(e.row)) ? void 0 : l.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })) + " ", 1), p("span", Se, y(e.row.quoteSymbol), 1)]))]
                    })),
                    _: 1
                }, 8, ["label"])) : k("", !0), 1 == Xl.value ? (m(), w(g(P), {
                    key: 5,
                    align: "right",
                    label: g(Pl)("wall.status")
                }, {
                    default: b((e => [h(y(1 == e.row.status ? g(Pl)("hiss.completed") : 2 == e.row.status ? g(Pl)("exh.canceled") : 3 == e.row.status ? g(Pl)("exh.overtimed") : 4 == e.row.status ? g(Pl)("exh.pending") : g(Pl)("exh.rejected")), 1)])),
                    _: 1
                }, 8, ["label"])) : k("", !0), 0 == Xl.value ? (m(), w(g(P), {
                    key: 6,
                    align: "right",
                    width: "120"
                }, {
                    header: b((() => l[24] || (l[24] = []))),
                    default: b((e => [v(g(B), {
                        class: "text-10",
                        type: "primary",
                        onClick: l => sa(e.$index, e.row)
                    }, {
                        default: b((() => [h(y(g(Pl)("wall.cancel")), 1)])),
                        _: 2
                    }, 1032, ["onClick"])])),
                    _: 1
                })) : k("", !0)])),
                _: 1
            }, 8, ["element-loading-text", "element-loading-spinner", "data"])), [
                [g(D), Hl.value]
            ]), W.value && ta.value.length <= 0 ? (m(), c("p", Ll, y(g(Pl)("exh.no-records-found")), 1)) : k("", !0), p("div", null, [2 != Xl.value ? (m(), w(g(A), {
                key: 0,
                currentPage: Rl.value,
                "onUpdate:currentPage": [l[10] || (l[10] = e => Rl.value = e), l[11] || (l[11] = e => oa(!1))],
                class: "mt-5",
                background: "",
                "hide-on-single-page": "",
                size: "small",
                "page-size": 10,
                layout: "prev, pager, next, jumper",
                total: Number(Yl.value)
            }, null, 8, ["currentPage", "total"])) : (m(), w(g(F), {
                key: 1,
                class: "mt-4 text-medium",
                style: {
                    width: "100%"
                },
                disabled: Number(Yl.value) < 15 * Rl.value,
                onClick: da
            }, {
                default: b((() => [h(y(g(Pl)("wall.view-more")), 1)])),
                _: 1
            }, 8, ["disabled"]))])])])])])]), W.value ? (m(), w(g(O), {
                key: 0,
                modelValue: ql.value,
                "onUpdate:modelValue": l[19] || (l[19] = e => ql.value = e),
                class: "drawerFilterClick",
                direction: "btt",
                size: 291,
                "lock-scroll": !0,
                "destroy-on-close": !0
            }, {
                header: b((() => l[28] || (l[28] = [p("div", {
                    class: "head-text"
                }, "Filter", -1)]))),
                default: b((() => [p("div", Sl, [p("div", Cl, [p("div", _l, y(g(Pl)("wall.date-utc") + " "), 1), v(g(z), {
                    modelValue: Al.value,
                    "onUpdate:modelValue": l[12] || (l[12] = e => Al.value = e),
                    type: "daterange",
                    class: "datepick-small light-radio-group",
                    "unlink-panels": "",
                    "range-separator": g(Pl)("wall.to"),
                    "start-placeholder": g(Pl)("wall.start-date"),
                    "end-placeholder": g(Pl)("wall.end-date"),
                    shortcuts: la,
                    "value-format": "x",
                    onChange: ra,
                    style: {
                        "max-width": "300px"
                    }
                }, null, 8, ["modelValue", "range-separator", "start-placeholder", "end-placeholder"])]), p("div", jl, [p("div", Vl, y(g(Pl)("wall.symbol") + " "), 1), p("div", Ul, [v(g(N), {
                    modelValue: Ol.value,
                    "onUpdate:modelValue": l[13] || (l[13] = e => Ol.value = e),
                    size: "small",
                    class: "mr-2 ml-2",
                    placeholder: g(Pl)("dash.all").toUpperCase(),
                    style: {
                        "max-width": "85px",
                        "min-width": "75px"
                    }
                }, {
                    default: b((() => [(m(!0), c(f, null, x(ia.coinList, (e => (m(), w(g(T), {
                        key: e.value,
                        label: e.label,
                        value: e.value
                    }, null, 8, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue", "placeholder"]), l[29] || (l[29] = h("/  ")), v(g(N), {
                    modelValue: Wl.value,
                    "onUpdate:modelValue": l[14] || (l[14] = e => Wl.value = e),
                    size: "small",
                    class: "mx-1",
                    placeholder: g(Pl)("dash.all").toUpperCase(),
                    style: {
                        "max-width": "85px",
                        "min-width": "75px"
                    }
                }, {
                    default: b((() => [(m(!0), c(f, null, x(ia.baseList, (e => (m(), w(g(T), {
                        key: e.value,
                        label: e.label,
                        value: e.value
                    }, null, 8, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue", "placeholder"])])]), p("div", Dl, [p("div", Fl, y(g(Pl)("wall.type") + " "), 1), v(g(N), {
                    modelValue: $l.value,
                    "onUpdate:modelValue": l[15] || (l[15] = e => $l.value = e),
                    size: "small",
                    class: "mr-2 ml-2",
                    placeholder: g(Pl)("dash.all").toUpperCase(),
                    style: {
                        "max-width": "100px",
                        "min-width": "90px"
                    }
                }, {
                    default: b((() => [(m(!0), c(f, null, x(ia.typeList, (e => (m(), w(g(T), {
                        key: e.value,
                        label: e.label,
                        value: e.value
                    }, null, 8, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue", "placeholder"])]), p("div", El, [p("div", zl, y(g(Pl)("wall.direction") + " "), 1), v(g(N), {
                    modelValue: Gl.value,
                    "onUpdate:modelValue": l[16] || (l[16] = e => Gl.value = e),
                    class: "mr-2 ml-2",
                    size: "small",
                    placeholder: g(Pl)("dash.all").toUpperCase(),
                    style: {
                        "max-width": "90px",
                        "min-width": "80px"
                    }
                }, {
                    default: b((() => [(m(!0), c(f, null, x(ia.directionList, (e => (m(), w(g(T), {
                        key: e.value,
                        label: e.label,
                        value: e.value
                    }, null, 8, ["label", "value"])))), 128))])),
                    _: 1
                }, 8, ["modelValue", "placeholder"])]), p("div", Nl, [v(g(E), {
                    class: "btn-group"
                }, {
                    default: b((() => [v(g(F), {
                        type: "primary",
                        size: "small",
                        class: "btn-order-header",
                        onClick: l[17] || (l[17] = e => ma())
                    }, {
                        default: b((() => [l[30] || (l[30] = p("i", {
                            class: "lnir lnir-reload mr-2",
                            "aria-hidden": "true"
                        }, null, -1)), h(y(g(Pl)("wall.reset")), 1)])),
                        _: 1
                    }), v(g(F), {
                        type: "primary",
                        size: "small",
                        class: "btn-order-header",
                        onClick: l[18] || (l[18] = e => oa(!0))
                    }, {
                        default: b((() => [h(y(g(Pl)("wall.search")) + " ", 1), l[31] || (l[31] = p("i", {
                            class: "lnir lnir-search-alt ml-2",
                            "aria-hidden": "true"
                        }, null, -1))])),
                        _: 1
                    })])),
                    _: 1
                })])])])),
                _: 1
            }, 8, ["modelValue"])) : k("", !0)], 64))
        }
    }), [
        ["__scopeId", "data-v-66879e21"]
    ]),
    ql = {
        class: "page-content-inner"
    },
    Pl = e({
        __name: "orders",
        setup: e => (W("wall.orders"), (e, l) => {
            const a = Tl;
            return m(), c("div", ql, [v(a)])
        })
    });
export {
    Pl as
    default
};