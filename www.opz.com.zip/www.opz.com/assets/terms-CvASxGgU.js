import {
    _ as s
} from "./FooterB-Blg-ttBc.js";
import {
    _ as t
} from "./Navbar2-DVEXcHRs.js";
import {
    m as o,
    Y as e,
    dp as i,
    dn as r,
    cC as a,
    j as n,
    X as p,
    n as m,
    s as l,
    v as j,
    w as d,
    P as u,
    o as c,
    bw as x,
    cE as f,
    l as g,
    q as k,
    t as _
} from "./index-jdACH0Rc.js";
import {
    u as v
} from "./vue.8fc199ce-D3bCrqKA.js";
import {
    u as b
} from "./useSeoMeta-CRPJPIvz.js";
import "./_plugin-vue_export-helper-BCo6x5W8.js";
import "./AppPop-C6dVPDH2.js";
import "./index-Dwv4qbXN.js";
import "./browser-B3Bvmjnq.js";
import "./index-DPTDKB4o.js";
import "./index-D4R9Vjdp.js";
import "./index-Citk0ABi.js";
import "./index-DtPnfIe2.js";
import "./google-play-0W6tGWt8.js";
import "./VPlaceload-jGgmcTFZ.js";
import "./Button-BbTMX0Dh.js";
import "./AvatarSimple-CfXnZ0K8.js";
import "./via-placeholder-csI6CdwS.js";
import "./user-qMNVzsWD.js";
import "./sett-Dbwu6PJ1.js";
import "./avatarSettings-Daanxsoo.js";
import "./vue3-avataaars-C_k_hIh4.js";
import "./index-cRGdv3RN.js";
import "./ButtonGR-BF9zAU5B.js";
import "./index-C8W9xb4z.js";
import "./index-B1yvdImc.js";
import "./index-Cg9BJciP.js";
import "./use-dialog-CmZNE833.js";
import "./use-global-config-Dm8LyY4T.js";
import "./index-BWeq1WY3.js";
import "./index-DBFvTDaE.js";
import "./typescript-CRqm1_SZ.js";
import "./logo-DqlCWKKL.js";
import "./index-DWTvrBdo.js";
import "./aria-C-hsWcn7.js";
const y = {
        class: "inline-block px-2"
    },
    h = {
        class: "inline-block px-2"
    },
    w = o({
        __name: "terms",
        setup(o) {
            const {
                t: w
            } = e();
            b(w("inx.terms-conditions"), "OPZ " + w("inx.terms-conditions"));
            const A = i(),
                B = r(),
                P = !!A.query.mobile;
            return v({
                meta: [{
                    name: "robots",
                    content: "noindex"
                }]
            }), (o, e) => {
                const i = t,
                    r = a("RouterView"),
                    v = a("RouterLink"),
                    b = s;
                return c(), n(u, null, [p(B).isAppOn || p(P) ? l("", !0) : (c(), m(i, {
                    key: 0
                })), j(r, null, {
                    default: d((({
                        Component: s
                    }) => [j(x, {
                        name: "fade-fast",
                        mode: "out-in"
                    }, {
                        default: d((() => [(c(), m(f(s), {
                            key: p(A).fullPath
                        }))])),
                        _: 2
                    }, 1024)])),
                    _: 1
                }), p(B).isAppOn || p(P) ? l("", !0) : (c(), m(b, {
                    key: 1
                }, {
                    links: d((() => [g("li", y, [j(v, {
                        to: {
                            name: "index"
                        },
                        class: "footer-link"
                    }, {
                        default: d((() => [k(_(p(w)("pga.home")), 1)])),
                        _: 1
                    })]), g("li", h, [j(v, {
                        to: {
                            name: "help-desk-center"
                        },
                        class: "footer-link"
                    }, {
                        default: d((() => [k(_(p(w)("pga.help-center")), 1)])),
                        _: 1
                    })])])),
                    _: 1
                }))], 64)
            }
        }
    });
export {
    w as
    default
};