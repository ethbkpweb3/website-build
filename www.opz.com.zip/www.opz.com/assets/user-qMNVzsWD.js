const s = "/images/svg/user.svg";
export {
    s as _
};