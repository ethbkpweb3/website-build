import {
    i as a,
    o as r,
    j as t,
    k as e,
    l as i
} from "./index-jdACH0Rc.js";
const l = {
        render: function(a, e) {
            return r(), t("svg")
        }
    },
    s = [e('<g id="Top/_Resources/Prescription-01" fill="none" transform="translate(62 85)"><defs><filter id="filter1" width="101.5%" height="109.8%" x="-.8%" y="-2.4%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter></defs><g id="Glasses" fill="#D6EAF2" filter="url(&#39;#filter1&#39;)" transform="translate(8 8)"><path id="Frame-Stuff" d="M46.25 7.275c2.37.022 3.492.417 3.896 2.89.41 2.506.011 5.322-.46 7.79-.721 3.768-1.92 7.46-4.708 10.214-1.47 1.45-3.261 2.606-5.167 3.395-1.012.42-2.081.722-3.15.952-.312.067-2.979.434-1.343.248-3.817.435-7.958.418-11.146-2.012-3.532-2.692-5.952-6.952-7.015-11.196-.623-2.483-1.93-8.422.459-10.407 2.737-2.274 28.633-1.874 28.633-1.874M22.217.491c-5.44.187-9.071 1.143-11.755 6.578-4.917 9.961 3.5 24.9 12.89 28.97 10.976 4.76 23.24-.507 29.043-10.033 3.073-5.044 4.626-12.683 4.526-18.502C56.795.077 51.607-.13 45.51.034zM79.68 7.273c-2.371.022-3.492.416-3.896 2.89-.41 2.505-.012 5.322.46 7.79.72 3.767 1.919 7.459 4.708 10.213 1.47 1.45 3.261 2.606 5.167 3.396 1.012.419 2.08.722 3.15.951.312.067 2.978.435 1.343.248 3.817.436 7.958.418 11.145-2.011 3.533-2.692 5.952-6.952 7.016-11.196.623-2.483 1.93-8.422-.46-10.407-2.737-2.275-28.632-1.874-28.632-1.874M103.713.488c5.44.187 9.071 1.144 11.754 6.579 4.918 9.96-3.5 24.9-12.889 28.97-10.977 4.76-23.24-.508-29.043-10.033C70.46 20.96 68.907 13.32 69.007 7.5 69.135.074 74.323-.132 80.42.031z"></path><path id="Frame-Stuff" d="M13.197 4.927c-3.412.191-7.31.237-10.507 1.712-3.385 1.562-3.908 5.1.36 5.587 1.92.22 3.845-.143 5.737-.481 1.55-.277 3.655-.187 5.12-.78 2.729-1.103 2.553-6.225-.71-6.038m99.538 0c3.412.191 7.31.237 10.507 1.712 3.384 1.562 3.907 5.1-.36 5.587-1.921.22-3.845-.143-5.738-.481-1.55-.277-3.654-.187-5.119-.78-2.73-1.103-2.554-6.225.71-6.038M73.11 7.013c-1.947-2.3-7.019-3.628-10.219-3.628s-8.123 1.328-10.069 3.628c-.981 1.16-1.015 2.711.686 3.438 2.118.906 4.01-.737 5.705-1.596 2.168-1.098 5.499-.978 7.506 0 1.708.833 3.586 2.502 5.704 1.596 1.701-.727 1.668-2.279.686-3.438"></path></g></g>', 1)];
const o = {
        render: function(a, e) {
            return r(), t("svg", null, [...s])
        }
    },
    h = [e('<g id="Top/_Resources/Round" fill="none" transform="translate(62 85)"><defs><filter id="filter1" width="101.6%" height="108.3%" x="-.8%" y="-2.1%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0"></feColorMatrix></filter><path id="Round-path1" d="M80.465 16.394C84.38 8.46 92.553 3 102 3c8.92 0 16.703 4.866 20.84 12.088q.316-.087.66-.088h8a2.5 2.5 0 1 1 0 5h-6.537A24 24 0 0 1 126 27c0 13.255-10.745 24-24 24S78 40.255 78 27c0-1.422.124-2.815.36-4.169C78.277 18.455 74.915 15 70.863 15c-3.736 0-6.887 2.94-7.42 6.83.365 1.665.558 3.395.558 5.17 0 13.255-10.745 24-24 24S16 40.255 16 27c0-2.435.363-4.785 1.037-7H10.5a2.5 2.5 0 1 1 0-5h8q.343 0 .66.088C23.297 7.866 31.08 3 40 3c9.352 0 17.455 5.35 21.416 13.155C63.493 13.039 66.949 11 70.862 11c4.013 0 7.545 2.144 9.603 5.394M40 47c11.046 0 20-8.954 20-20S51.046 7 40 7s-20 8.954-20 20 8.954 20 20 20m62 0c11.046 0 20-8.954 20-20s-8.954-20-20-20-20 8.954-20 20 8.954 20 20 20"></path></defs><g id="Lennon-Glasses"><use fill="#000" filter="url(&#39;#filter1&#39;)" href="#Round-path1"></use><use fill="#252C2F" href="#Round-path1"></use></g></g>', 1)];
const c = {
        render: function(a, e) {
            return r(), t("svg", null, [...h])
        }
    },
    n = [e('<g id="Top/_Resources/Wayfarers" fill="none" stroke-width="1" transform="translate(62 85)"><defs><path id="react-path-1157" d="M44.918 17.571c0 9.703-8.25 17.572-21.998 17.572h-2.75C6.423 35.143.923 27.27.923 17.57.923 7.866 2.207 0 21.455 0h2.931c19.248 0 20.532 7.866 20.532 17.571"></path><path id="react-path-1158" d="M106.486 17.571c0 9.703-8.247 17.572-21.997 17.572h-2.75c-13.748 0-19.248-7.872-19.248-17.572C62.491 7.866 63.775 0 83.023 0h2.932c19.244 0 20.531 7.866 20.531 17.571"></path><linearGradient id="react-linear-gradient-1160" x1="50%" x2="50%" y1="0%" y2="100%"><stop offset="0%" stop-color="#FFF" stop-opacity=".5"></stop><stop offset="70.506%" stop-opacity=".5"></stop></linearGradient><filter id="react-filter-1159" width="101.6%" height="109.8%" x="-.8%" y="-2.4%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter></defs><g id="Wayfarers" filter="url(#react-filter-1159)" transform="translate(7 7)"><g id="Shades" fill-rule="evenodd" transform="translate(10.795 2.929)"><g id="Shade"><use fill="#000" fill-opacity=".7" href="#react-path-1157"></use><use fill="url(#react-linear-gradient-1160)" href="#react-path-1157" style="mix-blend-mode:screen;"></use></g><g id="Shade"><use fill="#000" fill-opacity=".7" href="#react-path-1158"></use><use fill="url(#react-linear-gradient-1160)" href="#react-path-1158" style="mix-blend-mode:screen;"></use></g></g><path id="Left" fill="#252C2F" fill-rule="nonzero" d="M33.716 41h-2.75c-13.888 0-22.18-7.664-22.18-20.5C8.787 10.127 10.6 0 32.25 0h2.932c21.651 0 23.463 10.127 23.463 20.5 0 12.069-10.25 20.5-24.93 20.5M32.25 5.854c-17.6 0-17.6 6.464-17.6 14.646 0 6.68 2.83 14.643 16.316 14.643h2.75c11.226 0 19.066-6.021 19.066-14.643 0-8.182 0-14.646-17.6-14.646z"></path><path id="Right" fill="#252C2F" fill-rule="nonzero" d="M95.284 41h-2.75c-13.888 0-22.18-7.664-22.18-20.5 0-10.373 1.813-20.5 23.464-20.5h2.932c21.651 0 23.463 10.127 23.463 20.5 0 12.069-10.25 20.5-24.929 20.5M93.818 5.854c-17.6 0-17.6 6.464-17.6 14.646 0 6.68 2.833 14.643 16.316 14.643h2.75c11.226 0 19.066-6.021 19.066-14.643 0-8.182 0-14.646-17.6-14.646z"></path><path id="Stuff" fill="#252C2F" fill-rule="nonzero" d="M2.932 5.857C3.618 5.172 11.123 0 32.25 0c17.714 0 21.464 1.88 27.14 4.72l.415.21c.395.143 2.413.844 4.773.921a16.5 16.5 0 0 0 4.528-.881C75.584 1.748 81.926 0 96.75 0c21.127 0 28.632 5.172 29.318 5.857A2.93 2.93 0 0 1 129 8.786v2.928c0 1.62-1.31 2.929-2.932 2.929 0 0-5.863 0-5.863 2.928s-2.932-4.237-2.932-5.857V8.862c-3.576-1.4-9.976-3.005-20.523-3.005-11.75 0-17.602 1.131-22.622 3.247l.056.139-2.496 1.007 2.493 1.008-2.2 5.43-2.717-1.1a13 13 0 0 0-1.493-.457c-2.024-.51-4.106-.666-5.946-.28a7.7 7.7 0 0 0-1.877.642l-2.622 1.31-2.623-5.238 2.622-1.31.006-.003-2.512-1.015.08-.198C50.57 6.976 46.58 5.857 32.25 5.857c-10.546 0-16.947 1.604-20.523 3.004v2.853c0 1.62-2.932 8.786-2.932 5.857s-5.863-2.928-5.863-2.928A2.93 2.93 0 0 1 0 11.714V8.786a2.93 2.93 0 0 1 2.932-2.929"></path></g></g>', 1)];
const d = {
        render: function(a, e) {
            return r(), t("svg", null, [...n])
        }
    },
    f = [e('<g id="Top/_Resources/Kurt" fill="none" transform="translate(62 85)"><defs><filter id="filter1" width="101.5%" height="108%" x="-.8%" y="-2%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.16 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter></defs><g id="Kurts" filter="url(&#39;#filter1&#39;)" transform="translate(5 2)"><path id="It!" fill="#F4F4F4" d="M66 11.111c-11.037 0-12.63-9.084-35.33-10.37C7.987-.283.816 6.449.777 11.11c.037 4.293-1.128 15.45 13.589 28.519 14.772 15.512 29.905 10.252 35.33 5.185C55.134 42.473 61.34 21.46 66 21.48s10.865 20.992 16.306 23.334c5.424 5.067 20.557 10.327 35.33-5.185 14.716-13.069 13.55-24.226 13.588-28.519-.04-4.662-7.21-11.394-29.895-10.37C78.63 2.027 77.037 11.11 66 11.11"></path><path id="Did" fill="#2F383B" d="M55.13 21.481c.38-7.658-12.914-15.839-27.177-15.555-14.256.299-16.111 9.453-16.306 12.963-.349 8.133 8.367 26.415 24.459 25.926 16.091-.51 18.803-18.28 19.023-23.334"></path><path id="Courtney" fill="#2F383B" d="M120.353 21.481c.38-7.658-12.914-15.839-27.177-15.555-14.255.299-16.11 9.453-16.305 12.963-.35 8.133 8.367 26.415 24.458 25.926 16.092-.51 18.804-18.28 19.024-23.334" transform="matrix(-1 0 0 1 197.224 0)"></path></g></g>', 1)];
const u = {
        render: function(a, e) {
            return r(), t("svg", null, [...f])
        }
    },
    p = [e('<g id="Top/_Resources/Prescription-02" fill="none" stroke-width="1" transform="translate(62 85)"><defs><filter id="react-filter-1166" width="101.5%" height="109.8%" x="-.8%" y="-2.4%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter></defs><g id="Wayfarers" fill="#252C2F" fill-rule="nonzero" filter="url(#react-filter-1166)" transform="translate(6 7)"><path id="Left" d="M34 41h-2.758C17.315 41 9 33.336 9 20.5 9 10.127 10.817 0 32.53 0h2.94C57.183 0 59 10.127 59 20.5 59 32.569 48.721 41 34 41M32.385 6C13 6 13 12.841 13 21.502 13 28.572 16.116 37 30.97 37H34c12.365 0 21-6.373 21-15.498C55 12.84 55 6 35.615 6z"></path><path id="Right" d="M96 41h-2.758C79.315 41 71 33.336 71 20.5 71 10.127 72.817 0 94.53 0h2.94C119.183 0 121 10.127 121 20.5 121 32.569 110.721 41 96 41M94.385 6C75 6 75 12.841 75 21.502 75 28.572 78.12 37 92.97 37H96c12.365 0 21-6.373 21-15.498C117 12.84 117 6 97.615 6z"></path><path id="Stuff" d="M2.955 5.772C3.645 5.096 11.21 0 32.5 0c17.851 0 21.63 1.853 27.35 4.652l.419.207c.398.14 2.431.83 4.81.907a17 17 0 0 0 4.563-.869C76.17 1.722 82.562 0 97.5 0c21.29 0 28.854 5.096 29.545 5.772 1.634 0 2.955 1.29 2.955 2.885v2.886c0 1.596-1.32 2.886-2.955 2.886 0 0-6.901 0-6.901 2.886 0 2.885-1.962-4.176-1.962-5.772v-2.81c-3.603-1.38-10.054-3.947-20.682-3.947-11.842 0-17.739 2.1-22.798 4.185l.057.137-.003 1.986-2.217 5.35L69.8 15.36c-.244-.097-.772-.27-1.504-.451-2.04-.503-4.137-.656-5.992-.276q-1.021.21-1.891.633l-2.643 1.29-2.643-5.16.117-2.295.08-.195c-4.362-2.033-8.385-4.12-22.824-4.12-10.628 0-17.078 2.565-20.682 3.944v2.812c0 1.596-2.954 8.657-2.954 5.772 0-2.886-5.91-2.886-5.91-2.886-1.63 0-2.954-1.29-2.954-2.886V8.657c0-1.595 1.324-2.885 2.955-2.885"></path></g></g>', 1)];
const g = {
        render: function(a, e) {
            return r(), t("svg", null, [...p])
        }
    },
    m = [e('<g id="Top/_Resources/Sunglasses" fill="none" stroke-width="1" transform="translate(62 85)"><defs><linearGradient id="react-linear-gradient-1164" x1="50%" x2="50%" y1="0%" y2="70.506%"><stop offset="0%" stop-color="#FFF" stop-opacity=".5"></stop><stop offset="100%" stop-opacity=".5"></stop></linearGradient><linearGradient id="react-linear-gradient-1165" x1="50%" x2="50%" y1="0%" y2="100%"><stop offset="0%" stop-color="#FFF" stop-opacity=".5"></stop><stop offset="70.506%" stop-opacity=".5"></stop></linearGradient><path id="react-path-1161" d="M47.01 6.277c2.511.024 3.698.45 4.126 3.115.433 2.7.012 5.736-.488 8.395-.762 4.06-2.031 8.04-4.984 11.007-1.555 1.564-3.452 2.81-5.47 3.66-1.071.452-2.203.778-3.334 1.026-.33.072-3.154.468-1.422.267-4.041.47-8.425.45-11.8-2.168-3.74-2.901-6.301-7.493-7.427-12.066-.66-2.676-2.044-9.076.486-11.216 2.898-2.452 30.313-2.02 30.313-2.02"></path><path id="react-path-1162" d="M78.92 6.275c-2.512.024-3.699.449-4.126 3.114-.434 2.7-.012 5.736.487 8.395.763 4.061 2.032 8.04 4.984 11.008 1.556 1.563 3.453 2.809 5.47 3.66 1.072.451 2.204.778 3.335 1.025.33.072 3.153.469 1.422.267 4.04.47 8.425.45 11.8-2.167 3.74-2.902 6.3-7.493 7.427-12.066.66-2.677 2.043-9.077-.486-11.217-2.898-2.451-30.314-2.02-30.314-2.02"></path><filter id="react-filter-1163" width="101.6%" height="110.5%" x="-.8%" y="-2.6%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter></defs><g id="Sunglasses" filter="url(#react-filter-1163)" transform="translate(8 8)"><g id="shades"><use fill="#000" fill-opacity=".7" href="#react-path-1161"></use><use fill="url(#react-linear-gradient-1164)" href="#react-path-1161" style="mix-blend-mode:screen;"></use></g><g id="shades"><use fill="#000" fill-opacity=".7" href="#react-path-1162"></use><use fill="url(#react-linear-gradient-1165)" href="#react-path-1162" style="mix-blend-mode:screen;"></use></g><g id="Glasses" fill="#252C2F"><path id="Frame" d="M46.25 7.275c2.37.022 3.492.417 3.896 2.89.41 2.506.011 5.322-.46 7.79-.721 3.768-1.92 7.46-4.708 10.214-1.47 1.45-3.261 2.606-5.167 3.395-1.012.42-2.081.722-3.15.952-.312.067-2.979.434-1.343.248-3.817.435-7.958.418-11.146-2.012-3.532-2.692-5.952-6.952-7.015-11.196-.623-2.483-1.93-8.422.459-10.407 2.737-2.274 28.633-1.874 28.633-1.874M22.217.491c-5.44.187-9.071 1.143-11.755 6.578-4.917 9.961 3.5 24.9 12.89 28.97 10.976 4.76 23.24-.507 29.043-10.033 3.073-5.044 4.626-12.683 4.526-18.502C56.795.077 51.607-.13 45.51.034zM79.68 7.273c-2.371.022-3.492.416-3.896 2.89-.41 2.505-.012 5.322.46 7.79.72 3.767 1.919 7.459 4.708 10.213 1.47 1.45 3.261 2.606 5.167 3.396 1.012.419 2.08.722 3.15.951.312.067 2.978.435 1.343.248 3.817.436 7.958.418 11.145-2.011 3.533-2.692 5.952-6.952 7.016-11.196.623-2.483 1.93-8.422-.46-10.407-2.737-2.275-28.632-1.874-28.632-1.874M103.713.488c5.44.187 9.071 1.144 11.754 6.579 4.918 9.96-3.5 24.9-12.889 28.97-10.977 4.76-23.24-.508-29.043-10.033C70.46 20.96 68.907 13.32 69.007 7.5 69.135.074 74.323-.132 80.42.031z"></path><path id="Frame" d="M13.197 4.927c-3.412.191-7.31.237-10.507 1.712-3.385 1.562-3.908 5.1.36 5.587 1.92.22 3.845-.143 5.737-.481 1.55-.277 3.655-.187 5.12-.78 2.729-1.103 2.553-6.225-.71-6.038m99.538 0c3.412.191 7.31.237 10.507 1.712 3.384 1.562 3.907 5.1-.36 5.587-1.921.22-3.845-.143-5.738-.481-1.55-.277-3.654-.187-5.119-.78-2.73-1.103-2.554-6.225.71-6.038M73.11 7.013c-1.947-2.3-7.019-3.628-10.219-3.628s-8.123 1.328-10.069 3.628c-.981 1.16-1.015 2.711.686 3.438 2.118.906 4.01-.737 5.705-1.596 2.168-1.098 5.499-.978 7.506 0 1.708.833 3.586 2.502 5.704 1.596 1.701-.727 1.668-2.279.686-3.438"></path></g></g></g>', 1)];
const C = {
        Blank: l,
        Prescription01: o,
        Round: c,
        Wayfarers: d,
        Kurt: u,
        Prescription02: g,
        Sunglasses: {
            render: function(a, e) {
                return r(), t("svg", null, [...m])
            }
        }
    },
    v = [e('<g id="Clothing/Blazer-+-Shirt" transform="translate(0 170)"><defs><path id="BlazerShirt-path1" d="M133.96.295c36.976 3.03 66.04 34 66.04 71.757V81H0v-8.948C0 33.952 29.592 2.765 67.045.22Q67 .78 67 1.348c0 11.863 14.998 21.48 33.5 21.48S134 13.211 134 1.348q0-.53-.04-1.053"></path></defs><g id="Shirt" transform="translate(32 29)"><mask id="BlazerShirt-mask1" fill="#fff"><use href="#BlazerShirt-path1"></use></mask><use fill="#E6E6E6" class="CustomColor" href="#BlazerShirt-path1"></use><g id="Color/Palette/Black" fill="#262E33" mask="url(&#39;#BlazerShirt-mask1&#39;)"><path id="Color" d="M0 0h264v110H0z" transform="translate(-32 -29)"></path></g><g id="Shadowy" fill="#000" mask="url(&#39;#BlazerShirt-mask1&#39;)" opacity=".16"><ellipse id="Hola" cx="40.5" cy="27.848" rx="39.635" ry="26.914" transform="translate(60 -25)"></ellipse></g></g><g id="Blazer" transform="translate(32 28)"><path id="Saco" fill="#3A4C5A" d="M68.785 1.122C30.512 2.804 0 34.365 0 73.052V82h69.362C65.96 69.92 64 55.709 64 40.5c0-14.327 1.74-27.769 4.785-39.378M131.638 82H200v-8.948c0-38.345-29.975-69.69-67.771-71.878C135.265 12.77 137 26.194 137 40.5c0 15.209-1.96 29.42-5.362 41.5"></path><path id="Pocket-hanky" fill="#E6E6E6" d="m149 58 9.556-7.167a4 4 0 0 1 4.856.043L170 56z"></path><path id="Wing" fill="#2F4351" d="M69 0q-6 29 5 82H58L44 46l6-9-6-6L63 1q3.042-.945 6-1"></path><path id="Wing" fill="#2F4351" d="M151 0q-6 29 5 82h-16l-14-36 6-9-6-6 19-30q3.042-.945 6-1" transform="matrix(-1 0 0 1 282 0)"></path></g></g>', 1)];
const M = {
        render: function(a, e) {
            return r(), t("svg", null, [...v])
        }
    },
    H = [e('<g id="Clothing/Blazer-+-Sweater" transform="translate(0 170)"><defs><path id="BlazerSweater-path1" d="M105.192 29.052H104c-39.765 0-72 32.235-72 72V110h200v-8.948c0-39.765-32.235-72-72-72h-1.192q.191 1.475.192 3c0 13.807-12.088 25-27 25s-27-11.193-27-25q0-1.525.192-3"></path></defs><mask id="BlazerSweater-mask1" fill="#fff"><use href="#BlazerSweater-path1"></use></mask><use fill="#E6E6E6" class="CustomColor" href="#BlazerSweater-path1"></use><g id="Color/Palette/Black" fill="#262E33" mask="url(&#39;#BlazerSweater-mask1&#39;)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Blazer" transform="translate(32 28)"><path id="Saco" fill="#3A4C5A" d="M68.785 1.122C30.512 2.804 0 34.365 0 73.052V82h69.362C65.96 69.92 64 55.709 64 40.5c0-14.327 1.74-27.769 4.785-39.378M131.638 82H200v-8.948c0-38.345-29.975-69.69-67.771-71.878C135.265 12.77 137 26.194 137 40.5c0 15.209-1.96 29.42-5.362 41.5"></path><path id="Pocket-hanky" fill="#E6E6E6" d="m149 58 9.556-7.167a4 4 0 0 1 4.856.043L170 56z"></path><path id="Wing" fill="#2F4351" d="M69 0q-6 29 5 82H58L44 46l6-9-6-6L63 1q3.042-.945 6-1"></path><path id="Wing" fill="#2F4351" d="M151 0q-6 29 5 82h-16l-14-36 6-9-6-6 19-30q3.042-.945 6-1" transform="matrix(-1 0 0 1 282 0)"></path></g><path id="Collar" fill="#F2F2F2" d="M156 21.539c6.772 4.597 11 11.117 11 18.349 0 7.4-4.428 14.057-11.48 18.668l-5.94-4.68-4.58.332 1-3.151-.078-.061C152.022 47.853 156 42.7 156 36.876zm-48 0c-6.772 4.597-11 11.117-11 18.349 0 7.4 4.428 14.057 11.48 18.668l5.94-4.68 4.58.332-1-3.151.078-.061C111.978 47.853 108 42.7 108 36.876z"></path></g>', 1)];
const S = {
        render: function(a, e) {
            return r(), t("svg", null, [...H])
        }
    },
    k = [i("g", {
        id: "Clothing/Collar-+-Sweater",
        transform: "translate(0 170)"
    }, [i("defs", null, [i("path", {
        id: "CollarSweater-path1",
        d: "M105.192 29.052H104c-39.765 0-72 32.235-72 72V110h200v-8.948c0-39.765-32.235-72-72-72h-1.192q.191 1.475.192 3c0 13.807-12.088 25-27 25s-27-11.193-27-25q0-1.525.192-3"
    })]), i("use", {
        fill: "var(--avataaar-shirt-color)",
        class: "CustomColor",
        href: "#CollarSweater-path1"
    }), i("path", {
        id: "Collar",
        fill: "#F2F2F2",
        d: "M156 22.28c6.182 4.555 10 10.826 10 17.748 0 7.205-4.137 13.705-10.771 18.3l-5.65-4.452-4.579.332 1-3.151-.078-.061C152.022 47.853 156 42.7 156 36.876zm-48-.709c-6.767 4.603-11 11.169-11 18.457 0 7.398 4.362 14.052 11.308 18.664l6.113-4.816 4.579.332-1-3.151.078-.061C111.978 47.853 108 42.7 108 36.876z"
    })], -1)];
const y = {
        render: function(a, e) {
            return r(), t("svg", null, [...k])
        }
    },
    F = [e('<g id="Clothing/Hoodie" transform="translate(0 170)"><defs><path id="Hoodie-path1" d="M108 13.07c-17.919 2.006-31.72 7.482-31.996 21.575C50.146 45.568 32 71.165 32 100.999V110h200v-9c0-29.835-18.146-55.432-44.004-66.355-.276-14.093-14.077-19.57-31.996-21.574V32c0 13.255-10.745 24-24 24s-24-10.745-24-24z"></path></defs><mask id="Hoodie-mask1" fill="#fff"><use href="#Hoodie-path1"></use></mask><use fill="var(--avataaar-shirt-color)" class="CustomColor" href="#Hoodie-path1"></use><path id="Straps" fill="#F4F4F4" d="M102 61.74V110h-7V58.15a65 65 0 0 0 7 3.59m67-3.59V98.5a3.5 3.5 0 1 1-7 0V61.74a65 65 0 0 0 7-3.59" mask="url(&#39;#Hoodie-mask1&#39;)"></path><path id="Shadow" fill="#000" d="M90.96 12.724C75.91 15.571 65.5 21.243 65.5 32.308 65.5 52.02 98.538 68 132 68s66.5-15.98 66.5-35.692c0-11.065-10.41-16.737-25.46-19.584 9.085 3.35 14.96 8.982 14.96 18.353C188 51.469 160.179 68 132 68S76 51.469 76 31.077c0-9.37 5.875-15.003 14.96-18.353" mask="url(&#39;#Hoodie-mask1&#39;)" opacity=".16"></path></g>', 1)];
const L = {
        render: function(a, e) {
            return r(), t("svg", null, [...F])
        }
    },
    w = [i("g", {
        id: "Clothing/Graphic-Shirt",
        transform: "translate(0 170)"
    }, [i("defs", null, [i("path", {
        id: "GraphicShirt-path1",
        d: "M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"
    })]), i("use", {
        fill: "#E6E6E6",
        class: "CustomColor",
        href: "#GraphicShirt-path1"
    })], -1)];
const x = {
        render: function(a, e) {
            return r(), t("svg", null, [...w])
        }
    },
    B = [e('<g id="Clothing/Overall" transform="translate(0 170)"><defs><path id="Overall-path1" d="M94 29.688V74h76V29.688a71.5 71.5 0 0 1 26 8.944V110H68V38.632a71.5 71.5 0 0 1 26-8.944"></path></defs><use fill="var(--avataaar-shirt-color)" class="CustomColor" href="#Overall-path1"></use><circle id="Button" cx="81" cy="83" r="5" fill="#F4F4F4"></circle><circle id="Button" cx="183" cy="83" r="5" fill="#F4F4F4"></circle></g>', 1)];
const z = {
        render: function(a, e) {
            return r(), t("svg", null, [...B])
        }
    },
    T = [e('<g id="Clothing/Shirt-Crew-Neck" transform="translate(0 170)"><defs><path id="ShirtCrewNeck-path1" d="M165.96 29.295c36.976 3.03 66.04 34 66.04 71.757V110H32v-8.948c0-38.1 29.592-69.287 67.045-71.832Q99 29.78 99 30.348c0 11.863 14.998 21.48 33.5 21.48s33.5-9.617 33.5-21.48q0-.53-.04-1.053"></path></defs><mask id="ShirtCrewNeck-mask1" fill="#fff"><use href="#ShirtCrewNeck-path1"></use></mask><use fill="var(--avataaar-shirt-color)" class="CustomColor" href="#ShirtCrewNeck-path1"></use><g id="Shadowy" fill="#000" mask="url(&#39;#ShirtCrewNeck-mask1&#39;)" opacity=".16"><ellipse id="Hola" cx="40.5" cy="27.848" rx="39.635" ry="26.914" transform="translate(92 4)"></ellipse></g></g>', 1)];
const E = {
        render: function(a, e) {
            return r(), t("svg", null, [...T])
        }
    },
    O = [i("g", {
        id: "Clothing/Shirt-V-Neck",
        transform: "translate(0 170)"
    }, [i("defs", null, [i("path", {
        id: "ShirtVNeck-path1",
        d: "M171.32 29.936C205.706 35.366 232 65.14 232 101.052V110H32v-8.948c0-35.914 26.294-65.686 60.682-71.116a23.9 23.9 0 0 0 7.554 13.603l29.085 26.229a4 4 0 0 0 5.358 0l29.085-26.229a24 24 0 0 0 1.234-1.196 23.9 23.9 0 0 0 6.322-12.407"
    })]), i("use", {
        fill: "var(--avataaar-shirt-color)",
        class: "CustomColor",
        href: "#ShirtVNeck-path1"
    })], -1)];
const A = {
        render: function(a, e) {
            return r(), t("svg", null, [...O])
        }
    },
    N = [i("g", {
        id: "Clothing/Shirt-Scoop-Neck",
        transform: "translate(0 170)"
    }, [i("defs", null, [i("path", {
        id: "ShirtScoopNeck-path1",
        d: "M181.544 32.33C210.784 41.488 232 68.792 232 101.052V110H32v-8.948c0-32.655 21.739-60.232 51.534-69.05A18 18 0 0 0 83 36.348c0 16.281 22.162 29.48 49.5 29.48S182 52.629 182 36.348c0-1.363-.155-2.704-.456-4.018"
    })]), i("use", {
        fill: "var(--avataaar-shirt-color)",
        class: "CustomColor",
        href: "#ShirtScoopNeck-path1"
    })], -1)];
const V = {
        BlazerShirt: M,
        CollarSweater: y,
        BlazerSweater: S,
        Hoodie: L,
        GraphicShirt: x,
        Overall: z,
        ShirtCrewNeck: E,
        ShirtVNeck: A,
        ShirtScoopNeck: {
            render: function(a, e) {
                return r(), t("svg", null, [...N])
            }
        }
    },
    q = [e('<g id="Top"><defs><path id="Eyepatch-path1" d="M0 0h264v280H0z"></path></defs><mask id="Eyepatch-mask1" fill="#fff"><use href="#Eyepatch-path1"></use></mask><g id="Top/Accesories/Eyepatch" mask="url(&#39;#Eyepatch-mask1&#39;)"><path fill="#28354B" d="M159.395 39.781c-3.077-3.088-6.276 3.858-7.772 5.647-3.61 4.32-7.083 8.755-10.755 13.024-7.252 8.43-14.429 16.922-21.634 25.388-1.094 1.286-.961 1.425-2.397 1.549-.951.082-2.274-.409-3.263-.463-2.75-.151-5.462.309-8.138.897-5.345 1.173-11.01 3.106-15.647 6.075-1.217.78-2.002 1.7-3.322 1.943-1.149.212-2.673-.211-3.845-.322-2.08-.195-5.084-1.046-7.127-.605-2.592.56-3.578 3.697-.935 5.086 2.01 1.056 6.01.476 8.264.645 2.573.192 1.788.06 1.423 2.52-.523 3.533.352 7.481 1.842 10.713 3.46 7.505 13.034 15.457 21.766 14.725 7.287-.61 13.672-7.19 16.664-13.503 1.532-3.231 2.436-6.908 2.731-10.472.189-2.266.084-4.67-.566-6.865-.321-1.085-.83-2.208-1.376-3.193-.442-.799-2.4-2.65-2.52-3.453-.232-1.557 4.185-5.73 5.028-6.773 3.973-4.916 7.964-9.812 11.906-14.755 3.881-4.869 7.784-9.725 11.768-14.51 1.804-2.17 10.828-10.364 7.905-13.298" class="CustomColor"></path></g></g>', 1)];
const D = {
        render: function(a, e) {
            return r(), t("svg", null, [...q])
        }
    },
    b = [e('<g id="Top"><defs><path id="LongHairMiaWallace-path1" d="M0 0h264v280H0z"></path><path id="LongHairMiaWallace-path2" d="M148.86 69q.14 1.982.14 4v38c0 22.34-13.08 41.623-32 50.611v8.706c18.146 1.499 35.721 4.018 46 6.683 9.953-13.56 22.885-26.2 23-51 .085-18.985-27.676-95.572-40-111-8.138-10.188-28.695-13.55-53-14S48.923 6.509 41 16C30.319 28.795-.085 107.015 0 126c.116 24.8 13.048 37.44 23 51 10.279-2.665 27.854-5.184 46-6.683v-8.706C50.08 152.623 37 133.339 37 111V73q0-2.018.14-4h28.234l3.879-21.444L72.058 69h76.801Z"></path></defs><mask id="LongHairMiaWallace-mask1" fill="#fff"><use href="#LongHairMiaWallace-path1"></use></mask><g id="Top/Long-Hair/Mia-Wallace" mask="url(&#39;#LongHairMiaWallace-mask1&#39;)"><g transform="translate(-1)"><path id="Shadow" fill="#000" d="M69.033 76.213q19.407-49.626 41.025-49.626c.539 0 29.253-.238 48.055-.36C178.767 35.585 193 55.304 193 78.115V93h-82.942l-2.805-23.18-3.88 23.18H69V78.115q0-.955.033-1.902" opacity=".16"></path><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairMiaWallace-path2" transform="translate(40 19)"></use></g></g></g>', 1)];
const W = {
        render: function(a, e) {
            return r(), t("svg", null, [...b])
        }
    },
    G = [e('<g id="Top"><defs><path id="ShortHairShortCurly-path2" d="M0 0h264v280H0z"></path><path id="ShortHairShortCurly-path1" d="M94.252 52.022q.185-.081-.916-.062 1.338-.003.916.062m-8.135-15.72c-.002-.02.017.15 0 0m107.648 34.464c-.264-3.317-.732-6.614-1.518-9.855-.625-2.576-1.478-5.033-2.487-7.491-.61-1.485-2.032-3.524-2.2-5.126-.165-1.577 1.067-3.325 1.33-5.162a16 16 0 0 0-.156-5.438c-.833-4.023-3.594-7.764-7.857-8.813-.952-.234-2.964.055-3.636-.5-.771-.635-1.308-2.8-2.006-3.669-1.99-2.476-5.095-4.07-8.37-3.514-2.41.409-1.026.907-2.833-.512-1.005-.788-1.756-1.993-2.732-2.847-1.467-1.283-3.15-2.38-4.892-3.282-4.557-2.358-9.754-4.072-14.844-4.908-9.285-1.524-19.195-.195-28.195 2.22-4.479 1.201-8.987 2.726-13.147 4.743-1.783.864-2.813 1.582-4.673 1.808-2.928.357-5.409.339-8.183 1.581-8.536 3.822-12.381 12.689-9.06 21.174a14.6 14.6 0 0 0 2.82 4.584c1.521 1.68 2.072 1.35.762 3.282a53 53 0 0 0-4.955 9.172c-3.529 8.402-4.12 17.864-3.89 26.824.081 3.137.216 6.313.71 9.42.214 1.344.274 3.872 1.282 4.87.512.506 1.241.788 1.969.587 1.71-.474 1.121-1.735 1.161-2.906.2-5.884-.07-11.089 1.33-16.902 1.033-4.294 2.755-8.195 4.988-12.035 2.838-4.884 5.903-9.173 9.807-13.355.917-.984 1.118-1.4 2.349-1.472.932-.054 2.295.584 3.2.805 1.999.487 4 .968 6.034 1.296 3.74.603 7.444.644 11.217.525 7.426-.232 14.885-.753 22.085-2.623 4.782-1.242 9.022-3.47 13.602-5.105.082-.029 1.23-.847 1.43-.814.282.047 1.978 1.826 2.264 2.05 2.226 1.746 4.667 2.479 7.07 3.83 2.964 1.667.094-.718 1.728 1.359.477.605.72 1.726 1.103 2.411a18.1 18.1 0 0 0 4.93 5.624c1.956 1.47 4.894 2.18 5.891 4.095.769 1.477 1.028 3.484 1.648 5.06 1.628 4.136 3.777 7.992 5.926 11.887 1.732 3.14 3.625 5.881 3.818 9.468.067 1.248-1.121 8.737 1.773 6.46.429-.338 1.353-4.156 1.543-4.804.772-2.633 1.046-5.381 1.395-8.086.694-5.38.923-10.498.47-15.916"></path></defs><mask id="ShortHairShortCurly-mask2" fill="#fff"><use href="#ShortHairShortCurly-path2"></use></mask><g id="Top/Short-Hair/Short-Curly" mask="url(&#39;#ShortHairShortCurly-mask2&#39;)"><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairShortCurly-path1" transform="translate(-1)"></use></g></g>', 1)];
const P = {
        render: function(a, e) {
            return r(), t("svg", null, [...G])
        }
    },
    j = [e('<g id="Top"><defs><path id="Hat-path2" d="M0 0h264v280H0z"></path><path id="Hat-path1" d="M156 180.611c17.53-8.328 30.048-25.496 31.791-45.744C193.57 134.002 198 129.02 198 123v-13c0-5.946-4.325-10.882-10-11.834V92a55.8 55.8 0 0 0-4.638-22.35C173.435 53 89.312 53.802 80.71 69.484A55.8 55.8 0 0 0 76 92v6.166c-5.675.952-10 5.888-10 11.834v13c0 6.019 4.43 11.002 10.209 11.867 1.743 20.248 14.26 37.416 31.791 45.744V199h-4c-39.765 0-72 32.235-72 72v9h200v-9c0-39.765-32.235-72-72-72h-4zM0 0h264v280H0z"></path></defs><mask id="Hat-mask1" fill="#fff"><use href="#Hat-path2"></use></mask><g id="Top/Accesories/Hat" mask="url(&#39;#Hat-mask1&#39;)"><g transform="translate(-1)"><g id="Hat" transform="translate(1)"><mask id="Hat-mask2" fill="#fff"><use href="#Hat-path1"></use></mask><path fill="var(--avataaar-top-color)" d="M123.182 2h18.636c18.791 0 35.049 13.08 39.072 31.436L190 75H75l9.11-41.564C88.133 15.08 104.39 2 123.182 2" mask="url(&#39;#Hat-mask2&#39;)" style="fill-opacity:.6;"></path><ellipse id="Hipster" cx="132" cy="87.5" fill="var(--avataaar-top-color)" mask="url(&#39;#Hat-mask2&#39;)" rx="122" ry="57.5"></ellipse><ellipse id="Hipster" cx="132" cy="87.5" fill="#2e2e2e" mask="url(&#39;#Hat-mask2&#39;)" rx="122" ry="57.5" style="fill-opacity:.1;"></ellipse><ellipse id="Very" cx="132" cy="82" fill="var(--avataaar-top-color)" mask="url(&#39;#Hat-mask2&#39;)" rx="62" ry="25"></ellipse><ellipse id="Very" cx="132" cy="82" fill="#2e2e2e" mask="url(&#39;#Hat-mask2&#39;)" rx="62" ry="25" style="fill-opacity:.5;"></ellipse></g></g></g></g>', 1)];
const R = {
        render: function(a, e) {
            return r(), t("svg", null, [...j])
        }
    },
    Z = [e('<g id="Top"><defs><path id="LongHairNotTooLong-path1" d="M0 0h264v280H0z"></path><path id="LongHairNotTooLong-path2" d="M59 102.34V182a8 8 0 0 0 8 8h42v-9.389c-17.53-8.328-30.048-25.496-31.791-45.744C71.43 134.002 67 129.02 67 123v-13c0-3.49 1.49-6.633 3.87-8.826 11.539-2.619 24.1-7.536 36.472-14.679 12.131-7.004 22.502-15.237 30.479-23.743q-5.14 11.862-12.449 20.783 19.013-8.285 25.892-26.639.565 1.383 1.18 2.762c10.256 23.035 27.874 39.36 45.762 44.745.513 2.11.794 4.08.794 5.597v13c0 6.019-4.43 11.002-10.209 11.867-1.743 20.248-14.26 37.416-31.791 45.744V190h18c17.673 0 32-14.327 32-32v-54.125q0-.1-.028-.26-.216-18.391-.612-21.39C201.577 45.977 170.556 18 133 18c-36.085 0-66.137 25.828-73 60-5.523 0-10 5.596-10 12.5 0 4.55 1.695 8.643 4.853 10.773.905.61 2.47.925 4.147 1.067"></path></defs><mask id="LongHairNotTooLong-mask1" fill="#fff"><use href="#LongHairNotTooLong-path1"></use></mask><g id="Top/Long-Hair/Long-but-not-too-long" mask="url(&#39;#LongHairNotTooLong-mask1&#39;)"><g transform="translate(-1)"><use id="Behind" fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairNotTooLong-path2"></use><g id="Top" opacity=".16" transform="translate(50 18)"><path id="Combined-Shape" fill="#FFF" d="M11.899 84.775c13.812-1.76 29.78-7.237 45.443-16.28 12.131-7.004 22.502-15.237 30.479-23.743q-5.14 11.862-12.449 20.783 19.013-8.285 25.892-26.639.565 1.383 1.18 2.762C114.382 68.471 136.296 86.194 157 88.151V74c0-40.87-33.13-74-74-74-36.085 0-66.137 25.828-72.679 60.006A8 8 0 0 0 10 60C4.477 60 0 65.596 0 72.5c0 6.482 3.947 11.811 9 12.438v.155q.474-.044.953-.093a8.2 8.2 0 0 0 1.946-.225"></path></g></g></g></g>', 1)];
const U = {
        render: function(a, e) {
            return r(), t("svg", null, [...Z])
        }
    },
    Q = [e('<g id="Top"><defs><path id="ShortHairShortFlat-path2" d="M0 0h264v280H0z"></path><path id="ShortHairShortFlat-path1" d="M180.15 39.92c-2.76-2.82-5.964-5.213-9.08-7.613-.688-.53-1.387-1.046-2.06-1.595-.152-.125-1.718-1.246-1.905-1.659-.451-.993-.19-.22-.128-1.404.079-1.498 3.134-5.73.854-6.7-1.003-.427-2.791.709-3.753 1.084a60 60 0 0 1-5.731 1.9c.932-1.857 2.708-5.574-.631-4.579-2.602.775-5.026 2.768-7.64 3.705.865-1.417 4.324-5.811 1.198-6.057-.972-.076-3.803 1.748-4.85 2.138-3.137 1.165-6.34 1.92-9.634 2.513-11.198 2.018-24.293 1.442-34.653 6.54-7.988 3.93-15.874 10.029-20.489 17.795-4.447 7.485-6.11 15.676-7.041 24.253-.683 6.295-.739 12.802-.42 19.119.105 2.07.338 11.61 3.345 8.721 1.498-1.44 1.487-7.253 1.864-9.22.751-3.916 1.474-7.848 2.726-11.638 2.206-6.68 4.809-13.793 10.305-18.393 3.527-2.952 6.004-6.941 9.379-9.919 1.516-1.337.36-1.198 2.797-1.022 1.638.117 3.282.162 4.923.205 3.796.099 7.598.074 11.395.087 7.647.028 15.258.136 22.898-.265 3.395-.177 6.799-.274 10.185-.588 1.891-.175 5.247-1.387 6.804-.461 1.425.847 2.905 3.615 3.928 4.748 2.418 2.679 5.3 4.724 8.126 6.92 5.895 4.58 8.87 10.332 10.66 17.488 1.784 7.13 1.284 13.745 3.491 20.762.389 1.233 1.416 3.36 2.682 1.454.235-.354.175-2.3.175-3.42 0-4.52 1.144-7.91 1.13-12.46-.056-13.832-.504-31.868-10.85-42.439"></path></defs><mask id="ShortHairShortFlat-mask2" fill="#fff"><use href="#ShortHairShortFlat-path2"></use></mask><g id="Top/Short-Hair/Short-Flat" mask="url(&#39;#ShortHairShortFlat-mask2&#39;)"><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairShortFlat-path1" transform="translate(-1)"></use></g></g>', 1)];
const _ = {
        render: function(a, e) {
            return r(), t("svg", null, [...Q])
        }
    },
    I = [e('<g id="Top"><defs><path id="Hijab-path1" d="M0 0h264v280H0z"></path><path id="Hijab-path2" d="M66.042 77.075C71.68 45.205 99.513 21 133 21c37.555 0 68 30.445 68 68v30.751q1.313 14.705 2.456 20.603c1.377 7.104 5.694 4.761 5.694 14.866s-4.328 13.5-4.347 22.485c-.019 8.986 15.397 16.131 15.397 27.538s-7.074 65.233-77.622 65.233q-22.605 0-38.51-12.862Q105.091 267.349 106 280H59c.932-23.771-7.284-37.064-7.284-63.554S65.353 151.428 65 142q.03-.873.062-2.068A69 69 0 0 1 65 137V89c0-3.976.341-7.872.996-11.661L66 77zM132.5 53C102.4 53 78 77.4 78 107.5v23c0 30.1 24.4 54.5 54.5 54.5h1c30.1 0 54.5-24.4 54.5-54.5v-23c0-30.1-24.4-54.5-54.5-54.5z"></path></defs><mask id="Hijab-mask1" fill="#fff"><use href="#Hijab-path1"></use></mask><g id="Top/Accesories/Hijab" mask="url(&#39;#Hijab-mask1&#39;)"><g transform="translate(-1)"><mask id="Hijab-mask2" fill="#fff"><use href="#Hijab-path2"></use></mask><use fill="var(--avataaar-top-color)" class="CustomColor" href="#Hijab-path2"></use><path id="Band" fill="#FFF" stroke="none" d="M72.074 104.96A61.4 61.4 0 0 1 71 93.5C71 59.534 98.758 32 133 32s62 27.534 62 61.5c0 3.916-.369 7.747-1.074 11.46C192.34 72.683 165.67 47 133 47s-59.341 25.683-60.926 57.96" mask="url(&#39;#Hijab-mask2&#39;)" opacity=".5"></path><path id="Shadows" fill="#000" stroke="none" d="M187.93 104.695A55 55 0 0 1 189 115.5v23c0 30.1-24.4 54.5-54.5 54.5h-3c-30.1 0-54.5-24.4-54.5-54.5v-23c0-3.7.369-7.312 1.07-10.805Q78 106.089 78 107.5v23c0 30.1 24.4 54.5 54.5 54.5h1c30.1 0 54.5-24.4 54.5-54.5v-23q0-1.41-.07-2.805m-73.763 102.3c6.484 4.986 21.496 6.713 38.238 3.761 16.74-2.951 30.257-9.71 34.645-16.612q.102.379.171.767c1.71 9.695-13.236 20.434-33.38 23.987-20.146 3.552-37.863-1.428-39.573-11.123a9 9 0 0 1-.101-.78m11.868 28.926c8.192 5.654 24.387 5.923 41.069-.149s28.915-16.687 31.556-26.284q.215.48.396.98c4.527 12.436-8.077 28.441-28.151 35.748s-40.017 3.147-44.544-9.29q-.181-.498-.326-1.005" mask="url(&#39;#Hijab-mask2&#39;)" opacity=".16"></path></g></g></g>', 1)];
const K = {
        render: function(a, e) {
            return r(), t("svg", null, [...I])
        }
    },
    Y = [e('<g id="Top"><defs><path id="LongHairShavedSides-path2" d="M0 0h264v280H0z"></path><path id="LongHairShavedSides-path3" d="M156 180.611c17.53-8.328 30.048-25.496 31.791-45.744C193.57 134.002 198 129.02 198 123v-13c0-5.946-4.325-10.882-10-11.834V92c0-30.928-25.072-56-56-56S76 61.072 76 92v6.166c-5.675.952-10 5.888-10 11.834v13c0 6.019 4.43 11.002 10.209 11.867 1.743 20.248 14.26 37.416 31.791 45.744V199h-4c-39.765 0-72 32.235-72 72v9h200v-9c0-39.765-32.235-72-72-72h-4zM0 0h264v280H0z"></path><path id="LongHairShavedSides-path1" d="M65.18 77.737c2.183-1.632 15.227-2.258 17.578-3.648.734-.434 1.303-.873 1.742-1.309.439.436 1.009.875 1.742 1.31 2.351 1.389 15.395 2.015 17.578 3.647 2.21 1.654 3.824 5.448 3.647 8.414-.212 3.56-4.106 12.052-13.795 13.03-2.114-2.353-5.435-3.87-9.172-3.87s-7.058 1.517-9.172 3.87c-9.69-.978-13.583-9.47-13.795-13.03-.176-2.966 1.437-6.76 3.647-8.414m.665 17.164.017.007zm79.018-38.916c-.389-5.955-1.585-11.833-2.629-17.699-.281-1.579-1.81-12.286-2.5-12.286-.232 9.11-1.032 18.08-2.064 27.14-.309 2.708-.632 5.416-.845 8.134-.171 2.196.135 4.848-.397 6.972-.679 2.706-4.08 5.232-6.725 6.165-6.6 2.326-12.105-7.303-17.742-10.12-7.318-3.656-19.897-4.527-27.38.239-7.645-4.766-20.224-3.895-27.542-.239-5.637 2.817-11.142 12.446-17.742 10.12-2.645-.933-6.047-3.459-6.725-6.165-.532-2.124-.226-4.776-.397-6.972-.213-2.718-.536-5.426-.845-8.135C30.298 44.08 29.497 35.11 29.265 26c-.689 0-2.218 10.707-2.5 12.286-1.043 5.866-2.24 11.744-2.627 17.7-.4 6.119.077 12.181 1.332 18.177a165 165 0 0 0 2.049 8.541c.834 3.143-.32 9.262.053 12.488.707 6.104 3.582 18.008 6.811 23.259 1.561 2.538 3.39 4.123 5.433 6.168 1.967 1.97 2.788 5.021 4.91 7.118 3.956 3.908 9.72 6.234 15.64 6.806C65.677 143.05 74.506 146 84.5 146s18.823-2.95 24.135-7.457c5.919-.572 11.683-2.898 15.64-6.806 2.121-2.097 2.942-5.149 4.909-7.118 2.042-2.045 3.872-3.63 5.433-6.168 3.229-5.251 6.104-17.155 6.81-23.259.374-3.226-.78-9.345.054-12.488.75-2.828 1.45-5.676 2.05-8.54 1.254-5.997 1.73-12.06 1.332-18.179"></path><rect id="LongHairShavedSides-path4" width="112" height="150" x="0" y="0" rx="56"></rect></defs><mask id="LongHairShavedSides-mask2" fill="#fff"><use href="#LongHairShavedSides-path2"></use></mask><g id="Top/Long-Hair/Shaved-Sides" mask="url(&#39;#LongHairShavedSides-mask2&#39;)"><g transform="translate(-1)"><g id="Behind" fill="none" transform="translate(1)"><mask id="LongHairShavedSides-mask3" fill="#fff"><use href="#LongHairShavedSides-path3"></use></mask><path fill="var(--avataaar-hair-color)" d="M116.18 40H146c25.405 0 46 20.595 46 46v68.109c0 26.541 18.759 50.24 30.61 71.943s-7.355 42.19-26.84 50.717A38.5 38.5 0 0 1 180.332 280h-45.068c-56.352 0-65.046-63.69-67.566-133.496l2.52-62.36C71.213 59.48 91.497 40 116.179 40Z" class="CustomColor" mask="url(&#39;#LongHairShavedSides-mask3&#39;)"></path></g><g id="Top" fill="none" transform="translate(77 36)"><mask id="LongHairShavedSides-mask1" fill="#fff"><use href="#LongHairShavedSides-path4"></use></mask><path id="Shadow" fill="#000" d="M98.801 19.94C107.027 29.484 112 41.91 112 55.5v10-4c0-15.74-6.672-29.92-17.342-39.87q-46.107 16.57-77.717.378C6.505 31.937 0 45.958 0 61.5v4-10c0-13.607 4.987-26.05 13.233-35.6-3.834-3.04-4.974-11.713 6.234-15.023 11.845-3.499 9.84-18.079 27.99-20.803C65.61-18.65 63.972-11.375 81.03-12.35c17.057-.974 22.607-16.763 25.82-12.724 12.74 16.01 9.572 34.414-8.048 45.014Z" mask="url(&#39;#LongHairShavedSides-mask1&#39;)" opacity=".16"></path></g><path fill="#E0C863" d="M90.878 52.361q33.225 19.299 83.366 0c14.53-7.772 25.087-23.319 8.707-43.398-2.169-2.658-10.707 6.713-27.6 7.687s-13.271-3.3-31.248-.576-15.991 17.304-27.722 20.803c-11.73 3.498-9.803 12.987-5.503 15.484" class="CustomColor"></path></g></g></g>', 1)];
const J = {
        render: function(a, e) {
            return r(), t("svg", null, [...Y])
        }
    },
    X = [e('<g id="Top"><defs><path id="ShortHairShortRound-path2" d="M0 0h264v280H0z"></path><path id="ShortHairShortRound-path1" d="M167.309 35.006c-20.188-11.7-40.18-9.784-55.272-5.976s-24.02 14.621-31.68 30.618c-3.761 7.855-5.991 17.143-6.334 25.833-.135 3.412.325 6.934 1.245 10.22.337 1.205 2.155 5.386 2.654 2.008.167-1.125-.442-2.676-.5-3.871-.078-1.569.005-3.157.112-4.723.2-2.928.722-5.8 1.65-8.59 1.328-3.988 3.017-8.312 5.603-11.677 6.401-8.327 17.482-8.802 26.28-13.384-.764 1.405-3.707 3.68-2.688 5.263.705 1.094 3.37.762 4.643.727 3.349-.092 6.713-.674 10.02-1.147 5.214-.745 10.099-2.255 15.005-4.089 4.016-1.502 8.603-2.892 11.622-6.078 4.87 5.048 11.14 9.795 17.401 13.003 5.618 2.88 14.679 4.318 18.113 10.158 4.065 6.914 2.195 15.406 3.436 22.9.472 2.85 1.545 2.786 2.132.237.997-4.33 1.468-8.828 1.151-13.279-.718-10.048-4.405-36.453-24.593-48.153"></path></defs><mask id="ShortHairShortRound-mask2" fill="#fff"><use href="#ShortHairShortRound-path2"></use></mask><g id="Top/Short-Hair/Short-Round" mask="url(&#39;#ShortHairShortRound-mask2&#39;)"><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairShortRound-path1" transform="translate(-1)"></use></g></g>', 1)];
const $ = {
        render: function(a, e) {
            return r(), t("svg", null, [...X])
        }
    },
    aa = [e('<g id="Top"><defs><path id="LongHairBigHair-path1" d="M0 0h264v280H0z"></path><path id="LongHairBigHair-path2" d="M222.385 182.806c-5.374 5.712-10.737 9.322-10.554 15.194.317 11.889 43.608 47.051 5.169 69H16.005c-38.439-21.949 4.852-57.111 5.17-69 .182-5.872-5.18-9.482-10.555-15.194C5.247 177.094-.137 169.28.003 155c.941-29.028 31.369-26.412 31.2-46 .169-19-11.39-26.84 0-63C42.84 9.54 72.917.768 116.003.016V0l.5.008.5-.008v.016c43.086.752 73.163 9.523 84.8 45.984 11.388 36.16-.17 44 0 63-.17 19.588 30.258 16.972 31.2 46 .14 14.28-5.245 22.094-10.618 27.806m-39.501-87.481c-21.52-11.588-39.994-28.18-52.038-47.023C112.764 73.924 76.53 78.535 51.224 94.68A12 12 0 0 0 51 97v13c0 6.019 4.43 11.002 10.209 11.867 1.743 20.248 14.26 37.416 31.791 45.744V186h-4c-39.765 0-72 32.235-72 72v9h200v-9c0-39.765-32.235-72-72-72h-4v-18.389c17.53-8.328 30.048-25.496 31.791-45.744C178.57 121.002 183 116.02 183 110V97q-.001-.853-.116-1.675"></path><path id="LongHairBigHair-path3" d="M222.385 182.806c-5.374 5.712-10.737 9.322-10.554 15.194.317 11.889 43.608 47.051 5.169 69H16.005c-38.439-21.949 4.852-57.111 5.17-69 .182-5.872-5.18-9.482-10.555-15.194C5.247 177.094-.137 169.28.003 155c.941-29.028 31.369-26.412 31.2-46 .169-19-11.39-26.84 0-63C42.84 9.54 72.917.768 116.003.016V0l.5.008.5-.008v.016c43.086.752 73.163 9.523 84.8 45.984 11.388 36.16-.17 44 0 63-.17 19.588 30.258 16.972 31.2 46 .14 14.28-5.245 22.094-10.618 27.806M93 186h-4c-39.765 0-72 32.235-72 72v9h200v-9c0-39.765-32.235-72-72-72h-4v-46H93z"></path></defs><mask id="LongHairBigHair-mask2" fill="#fff"><use href="#LongHairBigHair-path1"></use></mask><g id="Top/Long-Hair/Big-Hair" mask="url(&#39;#LongHairBigHair-mask2&#39;)"><g transform="translate(-1)"><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairBigHair-path2" transform="translate(16 13)"></use><g id="Shadow" fill="none" transform="translate(16 13)"><mask id="LongHairBigHair-mask1" fill="#fff"><use href="#LongHairBigHair-path3"></use></mask><path id="Shadow-Mask" fill="#000" d="M30.099 115.057c-2.374 3.026-5.57 7.471-5.737 7.137 1.873-2.383 3.013-5.182 2.979-8.758.177-18.101-11.904-25.569 0-60.017.669-1.91 1.766-3.715 3.245-5.414-10.343 34.454.783 42.35.617 60.995.02 2.295-.38 4.285-1.104 6.057m172.32-67.052c1.48 1.7 2.577 3.504 3.245 5.414 10.158 29.394 2.852 39.144.6 52.617-.3.805-.069 1.754-.384 2.567-30.673-10.458-58.29-30.043-74.385-52.991-22.784 29.424-73.14 29.761-97.821 55.324.387-.544.754-1.051 1.084-1.49 22.536-29.919 73.489-29.122 96.088-61.144 15.398 24.088 41.818 44.648 71.163 55.625.301-.854.08-1.85.367-2.694 2.108-13.833 8.84-23.926.043-53.228" mask="url(&#39;#LongHairBigHair-mask1&#39;)" opacity=".16"></path></g><path id="Light" fill="#FFF" d="M50.758 122.446c22.536-29.919 73.489-29.122 96.088-61.144 15.398 24.088 41.818 44.648 71.163 55.625.301-.854.08-1.85.367-2.694 2.155-14.144 9.144-24.378-.573-55.233-11.637-36.46-41.714-45.232-84.8-45.984l-1-.016c-43.086.768-73.163 9.54-84.8 46-11.39 36.16.169 44 0 63 .032 3.753-1.059 6.691-2.85 9.193.183.402 4.153-5.756 6.405-8.747" opacity=".1"></path></g></g></g>', 1)];
const ra = {
        render: function(a, e) {
            return r(), t("svg", null, [...aa])
        }
    },
    ta = [e('<g id="Top"><defs><path id="LongHairStraight-path1" d="M0 0h264v280H0z"></path><path id="LongHairStraight-path2" d="M133.506 81.335A12 12 0 0 1 140 92v13c0 6.019-4.43 11.002-10.209 11.867-1.743 20.248-14.26 37.416-31.791 45.744V181h4c17.49 0 33.525 6.237 46 16.608V74c0-20.435-8.283-38.935-21.674-52.326S94.435 0 74 0C33.13 0 0 33.13 0 74v183.716c13.57-1.94 24-13.61 24-27.716v-45.577A72 72 0 0 1 46 181h4v-18.389a56.23 56.23 0 0 1-26-25.365v-61.98c9.147-2.975 18.778-7.249 28.342-12.77 15.403-8.894 28.09-19.555 36.724-30.099a87 87 0 0 0 7.044 15.488c8.768 15.186 21.114 26.349 33.89 32.032v.249q.6.1 1.18.26 1.162.484 2.326.91Z"></path></defs><mask id="LongHairStraight-mask1" fill="#fff"><use href="#LongHairStraight-path1"></use></mask><g id="Top/Long-Hair/Straight" mask="url(&#39;#LongHairStraight-mask1&#39;)"><g transform="translate(-1)"><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairStraight-path2" transform="translate(59 18)"></use><path id="Shadow" fill="#000" d="M192.506 99.335c4.869 1.773 9.757 2.737 14.494 2.813V92c0-20.435-8.283-38.935-21.674-52.326C198.717 53.065 207 71.565 207 92v123.608C194.525 205.237 178.49 199 161 199h-4v-18.389c17.53-8.328 30.048-25.496 31.791-45.744C194.57 134.002 199 129.02 199 123v-13a12 12 0 0 0-6.494-10.665m-2.326-.91a12 12 0 0 0-1.18-.26v-.248q.59.262 1.18.509ZM83 155.246a56.23 56.23 0 0 0 26 25.366V199h-4c-7.673 0-15.065 1.2-22 3.423z" opacity=".24"></path></g></g></g>', 1)];
const ea = {
        render: function(a, e) {
            return r(), t("svg", null, [...ta])
        }
    },
    ia = [e('<g id="Top"><defs><path id="ShortHairShortWaved-path2" d="M0 0h264v280H0z"></path><path id="ShortHairShortWaved-path1" d="M183.68 38.949c5.406-4.95 6.707-14.987 3.638-21.5-3.769-7.995-11.417-8.997-18.746-5.48-6.908 3.315-13.057 4.419-20.622 2.813-7.258-1.541-14.144-4.26-21.647-4.706-12.325-.733-24.3 3.839-32.7 13.053-1.603 1.758-2.894 3.768-4.115 5.805-.976 1.63-2.077 3.38-2.493 5.258-.198.894.17 3.098-.275 3.83-.48.79-2.296 1.515-3.069 2.102-1.567 1.189-2.924 2.53-4.18 4.047-2.666 3.222-4.133 6.587-5.368 10.572-4.102 13.245-4.45 28.998.854 42.004.707 1.734 2.898 5.352 4.186 1.638.255-.734-.334-3.194-.333-3.935.005-2.72 1.506-20.729 8.047-30.817 2.13-3.284 11.973-15.58 13.984-15.68 1.065 1.693 11.88 12.51 39.942 11.242 12.662-.572 22.4-6.26 24.738-8.727 1.028 5.533 12.992 13.816 14.815 17.224 5.267 9.846 6.435 30.304 8.445 30.265s3.453-5.237 3.867-6.23c3.072-7.375 3.595-16.632 3.267-24.559-.427-10.202-4.638-21.226-12.235-28.22Z"></path></defs><mask id="ShortHairShortWaved-mask2" fill="#fff"><use href="#ShortHairShortWaved-path2"></use></mask><g id="Top/Short-Hair/Short-Waved" mask="url(&#39;#ShortHairShortWaved-mask2&#39;)"><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairShortWaved-path1" transform="translate(-1)"></use></g></g>', 1)];
const la = {
        render: function(a, e) {
            return r(), t("svg", null, [...ia])
        }
    },
    sa = [e('<g id="Top"><defs><path id="LongHairBob-path1" d="M0 0h264v280H0z"></path><path id="LongHairBob-path2" d="M38 79.36V111c0 22.34 13.08 41.623 32 50.611v13.135c-19.637 2.688-35.359 7.418-46.615 6.254C9.162 179.53 1.496 150.796 1 126 .383 95.164 29.319 30.795 40 18 47.923 8.509 69.695.55 94 1s46.862 5.812 55 16c12.324 15.428 37.869 74.079 38 109 .094 24.8-9.537 49.66-23 51-11.08 1.103-26.524-1.489-46-3.003v-12.386c18.92-8.988 32-28.272 32-50.611V82.988q-14.282-7.286-25.846-17.647 4.812 7.944 10.46 13.532-40.526-11.37-64.473-38.528Q58.169 65.042 38 79.36"></path></defs><mask id="LongHairBob-mask1" fill="#fff"><use href="#LongHairBob-path1"></use></mask><g id="Top/Long-Hair/Bob" mask="url(&#39;#LongHairBob-mask1&#39;)"><g transform="translate(-1)"><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairBob-path2" transform="translate(39 19)"></use></g></g></g>', 1)];
const oa = {
        render: function(a, e) {
            return r(), t("svg", null, [...sa])
        }
    },
    ha = [e('<g id="Top"><defs><path id="LongHairStraight2-path1" d="M0 0h264v280H0z"></path><path id="LongHairStraight2-path2" d="M21 157.54V69.047c0-3.532.398-6.971 1.152-10.275C25.205 38.731 36.775 22.811 50 13c19.905-14.76 53.442-19.018 65.047-1.478C123.698 7.681 136.52 11.182 146 20c9.565 9.415 17.2 30.197 12.657 47.204q.158 1.898.158 3.837v21.851A12.01 12.01 0 0 0 149 83.166V83c-6.036-21.536-23.77-31.42-34.57-41.223C97.535 60.673 44.823 60.74 27 98v10c0 6.019 4.43 11.002 10.209 11.867 1.743 20.248 14.26 37.416 31.791 45.744V166c2.93 43.855-6.642 98.797-69 82 13.606-7.962 20.808-58.944 21-90.46m96 8.071c17.53-8.328 30.048-25.496 31.791-45.744a12.01 12.01 0 0 0 10.024-9.76v1.363a100 100 0 0 0 10.963 45.524l26.949 52.707c6.963 13.619 4.919 29.473-3.936 40.768C189.966 213.289 158.903 184 121 184h-4z"></path><path id="LongHairStraight2-path3" d="M65.18 77.737c2.183-1.632 15.227-2.258 17.578-3.648.734-.434 1.303-.873 1.742-1.309.439.436 1.009.875 1.742 1.31 2.351 1.389 15.395 2.015 17.578 3.647 2.21 1.654 3.824 5.448 3.647 8.414-.212 3.56-4.106 12.052-13.795 13.03-2.114-2.353-5.435-3.87-9.172-3.87s-7.058 1.517-9.172 3.87c-9.69-.978-13.583-9.47-13.795-13.03-.176-2.966 1.437-6.76 3.647-8.414m.665 17.164.017.007zm79.018-38.916c-.389-5.955-1.585-11.833-2.629-17.699-.281-1.579-1.81-12.286-2.5-12.286-.232 9.11-1.032 18.08-2.064 27.14-.309 2.708-.632 5.416-.845 8.134-.171 2.196.135 4.848-.397 6.972-.679 2.706-4.08 5.232-6.725 6.165-6.6 2.326-12.105-7.303-17.742-10.12-7.318-3.656-19.897-4.527-27.38.239-7.645-4.766-20.224-3.895-27.542-.239-5.637 2.817-11.142 12.446-17.742 10.12-2.645-.933-6.047-3.459-6.725-6.165-.532-2.124-.226-4.776-.397-6.972-.213-2.718-.536-5.426-.845-8.135C30.298 44.08 29.497 35.11 29.265 26c-.689 0-2.218 10.707-2.5 12.286-1.043 5.866-2.24 11.744-2.627 17.7-.4 6.119.077 12.181 1.332 18.177a165 165 0 0 0 2.049 8.541c.834 3.143-.32 9.262.053 12.488.707 6.104 3.582 18.008 6.811 23.259 1.561 2.538 3.39 4.123 5.433 6.168 1.967 1.97 2.788 5.021 4.91 7.118 3.956 3.908 9.72 6.234 15.64 6.806C65.677 143.05 74.506 146 84.5 146s18.823-2.95 24.135-7.457c5.919-.572 11.683-2.898 15.64-6.806 2.121-2.097 2.942-5.149 4.909-7.118 2.042-2.045 3.872-3.63 5.433-6.168 3.229-5.251 6.104-17.155 6.81-23.259.374-3.226-.78-9.345.054-12.488.75-2.828 1.45-5.676 2.05-8.54 1.254-5.997 1.73-12.06 1.332-18.179"></path></defs><mask id="LongHairStraight2-mask1" fill="#fff"><use href="#LongHairStraight2-path1"></use></mask><g id="Top/Long-Hair/Straight" mask="url(&#39;#LongHairStraight2-mask1&#39;)"><g transform="translate(-1)"><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairStraight2-path2" transform="translate(40 15)"></use><path id="Shadow" fill="#000" d="M67 113c17.823-32.335 70.535-32.393 87.43-48.792 10.778 8.49 28.462 15.059 34.533 33.66-6.071-21.444-23.755-31.308-34.533-41.09C137.535 75.672 84.823 75.74 67 113" opacity=".16"></path></g></g></g>', 1)];
const ca = {
        render: function(a, e) {
            return r(), t("svg", null, [...ha])
        }
    },
    na = [e('<g id="Top"><defs><path id="ShortHairSides-path1" d="M0 0h264v280H0z"></path><path id="ShortHairSides-path2" d="M65.18 77.737c2.183-1.632 15.227-2.258 17.578-3.648.734-.434 1.303-.873 1.742-1.309.439.436 1.009.875 1.742 1.31 2.351 1.389 15.395 2.015 17.578 3.647 2.21 1.654 3.824 5.448 3.647 8.414-.212 3.56-4.106 12.052-13.795 13.03-2.114-2.353-5.435-3.87-9.172-3.87s-7.058 1.517-9.172 3.87c-9.69-.978-13.583-9.47-13.795-13.03-.176-2.966 1.437-6.76 3.647-8.414m.665 17.164.017.007zm79.018-38.916c-.389-5.955-1.585-11.833-2.629-17.699-.281-1.579-1.81-12.286-2.5-12.286-.232 9.11-1.032 18.08-2.064 27.14-.309 2.708-.632 5.416-.845 8.134-.171 2.196.135 4.848-.397 6.972-.679 2.706-4.08 5.232-6.725 6.165-6.6 2.326-12.105-7.303-17.742-10.12-7.318-3.656-19.897-4.527-27.38.239-7.645-4.766-20.224-3.895-27.542-.239-5.637 2.817-11.142 12.446-17.742 10.12-2.645-.933-6.047-3.459-6.725-6.165-.532-2.124-.226-4.776-.397-6.972-.213-2.718-.536-5.426-.845-8.135C30.298 44.08 29.497 35.11 29.265 26c-.689 0-2.218 10.707-2.5 12.286-1.043 5.866-2.24 11.744-2.627 17.7-.4 6.119.077 12.181 1.332 18.177a165 165 0 0 0 2.049 8.541c.834 3.143-.32 9.262.053 12.488.707 6.104 3.582 18.008 6.811 23.259 1.561 2.538 3.39 4.123 5.433 6.168 1.967 1.97 2.788 5.021 4.91 7.118 3.956 3.908 9.72 6.234 15.64 6.806C65.677 143.05 74.506 146 84.5 146s18.823-2.95 24.135-7.457c5.919-.572 11.683-2.898 15.64-6.806 2.121-2.097 2.942-5.149 4.909-7.118 2.042-2.045 3.872-3.63 5.433-6.168 3.229-5.251 6.104-17.155 6.81-23.259.374-3.226-.78-9.345.054-12.488.75-2.828 1.45-5.676 2.05-8.54 1.254-5.997 1.73-12.06 1.332-18.179"></path><path id="ShortHairSides-path3" d="M6 28c-5.076.071-6-1.006-6-5C0 17.344 4.04 6.778 8 2c1.176-2.17 3.619-3.432 3 1-2.66 8.477.417 24.914-5 25m114 0c-5.417-.086-2.34-16.523-5-25-.619-4.432 1.824-3.17 3-1 3.96 4.778 8 15.344 8 21 0 3.994-.924 5.071-6 5"></path></defs><mask id="ShortHairSides-mask2" fill="#fff"><use href="#ShortHairSides-path1"></use></mask><g id="Top/Short-Hair/Sides" mask="url(&#39;#ShortHairSides-mask2&#39;)"><g transform="translate(-1)"><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairSides-path3" transform="translate(70 74)"></use></g></g></g>', 1)];
const da = {
        render: function(a, e) {
            return r(), t("svg", null, [...na])
        }
    },
    fa = [e('<g id="Top"><defs><path id="LongHairBun-path2" d="M0 0h264v280H0z"></path><path id="LongHairBun-path1" d="M114.94 28.337q-1.48.334-2.903.693c-15.092 3.808-24.02 14.621-31.68 30.618-3.761 7.855-5.991 17.143-6.334 25.833-.135 3.412.325 6.934 1.245 10.22.337 1.205 2.155 5.386 2.654 2.008.167-1.125-.442-2.676-.5-3.871-.078-1.569.005-3.157.112-4.723.2-2.928.722-5.8 1.65-8.59 1.328-3.988 3.017-8.312 5.603-11.677C91.188 60.521 95.765 43.206 133 41.671s48.749 25.79 52.183 31.63c4.065 6.914 2.195 15.406 3.436 22.9.472 2.85 1.545 2.786 2.132.237.997-4.33 1.468-8.828 1.151-13.279-.718-10.048-4.405-36.453-24.593-48.153-5.443-3.154-10.87-5.319-16.192-6.723C154.177 25.31 156 21.568 156 17.5 156 7.835 145.703 0 133 0s-23 7.835-23 17.5c0 4.092 1.846 7.857 4.94 10.837"></path></defs><mask id="LongHairBun-mask2" fill="#fff"><use href="#LongHairBun-path2"></use></mask><g id="Top/Long-Hair/Bun" mask="url(&#39;#LongHairBun-mask2&#39;)"><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairBun-path1" transform="translate(-1)"></use></g></g>', 1)];
const ua = {
        render: function(a, e) {
            return r(), t("svg", null, [...fa])
        }
    },
    pa = [e('<g id="Top"><defs><path id="LongHairStraightStrand-path1" d="M0 0h264v280H0z"></path><path id="LongHairStraightStrand-path2" d="M8.461 88.694C8.161 89.744 8 90.854 8 92v13c0 6.019 4.43 11.002 10.209 11.867 1.743 20.248 14.26 37.416 31.791 45.744V181h-4c-15.619 0-30.076 4.973-41.875 13.423A73.9 73.9 0 0 1 0 170V74C0 33.13 33.13 0 74 0s74 33.13 74 74v96a73.9 73.9 0 0 1-4.125 24.423C132.076 185.973 117.619 181 102 181h-4v-18.389c17.53-8.328 30.048-25.496 31.791-45.744C135.57 116.002 140 111.02 140 105V92c0-1.69-.349-3.297-.979-4.755-12.956-2.188-27.542-7.476-41.872-15.75-12.132-7.004-22.503-15.237-30.48-23.743q5.14 11.862 12.45 20.783-19.013-8.285-25.892-26.639a100 100 0 0 1-1.18 2.762c-9.84 22.1-26.456 38.024-43.586 44.036"></path><path id="LongHairStraightStrand-path3" d="M65.18 77.737c2.183-1.632 15.227-2.258 17.578-3.648.734-.434 1.303-.873 1.742-1.309.439.436 1.009.875 1.742 1.31 2.351 1.389 15.395 2.015 17.578 3.647 2.21 1.654 3.824 5.448 3.647 8.414-.212 3.56-4.106 12.052-13.795 13.03-2.114-2.353-5.435-3.87-9.172-3.87s-7.058 1.517-9.172 3.87c-9.69-.978-13.583-9.47-13.795-13.03-.176-2.966 1.437-6.76 3.647-8.414m.665 17.164.017.007zm79.018-38.916c-.389-5.955-1.585-11.833-2.629-17.699-.281-1.579-1.81-12.286-2.5-12.286-.232 9.11-1.032 18.08-2.064 27.14-.309 2.708-.632 5.416-.845 8.134-.171 2.196.135 4.848-.397 6.972-.679 2.706-4.08 5.232-6.725 6.165-6.6 2.326-12.105-7.303-17.742-10.12-7.318-3.656-19.897-4.527-27.38.239-7.645-4.766-20.224-3.895-27.542-.239-5.637 2.817-11.142 12.446-17.742 10.12-2.645-.933-6.047-3.459-6.725-6.165-.532-2.124-.226-4.776-.397-6.972-.213-2.718-.536-5.426-.845-8.135C30.298 44.08 29.497 35.11 29.265 26c-.689 0-2.218 10.707-2.5 12.286-1.043 5.866-2.24 11.744-2.627 17.7-.4 6.119.077 12.181 1.332 18.177a165 165 0 0 0 2.049 8.541c.834 3.143-.32 9.262.053 12.488.707 6.104 3.582 18.008 6.811 23.259 1.561 2.538 3.39 4.123 5.433 6.168 1.967 1.97 2.788 5.021 4.91 7.118 3.956 3.908 9.72 6.234 15.64 6.806C65.677 143.05 74.506 146 84.5 146s18.823-2.95 24.135-7.457c5.919-.572 11.683-2.898 15.64-6.806 2.121-2.097 2.942-5.149 4.909-7.118 2.042-2.045 3.872-3.63 5.433-6.168 3.229-5.251 6.104-17.155 6.81-23.259.374-3.226-.78-9.345.054-12.488.75-2.828 1.45-5.676 2.05-8.54 1.254-5.997 1.73-12.06 1.332-18.179"></path></defs><mask id="LongHairStraightStrand-mask1" fill="#fff"><use href="#LongHairStraightStrand-path1"></use></mask><g id="Top/Long-Hair/Straight-+-Strand" mask="url(&#39;#LongHairStraightStrand-mask1&#39;)"><g transform="translate(-1)"><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairStraightStrand-path2" transform="translate(59 18)"></use><path id="Shadow" fill="#000" d="M59 102.419v6.419c19.945-3.088 40.59-20.448 52.046-46.18q.615-1.38 1.18-2.762 6.008 16.029 21.27 24.378a78 78 0 0 0 4.622 6.261q-19.012-8.285-25.891-26.639a101 101 0 0 1-1.18 2.762C99.59 92.39 78.944 109.75 59 112.838zm148-1.279v9.14c-14.953-.867-33.099-6.535-50.851-16.785-10.273-5.93-19.283-12.743-26.646-19.855a99 99 0 0 1-3.833-7.888c7.976 8.506 18.347 16.74 30.479 23.743 17.752 10.25 35.898 15.918 50.851 16.786z" opacity=".16"></path></g></g></g>', 1)];
const ga = {
        render: function(a, e) {
            return r(), t("svg", null, [...pa])
        }
    },
    ma = [e('<g id="Top"><defs><path id="ShortHairTheCaesar-path1" d="M0 0h264v280H0z"></path><path id="ShortHairTheCaesar-path2" d="M1 64c.347 1.488 1.673 1.223 2 0-.463-1.554 3.296-28.752 13-36 3.618-2.517 23.008-4.768 42.313-4.754C77.409 23.259 96.42 25.51 100 28c9.704 7.248 13.463 34.446 13 36 .327 1.223 1.653 1.488 2 0 .72-10.298 0-63.726-57-63S.28 53.702 1 64"></path></defs><mask id="ShortHairTheCaesar-mask1" fill="#fff"><use href="#ShortHairTheCaesar-path1"></use></mask><g id="Top/Short-Hair/The-Caesar" mask="url(&#39;#ShortHairTheCaesar-mask1&#39;)"><g transform="translate(-1)"><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairTheCaesar-path2" transform="translate(75 34)"></use></g></g></g>', 1)];
const Ca = {
        render: function(a, e) {
            return r(), t("svg", null, [...ma])
        }
    },
    va = [e('<g id="Top"><defs><path id="LongHairCurly-path1" d="M0 0h264v280H0z"></path><path id="LongHairCurly-path2" d="M48.725 89.219A12 12 0 0 0 42 100v13c0 6.019 4.43 11.002 10.209 11.867 1.743 20.248 14.26 37.416 31.791 45.744V189h-4q-2.38 0-4.721.152a72 72 0 0 1-13.689-9.103A48 48 0 0 1 48 182c-26.51 0-48-21.49-48-48 0-14.41 6.349-27.335 16.402-36.134A43.8 43.8 0 0 1 8 72c0-21.84 15.911-39.962 36.774-43.41C51.019 11.89 67.12 0 86 0a43.8 43.8 0 0 1 22 5.886A43.8 43.8 0 0 1 130 0c18.88 0 34.981 11.89 41.226 28.59C192.09 32.039 208 50.16 208 72a43.8 43.8 0 0 1-8.402 25.866C209.65 106.665 216 119.591 216 134c0 26.51-21.49 48-48 48-4.72 0-9.281-.681-13.59-1.951a72 72 0 0 1-13.689 9.103A73 73 0 0 0 136 189h-4v-18.389c17.53-8.328 30.048-25.496 31.791-45.744C169.57 124.002 174 119.02 174 113v-13a11.99 11.99 0 0 0-5.476-10.073 24 24 0 0 1-3.235-1.47q-.63-.18-1.289-.291v-.453c-8.68-5.303-17.235-16.538-22.55-30.914C131.312 58.835 119.547 60 107 60c-11.961 0-23.212-1.059-33.02-2.921C68.756 71.064 60.465 82.043 52 87.423v.743a12 12 0 0 0-3.275 1.053"></path></defs><mask id="LongHairCurly-mask1" fill="#fff"><use href="#LongHairCurly-path1"></use></mask><g id="Top/Long-Hair/Curly" mask="url(&#39;#LongHairCurly-mask1&#39;)"><g transform="translate(-1)"><path id="Shadow" fill="#000" d="M105.985 27.764C114.013 26.627 122.796 26 132 26c10.358 0 20.183.794 29 2.216C183.451 38.75 199 61.56 199 88v17.044c-11.538-.371-25.169-14.28-32.55-34.245C156.312 72.835 144.547 74 132 74c-11.961 0-23.212-1.059-33.02-2.921-7.304 19.548-20.597 33.223-31.98 33.943V88c0-26.825 16.004-49.913 38.985-60.236" opacity=".16"></path><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairCurly-path2" transform="translate(25 10)"></use></g></g></g>', 1)];
const Ma = {
    render: function(a, e) {
        return r(), t("svg", null, [...va])
    }
};
const Ha = {
        render: function(a, e) {
            return r(), t("svg")
        }
    },
    Sa = [e('<g id="Top"><defs><path id="ShortHairTheCaesarSidePart-path1" d="M0 0h264v280H0z"></path><path id="ShortHairTheCaesarSidePart-path2" d="M82.018 24.378c-7.032-.693-15.36-1.127-23.705-1.132C39.008 23.232 19.618 25.483 16 28 6.296 35.248 2.537 62.446 3 64c-.327 1.223-1.653 1.488-2 0C.28 53.702 1 1.726 58 1s57.72 52.702 57 63c-.347 1.488-1.673 1.223-2 0 .463-1.554-3.296-28.752-13-36-1.76-1.224-7.247-2.39-14.641-3.261L89 16z"></path></defs><mask id="ShortHairTheCaesarSidePart-mask1" fill="#fff"><use href="#ShortHairTheCaesarSidePart-path1"></use></mask><g id="Top/Short-Hair/The-Caesar-+-Side-Part" mask="url(&#39;#ShortHairTheCaesarSidePart-mask1&#39;)"><g transform="translate(-1)"><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairTheCaesarSidePart-path2" transform="translate(75 34)"></use></g></g></g>', 1)];
const ka = {
        render: function(a, e) {
            return r(), t("svg", null, [...Sa])
        }
    },
    ya = [e('<g id="Top"><defs><path id="LongHairCurvy-path1" d="M0 0h264v280H0z"></path><path id="LongHairCurvy-path2" d="M162.831 71.618A57 57 0 0 1 163 76v38c0 22.34-13.08 41.623-32 50.611V183h4c1.524 0 2.038.047 3.539.14-14.913 27.356-18.715 50.434-1.067 64.403 1.698 1.203 2.924 1.786 3.135 1.885 2.373 1.118 4.837 2.34 7.467 2.955 4.623 1.08 9.933-.373 14.557-.953 2.112-.266 4.217-.43 6.346-.436 2.565-.009 5.211.084 7.142 1.697 1.884 1.574 1.644 7.198-3.875 9.833 4.1 1.855 9.012-2.453 10.688-5.177 1.466-2.385 2.594-4.968 3.214-7.605.772-3.283.822-6.725.218-10.014-1.258-6.848-4.176-13.432-6.163-20.122-.732-2.466-1.686-5.165-2.102-7.69-.113-.684-.247-3.215-.141-3.744.078-.393.059-.797 1.415-1.176 3.916-1.096 8.007-2.933 10.852-5.52 3.365-3.058 5.119-7.03 6.533-10.979 2.24-6.252 3.523-12.947 4.113-19.44.122-1.349.191-2.695.215-4.047.015-.817-.085-1.747.008-2.565.153-1.34-.054-.987 1.248-1.874 4.257-2.9 7.58-7.122 9.71-11.37 3.346-6.672 3.782-13.708 1.066-20.467-2.253-5.607-5.827-11.235-11.392-14.846-2.137-1.386-4.392-2.643-6.61-3.93-1.21-.7-4.048-1.615-4.906-2.517-.6-.63.355-3.792.476-4.858.528-4.648-.08-9.157-1.165-13.696-2.394-10.008-12.033-26.149-15.903-35.662-3.325-8.172-8.136-55.3-65.031-55.026C51.69.473 41.419 50.438 33.716 59.774c-8.365 10.138-16.809 29.402-11.113 47.262-5.504 6.922-18.058 17.008-21.218 27.09-1.982 6.325-1.897 13.37.644 19.507 1.437 3.471 3.496 6.618 5.911 9.64 2.117 2.646 4.468 5.15 6.518 7.837 1.237 1.622 1.568 2.02 1.102 4.018-.92 3.94-2.819 7.725-4.466 11.475-2.552 5.81-4.697 11.22-5.014 17.413-.302 5.896 1.324 22.673 18.261 32.56a63 63 0 0 0 6.042 3.11c-1.09-3.396.146-15.524 2.343-20.032.56 1.55 1.511 3.043 2.536 4.398 1.6 2.115 5.374 7.409 10.147 7.655-1.937-2.984-4.02-4.998-4.624-8.598 3.977 1.96 9.634 3.747 14.262 3.582 3.404-.12 8.424-1.82 10.953-3.943-8.372 1.327-16.321-1.433-19.518-7.329-.667-1.23-1.174-2.52-1.468-3.86-.417-1.9-1.076-4.944-.191-6.697.215-.426.566-.86.984-1.29l-.197-.235c5.694-4.787 12.84-12.404 16.665-17.97q.106-.183.21-.367h.04l.085-.126A72.2 72.2 0 0 1 79 183h4v-18.389C64.08 155.623 51 136.339 51 114V76c0-2.463.159-4.888.467-7.267 3.942-1.263 7.898-2.455 11.932-3.528 4.456-1.186 14.399-3.114 18.29-4.01l2.736-2.98 1.063 1.955c2.158-.166 14.078-1.957 14.078-1.957l1.33-3.223c1.717 1.763 2.939 2.679 2.939 2.679 2.556-.209 13.653-.458 16.285-.426 0 0 7.34.258 9.12.328l1.668-.638.548 1.077c1.454.591 10.243 3.59 11.978 4.128l2.547-.906c1.12 2.694 3.94 2.354 6.276 4.481 2.503 2.279 7.226 4.024 10.574 5.905"></path></defs><mask id="LongHairCurvy-mask1" fill="#fff"><use href="#LongHairCurvy-path1"></use></mask><g id="Top/Long-Hair/Curvy" mask="url(&#39;#LongHairCurvy-mask1&#39;)"><g transform="translate(-1)"><path id="Top-Shadow" fill="#000" d="M100.9 42.465c-9.798 6.007-18.514 13.862-24.313 22.895-2.762 4.303-5.034 8.84-7.15 13.398a136 136 0 0 0-2.961 6.931c-.587 1.47-1.487 3.056-.64 4.599.517-.302.713-.194.388.347 2.692.734 6.434-1.335 8.767-2.099 4.763-1.56 9.53-3.033 14.408-4.331 4.456-1.186 14.399-3.114 18.29-4.01l2.736-2.98 1.063 1.955c2.158-.166 14.078-1.957 14.078-1.957l1.33-3.223c1.717 1.763 2.939 2.679 2.939 2.679 2.556-.209 13.653-.458 16.285-.426 0 0 7.34.258 9.12.328l1.668-.638.548 1.077c1.454.591 10.243 3.59 11.978 4.128l2.547-.906c1.12 2.694 3.94 2.354 6.276 4.481 3.092 2.814 9.569 4.816 12.66 7.263 1.108.876 2.143 1.792 3.183 2.726 1.156 1.037.985 1.188 1.36 2.378.113.356 1.256 2.199 1.743 2.35 1.733.536-10.154-30.486-13.417-34.453-3.368-4.094-25.211-31.654-54.174-30.752" opacity=".16"></path><g id="Hair" fill="none" transform="translate(26 16)"><mask id="LongHairCurvy-mask2" fill="#fff"><use href="#LongHairCurvy-path2"></use></mask><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairCurvy-path2"></use><path id="Shadow" fill="#000" d="M62.68 184.462c7.075-9.707-.531-36.675-6.552-46.661q25.256-11.495 99.746 4.247-7.192 13.279-5.868 23.71-6.806 8.363-11.246 17.383l-34.871 8.606q-33.054 3.98-41.21-7.285Z" mask="url(&#39;#LongHairCurvy-mask2&#39;)" opacity=".24"></path></g><path id="Lights" fill="#FFF" d="M79.04 170.094c-.059-.201-.205-.427-.405-.665q.205.331.405.665m-22.63-49.719a88.6 88.6 0 0 0 4.456 18.002c2.062 5.721 4.42 11.46 7.813 16.69 3.161 4.876 6.924 9.425 9.956 14.362-.797-.948-2.472-2.1-3.114-2.778a50 50 0 0 1-2.984-3.458c-1.923-2.443-3.637-5-5.294-7.583-3.252-5.073-5.69-10.576-7.803-16.08-4.15-10.807-8.313-23.913-4.666-35.33-.282.735.459 2.488.575 3.297.204 1.414.386 2.837.478 4.26.185 2.883.184 5.749.583 8.618m12.445 44.666c-1.358-1.731-3.881-3.097-5.442-4.762-1.415-1.51-2.511-3.2-3.506-4.94-2.255-3.94-3.737-7.964-4.217-12.37.11.523.918 1.427 1.173 1.856a85 85 0 0 1 1.788 3.124c1.097 2.04 2.013 4.15 3.122 6.187 2.038 3.74 4.63 7.36 7.082 10.905m4.677 18.458c1.115 1.962 2.04 3.966 2.625 6.102a42 42 0 0 1 .77 3.413c.07.369.082 1.696.258 2.27-2.215-4.291-3.905-8.835-6.543-12.942-2.604-4.054-5.947-7.781-9.446-11.281-3.695-3.695-7.41-7.182-9.392-11.847-1.725-4.06-2.391-8.218-1.99-12.556.002 1.911 1.757 4.622 2.363 6.469.83 2.527 1.489 5.105 2.737 7.507 2.126 4.089 5.959 7.243 9.165 10.688 3.553 3.816 6.946 7.762 9.453 12.177m-14.303-9.32a22 22 0 0 1 2.806 3.275c.898 1.285 1.556 2.636 2.145 4.05.507 1.217.73 3.482 1.527 4.498-2.578-3.146-5.233-6.117-7.011-9.69-.607-1.222-1.548-3.023-2.243-4.495.231.593 2.253 1.86 2.776 2.362m-10.326 6.349c2.838 4.25 6.548 8.081 8.974 12.528 2.83 5.187 4.075 10.807 4.326 16.54.119 2.711.112 5.465-.253 8.168-.196 1.448-.51 2.886-.869 4.312-.136.54-.84 1.926-.977 2.77-.29-10.54 1.454-21.082-4.027-30.903-2.596-4.65-6.586-8.616-9.679-13.018-2.782-3.959-5.498-7.841-7.713-12.074 1.356 1.716 3.8 3.065 5.316 4.769 1.899 2.134 3.348 4.58 4.902 6.908m11.2 44.319c-.032.204-.033.377.014.5l-.013-.5Zm-9.543-22.353c.001.496.816 1.518 1.04 2.035.52 1.209.946 2.478 1.157 3.76.418 2.529-.13 5.14-1.067 7.561-1.9 4.907-4.874 9.253-8.613 13.3 1.335-1.748 1.867-4.589 2.806-6.538.965-2 2-3.97 2.85-6.011 1.92-4.605 1.75-9.311 1.827-14.107M41.917 221.2c.401-.548.193-3.183.405-3.872.392-1.273 1.07-2.502 1.849-3.635-.416.699.198 2.466-.005 3.373-.332 1.489-1.17 2.932-2.249 4.134m57.69-178.453a.9.9 0 0 0-.239.297zm-14.76 21.584c1.42-1.246 2.177-4.19 3.156-5.78 1.125-1.825 2.418-3.579 3.645-5.356 2.432-3.524 4.726-6.984 7.72-10.19-.622.934-1.173 3.768-1.514 4.513a34.6 34.6 0 0 1-3.221 5.605c-2.86 4.044-5.93 7.803-9.786 11.208m-.535-10.21c.75-1.327 1.894-2.448 3.18-3.414-.573.503-.831 2.575-1.225 3.275-.795 1.412-1.953 2.63-3.196 3.772.664-.582.772-2.803 1.24-3.633Zm119.194 98.006-.041.31c-.002-1.525-.68-3.2-.76-4.769-.113-2.19.202-4.315 1.082-6.392 1.74-4.101 5.003-7.207 9.164-9.638-1.145.674-2.267 3.213-3.001 4.268-1.103 1.586-2.282 3.187-3.214 4.85-1.943 3.469-2.506 7.618-3.23 11.371m-1.508-21.646a23 23 0 0 1-.989 3.626c-.474 1.279-1.093 2.523-1.783 3.728-.43.75-1.98 2.327-1.978 3.157-.083-4.898 1.728-9.335 5.172-13.257-.378.657-.283 2.03-.422 2.746m-.801 35.238c3.656-.517 7.105 1.261 9.421 3.551 1.238 1.224 2.338 2.63 3.065 4.133.547 1.13.546 2.983 1.28 3.92-1.797-2.419-4.076-4.373-6.324-6.464-1.564-1.455-4.688-5.181-7.442-5.14m-.778 10.377c-.192-.065-1.934-.558-2.337-.32.597-.267 1.33-.592 1.987-.679 4.284-.569 9.492 3.141 10.067 6.721-.478-1.226-3.025-2.24-4.176-2.85-1.823-.967-3.564-2.137-5.541-2.872m1.809 7.811c.742.182 2.32 1.176 3.047 1.165-2.929.07-5.572-.255-8.391-.914.152.041 1.759-.456 1.811-.463 1.215-.172 2.357-.076 3.533.212m-11.345 13.857c4.288-.242 9.336.384 13.431 1.417a22.3 22.3 0 0 1 5.692 2.295c1.414.814 3.93 1.932 4.876 3.137-3.74-6.452-11.85-9.803-20.16-8.14-1.107.222-2.808 1.276-3.84 1.291Zm-.96 12.433c2.688-.965 5.661-1.894 8.583-2.029 2.771-.127 5.845.29 8.41 1.173-.883-.24-2.993.332-3.92.437-1.297.147-2.596.299-3.896.418a52 52 0 0 1-4.801.222c-1.14-.002-3.32-.54-4.376-.221M179.46 227.41c.253 3.972 2.552 7.434 5.931 10.08 3.583 2.805 8.379 4.082 10.98 7.829 1.267 1.825 1.943 3.95 1.834 6.098-.056 1.106-.334 2.218-.635 3.294-.197.708-.902 1.868-.901 2.559.031-3.887.084-8.412-2.636-11.673-2.731-3.274-7.493-4.427-10.829-7.115-3.278-2.642-5.765-6.094-6.325-9.985-.452-3.144-.23-8.626 3.03-10.76-.662.39-.53 2.374-.547 2.931a74 74 0 0 0 .098 6.742m-2.453 15.262c.396.52 2.57 1.151 3.208 1.51 1.456.817 2.865 1.746 4.02 2.877 2.317 2.266 3.81 5.445 3.918 8.494 0-.72-1.646-2.457-2.109-3.073-.768-1.022-1.635-1.969-2.518-2.917-2.154-2.31-4.39-4.564-6.52-6.891Zm52.162-88.882c1.204 1.05 2.01 2.357 2.675 3.709 1.53 3.12 1.815 6.717.589 10 .203-.704-.401-2.184-.571-2.898-.373-1.563-.955-3.04-1.563-4.542-1.18-2.916-2.134-5.648-4.184-8.202.53.668 2.328 1.3 3.054 1.933M171.51 41.983c0 .332.917 1.293 1.123 1.654.517.902.924 1.849 1.064 2.855.158 1.142-.035 2.259-.381 3.369-.206.66-1.184 1.934-1.184 2.528-.16-3.498-.933-6.86-.622-10.406m7.637 6.822c.165 1.243-.24 2.644-.964 3.742.132-.31-.454-2.383-.473-2.762-.059-1.173.07-2.38.146-3.552.001.64 1.183 1.763 1.291 2.572m-60.77 1.568a35 35 0 0 1-4.15 4.243c-1.023.89-2.984 1.89-3.764 2.91 3.501-5.711 7.546-10.638 12.302-15.63-.716.92-.903 2.916-1.428 3.993-.774 1.587-1.81 3.076-2.96 4.484m5.898 2.479c.57-.336 1.104-1.993 1.538-2.55a17 17 0 0 1 2.578-2.63c-.205.22-.602 2.044-.825 2.402-.723 1.16-2 2.107-3.29 2.778Z" opacity=".6"></path></g></g></g>', 1)];
const Fa = {
        render: function(a, e) {
            return r(), t("svg", null, [...ya])
        }
    },
    La = [e('<g id="Top"><defs><path id="ShortHairDreads01-path1" d="M0 0h264v280H0z"></path><path id="ShortHairDreads01-path2" d="M65.18 77.737c2.183-1.632 15.227-2.258 17.578-3.648.734-.434 1.303-.873 1.742-1.309.439.436 1.009.875 1.742 1.31 2.351 1.389 15.395 2.015 17.578 3.647 2.21 1.654 3.824 5.448 3.647 8.414-.212 3.56-4.106 12.052-13.795 13.03-2.114-2.353-5.435-3.87-9.172-3.87s-7.058 1.517-9.172 3.87c-9.69-.978-13.583-9.47-13.795-13.03-.176-2.966 1.437-6.76 3.647-8.414m.665 17.164.017.007zm79.018-38.916c-.389-5.955-1.585-11.833-2.629-17.699-.281-1.579-1.81-12.286-2.5-12.286-.232 9.11-1.032 18.08-2.064 27.14-.309 2.708-.632 5.416-.845 8.134-.171 2.196.135 4.848-.397 6.972-.679 2.706-4.08 5.232-6.725 6.165-6.6 2.326-12.105-7.303-17.742-10.12-7.318-3.656-19.897-4.527-27.38.239-7.645-4.766-20.224-3.895-27.542-.239-5.637 2.817-11.142 12.446-17.742 10.12-2.645-.933-6.047-3.459-6.725-6.165-.532-2.124-.226-4.776-.397-6.972-.213-2.718-.536-5.426-.845-8.135C30.298 44.08 29.497 35.11 29.265 26c-.689 0-2.218 10.707-2.5 12.286-1.043 5.866-2.24 11.744-2.627 17.7-.4 6.119.077 12.181 1.332 18.177a165 165 0 0 0 2.049 8.541c.834 3.143-.32 9.262.053 12.488.707 6.104 3.582 18.008 6.811 23.259 1.561 2.538 3.39 4.123 5.433 6.168 1.967 1.97 2.788 5.021 4.91 7.118 3.956 3.908 9.72 6.234 15.64 6.806C65.677 143.05 74.506 146 84.5 146s18.823-2.95 24.135-7.457c5.919-.572 11.683-2.898 15.64-6.806 2.121-2.097 2.942-5.149 4.909-7.118 2.042-2.045 3.872-3.63 5.433-6.168 3.229-5.251 6.104-17.155 6.81-23.259.374-3.226-.78-9.345.054-12.488.75-2.828 1.45-5.676 2.05-8.54 1.254-5.997 1.73-12.06 1.332-18.179"></path><path id="ShortHairDreads01-path3" d="M185.832 73.929c1.757.988 3.148 10.899 3.216 14.689.042 2.338.08 11.256-2.394 10.485-.753-.235-1.902-4.956-2.066-7.719s-1.733-12.164-4.141-16.49c-.55-.988-2.126-2.723-1.445-3.56.844-1.036 1.664-.434 2.695-.02 1.115.45 3.937 2.504 4.135 2.615m.805-2.972c-.746.962-5.841-1.74-7.966-2.913-17.845-9.86-21.31-12.995-49.425-12.586-28.116.409-47.379 13.582-48.462 14.93-.754.937-1.716 3.44-2.508 10.413-.791 6.972.22 19.477-2.646 19.462-2.438-.013-2.97-23.786-1.916-33.217.161-1.448.784-4.038.333-5.34-.394-1.138-2.322-1.135-2.014-3.03.35-2.159 2.525-1.087 3.473-2.119 1.795-1.954-.974-2.417-1.433-4.126-.682-2.542 1.29-3.197 3.067-4 1.966-.887 1.71-.108 3.306-1.846-2.131-1.563-2.902-3.691.016-4.833 1.24-.485 4.465.157 5.436-.572.253-.19.353-1.28.51-1.502 1.55-2.219 1.168-3.825 1.01-6.316-.129-2.038-.112-3.909 2.329-4.112 1.628-.136 2.952 1.194 4.411 1.586 1.619.435 1.01.752 2.279-.121 2.226-1.533.711-4.52 2.476-6.303 2.423-2.446 4.01 1.14 5.956 1.41 4.222.588 2.867-3.7 5.367-5.272 2.988-1.876 3.277 2.251 5.143 2.398 1.617.127 4.529-2.993 5.938-3.575 4.183-1.726 6.255 3.13 10.237 2.511 2.89-.45 3.67-.816 6.277.828 2.53 1.595 3.132.454 5.998.432 2.025-.016 3.265 1.676 4.959 1.853.844.088 1.653-.792 2.56-.737 3.237.197 3.442 4.383 6.014 5.536 2.35 1.053 5.112-.427 7.445-.7 5.69-.668 1.793 4.647 1.954 7.819 2.233.52 4.5-1.564 6.724-1.18 3.502.604 2.18 4.233 1.368 6.68 2.427-.044 8.76-2.737 10.332.707.81 1.776-1.078 4.147-1.047 5.952.043 2.542 1.91 4.645 2.571 7.05.892 3.247 2.163 11.95-.072 14.833"></path></defs><mask id="ShortHairDreads01-mask2" fill="#fff"><use href="#ShortHairDreads01-path1"></use></mask><g id="Top/Short-Hair/Dreads-01" mask="url(&#39;#ShortHairDreads01-mask2&#39;)"><g transform="translate(-1)"><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairDreads01-path3" transform="translate(1)"></use></g></g></g>', 1)];
const wa = {
        render: function(a, e) {
            return r(), t("svg", null, [...La])
        }
    },
    xa = [e('<g id="Top"><defs><path id="Turban-path1" d="M0 0h264v280H0z"></path><path id="Turban-path2" d="M156 180.611c17.53-8.328 30.048-25.496 31.791-45.744C193.57 134.002 198 129.02 198 123v-13c0-5.946-4.325-10.882-10-11.834V92c0-30.928-25.072-56-56-56S76 61.072 76 92v6.166c-5.675.952-10 5.888-10 11.834v13c0 6.019 4.43 11.002 10.209 11.867 1.743 20.248 14.26 37.416 31.791 45.744V199h-4c-39.765 0-72 32.235-72 72v9h200v-9c0-39.765-32.235-72-72-72h-4zM0 0h264v280H0z"></path><path id="Turban-path3" d="M83.972 55.817C107.404 69.414 145.115 82.111 139 138q29.066-8.46 29-46.676C167.918 44.148 115.85 0 86 0q-1.012 0-2.008.088A23 23 0 0 0 82 0C52.074 0 .08 44.148 0 91.324Q-.067 130.498 29 138c-6.138-55.889 31.51-68.586 54.972-82.183"></path></defs><mask id="Turban-mask1" fill="#fff"><use href="#Turban-path1"></use></mask><g id="Top/Accesories/Turban" mask="url(&#39;#Turban-mask1&#39;)"><g id="Turban"><path id="Band" fill="#EDECE3" d="M74.53 97.5c-1-2.41-1.53-4.92-1.53-7.5 0-18.225 26.415-33 59-33s59 14.775 59 33c0 2.58-.53 5.09-1.53 7.5C183.398 82.888 159.972 72 132 72S80.602 82.888 74.53 97.5"></path><use fill="var(--avataaar-top-color)" class="CustomColor" href="#Turban-path3" transform="translate(48 3)"></use><path id="Shadow" fill="#000" d="M48.011 96.012q.555 37.65 28.99 44.988-29.068-7.066-29-43.97 0-.51.01-1.018m104.635-65.544c.744 5.727-.52 12.421-4.646 19.668-11.153 21.43-71.439 21.868-71.666 79.544-.229-61.919 60.471-62.3 71.666-85.136 2.67-4.977 4.141-9.709 4.646-14.076" opacity=".16"></path></g></g></g>', 1)];
const Ba = {
        render: function(a, e) {
            return r(), t("svg", null, [...xa])
        }
    },
    za = [e('<g id="Top"><defs><path id="LongHairDreads-path1" d="M0 0h264v280H0z"></path><path id="LongHairDreads-path2" d="M85.718 185.073A73 73 0 0 1 89 185h4v-18.389a56.22 56.22 0 0 1-26.789-26.99c-2.764-8.607-2.6-17.934-3.21-26.795-.805-11.68-.112-23.078 2.536-34.578 2.39-10.376 5.824-15.941 13.626-24.255 4.36-4.646 10.905-4.915 17.42-6.564 6.593-1.67 12.611-4.21 16.735-8.99 9.083 10.41 33.354 6.664 42.236 18.01 10.802 13.798 10.923 22.7 12.193 38.643.953 11.951-.528 33.564-.943 46.538A56.24 56.24 0 0 1 141 166.611V185h4c6.636 0 13.062.898 19.163 2.578-2.05 3.174-4.494 6.18-7.051 8.973-3.831 4.188-7.681 8.52-12 12.367-4.941 4.401-9.668 7.597-12.668 13.082-1.358 2.483-3.737 5.094-1.22 7.817 2.3 2.487 5.925 1.975 8.386.175 3.637-2.66 6.338-6.858 9.69-9.915-3.238 5.815-7.742 14.484-5.43 21.005.787 2.217 1.586 2.173 2.802 3.65q2.88.066 2.276 2.606l.54 1.451c1.456 2.594 4.243 4.41 7.78 3.188 11.56-3.994-1.775-21.961 10.953-27.302 2.278 2.83-1.086 10.779-1.177 14.256-.111 4.287.122 14.013 6.642 15.179 8.496 1.52 5.22-6.597 5.555-10.05.39-4.016 2.86-9.312 4.87-12.869-1.222 3.78-3.508 12.154 2.817 13.87 7.317 1.986 6.481-6.586 7.592-10.15.229 5.275 7.045 17.749 13.205 7.896 3.173-5.076 1.009-13.441.66-18.854 4.414 4.56 7.94-1.35 7.84-4.63 1.677 4.752 7.982 18.002 13.57 7.485 3.398-6.395-.226-14.985-2.483-21.16 5.944.52 4.75-5.236 3.864-8.095-1.307-4.222-.61-4.841-.34-9.206 8.25 4.805 7.997-8.234 7.542-11.432-1.146-8.051-7.409-15.261-12.243-22.052-3.466-4.871-9.935-13.352-8.038-19.226 1.957 2.468 6.507 2.442 8.316-.142 1.532-2.188-.091-5.796-.83-7.982-2.021-5.98-6.06-9.844-9.711-14.981-7.108-10.001-6.086-23.133-6.743-34.313-.82-13.949-3.814-27.68-16.48-37.827-6.787-5.437-15.058-9.914-21.37-15.682-1.722-1.573-2.45-3.521-4.066-5.038-1.813-1.701-2.66-1.298-4.158-3.72-2.668-4.315-5.802-8.355-12.25-8.558-4.22-.132-9.556 3.43-13.359 2.909-3.122-.427-5.094-4.879-7.656-6.373-3.966-2.312-6.734-1.414-10.972-.075-6.31 1.994-10.33 2.689-16.755.306C97.69 2.539 93.565-.846 88.402.357c-4.05.945-5.858 4.213-8.244 6.718-2.46 2.586-1.271 1.73-4.87 2.305-3.68.588-6.586 1.122-9.378 3.532-4.512 3.895-1.386 9.955-4.953 13.389-1.925 1.854-5.935 2.737-8.165 4.654-2.434 2.092-4.424 4.635-6.248 7.11-3.551 4.823-5.976 10.079-8.58 15.281-4.843 9.681-9.161 19.671-11.002 30.072-.945 5.347-2.538 10.577-3.512 15.912-.75 4.115-.43 8.622-1.896 12.617-1.74 4.74-5.899 9.096-8.152 13.757-2.988 6.183-4.994 12.115-5.63 18.771-.624 6.544 1.113 12.311 1.879 18.727.443 3.717-.324 4.139-2.88 7.647-1.967 2.7-3.96 5.373-5.225 8.378-2.361 5.615-2.23 11.077 1.879 16.013 2.82 3.388 12.299 6.933 11.523-.618-.36-3.508-4.772-5.095-3.93-9.12.584-2.787 3.425-4.715 6.874-5.577 2.436-.608 3.636-.582 4.735 2.09.996 2.42-.325 7.706-.63 10.25-.123 1.023-.305 1.92-.428 2.867-.868 6.674-1.028 12.815-4.682 18.944-2.244 3.766-6.636 9.073-1.628 12.703 3.959 2.87 10.79 1.121 13.877-1.882 3.256 4.027 2.532 8.423 1.314 12.869-.756 2.76-2.824 6.802.431 9.033 4.408 3.021 11.603-1.738 14.908-4.14 1.91 4.268 3.703 19.827 11.235 10.552 2.198-2.705 5.858-5.344 6.555-8.534 1.156-5.29.326-10.858.804-16.202 2.404 6.997 4.038 9.787 5.51 16.97.884 4.321 1.231 18.82 10.174 16.91 6.88-1.47 2.48-10.524 1.601-14.215-1.683-7.07-2.496-10.063-4.122-17.14 2.533 4.626 4.746 9.371 7.18 14.034 2.39 4.58 13.078 14.027 16.205 10.05 3.127-3.978-4.496-9.645-6.23-14.46-3.609-10.024-7.98-20.006-9.017-30.508-.499-5.049.436-9.712.846-14.703.28-3.41-.141-6.902-.812-10.34"></path></defs><mask id="LongHairDreads-mask2" fill="#fff"><use href="#LongHairDreads-path1"></use></mask><g id="Top/Long-Hair/Dreads" mask="url(&#39;#LongHairDreads-mask2&#39;)"><g transform="translate(-1)"><g id="Hair" transform="translate(16 14)"><mask id="LongHairDreads-mask1" fill="#fff"><use href="#LongHairDreads-path2"></use></mask><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairDreads-path2"></use><path id="Shadows" fill="#000" d="M85.718 185.073A73 73 0 0 1 89 185h4v-18.389a56.22 56.22 0 0 1-26.789-26.99 37 37 0 0 0 1.95 4.888c5.756 11.833 13.257 22.412 16.327 35.08.435 1.798.869 3.633 1.23 5.484m78.445 2.505A72 72 0 0 0 145 185h-4v-18.389a56.24 56.24 0 0 0 25.502-24.404c-.077 2.994-.01 5.972.373 8.849 1.07 8.044 4.001 15.31 2.64 23.58-.744 4.532-2.725 8.875-5.352 12.942" mask="url(&#39;#LongHairDreads-mask1&#39;)" opacity=".24"></path><path id="Highlights" fill="#FFF" d="M49.36 108.248c-.124-2.422-1.98-10.537.329-11.939 2.53-1.537 2.002 7.707 2.028 8.654.044 1.537 1.211 13.135-.927 13.084-2.132-.051-1.347-8.219-1.43-9.799m8.435 57.75c-.009 1.014-1.072.953-1.832.688-.937-.328-.363-2.484-.413-3.191-.13-1.86-1.023-7.338.34-8.873 2.726-3.069 1.916 9.948 1.905 11.376m-25.674 13.163c1.93-.054.144-37.832-2.821-37.79-2.083.03 1.361 37.827 2.821 37.79m2.232 19.355c-2.397 0-1.957 8.462-.545 9.139 2.14 1.025 3.227-9.139.545-9.139m15.237 3.539c.021 1.058-1.179 1.074-1.98.744-.908-.376-.528-3.506-.563-4.2-.114-2.188-2.017-10.672-.286-12.231 1.974-1.778 2.017.173 2.548 1.498 1.564 3.903.197 10.032.28 14.189Zm140.652-79.722c.11 1.463 1.069 11.018-.524 11.746-2.742 1.254-1.561-4.65-1.55-5.413.107-7.437-.969-14.812-1.787-22.21-.155-1.404-2.625-12.224-.816-13.12 2.707-1.342 2.303 2.245 2.458 3.41 1.129 8.468 1.628 17.078 2.22 25.587Zm-3.219 33.254c-2.532-.502-3.858 8.094-2.702 9.016 1.917 1.53 5.35-8.49 2.702-9.016m-.268 37.798c-1.139-.226-9.433 15.733-8.75 16.635 1.299 1.719 12.829-15.82 8.75-16.635m-20.422 7.374c-1.782-.803-9.334 10.75-7.406 11.619 1.748.786 9.561-10.652 7.406-11.62Zm42.092-43.312c-2.15 0-2.055 11.822-.4 12.568 1.711.77 2.942-12.568.4-12.568M178.14 48.844c-.609-.87-7.175-8.62-2.472-7.513 2.291.539 5.448 7.352 6.481 9.41.594 1.183 3.985 6.46.392 6.086-.977-.101-3.59-6.82-4.401-7.983m-23.092-15.488q-1.27.572.042 1.072 1.27-.57-.042-1.072m-84.43 8.13c-2.004 1.844-9.542 12.519-12.125 12.626-4.707.195 4.278-9.025 5.297-10.198.455-.527 2.486-3.092 3.722-3.723 1.261-.643 5.444-.859 3.107 1.295ZM43.255 69.981c-2.183-.43-5.835 10.264-4.56 11.555 1.923 1.95 7.007-11.07 4.56-11.555m24.939 119.011c.412 1.341 4.631 11.08 3.571 12.361-1.621 1.958-2.087-.817-2.617-1.967-1.178-2.555-4.238-8.846-3.746-11.536.477-2.608 2.375-.201 2.792 1.142m-8.207 22.824c-2.295 0-2.03 9.802-.663 10.385 2.116.902 3.478-10.385.663-10.385m161.805-8.37c.137.604 2.054 5.563-.663 4.845-1.562-.413-1.802-4.785-2.201-6.11-1.23-4.086-5.28-9.163-5.632-13.194-.34-3.897 1.84-2.412 3.515.889 2.236 4.407 3.913 8.87 4.981 13.57m-19.702-.495c-2.132-.01-2.235 10.773-.902 11.402 1.864.878 3.621-11.402.902-11.402m6.16-88.297c1.582-.412-3.41-13.325-5.177-13.183-2.695.217 2.776 13.803 5.178 13.183Zm-26.815 56.093q-1.27.57.043 1.071 1.27-.57-.043-1.071m-24.218 55.24c.794 0 1.121-1.223-.051-1.25-.775.006-1.184 1.25.051 1.25M58.684 170.63c.03-1.909-2.469-.51-2.453 1.101.032 3.214 2.4 1.746 2.453-1.101m-6.165-47.746c-.804 0-1.134 1.236.05 1.266.785-.006 1.198-1.266-.05-1.266m-19.132 62.51c-.078-1.941-1.7.043-1.61.046.288.007 1.67 1.417 1.61-.046M37.6 84.063c-2.368 0-2.025 5.754-.514 6.123 2.52.616 2.865-6.123.514-6.123m12.613 124.263c-2.286 0-2.44 7.814-.863 8.3 2.451.754 3.243-8.3.863-8.3m-18.756 5.606q-1.308.587.042 1.103 1.309-.585-.042-1.103m169.999 3.35c-2.32 0-2.23 9.554-.805 10.2 1.99.902 3.488-10.2.805-10.2m-23.51 8.88c-2.411-.482-3.674 7.405-2.55 8.29 1.852 1.459 5.025-7.796 2.55-8.29m-20.48 7.29c-1.998 0-1.508 3.574-.355 4.106 1.994.92 2.583-4.107.354-4.107ZM86.48 19.508c-1.672 0-12.16 4.744-8.24 6.15 2.396.859 12.497-6.15 8.24-6.15" mask="url(&#39;#LongHairDreads-mask1&#39;)" opacity=".3"></path></g></g></g></g>', 1)];
const Ta = {
        render: function(a, e) {
            return r(), t("svg", null, [...za])
        }
    },
    Ea = [e('<g id="Top"><defs><path id="ShortHairDreads02-path1" d="M0 0h264v280H0z"></path><path id="ShortHairDreads02-path2" d="M65.18 77.737c2.183-1.632 15.227-2.258 17.578-3.648.734-.434 1.303-.873 1.742-1.309.439.436 1.009.875 1.742 1.31 2.351 1.389 15.395 2.015 17.578 3.647 2.21 1.654 3.824 5.448 3.647 8.414-.212 3.56-4.106 12.052-13.795 13.03-2.114-2.353-5.435-3.87-9.172-3.87s-7.058 1.517-9.172 3.87c-9.69-.978-13.583-9.47-13.795-13.03-.176-2.966 1.437-6.76 3.647-8.414m.665 17.164.017.007zm79.018-38.916c-.389-5.955-1.585-11.833-2.629-17.699-.281-1.579-1.81-12.286-2.5-12.286-.232 9.11-1.032 18.08-2.064 27.14-.309 2.708-.632 5.416-.845 8.134-.171 2.196.135 4.848-.397 6.972-.679 2.706-4.08 5.232-6.725 6.165-6.6 2.326-12.105-7.303-17.742-10.12-7.318-3.656-19.897-4.527-27.38.239-7.645-4.766-20.224-3.895-27.542-.239-5.637 2.817-11.142 12.446-17.742 10.12-2.645-.933-6.047-3.459-6.725-6.165-.532-2.124-.226-4.776-.397-6.972-.213-2.718-.536-5.426-.845-8.135C30.298 44.08 29.497 35.11 29.265 26c-.689 0-2.218 10.707-2.5 12.286-1.043 5.866-2.24 11.744-2.627 17.7-.4 6.119.077 12.181 1.332 18.177a165 165 0 0 0 2.049 8.541c.834 3.143-.32 9.262.053 12.488.707 6.104 3.582 18.008 6.811 23.259 1.561 2.538 3.39 4.123 5.433 6.168 1.967 1.97 2.788 5.021 4.91 7.118 3.956 3.908 9.72 6.234 15.64 6.806C65.677 143.05 74.506 146 84.5 146s18.823-2.95 24.135-7.457c5.919-.572 11.683-2.898 15.64-6.806 2.121-2.097 2.942-5.149 4.909-7.118 2.042-2.045 3.872-3.63 5.433-6.168 3.229-5.251 6.104-17.155 6.81-23.259.374-3.226-.78-9.345.054-12.488.75-2.828 1.45-5.676 2.05-8.54 1.254-5.997 1.73-12.06 1.332-18.179"></path><path id="ShortHairDreads02-path3" d="M153.503 98.874C157.9 100.654 161 104.965 161 110v13c0 5.288-3.42 9.776-8.168 11.375a55.7 55.7 0 0 1-11.076 29.29c.209.807.41 1.625.556 2.503.55 3.327-.12 6.093 1.645 9.093.457.78 1.183 1.247 1.522 2.144.533 1.415-.232 4.594 1.95 4.595 3.106 0 1.374-5.966.596-7.384-1.525-2.772-2.462-3.45-2.383-7.044 1.745 1.16 7.53 3.376 9.448 2.316 4.432-2.448-6.662-4.936-7.438-5.453 1.704-1.666 3.656-2.55 5.197-4.746 1.26-1.793 2.406-4.397 4.55-4.501 1.186-.058 4.657 2.884 5.71.866.964-1.85-1.115-2.122-1.928-2.777-1.502-1.21-1.84-.006-1.474-2.134 1.085 1.165 2.789.429 3.244-1.015.49-1.559-1.127-2.024-1.097-3.014-.012.387.834-5.115.7-4.938.86-1.135 3.908-.784 5.413-.62 2.296.248 2.164.317 3.255 2.436.882 1.715 3.198 5.178 3.707.641.121-1.085-.869-3.404-1.45-4.338-.627-1.007-2.517-1.643-2.912-2.427-.944-1.87 2.165-6.034 1.639-8.854 1.093.418 3.857 6.927 5.198 1.599.707-2.8-6.505-8.945-3.514-9.894 2.289-.726 4.612 2.225 5.25 4.044.473 1.348.26 4.238 1.068 5.353 3.036 4.203 3.41-2.74 3.157-4.572-.559-4.026-1.984-6.988-5.623-8.51 1.295-1.607-.345-2.887-1.275-3.893 1.528-1.657 11.437.104 9.208-4.327-.538-1.072-2.481-1.262-3.467-1.655-2.49-.992-4.985-3.01-6.257-5.562 1.841-.46 7.28.798 6.565-2.996-.563-2.982-5.403-2.067-7.278-1.61 1.692-1.016 4.973-.174 5.434-2.941.531-3.183-3.288-3.076-5.08-2.402-.422-3.358 5.53-5.83 7.213-8.4.568-.867 1.47-1.164.746-2.633-1.306-2.643-4.68 1.086-5.792 2.09.876-1.628 3.32-8.403 2.95-10.122-.546-2.526-2.353-2.615-3.79-.568-.93 1.33-1.19 4.703-1.68 6.427-2.04-1.537-2.143.246-2.248-2.191-.068-1.58 2.002-4.701 2.532-6.248.456-1.329 1.668-3.76.943-5.046-1.776-3.143-3.473 1.172-3.94 2.652-.789-3.411 2.214-6.057 3.103-9.431.541-2.048 1.976-7.578-.51-8.561-3.394-1.341-2.2 4.956-2.678 7-.365 1.559-.922 4.077-2.139 4.845-.176.111-2.82.343-2.948.193-1.734-2.021 3.038-6.447 3.284-8.351.223-1.73-.44-2.825-2.061-2.929-.81-.051-2.12 1.2-2.495 1.119-1.48-.322.447-7.089.587-8.967.15-2.003-.094-7.172-3.483-4.785.227-2.697.364-5.236.734-7.891.195-1.4 1.398-2.645-.374-3.767-2.156-1.365-3.35 1.492-3.842 3.168-.846 2.885.9 7.375-3.158 7.466-4.665.106-1.444-4.73-1.215-7.868.128-1.74-1.012-6.421-3.262-3.263-.896 1.259-.587 5.694-1.084 7.183-1.106-.493.733-4.515-.23-5.564-2.06-2.247-3.788 1.026-5.099 1.692-.086-1.445-.187-2.891-.248-4.338-.093-2.2 1.255-6.83-.113-8.347-2.337-2.59-3.823.431-4.506 2.523-.613 1.884-.697 3.744-3.233 4 .208-2.717-2.258-8.436-1.035-10.727.553-1.035 1.679-.301 2.179-1.46.821-1.902-.524-2.71-1.986-2.771-6.792-.286-1.562 9.134-3.969 11.491-1.099-1.04.072-2.113-1.065-3.596-1.223-1.595-3.173-1.46-4.918-.738-.056-1.613 2.364-12.92-3.08-7.817-1.352 1.271-.974 3.393-1.693 4.886-.696 1.445-2.39 3.598-3.341 4.771-.51-2.067.272-4.63.82-6.666.38-1.415 2.931-5.805 2.387-7.244-1.58-4.167-6.323 2.72-7.572 3.832-1.582 1.41-7.88 6.045-9.901 4.64-.701-.487-.07-2.29-1.027-3.128-.47-.41-2.477-.6-3.05-.548.358-1.494-.346-3.427-2.055-2.91-2.149.65-1.219 3.838-2.58 5.002-2.53 2.164-5.535-2.112-8.245-1.992.414-1.755 3.485-8.062-1.399-6.144-1.246.49-2.13 3.351-2.44 4.54-.792 3.036-.222 3.593-3.509 4.45.257-1.76-.2-3.948.649-5.521.696-1.289 4.305-4.645.462-5.063-4.74-.516-4.274 7.672-4.855 10.44-4.206-2.549-6.974 1.098-9.48 4.252.447-1.419 1.553-15.557-2.965-11.237-1.292 1.237.138 3.066.05 4.478-.078 1.28-.5 2.422-.995 3.618-.796 1.921-1.72 3.887-2.974 5.524-1.573 2.059-1.015 2.22-2.82.823-2.425-1.873-3.577-6.624-3.457-9.525.09-2.16 1.196-6.548-2.384-5.531-3.507.996-1.649 7.974-1.296 10.453.381 2.687.635 5.436.183 8.173-2.984-3.05-3.42 3.302-4.017 4.385-.98 1.777-2.868 2.647-4.335 3.86-.8-2.794 2.405-5.157 1.77-7.38-1.194-4.165-4.571 1.716-5.313 2.87-.619.963-2.635 6.442-3.365 6.933-1.023.69-7.605-2.527-8.27-3.14-1.223-1.125-.778-4.272-2.316-4.99-4.72-2.197-1.932 5.735-1.005 7.375 2.419 4.284 3.516 9.456 2.949 14.504-.858-.302-1.915-1.312-2.468-2.077-1.076-1.49-.685-3.865-1.808-4.987-3.288-3.28-3.673 2.878-3.406 4.791.5 3.588 2.291 4.75 3.778 7.734 1.368 2.75-.445 6.069-.828 9.125-3.429-3.3-18.195-.543-14.396 4.502 1.978 2.633 4.318-2.377 6.598-2.25 4.083.225 6.235 5.295 5.967 8.846-.497-1.898-2.422-3.761-3.746-1.444-.897 1.573.635 4.26 1.374 5.823-.906-.444-5.372-2.52-6.246-2.161-3.44 1.414 1.3 4.151 2.537 4.698 4.224 1.868 6.887 3.92 8.2 8.992-2.367-.757-1.955-1.878-3.552-3.043-1.466-1.07-1.74-.518-3.09-.868-2.362-.611-5.441-1.427-8.11-.318-1.97.819-5.287 3.31-5.906 5.65-.757 2.874.844 3.606 2.904 2.143 2.45-1.739 2.897-5.105 6.583-4.96 1.769.068 3.52.995 4.64 2.325.835.993 1.323 2.43 2.12 3.495.703.94 2.564 2.259 2.957 3.254 1.418 3.595-1.276 6.795-3.083 9.314-.419-.554-3.477-1.758-4.11-1.878-2.94-.561-4.037.798-2.199 3.512.58.856 1.798 1.216 2.436 1.994.711.87 1.112 2.2 1.818 3.144 1.393 1.863 3.115 2.822 4.778 4.322-.613.41-.546-.624-1.102-.41-.404.156-1.107-.155-1.617.014-.828.275-.718 1.717-1.248 1.929-3.299 1.314-6.627-3.615-9.586-3.775-1.614-.088-2.975.994-2.2 3.022.538 1.412 2.87 2.178 4.036 2.767 3.246 1.644 6.478 2.868 9.948 1.607 2.797 2.438 6.159 3.64 9.674 3.675-2.011.998-4 2.235-4.702 4.721-1.189-1.23-4.108-6.952-5.633-2.462-1.045 3.087 3.723 6.871 5.92 8.262-2.555.755-4.677.907-7.277.607-1.357-.156-4.337-1.974-3.238 1.748 1.182 4.016 8.24 2.21 10.48 1.516.083-1.198-10.77 12.108-3.158 9.489 2.176-.748 2.385-5 5.418-5.373 3.503-.43 3.855 3.077 5.882 5.646 1.01 1.282 5.67 4.165 5.449 5.265-.191.952-2.75 1.496-3.293 2.828-.633 1.55-.347 2.746.532 4.078 1.538 2.333 4.36 2.691 6.592 3.604 3.164 1.295 4.31 2.867 5.73 6.217-2.502.12-9.62 7.36-5.258 8.648 1.625.48 1.372-.966 2.049-1.765l.821-1.545q.687-1.797 1.52-.22c.123-.031 1.61.388 1.947.409 1.708.105 2.85-1.192 4.266-1.893 1.023-.506 2.024-.418 2.795-1.586-.089.135.554-2.51.565-2.536.276-.637.985-.547 1.31-1.234-8.749-9.085-14.457-21.119-15.489-34.464C36.42 132.776 33 128.288 33 123v-13c0-5.035 3.1-9.345 7.497-11.126.531.374 1.27 0 1.503-.842-.463-1.506 3.296-27.854 13-34.876 3.618-2.438 23.008-2.619 42.313-2.606 19.096.014 38.108.195 41.687 2.606 9.704 7.022 13.463 33.37 13 34.876.233.843.972 1.216 1.503.842"></path></defs><mask id="ShortHairDreads02-mask2" fill="#fff"><use href="#ShortHairDreads02-path1"></use></mask><g id="Top/Short-Hair/Dreads-02" mask="url(&#39;#ShortHairDreads02-mask2&#39;)"><g transform="translate(-1)"><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairDreads02-path3" transform="translate(36)"></use></g></g></g>', 1)];
const Oa = {
        render: function(a, e) {
            return r(), t("svg", null, [...Ea])
        }
    },
    Aa = [e('<g id="Top"><defs><path id="WinterHat1-path3" d="M0 0h264v280H0z"></path><path id="WinterHat1-path1" d="M120 54H20v101c0 5.523-4.477 10-10 10s-10-4.477-10-10V44C0 19.7 19.7 0 44 0h52c24.3 0 44 19.7 44 44v111c0 5.523-4.477 10-10 10s-10-4.477-10-10z"></path><rect id="WinterHat1-path2" width="118" height="36" x="74" y="50" rx="8"></rect></defs><g id="Top/Accessories/Winter-Hat-1" transform="translate(-1)"><g id="hat" transform="translate(63 20)"><path id="inside" fill="#F4F4F4" d="M1 48h22.671v105.664c0 6.26-5.075 11.336-11.335 11.336S1 159.925 1 153.664zm115.329 0H139v105.664c0 6.26-5.075 11.336-11.336 11.336-6.26 0-11.335-5.075-11.335-11.336z"></path><use fill="var(--avataaar-top-color)" class="CustomColor" href="#WinterHat1-path1"></use></g><g id="hat-front"><use filter="url(&#39;#WinterHat1-path2&#39;)" href="#WinterHat1-path2"></use><use fill="#F4F4F4" href="#WinterHat1-path2"></use></g></g></g>', 1)];
const Na = {
        render: function(a, e) {
            return r(), t("svg", null, [...Aa])
        }
    },
    Va = [e('<g id="Top"><defs><filter id="filter5" width="107.7%" height="126.7%" x="-3.8%" y="-6.7%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter><filter id="filter6" width="113.3%" height="113.8%" x="-6.7%" y="-3.4%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter><filter id="filter7" width="113.3%" height="113.8%" x="-6.7%" y="-3.4%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter><filter id="filter1" width="107.7%" height="115.4%" x="-3.8%" y="-3.8%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter><filter id="filter2" width="105%" height="110%" x="-2.5%" y="-2.5%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter><filter id="filter3" width="105.4%" height="110.8%" x="-2.7%" y="-2.7%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter><filter id="filter4" width="103.6%" height="107.4%" x="-1.8%" y="-1.9%" filterUnits="objectBoundingBox"><feOffset dy="2" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset><feColorMatrix in="shadowOffsetOuter1" result="shadowMatrixOuter1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"></feColorMatrix><feMerge><feMergeNode in="shadowMatrixOuter1"></feMergeNode><feMergeNode in="SourceGraphic"></feMergeNode></feMerge></filter><path id="LongHairFrida-path2" d="M0 0h264v280H0z"></path><path id="LongHairFrida-path1" d="M65.18 77.737c2.183-1.632 15.227-2.258 17.578-3.648.734-.434 1.303-.873 1.742-1.309.439.436 1.009.875 1.742 1.31 2.351 1.389 15.395 2.015 17.578 3.647 2.21 1.654 3.824 5.448 3.647 8.414-.212 3.56-4.106 12.052-13.795 13.03-2.114-2.353-5.435-3.87-9.172-3.87s-7.058 1.517-9.172 3.87c-9.69-.978-13.583-9.47-13.795-13.03-.176-2.966 1.437-6.76 3.647-8.414m.665 17.164.017.007zm79.018-38.916c-.389-5.955-1.585-11.833-2.629-17.699-.281-1.579-1.81-12.286-2.5-12.286-.232 9.11-1.032 18.08-2.064 27.14-.309 2.708-.632 5.416-.845 8.134-.171 2.196.135 4.848-.397 6.972-.679 2.706-4.08 5.232-6.725 6.165-6.6 2.326-12.105-7.303-17.742-10.12-7.318-3.656-19.897-4.527-27.38.239-7.645-4.766-20.224-3.895-27.542-.239-5.637 2.817-11.142 12.446-17.742 10.12-2.645-.933-6.047-3.459-6.725-6.165-.532-2.124-.226-4.776-.397-6.972-.213-2.718-.536-5.426-.845-8.135C30.298 44.08 29.497 35.11 29.265 26c-.689 0-2.218 10.707-2.5 12.286-1.043 5.866-2.24 11.744-2.627 17.7-.4 6.119.077 12.181 1.332 18.177a165 165 0 0 0 2.049 8.541c.834 3.143-.32 9.262.053 12.488.707 6.104 3.582 18.008 6.811 23.259 1.561 2.538 3.39 4.123 5.433 6.168 1.967 1.97 2.788 5.021 4.91 7.118 3.956 3.908 9.72 6.234 15.64 6.806C65.677 143.05 74.506 146 84.5 146s18.823-2.95 24.135-7.457c5.919-.572 11.683-2.898 15.64-6.806 2.121-2.097 2.942-5.149 4.909-7.118 2.042-2.045 3.872-3.63 5.433-6.168 3.229-5.251 6.104-17.155 6.81-23.259.374-3.226-.78-9.345.054-12.488.75-2.828 1.45-5.676 2.05-8.54 1.254-5.997 1.73-12.06 1.332-18.179"></path></defs><mask id="LongHairFrida-mask1" fill="#fff"><use href="#LongHairFrida-path2"></use></mask><g id="Top/Long-Hair/Frida" mask="url(&#39;#LongHairFrida-mask1&#39;)"><g transform="translate(-1)"><path fill="var(--avataaar-hair-color)" d="M189 97.937v.229a12.01 12.01 0 0 1 9.893 10.227A16.44 16.44 0 0 0 203 97.5c0-2.13-.404-4.166-1.138-6.035A16.45 16.45 0 0 0 207 79.5c0-5.836-3.03-10.964-7.602-13.898A16.4 16.4 0 0 0 201 58.5c0-7.635-5.185-14.058-12.227-15.941q.226-1.499.227-3.059c0-11.322-9.178-20.5-20.5-20.5-2.63 0-5.143.495-7.453 1.397C157.317 15.306 151.295 12 144.5 12c-4.262 0-8.22 1.3-11.5 3.527A20.4 20.4 0 0 0 121.5 12c-6.795 0-12.817 3.306-16.547 8.397A20.5 20.5 0 0 0 97.5 19C86.178 19 77 28.178 77 39.5q.001 1.56.227 3.059C70.185 44.442 65 50.865 65 58.5c0 2.192.427 4.284 1.203 6.197C60.75 67.39 57 73.007 57 79.5c0 5.438 2.63 10.261 6.689 13.267A16.5 16.5 0 0 0 63 97.5c0 4.175 1.55 7.987 4.107 10.893A12.01 12.01 0 0 1 77 98.166v-.23l.083.064c2.903-47.147 48.47-30.258 55.917-56.664 7.447 26.406 53.014 9.517 55.917 56.664zm-80 82.674v4.2a16.6 16.6 0 0 1-2.5.189c-6.82 0-12.675-4.139-15.188-10.042C82.754 174.348 76 167.213 76 158.5c0-1.471.192-2.897.554-4.254C69.858 152.144 65 145.889 65 138.5c0-3.744 1.247-7.198 3.35-9.967a12.01 12.01 0 0 0 8.859 6.334c1.743 20.248 14.26 37.416 31.791 45.744m48 0v4.2q1.224.188 2.5.189c6.82 0 12.675-4.139 15.188-10.042 8.558-.61 15.312-7.745 15.312-16.458 0-1.471-.192-2.897-.554-4.254C196.142 152.144 201 145.889 201 138.5c0-3.744-1.247-7.198-3.35-9.967a12.01 12.01 0 0 1-8.859 6.334c-1.743 20.248-14.26 37.416-31.791 45.744" class="CustomColor"></path><g id="Ornamentos" transform="translate(67)"><g id="hoja" filter="url(&#39;#filter5&#39;)" opacity=".9" transform="scale(1 -1)rotate(-20 -137.666 -331.914)"><path id="leaf" fill="#5DD362" d="M3.611 10S1.95 0 13 0c7.222 0 12.278 5.714 12.278 5.714s-5.417 8.572-13.722 8.572C5.056 14.286 3.61 10 3.61 10Z"></path><path id="leaf" fill="#42BC53" d="M25.278 5.714s-5.417 8.572-13.722 8.572c-4.334 0-6.428-1.929-7.367-3.215-2.095 1.786-2.817 3.429-2.817 3.5-.072.286-.36.429-.65.429-.072 0-.216 0-.289-.071-.36-.143-.505-.572-.36-.929.071-.214 1.877-4.143 7.366-6.714 7.944-4.143 17.839-1.572 17.839-1.572"></path></g><g id="hoja" filter="url(&#39;#filter6&#39;)" transform="rotate(60 44.13 92.434)"><path id="leaf" fill="#5DD362" d="M15 12C15 5.9 9 0 9 0S1.7 4.3 1 13s5.8 10.7 5.8 10.7S15 20.8 15 12"></path><path id="leaf" fill="#42BC53" d="M8 29c.1 0 .2 0 .3-.1.5-.2.8-.8.6-1.3-.5-1.5-.9-2.9-1.1-4.4C10 22.2 15 18.9 15 12 15 5.9 9 0 9 0s-.4 1.1-1 3c-.2.5-5.2 13.6-.9 25.3.1.4.5.7.9.7"></path></g><g id="hoja" filter="url(&#39;#filter7&#39;)" transform="rotate(-120 31.465 30.827)"><path id="leaf" fill="#5DD362" d="M15 12C15 5.9 9 0 9 0S1.7 4.3 1 13s5.8 10.7 5.8 10.7S15 20.8 15 12"></path><path id="leaf" fill="#42BC53" d="M8 29c.1 0 .2 0 .3-.1.5-.2.8-.8.6-1.3-.5-1.5-.9-2.9-1.1-4.4C10 22.2 15 18.9 15 12 15 5.9 9 0 9 0s-.4 1.1-1 3c-.2.5-5.2 13.6-.9 25.3.1.4.5.7.9.7"></path></g><g id="Flor" filter="url(&#39;#filter1&#39;)" transform="matrix(-1 0 0 1 26 29)"><path fill="#4ACAD3" d="M24.424 20.956a5.17 5.17 0 0 0 .997-3.853 5.17 5.17 0 0 0-2.02-3.43c-.299-.225-.693-.41-1.141-.567.453-.141.854-.313 1.16-.527a5.206 5.206 0 0 0 1.277-7.243 5.206 5.206 0 0 0-7.242-1.277c-.306.215-.604.533-.893.911.006-.475-.033-.909-.143-1.267a5.16 5.16 0 0 0-2.532-3.07A5.17 5.17 0 0 0 9.926.25a5.207 5.207 0 0 0-3.453 6.493c.11.356.314.735.582 1.124-.448-.151-.869-.243-1.241-.25a5.206 5.206 0 0 0-5.29 5.11 5.18 5.18 0 0 0 .937 3.066 5.2 5.2 0 0 0 4.171 2.223c.373.006.796-.071 1.25-.206-.283.38-.5.75-.621 1.103a5.2 5.2 0 0 0 .662 4.68 5.17 5.17 0 0 0 2.561 1.93 5.206 5.206 0 0 0 6.61-3.225c.12-.352.178-.779.19-1.252.273.386.56.708.857.932a5.17 5.17 0 0 0 3.853.997 5.16 5.16 0 0 0 3.43-2.02Z"></path><path fill="#FFF" d="M11.178 8.64a1.444 1.444 0 1 1 2.763-.845c.233.763-.232 4.182-.232 4.182s-2.298-2.574-2.53-3.337Zm-2.242 5.797a1.444 1.444 0 1 1 .05-2.888c.798.014 3.905 1.513 3.905 1.513s-3.158 1.389-3.955 1.375m6.057-2.018s1.738-2.98 2.392-3.438a1.444 1.444 0 1 1 1.657 2.366c-.654.458-4.049 1.072-4.049 1.072m-3.073 6.838a1.444 1.444 0 0 1-.895-1.836c.26-.755 2.646-3.246 2.646-3.246s.345 3.432.086 4.187a1.445 1.445 0 0 1-1.837.895m5.32-1.96c-.638-.48-2.27-3.52-2.27-3.52s3.37.732 4.008 1.212a1.444 1.444 0 1 1-1.738 2.307Z"></path></g><g id="Flor" filter="url(&#39;#filter2&#39;)" transform="translate(20 16)"><path fill="#FDB599" d="m30.526 33.098.258-2.314 2.314-.26c2.847-.319 5.11-2.116 6.054-4.81 1.066-3.042.065-6.359-2.547-8.281l-1.874-1.38.932-2.134c1.229-2.806.645-5.895-1.52-8.061-2.167-2.166-5.256-2.75-8.063-1.522l-2.133.933-1.38-1.875C20.644.786 17.327-.218 14.284.848c-2.692.943-4.49 3.207-4.809 6.054l-.26 2.313-2.313.26c-2.847.319-5.11 2.117-6.054 4.81-.938 2.676-.298 5.56 1.669 7.528a8 8 0 0 0 .877.753l1.875 1.38-.934 2.134c-1.226 2.807-.643 5.896 1.523 8.062s5.255 2.749 8.062 1.523l2.134-.934 1.38 1.875c1.917 2.61 5.24 3.612 8.283 2.547 2.693-.945 4.49-3.208 4.809-6.055"></path><path fill="#FFF" d="M22.882 25.19a1.44 1.44 0 0 1-2.782.746C19.894 25.17 20 20 20 20s-2.492 4.529-3.055 5.091a1.44 1.44 0 0 1-2.036-2.036C15.47 22.492 20 20 20 20s-5.168.106-5.936-.1a1.44 1.44 0 0 1 .745-2.782C15.577 17.324 20 20 20 20s-2.676-4.423-2.882-5.19a1.44 1.44 0 0 1 2.782-.746c.206.768.1 5.936.1 5.936s2.492-4.529 3.055-5.091a1.44 1.44 0 0 1 2.036 2.036C24.53 17.508 20 20 20 20s5.169-.106 5.936.1a1.44 1.44 0 0 1-.745 2.782C24.423 22.676 20 20 20 20s2.675 4.422 2.882 5.19"></path></g><g id="Flor" filter="url(&#39;#filter3&#39;)" transform="translate(89 26)"><path fill="#F7D30C" d="M34.758 29.822a7.36 7.36 0 0 0 1.418-5.483 7.35 7.35 0 0 0-2.874-4.88c-.426-.321-.987-.584-1.625-.808.645-.201 1.216-.445 1.652-.75 3.342-2.34 4.158-6.964 1.817-10.307-2.34-3.342-6.964-4.157-10.306-1.817-.436.306-.86.758-1.27 1.296.008-.676-.048-1.294-.204-1.803A7.35 7.35 0 0 0 19.763.9a7.36 7.36 0 0 0-5.638-.543C10.223 1.55 8.019 5.695 9.21 9.597c.156.507.447 1.046.83 1.6-.638-.216-1.237-.346-1.768-.355-4.08-.071-7.456 3.19-7.528 7.27a7.37 7.37 0 0 0 1.334 4.363 7.4 7.4 0 0 0 5.936 3.164c.53.01 1.133-.1 1.777-.293-.4.54-.71 1.069-.883 1.57a7.4 7.4 0 0 0 .943 6.66 7.36 7.36 0 0 0 3.645 2.746c3.858 1.329 8.077-.73 9.405-4.588.173-.502.255-1.109.271-1.782.39.549.797 1.007 1.22 1.326a7.35 7.35 0 0 0 5.484 1.418 7.35 7.35 0 0 0 4.88-2.874Z"></path><path fill="#FFF" d="M15.908 12.295a2.055 2.055 0 1 1 3.93-1.202c.332 1.086-.33 5.95-.33 5.95s-3.269-3.662-3.6-4.748m-3.192 8.25a2.055 2.055 0 1 1 .072-4.11c1.135.02 5.558 2.153 5.558 2.153s-4.495 1.977-5.63 1.957m8.62-2.872s2.474-4.241 3.404-4.892a2.055 2.055 0 1 1 2.358 3.367c-.93.651-5.762 1.525-5.762 1.525m-4.373 9.731a2.055 2.055 0 0 1-1.274-2.613c.37-1.073 3.765-4.62 3.765-4.62s.492 4.886.123 5.96a2.056 2.056 0 0 1-2.614 1.273m7.57-2.79c-.907-.683-3.23-5.008-3.23-5.008s4.797 1.042 5.704 1.725a2.055 2.055 0 1 1-2.474 3.283"></path></g><g id="Flor" filter="url(&#39;#filter4&#39;)" transform="translate(48)"><path fill="#FF7398" d="M54.138 31.546c1.825-6.983-5.994-12.414-8.953-14.184.514-2.934 1.672-12.561-4.468-16.116C34.612-2.288 26.924 3.45 24.6 5.394q-.3-.189-.703-.423C20.83 3.196 13.13-.381 7.85 4.736 2.205 10.204 5.537 18.74 6.805 21.434c-2.16 2.01-8.384 8.592-5.818 15.59.706 1.929 2.011 3.456 3.882 4.538 4.03 2.334 9.607 1.958 11.723 1.707.993 1.88 3.83 6.712 7.888 9.061 1.67.967 3.375 1.413 5.07 1.325 6.905-.358 9.916-9.995 10.67-12.912 2.861-.396 12.086-2.199 13.918-9.197"></path><path fill="#FFF" d="M27.764 25.603s3.685 8.188.354 8.71c-3.334.521-1.46-8.591-1.46-8.591s-7.112 6.007-8.15 3.028c-1.04-2.979 7.7-4.048 7.7-4.048s-7.987-4.692-5.393-6.836 6.216 6.092 6.216 6.092 1.945-8.92 4.82-7.254c2.876 1.664-3.857 7.811-3.857 7.811s8.877-.99 8.37 2.352c-.505 3.342-8.6-1.264-8.6-1.264"></path></g></g><g id="Arete" transform="translate(182 129)"><rect id="Cadenita" width="2" height="39" x="9" y="0" fill="#E6E6E6" rx="1"></rect><path id="Rayo" fill="#9177FF" d="M20 37h-9.43L17 20H6L0 41h8.636L4 60z"></path></g></g></g></g>', 1)];
const qa = {
        render: function(a, e) {
            return r(), t("svg", null, [...Va])
        }
    },
    Da = [e('<g id="Top"><defs><path id="ShortHairFrizzle-path2" d="M0 0h264v280H0z"></path><path id="ShortHairFrizzle-path1" d="M90.91 55.361h84.176c18.247-10.527 21.673-29.21 8.764-45.435-3.214-4.04-8.764 11.75-25.821 12.724s-15.42-6.3-33.571-3.576c-18.152 2.724-16.146 17.304-27.99 20.803q-11.846 3.499-5.558 15.484"></path></defs><mask id="ShortHairFrizzle-mask2" fill="#fff"><use href="#ShortHairFrizzle-path2"></use></mask><g id="Top/Short-Hair/Frizzle" mask="url(&#39;#ShortHairFrizzle-mask2&#39;)"><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairFrizzle-path1" transform="translate(-1)"></use></g></g>', 1)];
const ba = {
        render: function(a, e) {
            return r(), t("svg", null, [...Da])
        }
    },
    Wa = [e('<g id="Top"><defs><path id="WinterHat2-path3" d="M0 0h264v280H0z"></path><path id="WinterHat2-path1" d="M72 21c54.773 0 72 47.803 72 82.045v73.865c0 19.495-22.633 19.537-22.633-10.921V86.535c0-6.075-3.732-9-9.816-9H32.45c-6.084 0-9.816 2.925-9.816 9v79.454C22.633 196.447 0 196.405 0 176.91v-73.865C0 68.803 17.227 21 72 21"></path><path id="WinterHat2-path2" d="M101.428 98.169c-2.513 2.294-5.19 3.325-8.575 2.604-.582-.124-2.957-4.538-8.853-4.538-5.897 0-8.27 4.414-8.853 4.538-3.385.721-6.062-.31-8.576-2.604-4.725-4.313-8.654-10.26-6.293-16.75 1.23-3.382 3.232-7.095 6.873-8.173 3.887-1.15 9.346-.002 13.264-.788 1.27-.254 2.656-.707 3.585-1.458.929.75 2.316 1.204 3.585 1.458 3.918.786 9.376-.362 13.264.788 3.64 1.078 5.642 4.79 6.873 8.173 2.361 6.49-1.568 12.437-6.294 16.75M140.081 26c-3.41 8.4-2.093 18.858-2.724 27.676-.513 7.167-2.02 17.91-8.384 22.539-3.255 2.367-9.179 6.345-13.431 5.235-2.927-.764-3.24-9.16-7.087-12.303-4.363-3.565-9.812-5.131-15.306-4.89-2.37.105-7.165.08-9.15 1.903-1.983-1.823-6.777-1.798-9.148-1.902-5.494-.242-10.943 1.324-15.306 4.889-3.847 3.143-4.16 11.54-7.087 12.303-4.252 1.11-10.176-2.868-13.431-5.235-6.365-4.63-7.87-15.372-8.384-22.54-.63-8.817.686-19.275-2.724-27.675-1.66 0-.565 16.129-.565 16.129v20.356c.032 15.288 9.581 38.17 30.754 46.908C63.286 111.53 75.015 115 84 115s20.714-3.14 25.892-5.277c21.173-8.737 30.722-31.95 30.754-47.238V42.13S141.74 26 140.081 26"></path></defs><g id="Top/Accessories/Winter-Hat-2" transform="translate(-1)"><g id="hat" transform="translate(61)"><g id="string" fill="#F4F4F4" transform="translate(0 176)"><circle id="puff" cx="9" cy="65" r="9"></circle><path d="M8 0h2v58H8z"></path></g><g id="string" fill="#F4F4F4" transform="translate(126 168)"><circle id="puff" cx="9" cy="65" r="9"></circle><path d="M8 0h2v58H8z"></path></g><circle id="puff" cx="72" cy="20" r="20" fill="#F4F4F4"></circle><mask id="WinterHat2-mask2" fill="#fff"><use href="#WinterHat2-path1"></use></mask><use fill="var(--avataaar-top-color)" class="CustomColor" href="#WinterHat2-path1"></use><path id="color-dark" fill="#000" d="M-1 21h146v46H-1z" mask="url(&#39;#WinterHat2-mask2&#39;)" opacity=".2"></path><g id="light-triangles" fill="#FFF" opacity=".5" transform="translate(29 32)"><path id="Triangle" d="M12.5 0 25 18H0z" transform="rotate(180 12.5 9)"></path><path id="Triangle" d="M43.5 0 56 18H31z" transform="rotate(180 43.5 9)"></path><path id="Triangle" d="M74.5 0 87 18H62z" transform="rotate(180 74.5 9)"></path></g><g id="dark-triangles" fill="#000" opacity=".5" transform="translate(13 41)"><path id="Triangle" d="M12.5 0 25 18H0zm31 0L56 18H31zm31 0L87 18H62zm31 0L118 18H93z"></path></g></g></g></g>', 1)];
const Ga = {
        render: function(a, e) {
            return r(), t("svg", null, [...Wa])
        }
    },
    Pa = [e('<g id="Top"><defs><path id="LongHairFro-path1" d="M0 0h264v280H0z"></path><path id="LongHairFro-path2" d="M180.666 104.495A11.95 11.95 0 0 1 182 110v13c0 6.019-4.43 11.002-10.209 11.867-1.743 20.248-14.26 37.416-31.791 45.744v9.443c3.832 1.896 8.059 2.946 12.5 2.946 7.621 0 14.61-3.093 20.059-8.242q2.193.241 4.441.242c18.39 0 34.26-12.316 41.622-30.116C224.9 149.814 229 141.454 229 132a32 32 0 0 0-.426-5.223C230.786 120.339 232 113.33 232 106c0-12.866-3.739-24.736-10.046-34.275Q222 70.869 222 70c0-10.957-5.507-20.443-13.53-25.043-7.31-17.588-22.73-29.966-40.773-30.9C163.274 9.075 157.201 6 150.5 6q-1.427.001-2.812.182C137.91 2.196 127.211 0 116 0S94.09 2.196 84.312 6.182A22 22 0 0 0 81.5 6c-6.701 0-12.774 3.075-17.197 8.057-18.044.934-33.463 13.312-40.774 30.9C15.507 49.557 10 59.043 10 70q0 .87.046 1.725C3.739 81.265 0 93.135 0 106c0 7.331 1.214 14.34 3.426 20.777A32 32 0 0 0 3 132c0 9.454 4.1 17.814 10.378 22.884C20.74 172.684 36.61 185 55 185q2.248-.001 4.441-.242C64.889 189.907 71.879 193 79.5 193c4.441 0 8.668-1.05 12.5-2.946v-9.443c-17.53-8.328-30.048-25.496-31.791-45.744C54.43 134.002 50 129.02 50 123v-13c0-1.983.481-3.854 1.333-5.502 2.702-.802 5.677-3.053 8.658-6.33l.009-.002v-.009c6.866-7.556 13.755-20.555 17.37-33.822 11.116 1.737 24.535 2.752 38.984 2.752 14.159 0 27.33-.975 38.314-2.649 3.62 13.226 10.486 26.172 17.332 33.71v.018l.02.003c2.976 3.272 5.947 5.522 8.646 6.326"></path><path id="LongHairFro-path3" d="M65.18 77.737c2.183-1.632 15.227-2.258 17.578-3.648.734-.434 1.303-.873 1.742-1.309.439.436 1.009.875 1.742 1.31 2.351 1.389 15.395 2.015 17.578 3.647 2.21 1.654 3.824 5.448 3.647 8.414-.212 3.56-4.106 12.052-13.795 13.03-2.114-2.353-5.435-3.87-9.172-3.87s-7.058 1.517-9.172 3.87c-9.69-.978-13.583-9.47-13.795-13.03-.176-2.966 1.437-6.76 3.647-8.414m.665 17.164.017.007zm79.018-38.916c-.389-5.955-1.585-11.833-2.629-17.699-.281-1.579-1.81-12.286-2.5-12.286-.232 9.11-1.032 18.08-2.064 27.14-.309 2.708-.632 5.416-.845 8.134-.171 2.196.135 4.848-.397 6.972-.679 2.706-4.08 5.232-6.725 6.165-6.6 2.326-12.105-7.303-17.742-10.12-7.318-3.656-19.897-4.527-27.38.239-7.645-4.766-20.224-3.895-27.542-.239-5.637 2.817-11.142 12.446-17.742 10.12-2.645-.933-6.047-3.459-6.725-6.165-.532-2.124-.226-4.776-.397-6.972-.213-2.718-.536-5.426-.845-8.135C30.298 44.08 29.497 35.11 29.265 26c-.689 0-2.218 10.707-2.5 12.286-1.043 5.866-2.24 11.744-2.627 17.7-.4 6.119.077 12.181 1.332 18.177a165 165 0 0 0 2.049 8.541c.834 3.143-.32 9.262.053 12.488.707 6.104 3.582 18.008 6.811 23.259 1.561 2.538 3.39 4.123 5.433 6.168 1.967 1.97 2.788 5.021 4.91 7.118 3.956 3.908 9.72 6.234 15.64 6.806C65.677 143.05 74.506 146 84.5 146s18.823-2.95 24.135-7.457c5.919-.572 11.683-2.898 15.64-6.806 2.121-2.097 2.942-5.149 4.909-7.118 2.042-2.045 3.872-3.63 5.433-6.168 3.229-5.251 6.104-17.155 6.81-23.259.374-3.226-.78-9.345.054-12.488.75-2.828 1.45-5.676 2.05-8.54 1.254-5.997 1.73-12.06 1.332-18.179"></path></defs><mask id="LongHairFro-mask1" fill="#fff"><use href="#LongHairFro-path1"></use></mask><g id="Top/Long-Hair/Fro" mask="url(&#39;#LongHairFro-mask1&#39;)"><g transform="translate(-1)"><path id="Shadow" fill="#000" d="M67 109.778c9.038-1.06 21.922-20.447 27.37-40.443 11.116 1.737 24.535 2.752 38.984 2.752 14.159 0 27.33-.975 38.314-2.649 5.462 19.953 18.31 39.269 27.332 40.339V89c0-22.884-11.647-43.048-29.336-54.887-.528 2.482-.88 5.222-1.04 8.184-10.34-1.404-22.396-2.21-35.27-2.21-13.164 0-25.472.842-35.964 2.306-.158-3-.512-5.775-1.047-8.286C78.65 45.947 67 66.113 67 89z" opacity=".16"></path><use id="Hair" fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairFro-path2" transform="translate(17)"></use></g></g></g>', 1)];
const ja = {
        render: function(a, e) {
            return r(), t("svg", null, [...Pa])
        }
    },
    Ra = [e('<g id="Top"><defs><path id="ShortHairShaggy-path2" d="M0 0h264v280H0z"></path><path id="ShortHairShaggy-path1" d="M198.747 37.856c-5.14-3.832-11.219-7.116-17.56-8.378-6.446-1.282-10.358-1.593-16.704-.073-1.633.392-2.184.78-3.62-.148-1.212-.783-9.663-9.49-35.421-4.657-26.035 4.885-33.77 44.075-43.427 45.566-3.48.537-7.781-.384-7.916-2.527-3.963 6.034-5.008 14.007-3.327 21.074 1.447 6.086 4.497 11.804 9.989 15.137 4.726 2.867 11.26 4.116 16.72 3.587 2.486-.24 4.746-.763 7.033-1.766 2.759-1.21 4.957-3.39 7.664-4.543a54 54 0 0 1-9.176 6.418c-1.64.907-3.304 1.532-5.113 2.024-1.236.336-3.761 1.481-4.956 1.182 7.807 1.396 15.16.18 22.32-3.163 3.23-1.508 6.338-3.332 9.19-5.476 2.833-2.13 6.095-4.307 8.31-7.11-.93 1.204.698-.586.913-.805a67 67 0 0 0 1.787-1.895c1.002-1.104 1.998-2.228 2.93-3.391 1.995-2.486 3.852-5.082 5.508-7.803 1.678-2.756 8.359-13.873 10.375-16.49-1.905 5.708-3.98 11.418-6.407 16.925 4.713-1.47 9.284-5.544 12.295-9.34 3.392-4.276 5.4-9.268 6.108-14.666 3.826 10.416 12.785 18.63 22.032 24.295-2.003-3.73-5.055-6.885-7.052-10.678 9.191 9.329 24.568 13.893 28.595 27.574 1.033-4.758 4.353-8.58 5.348-13.433 1.104-5.389 1.896-11.11 1.72-16.616-.396-12.242-8.631-23.723-18.158-30.824"></path></defs><mask id="ShortHairShaggy-mask2" fill="#fff"><use href="#ShortHairShaggy-path2"></use></mask><g id="Top/Short-Hair/Shaggy" mask="url(&#39;#ShortHairShaggy-mask2&#39;)"><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairShaggy-path1" transform="matrix(-1 0 0 1 285.93 0)"></use></g></g>', 1)];
const Za = {
        render: function(a, e) {
            return r(), t("svg", null, [...Ra])
        }
    },
    Ua = [e('<g id="Top"><defs><path id="WinterHat3-path3" d="M0 0h264v280H0z"></path><path id="WinterHat3-path1" d="M66 0c36.45 0 66 29.55 66 66v5H0v-5C0 29.55 29.55 0 66 0"></path><path id="WinterHat3-path2" d="M67.285 61.451Q91.202 44 133.073 44q41.869 0 65.659 17.45A8 8 0 0 1 202 67.9v30.47a4 4 0 0 1-6.135 3.383Q170.902 85.999 133.805 86q-37.383 0-63.73 15.994A4 4 0 0 1 64 98.575V67.914a8 8 0 0 1 3.285-6.463"></path></defs><g id="Top/Accessories/Winter-Hat-3" transform="translate(-1)"><g id="hat" transform="translate(67 12)"><circle id="puff" cx="66" cy="8" r="20" fill="#F4F4F4"></circle><use fill="var(--avataaar-top-color)" class="CustomColor" href="#WinterHat3-path1"></use></g><g id="hat-front"><use filter="url(&#39;#WinterHat3-path2&#39;)" href="#WinterHat3-path2"></use><use fill="#F4F4F4" href="#WinterHat3-path2"></use></g></g></g>', 1)];
const Qa = {
        render: function(a, e) {
            return r(), t("svg", null, [...Ua])
        }
    },
    _a = [e('<g id="Top"><defs><path id="LongHairFroBand-path1" d="M0 0h264v280H0z"></path><path id="LongHairFroBand-path2" d="M80.02 73.81A55.9 55.9 0 0 0 77 92v6.166c-5.675.952-10 5.888-10 11.834v13c0 6.019 4.43 11.002 10.209 11.867 1.743 20.248 14.26 37.416 31.791 45.744v10.944A36.4 36.4 0 0 1 93.5 195a36.35 36.35 0 0 1-23.19-8.312 54 54 0 0 1-5.81.312c-21.094 0-39.337-12.208-48.049-29.945C8.934 151.924 4 143.288 4 133.5c0-2.115.23-4.175.667-6.159A57.9 57.9 0 0 1 1 107c0-12.756 4.118-24.55 11.097-34.127A29 29 0 0 1 12 70.5c0-11.297 6.573-21.06 16.104-25.67 8.433-18.128 26.454-30.894 47.546-31.78A28.4 28.4 0 0 1 95.5 5c2.327 0 4.589.279 6.754.805C111.776 2.058 122.148 0 133 0c10.346 0 20.255 1.87 29.408 5.292A29 29 0 0 1 166.5 5a28.4 28.4 0 0 1 19.85 8.05c21.092.886 39.113 13.652 47.546 31.78C243.426 49.44 250 59.203 250 70.5q0 1.2-.097 2.373C256.882 82.45 261 94.243 261 107a57.9 57.9 0 0 1-3.667 20.341A28.6 28.6 0 0 1 258 133.5c0 9.788-4.934 18.424-12.451 23.555C236.837 174.792 218.594 187 197.5 187a54 54 0 0 1-5.81-.312A36.35 36.35 0 0 1 168.5 195c-4.018 0-7.884-.65-11.5-1.849v-12.54c17.53-8.328 30.048-25.496 31.791-45.744C194.57 134.002 199 129.02 199 123v-13c0-5.946-4.325-10.882-10-11.834V92c0-5.441-.776-10.702-2.224-15.676l1.377 12.87-11.34-24-45.136-19.523-30.114 10.557L80.065 76.42l-.045-2.609Z"></path></defs><mask id="LongHairFroBand-mask1" fill="#fff"><use href="#LongHairFroBand-path1"></use></mask><g id="Top/Long-Hair/Fro-+-Band" mask="url(&#39;#LongHairFroBand-mask1&#39;)"><g transform="translate(-1)"><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#LongHairFroBand-path2"></use><path id="Band" fill="#92D9FF" stroke="none" d="M76.631 98.975A48.6 48.6 0 0 1 76 91.152C76 62.35 101.296 39 132.5 39S189 62.35 189 91.152c0 2.659-.216 5.271-.631 7.823-4.09-25.092-27.545-44.33-55.869-44.33s-51.78 19.238-55.869 44.33"></path></g></g></g>', 1)];
const Ia = {
        render: function(a, e) {
            return r(), t("svg", null, [..._a])
        }
    },
    Ka = [e('<g id="Top"><defs><path id="ShortHairShaggyMullet-path1" d="M0 0h264v280H0z"></path><path id="ShortHairShaggyMullet-path2" d="M175.126 166.898c.715 2.24 1.749 4.333 3.43 5.788 1.62 1.404 4.512 1.06 6.543 1.117 1.672.048 3.346.053 5.016-.02.839-.036 1.213 1.015.534 1.499q-.195.139-.39.262a39 39 0 0 1-3.25 1.812c-2.524 1.258-5.188 2.244-7.982 2.734-1.916.337-3.816.4-5.654.177a9.8 9.8 0 0 0 1.699 1.94c1.73 1.501 4.816 1.133 6.983 1.194 1.784.052 3.57.057 5.353-.02.895-.039 1.295 1.084.57 1.601a8 8 0 0 1-.416.28 42 42 0 0 1-3.469 1.937c-2.693 1.345-5.536 2.398-8.518 2.922-5.5.966-10.87-.177-15.194-3.708a25 25 0 0 1-3.381-3.36v-2.442a56.2 56.2 0 0 0 18.126-13.713m-93.81-15.304a140 140 0 0 1-2.31 4.597c-4.795 9.11-10.764 20.602-22.507 21.405-1.088.075-1.519 1.347-.67 1.992 11.12 8.453 36.432 13.6 45.445 11.982a54 54 0 0 0 7.726-1.96v-8.999a56.2 56.2 0 0 1-27.685-29.017Zm114.59-82.914c.175 5.507-.617 11.227-1.721 16.616-.995 4.852-4.315 8.675-5.348 13.433-4.027-13.68-19.404-18.245-28.595-27.574 1.997 3.793 5.049 6.948 7.052 10.678-9.247-5.665-18.206-13.88-22.032-24.295-.707 5.398-2.716 10.39-6.108 14.666-3.011 3.796-7.582 7.87-12.295 9.34 2.428-5.507 4.502-11.217 6.407-16.925-2.016 2.617-8.697 13.734-10.375 16.49-1.656 2.72-3.513 5.317-5.507 7.803-.933 1.163-1.929 2.287-2.93 3.391a67 67 0 0 1-1.788 1.895c-.215.219-1.842 2.01-.912.806-2.216 2.802-5.478 4.979-8.31 7.109-2.853 2.144-5.96 3.968-9.192 5.476-7.159 3.343-14.512 4.56-22.32 3.163 1.196.299 3.721-.846 4.957-1.182 1.809-.492 3.474-1.117 5.113-2.024a54 54 0 0 0 9.176-6.418c-2.707 1.152-4.905 3.334-7.664 4.543-2.287 1.003-4.547 1.526-7.032 1.766-5.462.529-11.995-.72-16.721-3.587-5.492-3.333-8.542-9.051-9.99-15.137-1.68-7.067-.635-15.04 3.328-21.074.135 2.143 4.436 3.064 7.916 2.527 9.658-1.49 15.403-38.048 40.427-44.566 19.961-5.2 34.21 3.874 35.42 4.657 1.437.928 1.988.54 3.621.148 6.346-1.52 13.258-2.209 19.705-.927 6.34 1.262 12.418 4.546 17.559 8.378 9.527 7.101 17.762 18.582 18.159 30.824"></path><path id="ShortHairShaggyMullet-path3" d="M65.18 77.737c2.183-1.632 15.227-2.258 17.578-3.648.734-.434 1.303-.873 1.742-1.309.439.436 1.009.875 1.742 1.31 2.351 1.389 15.395 2.015 17.578 3.647 2.21 1.654 3.824 5.448 3.647 8.414-.212 3.56-4.106 12.052-13.795 13.03-2.114-2.353-5.435-3.87-9.172-3.87s-7.058 1.517-9.172 3.87c-9.69-.978-13.583-9.47-13.795-13.03-.176-2.966 1.437-6.76 3.647-8.414m.665 17.164.017.007zm79.018-38.916c-.389-5.955-1.585-11.833-2.629-17.699-.281-1.579-1.81-12.286-2.5-12.286-.232 9.11-1.032 18.08-2.064 27.14-.309 2.708-.632 5.416-.845 8.134-.171 2.196.135 4.848-.397 6.972-.679 2.706-4.08 5.232-6.725 6.165-6.6 2.326-12.105-7.303-17.742-10.12-7.318-3.656-19.897-4.527-27.38.239-7.645-4.766-20.224-3.895-27.542-.239-5.637 2.817-11.142 12.446-17.742 10.12-2.645-.933-6.047-3.459-6.725-6.165-.532-2.124-.226-4.776-.397-6.972-.213-2.718-.536-5.426-.845-8.135C30.298 44.08 29.497 35.11 29.265 26c-.689 0-2.218 10.707-2.5 12.286-1.043 5.866-2.24 11.744-2.627 17.7-.4 6.119.077 12.181 1.332 18.177a165 165 0 0 0 2.049 8.541c.834 3.143-.32 9.262.053 12.488.707 6.104 3.582 18.008 6.811 23.259 1.561 2.538 3.39 4.123 5.433 6.168 1.967 1.97 2.788 5.021 4.91 7.118 3.956 3.908 9.72 6.234 15.64 6.806C65.677 143.05 74.506 146 84.5 146s18.823-2.95 24.135-7.457c5.919-.572 11.683-2.898 15.64-6.806 2.121-2.097 2.942-5.149 4.909-7.118 2.042-2.045 3.872-3.63 5.433-6.168 3.229-5.251 6.104-17.155 6.81-23.259.374-3.226-.78-9.345.054-12.488.75-2.828 1.45-5.676 2.05-8.54 1.254-5.997 1.73-12.06 1.332-18.179"></path></defs><mask id="ShortHairShaggyMullet-mask1" fill="#fff"><use href="#ShortHairShaggyMullet-path1"></use></mask><g id="Top/Short-Hair/Shaggy-Mullet" mask="url(&#39;#ShortHairShaggyMullet-mask1&#39;)"><g transform="translate(-1)"><use fill="var(--avataaar-hair-color)" class="CustomColor" href="#ShortHairShaggyMullet-path2"></use><path id="Shadow" fill="#000" stroke="none" d="M175.126 166.898c.715 2.24 1.749 4.333 3.43 5.788 1.62 1.404 4.512 1.06 6.543 1.117 1.672.048 3.346.053 5.016-.02.839-.036 1.213 1.015.534 1.499q-.195.139-.39.262a39 39 0 0 1-3.25 1.812c-2.524 1.258-5.188 2.244-7.982 2.734-1.916.337-3.816.4-5.654.177a9.8 9.8 0 0 0 1.699 1.94c1.73 1.501 4.816 1.133 6.983 1.194 1.784.052 3.57.057 5.353-.02.895-.039 1.295 1.084.57 1.601a8 8 0 0 1-.416.28 42 42 0 0 1-3.469 1.937c-2.693 1.345-5.536 2.398-8.518 2.922-5.5.966-10.87-.177-15.194-3.708a25 25 0 0 1-3.381-3.36v-2.442a56.2 56.2 0 0 0 18.126-13.713m-93.81-15.304a140 140 0 0 1-2.31 4.597c-4.795 9.11-10.764 20.602-22.507 21.405-1.088.075-1.519 1.347-.67 1.992 11.12 8.453 36.432 13.6 45.445 11.982a54 54 0 0 0 7.726-1.96v-8.999a56.2 56.2 0 0 1-27.685-29.017Z" opacity=".16"></path></g></g></g>', 1)];
const Ya = {
        render: function(a, e) {
            return r(), t("svg", null, [...Ka])
        }
    },
    Ja = [e('<g id="Top"><defs><path id="WinterHat4-path5" d="M0 0h264v280H0z"></path><path id="WinterHat4-path1" d="M129.66 38.357A60.8 60.8 0 0 1 134 61v8H2v-8c0-8.025 1.55-15.688 4.366-22.707Q-3.238 18.099 2.636 5.12q11.257-3.414 26.08 5.419C38.486 3.888 50.289 0 63 0h10c12.722 0 24.535 3.895 34.31 10.557q14.84-8.856 26.11-5.437 5.883 12.999-3.76 33.237"></path><path id="WinterHat4-path2" d="M28.716 10.539c-9.957 6.778-17.804 16.426-22.35 27.754Q-3.238 18.099 2.636 5.12q11.257-3.414 26.08 5.419m100.943 27.818c-4.538-11.346-12.386-21.01-22.349-27.8q14.84-8.856 26.11-5.437 5.883 12.999-3.76 33.237Z"></path><path id="WinterHat4-path3" d="M21.862 15.96a61.3 61.3 0 0 0-11.433 14.08Q6.041 17.878 8.927 13.208q3.977-1.72 12.935 2.751Zm103.49 13.714a61.3 61.3 0 0 0-11.274-13.77q8.704-4.278 12.608-2.59 2.83 4.58-1.333 16.36Z"></path><path id="WinterHat4-path4" d="M67.285 61.451Q91.202 44 133.073 44q41.869 0 65.659 17.45A8 8 0 0 1 202 67.9v30.47a4 4 0 0 1-6.135 3.383Q170.902 85.999 133.805 86q-37.383 0-63.73 15.994A4 4 0 0 1 64 98.575V67.914a8 8 0 0 1 3.285-6.463"></path></defs><g id="Top/Accessories/Winter-Hat-4" transform="translate(-1)"><g id="hat" transform="translate(65 4)"><use fill="var(--avataaar-top-color)" class="CustomColor" href="#WinterHat4-path1"></use><use id="shadow" fill="#000" href="#WinterHat4-path2" opacity=".24"></use><use id="light" fill="#FFF" href="#WinterHat4-path3" opacity=".3"></use></g><g id="hat-front"><use filter="url(&#39;#WinterHat4-path4&#39;)" href="#WinterHat4-path4"></use><use fill="#F4F4F4" href="#WinterHat4-path4"></use></g></g></g>', 1)];
const Xa = {
        Eyepatch: D,
        Hat: R,
        Hijab: K,
        LongHairBigHair: ra,
        LongHairBob: oa,
        LongHairBun: ua,
        LongHairCurly: Ma,
        LongHairCurvy: Fa,
        LongHairDreads: Ta,
        LongHairFrida: qa,
        LongHairFro: ja,
        LongHairFroBand: Ia,
        LongHairMiaWallace: W,
        LongHairNotTooLong: U,
        LongHairShavedSides: J,
        LongHairStraight: ea,
        LongHairStraight2: ca,
        LongHairStraightStrand: ga,
        NoHair: Ha,
        ShortHairDreads01: wa,
        ShortHairDreads02: Oa,
        ShortHairFrizzle: ba,
        ShortHairShaggy: Za,
        ShortHairShaggyMullet: Ya,
        ShortHairShortCurly: P,
        ShortHairShortFlat: _,
        ShortHairShortRound: $,
        ShortHairShortWaved: la,
        ShortHairSides: da,
        ShortHairTheCaesar: Ca,
        ShortHairTheCaesarSidePart: ka,
        Turban: Ba,
        WinterHat1: Na,
        WinterHat2: Ga,
        WinterHat3: Qa,
        WinterHat4: {
            render: function(a, e) {
                return r(), t("svg", null, [...Ja])
            }
        }
    },
    $a = [i("g", {
        id: "Facial-Hair/Beard-Light",
        transform: "translate(49 72)"
    }, [i("defs", null, [i("path", {
        id: "BeardLight-path1",
        d: "M101.428 98.169c-2.513 2.294-5.19 3.325-8.575 2.604-.582-.124-2.957-4.538-8.853-4.538-5.897 0-8.27 4.414-8.853 4.538-3.385.721-6.062-.31-8.576-2.604-4.725-4.313-8.654-10.26-6.293-16.75 1.23-3.382 3.232-7.095 6.873-8.173 3.887-1.15 9.346-.002 13.264-.788 1.27-.254 2.656-.707 3.585-1.458.929.75 2.316 1.204 3.585 1.458 3.918.786 9.376-.362 13.264.788 3.64 1.078 5.642 4.79 6.873 8.173 2.361 6.49-1.568 12.437-6.294 16.75M140.081 26c-3.41 8.4-2.093 18.858-2.724 27.676-.513 7.167-2.02 17.91-8.384 22.539-3.255 2.367-9.179 6.345-13.431 5.235-2.927-.764-3.24-9.16-7.087-12.303-4.363-3.565-9.812-5.131-15.306-4.89-2.37.105-7.165.08-9.15 1.903-1.983-1.823-6.777-1.798-9.148-1.902-5.494-.242-10.943 1.324-15.306 4.889-3.847 3.143-4.16 11.54-7.087 12.303-4.252 1.11-10.176-2.868-13.431-5.235-6.365-4.63-7.87-15.372-8.384-22.54-.63-8.817.686-19.275-2.724-27.675-1.66 0-.565 16.129-.565 16.129v20.356c.032 15.288 9.581 38.17 30.754 46.908C63.286 111.53 75.015 115 84 115s20.714-3.14 25.892-5.277c21.173-8.737 30.722-31.95 30.754-47.238V42.13S141.74 26 140.081 26"
    })]), i("use", {
        fill: "var(--avataaar-facial-hair-color)",
        class: "CustomColor",
        href: "#BeardLight-path1"
    })], -1)];
const ar = {
        render: function(a, e) {
            return r(), t("svg", null, [...$a])
        }
    },
    rr = [i("g", {
        id: "Facial-Hair/Beard-Majestic",
        transform: "translate(49 72)"
    }, [i("defs", null, [i("path", {
        id: "BeardMajestic-path1",
        d: "M65.18 77.737c2.183-1.632 15.227-2.258 17.578-3.648.734-.434 1.303-.873 1.742-1.309.439.436 1.009.875 1.742 1.31 2.351 1.389 15.395 2.015 17.578 3.647 2.21 1.654 3.824 5.448 3.647 8.414-.212 3.56-4.106 12.052-13.795 13.03-2.114-2.353-5.435-3.87-9.172-3.87s-7.058 1.517-9.172 3.87c-9.69-.978-13.583-9.47-13.795-13.03-.176-2.966 1.437-6.76 3.647-8.414m.665 17.164.017.007zm79.018-38.916c-.389-5.955-1.585-11.833-2.629-17.699-.281-1.579-1.81-12.286-2.5-12.286-.232 9.11-1.032 18.08-2.064 27.14-.309 2.708-.632 5.416-.845 8.134-.171 2.196.135 4.848-.397 6.972-.679 2.706-4.08 5.232-6.725 6.165-6.6 2.326-12.105-7.303-17.742-10.12-7.318-3.656-19.897-4.527-27.38.239-7.645-4.766-20.224-3.895-27.542-.239-5.637 2.817-11.142 12.446-17.742 10.12-2.645-.933-6.047-3.459-6.725-6.165-.532-2.124-.226-4.776-.397-6.972-.213-2.718-.536-5.426-.845-8.135C30.298 44.08 29.497 35.11 29.265 26c-.689 0-2.218 10.707-2.5 12.286-1.043 5.866-2.24 11.744-2.627 17.7-.4 6.119.077 12.181 1.332 18.177a165 165 0 0 0 2.049 8.541c.834 3.143-.32 9.262.053 12.488.707 6.104 3.582 18.008 6.811 23.259 1.561 2.538 3.39 4.123 5.433 6.168 1.967 1.97 2.788 5.021 4.91 7.118 3.956 3.908 9.72 6.234 15.64 6.806C65.677 143.05 74.506 146 84.5 146s18.823-2.95 24.135-7.457c5.919-.572 11.683-2.898 15.64-6.806 2.121-2.097 2.942-5.149 4.909-7.118 2.042-2.045 3.872-3.63 5.433-6.168 3.229-5.251 6.104-17.155 6.81-23.259.374-3.226-.78-9.345.054-12.488.75-2.828 1.45-5.676 2.05-8.54 1.254-5.997 1.73-12.06 1.332-18.179"
    })]), i("use", {
        fill: "var(--avataaar-facial-hair-color)",
        class: "CustomColor",
        href: "#BeardMajestic-path1"
    })], -1)];
const tr = {
        render: function(a, e) {
            return r(), t("svg", null, [...rr])
        }
    },
    er = [i("g", {
        id: "Facial-Hair/Moustache-Fancy",
        transform: "translate(49 72)"
    }, [i("defs", null, [i("path", {
        id: "MoustacheFancy-path1",
        d: "M84 69.297c-6.792-3.586-16.422-4.148-21.611-2.165-5.775 2.205-10.884 8.451-19.75 5.696-.37-.114-.73.217-.619.58 1.374 4.51 9.008 7.599 11.602 7.7 11.34.442 20.473-8.278 30.378-8.947 9.906.67 19.04 9.389 30.379 8.947 2.594-.101 10.228-3.19 11.601-7.7.111-.363-.25-.694-.618-.58-8.867 2.755-13.976-3.49-19.75-5.696-5.19-1.983-14.82-1.42-21.612 2.165"
    })]), i("use", {
        fill: "var(--avataaar-facial-hair-color)",
        class: "CustomColor",
        href: "#MoustacheFancy-path1"
    })], -1)];
const ir = {
        render: function(a, e) {
            return r(), t("svg", null, [...er])
        }
    },
    lr = [i("g", {
        id: "Facial-Hair/Beard-Medium",
        transform: "translate(49 72)"
    }, [i("defs", null, [i("path", {
        id: "BeardMedium-path1",
        d: "M105.018 94.13c-3.868 5.591-6.76 1.817-10.88-1.254-2.481-1.849-6.177-4.148-9.634-4.035-3.456-.113-7.152 2.186-9.633 4.035-4.12 3.07-7.013 6.845-10.88 1.254-2.903-4.198-1.688-11.256 1.024-15.227 3.859-5.652 9.094-2.918 14.947-3.563 1.592-.175 3.19-.617 4.542-1.34 1.352.723 2.95 1.165 4.542 1.34 5.854.645 11.089-2.089 14.948 3.563 2.712 3.97 3.926 11.03 1.024 15.227M140.39 26c-3.424 14.075-4.998 28.434-7.481 42.671a319 319 0 0 1-1.685 8.879c-.127.62-.251 2.923-.862 3.214-1.851.884-5.624-3.817-6.633-4.879-2.533-2.666-5.045-5.356-8.13-7.448-6.235-4.227-13.535-6.726-21.13-7.32-3.178-.248-7.475.186-10.47 1.993-2.995-1.807-7.292-2.24-10.47-1.992-7.596.593-14.895 3.092-21.13 7.32-3.085 2.091-5.597 4.781-8.13 7.447-1.01 1.062-4.782 5.763-6.633 4.88-.61-.292-.735-2.595-.862-3.215a319 319 0 0 1-1.685-8.879C32.607 54.434 31.034 40.075 27.61 26c-.997 0-1.871 18.748-1.983 20.495-.452 7.094-.98 14.03-.305 21.131 1.164 12.249 2.377 27.608 11.71 36.962 8.434 8.451 20.678 10.218 31.24 15.553 1.36.687 3.163 1.535 5.108 2.23 2.049 1.563 6.113 2.629 10.794 2.629 4.91 0 9.142-1.173 11.08-2.862a47 47 0 0 0 4.475-1.997c10.56-5.336 22.805-7.102 31.238-15.553 9.334-9.354 10.547-24.713 11.712-36.962.674-7.1.146-14.037-.306-21.131C142.26 44.748 141.387 26 140.39 26"
    })]), i("use", {
        fill: "var(--avataaar-facial-hair-color)",
        class: "CustomColor",
        href: "#BeardMedium-path1"
    })], -1)];
const sr = {
    render: function(a, e) {
        return r(), t("svg", null, [...lr])
    }
};
const or = {
        render: function(a, e) {
            return r(), t("svg")
        }
    },
    hr = [i("g", {
        id: "Facial-Hair/Moustache-Magnum",
        transform: "translate(49 72)"
    }, [i("defs", null, [i("path", {
        id: "MoustacheMagnum-path1",
        d: "M83.998 74.84a6.04 6.04 0 0 1-2.048 1.85c-8.902 4.82-18.073.642-23.074.94-2.416.144-5.535 1.785-6.66.05-1.24-1.913 2.852-12.46 12.505-14.216 7.01-1.275 16.776.138 19.277 3.474 2.5-3.336 12.267-4.749 19.276-3.474 9.654 1.757 13.745 12.303 12.506 14.215-1.125 1.736-4.244.095-6.66-.05-5.001-.297-14.172 3.881-23.074-.94a6.04 6.04 0 0 1-2.048-1.85Z"
    })]), i("use", {
        fill: "var(--avataaar-facial-hair-color)",
        class: "CustomColor",
        href: "#MoustacheMagnum-path1"
    })], -1)];
const cr = {
        BeardMajestic: tr,
        BeardLight: ar,
        MoustacheFancy: ir,
        BeardMedium: sr,
        Blank: or,
        MoustacheMagnum: {
            render: function(a, e) {
                return r(), t("svg", null, [...hr])
            }
        }
    },
    nr = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Bat" fill="#FFF" fill-rule="evenodd"><path id="Batman!" d="M87.685 13.403c-1.393-6.431-6.21-10.15-12.5-11.586-2.526-.577-10.913-2.387-9.607 2.408.593 2.172.263 3.964-1.553 5.766-1.77 1.755-5.231 2.2-6.952-.011-1.474-1.895.427-4.721-.721-6.567-.446-.717-1.216-1.083-2.028-.732-1.141.494-.534 1.555-1.073 2.318-.849 1.203-1.245.826-2.01-.373-.48-.754-.008-1.575-1.246-1.897-1.433-.372-1.903.828-2.032 1.923-.082.687.322 1.792.336 2.488.027 1.364-.09 3.323-.725 4.529-1.125 2.137-2.704 1.453-4.383.096-1.98-1.602-2.561-3.385-2.178-5.817.459-2.917.292-5.709-3.28-3.884-5.02 2.564-9.68 7.135-12.588 11.919-2.445 4.02-4.37 8.893-2.203 13.473 2.21 4.675 5.862 8.69 10.966 9.883 1.321.31 5.092 1.811 6.345.552 1.947-1.957-2.548-3.783-3.435-4.975-1.258-1.69-2.337-4.915-.957-6.822 1.76-2.427 3.6-1.074 5.045.644 1.136 1.348 2.75 4.826 4.506 2.022 1.21-1.931 1.101-5.102 4.4-3.717 4.715 1.978 4.86 11.112 5.7 15.291.367 1.83 2.035 4.064 3.47 1.525.79-1.396.364-4.421.22-5.863-.296-2.985-1.08-5.92-.11-8.877.562-1.71 2.001-4.16 4.13-2.844 1.725 1.066 1.006 5.816 3.353 5.807 2.066-.007 1.502-3.791 2.603-5.039 1.68-1.904 4.916-.999 5.91 1.249 1.336 3.025-2.203 5.126-2.044 7.785.154 2.591 3.494 1.58 4.89.923 2.872-1.35 5.119-3.853 6.676-6.571 2.407-4.204 4.125-10.222 3.075-15.026" transform="translate(77 58)"></path></g></g>', 1)];
const dr = {
        render: function(a, e) {
            return r(), t("svg", null, [...nr])
        }
    },
    fr = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Cumbia" fill-rule="evenodd" stroke-width="1"><g id="Group" fill="#FFF" transform="translate(77 64)"><path id="Fill-1" d="M10.272 24.132c3.273-.559 5.73-3.554 5.18-6.788-.464-2.724-1.745-.343-2.976.853-1.335 1.298-2.45 2.574-4.536 2.054-3.607-.9-4.858-5.4-3.84-8.48a5.94 5.94 0 0 1 3.478-3.696c1.852-.746 3.204.09 4.748 1.094.289.187 1.73 1.37 1.994 1.25.462-.211.115-2.43.045-2.725-.338-1.421-1.266-2.575-2.617-3.238-3.333-1.635-7.514.489-9.64 3.055-4.884 5.897-.92 18.164 8.164 16.62"></path><path id="Fill-5" d="M20.283 5.038q0 .003 0 0m-1.594 12.865c.503 3.474 2.977 6.5 6.952 6.357 4.278-.155 6.056-4.098 7.008-7.486.957-3.399 2.052-7.683.664-11.093-.42-1.032-.685-2.38-1.716-1.53-1.252 1.033-1.409 4.039-1.515 5.442-.2 2.647-.781 9.97-4.108 10.944-4.179 1.222-4.048-5.847-4-7.977.04-1.896.246-3.734-.342-5.584-.313-.985-.59-2.44-1.528-1.634-1.29 1.108-1.453 3.828-1.544 5.327-.144 2.405-.214 4.842.129 7.234"></path><path id="Fill-7" d="M37.783 20.746c.188.412.624 1.402 1.02 1.679.944.66-.055.708.8-.059.813-.729 1.13-2.717 1.254-3.67.385-2.96-.12-6.108-.087-9.093 1.024 2.218 1.584 4.584 2.386 6.874.554 1.582 1.396 4.804 3.654 4.753 2.443-.055 2.57-3.145 2.894-4.819.461-2.37.97-4.721 1.676-7.037.092 3.91-1.427 10.995 2.108 13.92.014.013 1.432-4.15 1.467-4.406.223-1.691.083-3.444.107-5.148.051-3.597.718-8.003-.3-11.506C54.435 1.1 53.788-.03 52.354.001c-1.825.04-2.233 1.985-2.698 3.298-1.28 3.614-2.445 7.224-3.357 10.94-.548-1.68-5.339-16.421-8.789-10.901-.555.888-.315 2.218-.338 3.196-.044 1.879-.155 3.756-.196 5.635-.061 2.843-.41 5.907.808 8.577"></path><path id="Fill-9" d="M62.02 7.71c.72-.135 5.735-1.727 5.523-.136-.223 1.675-4.633 3.309-5.816 3.876a10.6 10.6 0 0 0-.643-3.567zm5.717-.64s-.027-.035 0 0m.122 8.341c2.272 1.22 1.287 3.417-.426 4.608-.649.45-6.53 1.802-6.513 1.663q.001.005-.004.005c.18-1.694-.257-5.018 1-6.02 1.304-1.04 4.5-.808 5.943-.256m.062-7.995c.009.022.001.002 0 0M57.944 24.26c.224.551.86 1.912 1.566 1.945.86.04.794-1.043.929-1.71 3.441 1.721 8.498-.047 10.907-3.03 2.787-3.45 1.348-8.27-2.579-9.745 2.113-1.688 4.026-5.399 1.255-7.49-2.196-1.655-5.828-1.747-8.123-.302-2.735 1.723-3.85 5.833-4.09 9.006-.255 3.382-1.158 8.125.135 11.326"></path><path id="Fill-11" d="M76.05 15.871c.074 2.07-.15 4.287.332 6.306.171.717.433 1.511.76 2.162.611 1.215.31 1.05 1.032.36 2.172-2.083 1.209-8.575 1.157-11.249-.041-2.078.064-4.28-.513-6.283-.162-.562-1.123-3.348-1.655-3.284-.816.098-1.376 3.93-1.423 4.693-.148 2.396.226 4.895.31 7.295"></path><path id="Fill-13" d="M94.748 16.43c-1.582-.137-3.622.075-5.117.557.697-1.916 1.475-4.054 2.238-5.79q.711-1.635 1.494-3.24c1.278 2.686 1.992 5.828 2.832 8.666q-.72-.13-1.447-.193m5.44.725c-.727-2.78-1.579-5.532-2.426-8.28-.538-1.743-1.13-3.911-2.6-5.168C91 .146 88.635 9.557 87.614 11.94c-.985 2.296-2.216 4.634-2.85 7.049a9.5 9.5 0 0 0-.244 3.652c.205 1.519-.004 1.741 1.294.914 1-.636 1.414-1.792 2.227-2.562.144-.136.218-.668.39-.755.188-.096 1.504.253 1.815.274 2.17.151 4.712-.218 6.715-1.054.205.842 1.627 5.962 2.977 5.773.597-.083.965-3.064.992-3.537.087-1.553-.352-3.049-.742-4.538"></path><path id="Fill-15" d="M109.302 3.432c-.264-1.203-.814-3.292-1.842-2.112-1.39 1.596-1.09 5.173-1.111 7.177-.015 1.451-1.552 12.062.556 11.883-.09 0 .845-1.668.98-1.922.815-1.524 1.131-2.97 1.329-4.722.365-3.237.783-7.111.088-10.304"></path><path id="Fill-17" d="M108.164 24.301c-2.24-2.728-6.311.658-5.041 3.374 1.729 3.7 7.331-.56 5.041-3.374"></path><path id="Fill-19" d="M94.898 28.545c-2.891-.738-6.297-.24-9.249-.152-3.081.092-6.16.264-9.24.357-6.568.198-13.124.092-19.692.038-12.454-.103-24.935.69-37.383.168-2.672-.112-5.545-.713-8.198-.209-.727.139-3.009.543-3.329 1.266-.336.76 1.402 1.555 2.331 1.955 2.422 1.044 5.329.858 7.9.964 2.93.12 5.887.058 8.819-.014 12.075-.297 24.089-1.343 36.18-1.165 6.976.103 13.937.038 20.912.001 3.32-.017 7 .526 10.273-.062.552-.1 3.763-.854 3.807-1.836.02-.453-2.806-1.228-3.13-1.311"></path></g></g></g>', 1)];
const ur = {
        render: function(a, e) {
            return r(), t("svg", null, [...fr])
        }
    },
    pr = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Diamond" fill-rule="evenodd" stroke-width="1"><g id="Diamond" fill="#FFF" transform="translate(106 60)"><path id="Fill-21" d="M34.78 27.737c-2.389 2.656-4.857 5.243-7.335 7.82.985-3.553 1.74-7.578 3.204-10.958.417-.962.1-1.084.927-1.493.609-.301 2.078.043 2.807.062 1.557.039 3.15.192 4.696-.05a222 222 0 0 0-4.299 4.619m-15.264 4.061c-2.699-3.282-5.384-6.568-8.658-9.317 1.289.137 2.696-.043 3.958.206 1.944.384 1.837.99 2.82 2.959 1.45 2.906 2.889 5.789 4.05 8.823-.711-.9-1.441-1.785-2.17-2.67m-9.098-12.532c.963-1.575 1.144-2.972 2.92-3.78 2.06-.939 5.3-.742 7.488-.916-1.37 1.523-3.037 3.103-3.604 5.122-.874-1.718-1.962-3.174-3.67-4.17-.215-.107 1.158 4.55 1.338 4.87-1.716-.096-3.522-.408-5.225-.092zm16.406-5.008c1.591.036 3.17.16 4.74.42-1.267 1.674-1.649 3.631-2.099 5.63-.478-2.258-2.209-4.362-3.734-6.048zm-3.498 1.074c.234-.158 4.457 5.086 5.066 5.556-3.312-.008-6.618-.17-9.926-.315 1.907-1.487 3.023-3.688 4.86-5.24m2.686 17.095c-.401 1.349-.777 2.708-1.214 4.047-1.555-4.732-3.862-9.188-6.008-13.674 3.34.088 6.676.209 10.016.256-.82 3.158-1.862 6.245-2.794 9.37m7.23-17.462c1.277 1.128 3.097 3.44 3.686 4.217a10 10 0 0 0 .179.23c.21.261.966 1.255 1.263 1.644-2.227-.226-4.545-.13-6.78-.15.498-2.054 1.104-4.012.584-6.128q.536.086 1.068.187m7.648 5.617c-2.158-2.676-4.37-7.258-7.864-8.077-3.472-.814-7.548-.454-11.074-.23-3.075.194-8.083-.204-10.795 1.593-1.393.923-2.425 3.005-2.908 4.551-.434 1.393.266 2.285-1.246 2.285-.096 0 2.504 3.673 2.81 3.962 2.272 2.14 4.444 4.202 6.457 6.597 2.835 3.374 5.405 8.338 9.145 9.736-.686-.339 2.792-2.967 3.21-3.419 2.11-2.288 4.246-4.554 6.372-6.83 1.938-2.073 4.05-4.03 5.93-6.15 1.435-1.619 1.439-2.175-.037-4.018"></path><path id="Fill-23" d="M6.999 12c.043.014-.909-2.045-.825-1.919-.475-.719-1.046-1.24-1.738-1.727C3.708 7.843.127 7.254 0 7c1.494 2.652 4.167 4.128 6.999 5"></path><path id="Fill-25" d="M22.355 7.196A6.2 6.2 0 0 0 23.15 9c.07.078.859-4.184.85-4.547C23.988 3.832 23.613 0 22.815 0c-1.337 0-.674 6.47-.459 7.196"></path><path id="Fill-27" d="M48.97 5c-2.992 0-9.68 5.854-8.908 9 .005.01.447-.35.35-.283l.057-.043c1.272-1.025 2.718-2.02 3.992-3.206.911-.85 1.987-1.612 2.816-2.54C47.362 7.832 49.263 5 48.97 5"></path></g></g></g>', 1)];
const gr = {
        render: function(a, e) {
            return r(), t("svg", null, [...pr])
        }
    },
    mr = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Pizza" fill-rule="evenodd" stroke-width="1"><g id="Group-2" fill="#FFF" transform="translate(112 59)"><path id="Fill-29" d="M30.933 24.391c-4.082 1.38-8.55 3.324-10.905 7.074-1.847 2.942-1.971-.455-4.55.593-2.508 1.019-1.822 5.223-2.733 7.301-.708-1.191-1.043-2.516-1.935-3.604a6.6 6.6 0 0 0 1.814-1.724c.156-.32-4.792.348-5.076.43-1.411.401-2.74.77-4.088 1.429a79 79 0 0 0 1.965-2.989q.31-1.02 1.108-.006c.748.036 1.178.357 1.962.177 2.915-.667 3.843-6.223.25-5.987a93 93 0 0 0 4.253-8.802c.502 4.291 6.08 2.813 7.719.525 2.14-2.989-.604-8.662-4.484-8.112.581-1.375 1.17-2.762 1.65-4.178 1.092 1.61 3.001 2.39 4.538 3.457a18.2 18.2 0 0 1 4.163 4.006c2.386 3.14 3.793 7.007 6.215 10.052a7 7 0 0 0-1.866.358m9.006-4.388c-.632-5.757-5.15-11.601-9.44-15.176-2.55-2.125-10.24-7.385-13.306-3.34 2.472 1.071 5.2 1.33 7.65 2.489 3.32 1.572 5.922 4.16 8.168 7.055 3.137 4.045 7.97 12.283.474 14.386.518-.338.819-.709 1.228-1.308-1.007-.233-.6-1.878-.954-2.952-.412-1.25-1.21-2.467-1.884-3.582a57 57 0 0 0-3.504-5.171c-1.678-2.186-3.686-3.907-5.977-5.396-.907-.589-1.775-1.11-2.817-1.415-1.349-.394-.907.086-1.276-1.146-.232-.773-.024-1.763-.246-2.592-1.973 1.658-2.615 4.055-3.5 6.381-1.02 2.684-2.122 5.335-3.196 7.997-2.635 6.535-6.034 12.395-9.891 18.247-.672 1.02-2.165 2.95-1.09 4.174.96 1.095 2.33.306 3.386-.139 1.436-.604 3.385-2.164 4.935-1.347 1.998 1.054 1.054 4.984 4.214 4.827 3.114-.154 2.527-5.28 3.527-7.317 2.311 1.685 4.175.64 5.579-1.611 1.626-2.61 3.775-3.657 6.513-4.938 1.12-.524 3.034-1.94 4.2-2.115.966-.145 1.893.883 3.184.837 3.098-.113 4.392-4.253 4.023-6.848"></path><path id="Fill-31" d="M18.537 22.834c-2.425-.445-5.807-.074-6.029 3.153-.136 1.978 1.41 3.848 3.082 4.664 5.122 2.5 9.109-6.688 2.947-7.817"></path><path id="Fill-33" d="M28.336 19.158c-.65-.706-1.703-1.24-2.675-.993.31-.214.568-.6.864-.839-3.156-2.286-5.14 3.479-3.346 5.748 2.717 3.44 8.037-.766 5.157-3.916"></path></g></g></g>', 1)];
const Cr = {
        render: function(a, e) {
            return r(), t("svg", null, [...mr])
        }
    },
    vr = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Selena" fill-rule="evenodd" stroke-width="1"><g id="Selena" fill="#FFF" transform="translate(94 58)"><path id="Bom-Bom" d="M65.303 7.568c-.156.93-1.922 5.089-3.229 2.95-.509-.832.402-3.46.685-4.209.558-1.472.974-1.638 2.263-2.33.109 1.188.411 2.398.281 3.589m-2.984 3.319c.03.012.158.132 0 0m-.008-.007c-.006-.004 0 0 0 0M55.03 6.205c.01.008.053.042 0 0M42.555 11.16c-.207 1.22-.475 2.439-.904 3.6-.17-1.732.103-3.456 1-4.95q-.015.676-.096 1.35m-.01-2.502c-.004-.016-.159-.24 0 0M25.908 18.803c.153-1.533.768-3.017 1.906-4.044-.277 1.625-1.072 2.67-1.906 4.044m49.93-13.506c0 .637-2.06 2.335-2.574 2.803-.879.799-1.815 1.44-3.077 1.254-3.462-.51-2.09-4.206-2.641-6.481-.434-1.788-.879-1.114-2.082-1.227-1.118-.104-1.518-.656-2.682.187-2.096 1.519-3.766 3.496-4.659 5.98-.324-1.695-1.245-4.503-3.452-4.093-1.632.303-2.984 2.926-3.663 4.243-.052-1.198-.668-3.076-2.175-2.218-1.036.589-.991 3.381-1.218 4.41-.465 2.111-1.379 7.617-4.644 6.901 1.029-1.918 3.28-7.97 1.35-9.937-2.712-2.762-4.775 4.156-4.886 5.84-.08 1.205.806 3.944.329 4.692-.585.918-2.428 1.313-3.303.641-1.405-1.078-.85-2.83-.53-4.199.422-1.794.62-3.597.734-5.437.085-1.38 1.286-7.548-1.028-7.632-2.095-.075-2.309 5.138-2.458 6.563-.185 1.751-.296 3.525-.235 5.288.062 1.782.394 2.97-.297 4.643-.74 1.793-4.264 7.17-6.373 3.6 2.24-.983 4.911-5.518 3.71-8.067-1.667-3.534-5.416 1.85-5.96 3.656-.877 2.915-.491 6.722 2.864 7.671 3.493.989 6.19-2.286 7.421-5.18 1.002 1.588 2.845 1.986 4.55 1.505a5.8 5.8 0 0 0 1.89-.947c1.07-.81.444-.509 1.58-.542 3.297-.094 5.096-1.153 6.332-4.545-.015.934.343 2.36 1.598 1.849.974-.397.968-2.01 1.148-2.87.57-2.713 1.466-5.541 3.599-7.422 1.84 2.002.48 5.427 1.69 7.56 1.868 3.288 2.808-2.532 3.1-3.654.057 4.882 5.861 3.084 7.118-.157 3.3 3.515 10.234.349 8.923-4.678"></path><path id="Bidi" d="M69.434 15.349c-3.63 0-7.605 1.026-11.127 1.817a98 98 0 0 0-10.502 2.97c-3.871 1.339-7.812 2.554-11.59 4.122-3.276 1.36-7.508 2.353-9.512 5.416-.004.008 2.102-.088 2.272-.117 1.05-.174 1.952-.543 2.917-.956 1.747-.746 3.482-1.519 5.224-2.276 3.904-1.698 7.98-3.095 11.988-4.554 3.996-1.453 8.095-2.685 12.255-3.625 3.39-.767 7.182-.914 10.303-2.273q-.176.066.23-.091c-.079.038-2.221-.433-2.458-.433m-47.317 5.476c-2.27-.998-5.477-.558-7.835-.239-2.143.29-5.496.935-6.833 1.108-1.106.14-4.406 1.04-5.01-.197-.649-1.331 2.72-5.403 3.456-6.363 3.315-4.32 7.3-9.12 12.08-11.923-.44 1.95-.825 3.918-1.227 5.876-.166.808-.95 5.164.486 5.508.59.14 1.772-2.783 1.87-3.044.823-2.19 1.012-4.71 1.391-7.002.217-1.311 1.2-4.05-.694-4.502-1.629-.389-3.836 1.727-4.923 2.619-3.282 2.692-6.127 5.947-8.787 9.22-1.31 1.613-2.615 3.234-3.714 4.997-.904 1.45-3.09 4.49-2.145 6.282 1.698 3.221 9.84.398 12.432-.032 2.045-.339 4.152-.66 6.227-.376 2.162.295 2.057 1.27 1.339 3.196-1.478 3.96-4.776 7.36-7.724 10.32-1.299 1.303-6.38 7.419-7.66 4.091-.87-2.26-.1-5.035.9-7.114.468-.973 1.089-1.861 1.577-2.824.133-.263.802-2.425.947-2.473-3.87 1.35-6.117 6.585-6.332 10.287-.102 1.741.136 4.324 1.8 5.368s3.226-.227 4.549-1.185c3.642-2.64 6.891-5.998 9.865-9.335 1.626-1.824 8.453-10.287 3.965-12.263"></path></g></g></g>', 1)];
const Mr = {
        render: function(a, e) {
            return r(), t("svg", null, [...vr])
        }
    },
    Hr = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Skull-Outline" fill-rule="evenodd" stroke-width="1"><g id="Skull" fill="#FFF" transform="translate(113 59)"><path id="Boo!" d="M36.335 17.04c-.18 1.038-.442 2.069-.988 2.989-.72 1.211-2.026 1.707-2.783 2.818-1.193 1.752.392 4.276-.786 5.837-1.266 1.68-4.142.663-5.262 2.892-1.18 2.35.538 5.492-.943 7.83-1.47-.37-1.922-5.886-4.189-2.367-1.452 2.254-.471 3.475-2.649.235-.756-1.125-1.61-2.136-3.096-1.393-1.043.521-1.258 2.837-2.21 3.086-2.333.612-2.418-5.617-3.212-6.796-.436-.648-.842-1.032-1.617-1.277-.672-.213-1.869.215-2.425-.1-1.045-.592-1.186-2.556-1.225-3.598-.074-1.939.575-3.919.04-5.838-.451-1.612-1.887-2.603-2.357-4.183C.1 8.64 11.683 3.895 18.3 3.63c7.74-.31 19.037 4.222 18.036 13.41m1.838-5.316c-1.456-3.441-4.655-6.177-7.915-8.013a18.5 18.5 0 0 0-5.085-1.94c-1.641-.36-3.558-.123-5.125-.576C18.728.812 17.91-.048 16.356.002c-2.118.068-4.319 1.172-6.168 2.086-3.66 1.807-6.771 4.148-8.726 7.743-2.098 3.859-1.9 7.356.349 10.952 2.145 3.434-.974 8.262 2.167 11.526C5.3 33.68 6.6 32.68 7.85 33.34c.962.508.921 3.462 1.188 4.328 1.2 3.893 5.514 5.4 7.506 1.191.94 2.353 4.655 4.764 6.385 1.686 1.082 1.4 2.954 1.995 4.383.795 1.344-1.128 1.492-3.755 1.56-5.343.054-1.238-.497-2.764.454-3.658 1.047-.984 3.194-.57 4.37-1.839 1.34-1.45.789-3.146.892-4.872.104-1.746.416-1.301 1.71-2.562 2.885-2.81 3.374-7.807 1.875-11.343"></path><path id="Boo!" d="M14.42 28.121c2.02-1.822 1.591-7.397 1.424-9.959-.316-4.86-3.355-3.408-5.206-.38-1.4 2.29-4.766 5.994-3.257 8.876 1.202 2.296 5.18 3.136 7.039 1.463m13.37-8.847c-1.034-1.92-1.42-2.212-2.65-3.785-.791-1.011-1.9-2.802-3.404-2.442-2.582.62-1.528 6.612-1.498 8.402.024 1.358-.277 2.765.851 3.728 1.155.986 3.053.897 4.44.69 4.259-.633 4.062-3.253 2.262-6.593M19.24 31.83c-.284-.036.077-.362.12-.587.187.614.326.643-.12.587m1.045-4.31c-2.617-2.77-7.574 6.397-4.08 7.425.805.237 1.4-.363 2.155-.468 1.1-.153 2.024.487 2.973-.522 1.491-1.584.187-5.098-1.048-6.436"></path></g></g></g>', 1)];
const Sr = {
        render: function(a, e) {
            return r(), t("svg", null, [...Hr])
        }
    },
    kr = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Bear" fill-rule="evenodd" stroke-width="1"><defs><path id="poly-1" d="M47.892.43v41.49H.453V.43z"></path></defs><g id="Group-76" transform="translate(108 59)"><path id="Fill-74" fill="#FFF" d="M34.447 31.586c-.479 2.816-4.08 7.345-7.147 4.384-3.467-3.344 4.225-4.81 1.481-7.594-1.184-1.2-4.412-.537-6.002-.41-1.49.117-3.866.454-3.296 2.624.433 1.65 1.71.944 2.389 1.892.535.748.308 3.507-.49 4.267-1.002.956-2.189.663-3.584.05-3.192-1.4-4.677-5.312-2.575-8.216 4.155-5.741 20.067-7.059 19.224 3.003M14.985 14.724c.985-.443 2.148-.203 2.732.787.802 1.356-.357 3.173-1.975 2.956-1.707-.23-2.57-2.919-.757-3.743m17.962 1.655c-.856 3.006-5.636-.378-2.936-2.29 1.552-1.099 3.447.491 2.936 2.29m14.88 6.79c-.236-2.38-.9-4.646-2.088-6.73-.623-1.093-1.393-2.111-2.19-3.081-.3-.365-.906-1.008-1.023-1.213-.709-1.24-.638-.362-.247-1.785.616-2.243 1.947-4.08.884-6.49-.99-2.24-3.655-3.293-5.984-3.426a8.2 8.2 0 0 0-3.207.449c-1.035.368-2.001 1.64-2.9 1.9-.698.204-2.685-.46-3.441-.508-1.395-.089-2.798-.05-4.192.034-1.63.096-5.376 1.263-6.913.877-1.015-.255-2.209-1.781-3.381-2.164C11.853.61 10.467.468 9.178.954c-2.285.864-4 3.552-4.053 5.942-.028 1.255.655 2.115.79 3.25.203 1.716.437.357-.487 1.726-.47.697-1.295 1.31-1.824 1.982C.779 17.44-.28 22.732.974 27.074c3.159 10.94 13.668 15.394 24.44 14.793 9.25-.516 23.564-7.718 22.413-18.698"></path></g></g></g>', 1)];
const yr = {
        render: function(a, e) {
            return r(), t("svg", null, [...kr])
        }
    },
    Fr = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Deer" fill="#FFF" fill-rule="evenodd"><path id="oh,-deer!" d="M76.96 16.235c.395 1.425-2.228 2.67-3.106 3.419-1.507 1.283-3.065 2.634-4.825 3.547-.748.388-1.553.703-2.362.935-1.247.357-1.104.107-1.58 1.165-.838 1.86-1.055 4.334-1.812 6.312-1.704 4.454-5.767 14.8-12.267 10.259-2.068-1.445-3.197-4.247-4.36-6.436-1.335-2.512-2.613-5.508-3.381-8.25-.375-1.336-.137-1.79-1.13-2.415-.622-.392-1.679-.493-2.383-.78-1.5-.61-2.813-1.436-4.088-2.43-1.238-.966-6.11-4.951-2.132-5.691 1.825-.34 4.217-.214 6.067-.12 2.027.102 4.073.57 5.876 1.535 1.841.987 1.301.701 3.21.15-3.322-1.126-6.649-2.998-8.884-5.781-1.207-1.503-4-7.654-1.9-9.065 2.52-1.696 2.73 5.346 3.439 6.567 1.592 2.744 4.508 3.78 7.042 5.299-1.74-1.668-3.04-3.505-3.673-5.868-.275-1.025-1.026-3.489-.519-4.486.529-1.04 1.772-1.106 2.458-.22.618.797.462 2.63.674 3.591.35 1.589.921 2.81 1.982 4.04 1.505 1.747 3.417 3.175 5.669 3.728 5.127 1.258 6.92-4.108 7.608-8.245.168-1.013-.08-2.693 1.05-3.18 1.367-.588 1.896.747 1.936 1.782.087 2.314-1.056 5.857-2.166 7.845 2.79-1.732 5.003-4.478 5.899-7.688.33-1.188.062-3.836 1.174-4.503 1.54-.924 2.029.917 1.975 2.022-.319 6.515-5.298 12.44-11.488 14.069 1.518.759 1.318.93 2.848.023.885-.525 1.845-.93 2.827-1.23 1.47-.452 3.055-.682 4.58-.817 1.22-.107 5.274-.817 5.742.917m-18.1 8.386c.86-2.138-2.496-2.216-2.822.095-.416 2.945 2.755 3.176 2.822-.095m-1.93 9.016c.659-2.196-3.526-2.112-3.896-.17-.436 2.291 3.406 1.73 3.896.17M51.702 27c2.324 0 3.272-3.065.997-3.861-2.89-1.013-3.815 3.861-.997 3.861" transform="translate(77 58)"></path></g></g>', 1)];
const Lr = {
        render: function(a, e) {
            return r(), t("svg", null, [...Fr])
        }
    },
    wr = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Hola" fill="#FFF" fill-rule="evenodd"><path id="Hola" d="M74.637 16.948c1.28 5.762-.904 11.244-5.33 15.004-2.08 1.768-4.434 3.074-7.056 3.835a25 25 0 0 1-4.497.87c-1.136.111-2.784-.4-3.79-.111-1.12.321-2.559 1.865-3.757 2.362a20 20 0 0 1-2.068.727c-1.506.438-3.065.734-4.613.977-1.602.25-8.283 1.302-7.455-1.637.284-1.01 3.11-2.504 3.724-3.184.454-.502 3.145-3.364 3.019-4.295-.04-.294-1.747-1.63-2.148-2.08-.909-1.019-1.762-2.058-2.245-3.351-.829-2.216-.786-4.998-.51-7.32.688-5.804 3.566-9.659 8.602-12.55 2.855-1.637 5.96-2.538 9.205-2.934 3.956-.483 7.11-.498 10.467 1.75 4.42 2.96 7.275 6.668 8.452 11.937m-5.131 6.988c1.086-.3-.308-3.053-1.079-1.72-.277.48.463 1.889 1.079 1.72m-1.821-5.322c.088.36.434.47.748.427.75-.104.28-.981.301-1.373.04-.749.107-2.639-.172-3.32-.513-1.254-.975-1.014-1.274.214-.267 1.1.123 2.947.397 4.052m-1.048 4.279c.843-.498-1.38-6.176-1.868-6.988-1.892-3.145-2.504 2.431-2.794 3.81-.125.596-1.518 6.781.339 4.787.99-1.064-.558-4.602 2.243-3.78.984.29.272.207.874 1.11.22.33.458 1.5 1.206 1.06Zm-6.342-1.294c.786-1.35-2.665-.721-3.062-.697.094-1.8.445-3.623.44-5.422 0-.475.165-2.191-.958-1.381-.454.327-.298 1.83-.336 2.28-.09 1.057-.948 4.707-.108 5.56.595.603 3.693.22 4.024-.34m-4.799-2.44c.338-1.344-.084-4.253-1.845-4.28-.613-.008-.335.831-.487.92-1.065.621-1.528.542-2.16 1.646-2.486 4.35 3.067 7.445 4.492 1.714m-6.027 3.83c.761-.21.546-9.977-.331-9.983-1.51-.008-.063 4.84-.635 5.49-.17.196-1.026.015-1.25.056-1.14.212-1.89.092-2.24-.606-.312-.62.36-4.88-1.258-2.79q.023 1.107.035 2.213.504 1.072-.376 1.306c-.03.47.392.864.397 1.017.025.771-.484 4.231.9 4.064.885-.107.32-3.481.317-4.03 1.143.027 2.34.155 3.475.008.006.427-.288 3.603.966 3.256ZM63.837 17A19 19 0 0 1 65 18.842q-.999.086-2 .158c.272-.668.544-1.335.837-2m-9.914 0c.145.423.256 3.288-1.355 2.976-.92-.177-.507-1.764-.246-2.091.55-.69.873-.448 1.601-.885" transform="translate(77 58)"></path></g></g>', 1)];
const xr = {
        render: function(a, e) {
            return r(), t("svg", null, [...wr])
        }
    },
    Br = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Resist" fill-rule="evenodd" stroke-width="1"><g id="Resist" fill="#FFF" transform="translate(80 67)"><path id="!" d="M102.565 21.071c-3.082-.666-5.192 3.535-1.912 4.784 2.815 1.072 4.845-4.145 1.912-4.784"></path><path id="H" d="M101.191 18c3.657 0 2.308-5.981 2.321-7.965.014-2.137 1.545-8.596-.89-9.734-4.216-1.971-3.06 6.325-3.034 7.968.028 1.816.167 3.72-.229 5.508-.35 1.58-1.129 4.223 1.832 4.223"></path><path id="C" d="M96.058 1.974c-1.082-.622-2.801-.32-3.987-.374-1.349-.06-2.69-.195-4.035-.293-2.177-.16-4.956-.563-7.118-.068-1.226.28-2.338 1.225-1.761 2.608.62 1.49 2.303 1.105 3.58 1.03.585-.035 2.033-.29 2.605-.089.997.35.573-.108.801 1.067.349 1.807.14 4 .125 5.838-.026 3.174-.036 6.364-.103 9.536-.026 1.236-.44 2.632.757 3.448.998.68 2.216.225 2.733-.793.514-1.013.026-3.067-.029-4.196-.066-1.347-.136-2.676-.097-4.025.104-3.585.282-7.167.368-10.754.943.046 1.922.018 2.856.15.683.095 1.665.535 2.322.5 1.9-.1 2.694-2.587.983-3.585"></path><path id="A" d="M67.722 8.813c-.012-.053-.082-.644 0 0m-.037-.276c.004.025 0 .008 0 0m1.432-3.11c3.416-3.981 4.583 4.347 7.246 3.995 4.26-.564-.941-6.953-2.669-7.776-3.515-1.675-6.605.08-8.277 3.267-2.098 4-.77 6.708 3.258 8.444 1.471.635 7.04 2.528 5.53 4.959-.76 1.224-3.526 1.329-4.7 1.086-2.356-.486-1.989-2.086-3.135-3.573-1.033-1.34-3.03-.947-3.342.781-.245 1.358 1.17 3.425 2.115 4.38 2.233 2.256 6.04 2.437 8.887 1.41 4.386-1.583 4.917-5.71 1.806-8.905-1.749-1.795-3.933-2.34-6.113-3.418-2.645-1.306-2.15-2.39-.606-4.65"></path><path id="E" d="M58.75 20.568c-.564-4.825-.696-9.717-.78-14.563-.027-1.554.706-5.206-1.453-5.865-2.915-.89-2.528 2.692-2.467 4.164.205 4.913.842 9.789 1.071 14.696.073 1.557-.429 4.574 1.831 4.946 2.75.454 2.008-2.081 1.798-3.378"></path><path id="P" d="M49.472 4.68c-2.36-3.159-7.154-3.669-10.09-.758-2.072 2.054-3.377 6.92-1.416 9.403 2.124 2.691 7.355.332 8.725 3.383 1.682 3.743-2.73 5.148-5.074 2.663-.843-.894-.659-2.454-1.9-3.007-1.763-.785-2.864.928-2.517 2.359.848 3.5 4.652 5.39 8.101 5.272 3.768-.13 5.402-2.977 5.163-6.4-.33-4.735-3.985-5.476-7.99-5.998-1.698-.22-1.92-.2-1.816-1.952.128-2.118 1.37-4.567 3.991-4.063 2.106.405 2.294 3.571 4.455 3.718 3.496.239 1.256-3.433.368-4.62"></path><path id="M" d="M31.721 20.438c-1.337.32-2.963.098-4.327.073-1.053-.019-4.574.427-5.261-.296-.76-.8-.513-3.247-.545-4.286-.046-1.454-.404-1.67.872-2 .749-.193 1.907-.096 2.682-.131 1.515-.07 3.465.21 4.93-.088 1.37-.28 2.502-1.751 1.25-3.004-.886-.888-2.542-.411-3.631-.386-2.034.046-4.069.036-6.103.072.008-1.568-.043-3.147.079-4.71 2.847.14 5.812.881 8.659.745 1.44-.07 3.04-.992 2.31-2.73-.624-1.49-2.521-1.287-3.843-1.346-1.653-.075-3.308-.113-4.962-.17-1.224-.042-3.005-.445-4.159.107-2.362 1.13-1.55 5.01-1.485 7.112.084 2.666.085 5.268.177 7.956.084 2.433-.037 5.641 2.852 6.325 2.89.684 6.245.033 9.192.176 1.209.058 2.861.41 3.455-.996.569-1.349-.73-2.774-2.142-2.423"></path><path id="I" d="M8.41 5.88c2.321.5 2.942 3.014 3.02 5.149.054 1.46.183 1.373-1.003 1.74-1.19.368-2.92.169-4.139.116-2.543-.11-2.235-.278-2.284-2.945-.012-.625-.475-3.504-.108-3.91.476-.528 3.839-.203 4.514-.15m5.077 14.838c-1.29-1.504-2.586-2.94-4.034-4.286 2.158-.06 4.503-.473 5.27-2.819.648-1.982.085-5-.668-6.872-.994-2.47-3.062-4.119-5.635-4.478-1.796-.251-6.278-.673-7.62.71C-.665 4.482.352 8.623.442 10.47c.16 3.271.044 6.518-.157 9.785-.064 1.055-.582 2.787-.041 3.737.6 1.054 2.059 1.317 2.969.537.984-.844.529-1.878.468-2.961-.093-1.676.075-3.404.174-5.074 1.608 1.312 3.25 2.591 4.762 4.022 1.493 1.414 2.564 3.202 3.99 4.627 1.011 1.01 2.82 1.425 3.331-.448.44-1.608-1.571-2.951-2.451-3.977"></path></g></g></g>', 1)];
const zr = {
        render: function(a, e) {
            return r(), t("svg", null, [...Br])
        }
    },
    Tr = [e('<g id="Clothing/Graphic-Shirt" transform="translate(0 170)"><defs><path id="react-path-1153" d="M165.624 29.268C202.76 32.138 232 63.18 232 101.052V110H32v-8.948c0-38.217 29.775-69.48 67.393-71.855A14 14 0 0 0 99 32.5C99 44.374 113.998 54 132.5 54S166 44.374 166 32.5c0-1.098-.128-2.178-.376-3.232"></path></defs><mask id="react-mask-1154" fill="#fff"><use href="#react-path-1153"></use></mask><use id="Clothes" fill="#E6E6E6" fill-rule="evenodd" href="#react-path-1153"></use><g id="Color/Palette/" fill="var(--avataaar-shirt-color)" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Color" d="M0 0h264v110H0z"></path></g><g id="Clothing/Graphic/Skull" fill="#FFF" fill-rule="evenodd" mask="url(#react-mask-1154)"><path id="Fill-49" d="M65.282 19.929c-.298 2.777-5.693 4.274-7.672 2.448-.912-.842-.927-2.574-1.128-3.702-.38-2.133-.656-4.258-.751-6.423-.058-1.325-.406-2.385 1.044-2.582.883-.12 1.793.468 2.515.933 2.447 1.573 6.33 6.138 5.992 9.326m-12.4-5.853c.284 2.825 1.32 7.739-.936 10.105-2.016 2.115-6.16.018-6.783-2.473-.773-3.09 2.275-6.78 4.145-8.87.574-.641 1.844-2.412 2.836-1.82.382.228.693 2.612.737 3.058m1.44 11.03c.647-1.523 6.913 3.019 3.953 5.18-.482.352-4.16 1.465-4.864.941-1.485-1.103.43-4.964.911-6.12m19.004-7.58c-.443-15.476-20.26-19.84-30.85-11.023-4.048 3.372-6.362 7.5-6.468 12.779-.09 4.471.619 8.689 4.034 11.764 1.481 1.333 2.46 2.149 3.245 3.97.824 1.906 1.2 4.335 2.742 5.833.85.825 2.09 1.492 3.266.96 2.162-.98 1.47-3.978 2.125-5.65 2.037 4.97 7.211 6.554 8.15.25 1.031 1.819 3.726 4.2 5.7 2.21.812-.82.934-2.15 1.072-3.227.245-1.912-.18-2.664 1.355-3.975 4.039-3.45 5.773-8.672 5.63-13.891" transform="translate(77 58)"></path></g></g>', 1)];
const Er = {
        Bat: dr,
        Cumbia: ur,
        Diamond: gr,
        Pizza: Cr,
        Selena: Mr,
        SkullOutline: Sr,
        Bear: yr,
        Deer: Lr,
        Hola: xr,
        Resist: zr,
        Skull: {
            render: function(a, e) {
                return r(), t("svg", null, [...Tr])
            }
        }
    },
    Or = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Eyes/Closed",
        opacity: ".6",
        transform: "translate(0 8)"
    }, [i("path", {
        id: "Closed-Eye",
        d: "M16.16 32.447C18.007 28.65 22.164 26 26.998 26c4.816 0 8.961 2.63 10.817 6.407.552 1.122-.233 2.04-1.024 1.36-2.451-2.107-5.932-3.423-9.793-3.423-3.74 0-7.124 1.235-9.56 3.228-.891.728-1.818-.014-1.278-1.125m58 0C76.007 28.65 80.164 26 84.998 26c4.816 0 8.961 2.63 10.817 6.407.552 1.122-.233 2.04-1.024 1.36-2.451-2.107-5.932-3.423-9.793-3.423-3.74 0-7.124 1.235-9.56 3.228-.891.728-1.818-.014-1.278-1.125",
        transform: "matrix(1 0 0 -1 0 60)"
    })])], -1)];
const Ar = {
        render: function(a, e) {
            return r(), t("svg", null, [...Or])
        }
    },
    Nr = [i("g", {
        class: "CustomColor",
        opacity: ".6",
        transform: "translate(76 90)"
    }, [i("circle", {
        id: "Eye",
        cx: "30",
        cy: "22",
        r: "6"
    }), i("circle", {
        id: "Eye",
        cx: "82",
        cy: "22",
        r: "6"
    })], -1)];
const Vr = {
        render: function(a, e) {
            return r(), t("svg", null, [...Nr])
        }
    },
    qr = [e('<g transform="translate(76 82)"><g id="Eyes/Eye-Roll" transform="translate(0 8)"><circle id="Eyeball" cx="30" cy="22" r="14" fill="#FFF"></circle><circle id="The-white-stuff" cx="82" cy="22" r="14" fill="#FFF"></circle><circle cx="30" cy="14" r="6" class="CustomColor" opacity=".7"></circle><circle cx="82" cy="14" r="6" class="CustomColor" opacity=".7"></circle></g></g>', 1)];
const Dr = {
        render: function(a, e) {
            return r(), t("svg", null, [...qr])
        }
    },
    br = [i("g", {
        fill: "#FF5353",
        class: "CustomColor",
        opacity: ".8",
        transform: "translate(76 90)"
    }, [i("path", {
        id: "Heart",
        d: "M35.958 10c-2.55 0-5.074 1.98-6.458 3.82-1.39-1.84-3.907-3.82-6.458-3.82C17.552 10 14 13.334 14 17.641c0 5.73 4.412 9.13 9.042 12.736 1.653 1.236 4.78 4.4 5.166 5.094.386.693 2.106.718 2.584 0 .477-.718 3.51-3.858 5.166-5.094C40.585 26.77 45 23.37 45 17.64c0-4.306-3.552-7.64-9.042-7.64m53 0c-2.55 0-5.074 1.98-6.458 3.82-1.39-1.84-3.907-3.82-6.458-3.82C70.552 10 67 13.334 67 17.641c0 5.73 4.412 9.13 9.042 12.736 1.653 1.236 4.78 4.4 5.166 5.094.386.693 2.106.718 2.584 0 .477-.718 3.51-3.858 5.166-5.094C93.585 26.77 98 23.37 98 17.64c0-4.306-3.552-7.64-9.042-7.64"
    })], -1)];
const Wr = {
        render: function(a, e) {
            return r(), t("svg", null, [...br])
        }
    },
    Gr = [e('<g transform="translate(76 82)"><g id="Eyes/Squint" transform="translate(0 8)"><defs><path id="Eye1" d="M14 14.048c9.61 0 14 4.451 14-2.486C28 4.624 21.732 0 14 0S0 4.624 0 11.562s4.39 2.486 14 2.486"></path><path id="Eye2" d="M14 14.048c9.61 0 14 4.451 14-2.486C28 4.624 21.732 0 14 0S0 4.624 0 11.562s4.39 2.486 14 2.486"></path></defs><g id="Eye" transform="translate(16 13)"><mask id="EyeMask1" fill="#fff"><use href="#Eye1"></use></mask><use id="The-white-stuff" fill="#FFF" href="#Eye1"></use><circle cx="14" cy="10" r="6" class="CustomColor" mask="url(&#39;#EyeMask1&#39;)" opacity=".7"></circle></g><g id="Eye" transform="translate(68 13)"><mask id="EyeMask2" fill="#fff"><use href="#Eye2"></use></mask><use id="Eyeball-Mask" fill="#FFF" href="#Eye2"></use><circle cx="14" cy="10" r="6" class="CustomColor" mask="url(&#39;#EyeMask2&#39;)" opacity=".7"></circle></g></g></g>', 1)];
const Pr = {
        render: function(a, e) {
            return r(), t("svg", null, [...Gr])
        }
    },
    jr = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Eyes/Wink",
        opacity: ".6",
        transform: "translate(0 8)"
    }, [i("circle", {
        id: "Eye",
        cx: "30",
        cy: "22",
        r: "6"
    }), i("path", {
        id: "Winky-Wink",
        d: "M70.412 24.205c1.847-3.799 6.005-6.447 10.838-6.447 4.816 0 8.961 2.63 10.818 6.407.551 1.122-.234 2.04-1.025 1.36-2.451-2.108-5.932-3.424-9.793-3.424-3.74 0-7.124 1.235-9.56 3.228-.891.729-1.818-.013-1.278-1.124",
        transform: "rotate(-4 81.252 21.758)"
    })])], -1)];
const Rr = {
        render: function(a, e) {
            return r(), t("svg", null, [...jr])
        }
    },
    Zr = [e('<g transform="translate(76 82)"><g id="Eyes/Cry" transform="translate(0 8)"><circle cx="30" cy="22" r="6" class="CustomColor" opacity=".6"></circle><path id="Drop" fill="#92D9FF" d="M25 27s-6 7.27-6 11.27a6 6 0 1 0 12 0c0-4-6-11.27-6-11.27"></path><circle cx="82" cy="22" r="6" class="CustomColor" opacity=".6"></circle></g></g>', 1)];
const Ur = {
        render: function(a, e) {
            return r(), t("svg", null, [...Zr])
        }
    },
    Qr = [i("g", {
        class: "CustomColor",
        opacity: ".6",
        transform: "translate(76 90)"
    }, [i("path", {
        id: "Eye",
        d: "m29 25.2 5.5 5.5c.5.4 1.2.4 1.6 0l1.6-1.6c.4-.5.4-1.2 0-1.6L32.2 22l5.5-5.5c.4-.5.4-1.2 0-1.6l-1.6-1.6c-.5-.4-1.2-.4-1.6 0L29 18.8l-5.5-5.5c-.5-.4-1.2-.4-1.6 0l-1.6 1.6c-.4.4-.4 1.1 0 1.6l5.5 5.5-5.5 5.5c-.4.5-.4 1.2 0 1.6l1.6 1.6c.5.4 1.2.4 1.6 0zm54 0 5.5 5.5c.5.4 1.2.4 1.6 0l1.6-1.6c.4-.5.4-1.2 0-1.6L86.2 22l5.5-5.5c.4-.5.4-1.2 0-1.6l-1.6-1.6c-.5-.4-1.2-.4-1.6 0L83 18.8l-5.5-5.5c-.5-.4-1.2-.4-1.6 0l-1.6 1.6c-.4.4-.4 1.1 0 1.6l5.5 5.5-5.5 5.5c-.4.5-.4 1.2 0 1.6l1.6 1.6c.5.4 1.2.4 1.6 0z"
    })], -1)];
const _r = {
        render: function(a, e) {
            return r(), t("svg", null, [...Qr])
        }
    },
    Ir = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Eyes/Happy",
        opacity: ".6",
        transform: "translate(0 8)"
    }, [i("path", {
        id: "Squint",
        d: "M16.16 22.447C18.007 18.65 22.164 16 26.998 16c4.816 0 8.961 2.63 10.817 6.407.552 1.122-.233 2.04-1.024 1.36-2.451-2.107-5.932-3.423-9.793-3.423-3.74 0-7.124 1.235-9.56 3.228-.891.728-1.818-.014-1.278-1.125m58 0C76.007 18.65 80.164 16 84.998 16c4.816 0 8.961 2.63 10.817 6.407.552 1.122-.233 2.04-1.024 1.36-2.451-2.107-5.932-3.423-9.793-3.423-3.74 0-7.124 1.235-9.56 3.228-.891.728-1.818-.014-1.278-1.125"
    })])], -1)];
const Kr = {
        render: function(a, e) {
            return r(), t("svg", null, [...Ir])
        }
    },
    Yr = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Eyes/Side",
        opacity: ".6",
        transform: "translate(0 8)"
    }, [i("path", {
        id: "Eye",
        d: "M27.241 20.346a6 6 0 1 0 10.699 2.8 2 2 0 0 0-.125-.739 8 8 0 0 0-.144-.372 6 6 0 0 0-1.646-2.484C33.9 17.317 30.506 16 26.998 16c-4.834 0-8.991 2.649-10.838 6.447-.54 1.111.387 1.853 1.278 1.125 2.436-1.993 5.82-3.228 9.56-3.228zm58 0a6 6 0 1 0 10.699 2.8 2 2 0 0 0-.125-.739 8 8 0 0 0-.144-.372 6 6 0 0 0-1.646-2.484C91.9 17.317 88.506 16 84.998 16c-4.834 0-8.991 2.649-10.838 6.447-.54 1.111.387 1.853 1.278 1.125 2.436-1.993 5.82-3.228 9.56-3.228z"
    })])], -1)];
const Jr = {
        render: function(a, e) {
            return r(), t("svg", null, [...Yr])
        }
    },
    Xr = [e('<g transform="translate(76 82)"><g id="Eyes/Surprised" transform="translate(0 8)"><circle id="The-White-Stuff" cx="30" cy="22" r="14" fill="#FFF"></circle><circle id="Eye-Ball" cx="82" cy="22" r="14" fill="#FFF"></circle><circle cx="30" cy="22" r="6" class="CustomColor" opacity=".7"></circle><circle cx="82" cy="22" r="6" class="CustomColor" opacity=".7"></circle></g></g>', 1)];
const $r = {
        render: function(a, e) {
            return r(), t("svg", null, [...Xr])
        }
    },
    at = [e('<g transform="translate(76 82)"><g id="Eyes/Wink-Wacky" transform="translate(0 8)"><circle id="cornea" cx="82" cy="22" r="12" fill="#FFF"></circle><circle cx="82" cy="22" r="6" class="CustomColor" opacity=".7"></circle><path id="Winky-Doodle" fill="#000" d="M16.16 25.447C18.007 21.65 22.164 19 26.998 19c4.816 0 8.961 2.63 10.817 6.407.552 1.122-.233 2.04-1.024 1.36-2.451-2.107-5.932-3.423-9.793-3.423-3.74 0-7.124 1.235-9.56 3.228-.891.728-1.818-.014-1.278-1.125" opacity=".6"></path></g></g>', 1)];
const rt = {
        Close: Ar,
        Default: Vr,
        EyeRoll: Dr,
        Hearts: Wr,
        Squint: Pr,
        Wink: Rr,
        Cry: Ur,
        Dizzy: _r,
        Happy: Kr,
        Side: Jr,
        Surprised: $r,
        WinkWacky: {
            render: function(a, e) {
                return r(), t("svg", null, [...at])
            }
        }
    },
    tt = [i("g", {
        transform: "translate(76 82)"
    }, [i("path", {
        id: "Eyebrow/Outline/Angry",
        d: "M15.611 15.185c4.24-5.769 6.878-5.484 13.313-.629l.67.508C34.422 18.726 36.708 20 40 20a2 2 0 1 0 0-4c-2.066 0-3.901-1.022-7.989-4.123-.375-.285-.492-.373-.678-.513-3.76-2.837-5.959-4.077-8.695-4.372-3.684-.398-7.058 1.482-10.25 5.823a2 2 0 0 0 3.223 2.37m80.777 0c-4.24-5.769-6.877-5.484-13.312-.629l-.67.508C77.578 18.726 75.292 20 72 20a2 2 0 1 1 0-4c2.066 0 3.901-1.022 7.989-4.123.375-.285.492-.373.678-.513 3.76-2.837 5.959-4.077 8.695-4.372 3.684-.398 7.058 1.482 10.25 5.823a2 2 0 0 1-3.224 2.37",
        class: "CustomColor",
        opacity: ".6"
    })], -1)];
const et = {
        render: function(a, e) {
            return r(), t("svg", null, [...tt])
        }
    },
    it = [i("g", {
        transform: "translate(76 82)"
    }, [i("path", {
        id: "Eyebrow/Natural/Flat-Natural",
        d: "M38.66 11.09c-4.998.362-9.923.086-14.918-.122-3.83-.158-7.717-.681-11.374 1.012-.7.324-4.53 2.28-4.44 3.349.07.855 3.935 2.191 4.63 2.436 3.67 1.29 7.181.896 10.954.67 4.628-.278 9.236-.074 13.861-.214 3.116-.093 7.917-.62 9.457-4.398.464-1.137.105-3.413-.36-4.657-.185-.496-.72-.683-1.125-.397-1.45 1.023-4.261 2.146-6.685 2.321m34.68 0c4.998.362 9.923.086 14.918-.122 3.83-.158 7.717-.681 11.374 1.012.7.324 4.53 2.28 4.44 3.349-.07.855-3.935 2.191-4.63 2.436-3.67 1.29-7.181.896-10.954.67-4.628-.278-9.236-.074-13.861-.214-3.116-.093-7.917-.62-9.457-4.398-.464-1.137-.105-3.413.36-4.657.185-.496.72-.683 1.125-.397 1.45 1.023 4.261 2.146 6.685 2.321",
        class: "CustomColor",
        opacity: ".6"
    })], -1)];
const lt = {
        render: function(a, e) {
            return r(), t("svg", null, [...it])
        }
    },
    st = [i("g", {
        transform: "translate(76 82)"
    }, [i("path", {
        id: "Eyebrow/Outline/Sad-Concerned",
        d: "M38.028 5.591c-1.48 8.389-14.09 14.18-23.238 10.432-1.015-.416-2.19.031-2.627.999s.033 2.09 1.048 2.505c11.444 4.69 26.835-2.38 28.762-13.303.183-1.039-.551-2.023-1.64-2.197-1.09-.175-2.122.525-2.305 1.564m35.945 0c1.48 8.389 14.09 14.18 23.238 10.432 1.014-.416 2.19.031 2.627.999s-.033 2.09-1.048 2.505c-11.444 4.69-26.835-2.38-28.762-13.303-.183-1.039.551-2.023 1.64-2.197 1.09-.175 2.121.525 2.305 1.564",
        class: "CustomColor",
        opacity: ".6"
    })], -1)];
const ot = {
        render: function(a, e) {
            return r(), t("svg", null, [...st])
        }
    },
    ht = [i("g", {
        transform: "translate(76 82)"
    }, [i("path", {
        id: "Eyebrow/Natural/Up-Down-Natural",
        d: "m22.766 1.578.911-.402C28.92-.905 36.865-.033 41.723 2.299c.567.272.18 1.153-.402 1.108-14.919-1.151-24.963 8.146-28.375 14.44-.101.187-.407.208-.482.034-2.308-5.319 4.45-13.985 10.302-16.303M86.993 12.07c5.761.773 14.746 5.795 13.994 11.607-.024.19-.312.25-.436.091-2.487-3.188-21.712-7.872-28.714-6.894-.64.09-1.063-.571-.626-.984 3.744-3.535 10.62-4.518 15.782-3.82",
        class: "CustomColor",
        opacity: ".6"
    })], -1)];
const ct = {
        render: function(a, e) {
            return r(), t("svg", null, [...ht])
        }
    },
    nt = [i("g", {
        transform: "translate(76 82)"
    }, [i("path", {
        id: "Eyebrow/Natural/Angry-Natural",
        d: "M44.095 17.125q.006-.014 0 0M19.284 5.005c-2.368-.266-4.858.497-6.427 2.434-.59.728-1.553 2.48-1.509 3.417.017.356.225.375 1.124.59 1.646.392 4.5-1.114 6.355-.972 2.582.198 5.047 1.395 7.283 2.679 3.838 2.202 8.354 6.84 13.093 6.598.353-.018 5.42-1.739 4.41-2.723-.316-.484-3.034-1.128-3.501-1.361-2.172-1.084-4.367-2.448-6.443-3.718-4.528-2.772-8.944-6.338-14.385-6.944m48.746 12.12q-.006-.014 0 0m24.876-12.12c2.368-.266 4.857.497 6.426 2.434.59.728 1.554 2.48 1.509 3.417-.017.356-.225.375-1.124.59-1.645.392-4.5-1.114-6.355-.972-2.582.198-5.046 1.395-7.282 2.679-3.839 2.202-8.355 6.84-13.093 6.598-.353-.018-5.42-1.739-4.411-2.723.317-.484 3.034-1.128 3.502-1.361 2.171-1.084 4.367-2.448 6.442-3.718 4.528-2.772 8.945-6.338 14.386-6.944",
        class: "CustomColor",
        opacity: ".6"
    })], -1)];
const dt = {
        render: function(a, e) {
            return r(), t("svg", null, [...nt])
        }
    },
    ft = [i("g", {
        transform: "translate(76 82)"
    }, [i("path", {
        id: "Eyebrow/Natural/Frown-Natural",
        d: "M36.37 6.876c-1.97 2.905-5.546 4.64-8.738 5.684-3.943 1.29-18.552 3.38-15.112 11.348a.147.147 0 0 0 .272.002c1.153-2.645 17.465-5.123 18.973-5.704 4.445-1.709 8.393-5.49 9.162-10.543.352-2.317-.637-6.049-1.548-7.55-.11-.18-.374-.136-.43.069-.36 1.331-1.41 4.971-2.58 6.694m39.261 0c1.97 2.905 5.546 4.64 8.738 5.684 3.943 1.29 18.551 3.379 15.112 11.348a.147.147 0 0 1-.272.002c-1.153-2.645-17.465-5.123-18.973-5.704-4.445-1.709-8.393-5.49-9.162-10.543-.352-2.317.637-6.049 1.548-7.55.11-.18.374-.136.43.069.36 1.331 1.41 4.971 2.58 6.694",
        class: "CustomColor",
        opacity: ".6"
    })], -1)];
const ut = {
        render: function(a, e) {
            return r(), t("svg", null, [...ft])
        }
    },
    pt = [i("g", {
        transform: "translate(76 82)"
    }, [i("path", {
        id: "Eyebrow/Natural/Sad-Concerned-Natural",
        d: "m31.234 20.422-.911.402c-5.242 2.081-13.188 1.209-18.046-1.123-.567-.272-.18-1.153.402-1.108 14.919 1.151 24.963-8.146 28.375-14.44.101-.187.407-.208.482-.034 2.308 5.319-4.45 13.985-10.302 16.303m49.532 0 .911.402c5.242 2.081 13.188 1.209 18.046-1.123.567-.272.18-1.153-.402-1.108-14.919 1.151-24.963-8.146-28.375-14.44-.101-.187-.407-.208-.482-.034-2.308 5.319 4.45 13.985 10.302 16.303",
        class: "CustomColor",
        opacity: ".6"
    })], -1)];
const gt = {
        render: function(a, e) {
            return r(), t("svg", null, [...pt])
        }
    },
    mt = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Eyebrow/Outline/Default",
        opacity: ".6"
    }, [i("path", {
        id: "I-Browse",
        d: "M15.63 17.159c3.915-5.51 14.648-8.598 23.893-6.328a2 2 0 0 0 .954-3.884C29.74 4.31 17.312 7.887 12.37 14.84a2 2 0 0 0 3.26 2.318Zm80.74 0c-3.915-5.51-14.648-8.598-23.893-6.328a2 2 0 0 1-.954-3.884c10.737-2.637 23.165.94 28.108 7.894a2 2 0 0 1-3.26 2.318Z",
        class: "CustomColor"
    })])], -1)];
const Ct = {
        render: function(a, e) {
            return r(), t("svg", null, [...mt])
        }
    },
    vt = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Eyebrow/Outline/Raised-Excited",
        opacity: ".6"
    }, [i("path", {
        id: "I-Browse",
        d: "M15.976 17.128C17.47 7.605 30.059 1.108 39.164 5.3a2 2 0 0 0 1.672-3.633c-11.487-5.29-26.9 2.664-28.812 14.84a2 2 0 1 0 3.952.62Zm80.048 0C94.53 7.605 81.942 1.108 72.837 5.3a2 2 0 0 1-1.673-3.633c11.487-5.29 26.9 2.664 28.812 14.84a2 2 0 0 1-3.952.62Z",
        class: "CustomColor"
    })])], -1)];
const Mt = {
        render: function(a, e) {
            return r(), t("svg", null, [...vt])
        }
    },
    Ht = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Eyebrow/Natural/Unibrow-Natural",
        opacity: ".6"
    }, [i("path", {
        d: "M56.997 12.82q0-.005 0 0m2.559 2.805c1.892 1.101 4.717 1.734 6.315 1.94 6.277.807 12.266-1.535 18.386-2.68 5.432-1.015 11.625-1.925 16.73.91.13.072 1.162.667 1.707 1.184a.81.81 0 0 0 1.291-.224c1.325-2.726-6.402-8.594-7.865-9.153-6.627-2.528-15.176.704-21.796 2.001-3.717.728-7.462 1.252-11.115 2.29-1.31.373-2.58 1.007-3.862 1.218-.162-.224-.362-.36-.588-.352-1.17.04-2.796 3.557-.56 3.676.7.038 1.13-.312 1.357-.81",
        class: "CustomColor"
    }), i("path", {
        d: "M55.003 12.79q.002-.005 0 0M15.881 7.573c6.626-2.528 15.176.705 21.796 2.001 3.716.729 7.461 1.253 11.114 2.291 1.47.418 2.887 1.165 4.33 1.274.7.053 1.106.903.635 1.435-1.545 1.74-5.586 2.7-7.626 2.962-6.278.807-12.267-1.534-18.387-2.679-5.432-1.016-11.624-1.925-16.73.91-.13.071-1.161.666-1.707 1.184a.81.81 0 0 1-1.29-.224C6.69 14 14.417 8.133 15.881 7.573m39.092 4.217c1.17.041 2.762 4.5.525 4.674-2.237.173-1.696-4.715-.525-4.674",
        class: "CustomColor"
    })])], -1)];
const St = {
        render: function(a, e) {
            return r(), t("svg", null, [...Ht])
        }
    },
    kt = [i("g", {
        transform: "translate(76 82)"
    }, [i("path", {
        id: "Eyebrow/Natural/Default-Natural",
        d: "M26.547 6.148c-5.807.269-15.195 4.488-14.953 10.344.008.192.29.276.427.129 2.755-2.96 22.316-5.95 29.205-4.365.63.145 1.11-.477.71-.927-3.422-3.848-10.186-5.426-15.389-5.18m59.906-.001c5.807.269 15.195 4.488 14.953 10.344-.008.192-.29.276-.427.129-2.755-2.96-22.316-5.95-29.205-4.365-.63.145-1.11-.477-.71-.927 3.422-3.848 10.186-5.426 15.389-5.18",
        class: "CustomColor",
        opacity: ".6"
    })], -1)];
const yt = {
        render: function(a, e) {
            return r(), t("svg", null, [...kt])
        }
    },
    Ft = [i("g", {
        transform: "translate(76 82)"
    }, [i("path", {
        id: "Eyebrow/Natural/Raised-Excited-Natural",
        d: "m22.766 1.578.911-.402C28.92-.905 36.865-.033 41.723 2.299c.567.272.18 1.153-.402 1.108-14.919-1.151-24.963 8.146-28.375 14.44-.101.187-.407.208-.482.034-2.308-5.319 4.45-13.985 10.302-16.303m66.468 0-.911-.402C83.08-.905 75.135-.033 70.277 2.299c-.567.272-.18 1.153.402 1.108 14.919-1.151 24.963 8.146 28.375 14.44.101.187.407.208.482.034 2.308-5.319-4.45-13.985-10.302-16.303",
        class: "CustomColor",
        opacity: ".6"
    })], -1)];
const Lt = {
        render: function(a, e) {
            return r(), t("svg", null, [...Ft])
        }
    },
    wt = [i("g", {
        transform: "translate(76 82)"
    }, [i("path", {
        id: "Eyebrow/Outline/Up-Down",
        d: "M15.591 14.162c4.496-6.326 14.012-9.508 23.756-6.366a2 2 0 1 0 1.228-3.807c-11.408-3.68-22.74.11-28.244 7.856a2 2 0 1 0 3.26 2.317m80.786 6.996c-3.914-5.509-14.647-8.598-23.892-6.328a2 2 0 0 1-.954-3.884c10.736-2.637 23.165.94 28.107 7.895a2 2 0 1 1-3.26 2.317Z",
        class: "CustomColor",
        opacity: ".6"
    })], -1)];
const xt = {
        Angry: et,
        FlatNatural: lt,
        SadConcerned: ot,
        UpDownNatural: ct,
        AngryNatural: dt,
        FrownNatural: ut,
        SadConcernedNatural: gt,
        Default: Ct,
        RaisedExcited: Mt,
        UnibrowNatural: St,
        DefaultNatural: yt,
        RaisedExcitedNatural: Lt,
        UpDown: {
            render: function(a, e) {
                return r(), t("svg", null, [...wt])
            }
        }
    },
    Bt = [e('<g transform="translate(76 82)"><g id="Mouth/Concerned" transform="translate(2 52)"><defs><path id="Mouth1" d="M35.118 15.128C36.176 24.62 44.226 32 54 32c9.804 0 17.874-7.426 18.892-16.96.082-.767-.775-2.04-1.85-2.04H37.088c-1.08 0-2.075 1.178-1.97 2.128"></path></defs><mask id="MouthMask1" fill="#fff"><use href="#Mouth1" transform="matrix(1 0 0 -1 0 45)"></use></mask><use id="Mouth" fill="#000" href="#Mouth1" opacity=".7" transform="matrix(1 0 0 -1 0 45)"></use><rect id="Teeth" width="31" height="16" x="39" y="2" fill="#FFF" mask="url(&#39;#MouthMask1&#39;)" rx="5"></rect><g id="Tongue" fill="#FF4F6D" mask="url(&#39;#MouthMask1&#39;)"><g transform="translate(38 24)"><circle id="friend?" cx="11" cy="11" r="11"></circle><circle id="How-you-doing" cx="21" cy="11" r="11"></circle></g></g></g></g>', 1)];
const zt = {
        render: function(a, e) {
            return r(), t("svg", null, [...Bt])
        }
    },
    Tt = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Mouth/Disbelief",
        fill: "#000",
        opacity: ".7",
        transform: "translate(2 52)"
    }, [i("path", {
        id: "Mouth",
        d: "M40 15c0 7.732 6.268 14 14 14s14-6.268 14-14",
        transform: "matrix(1 0 0 -1 0 44)"
    })])], -1)];
const Et = {
        render: function(a, e) {
            return r(), t("svg", null, [...Tt])
        }
    },
    Ot = [e('<g transform="translate(76 82)"><g id="Mouth/Grimace" transform="translate(2 52)"><defs><rect id="Grimace-path1" width="60" height="22" x="24" y="9" rx="11"></rect></defs><rect id="Mouth" width="64" height="26" x="22" y="7" fill="#000" opacity=".6" rx="13"></rect><mask id="Grimace-mask1" fill="#fff"><use href="#Grimace-path1"></use></mask><use id="Mouth" fill="#FFF" href="#Grimace-path1"></use><path id="Grimace-Teeth" fill="#E6E6E6" d="M71 22h-9v12h-4V22h-9v12h-4V22h-9v12h-4V22h-8v-4h8V6h4v12h9V6h4v12h9V6h4v12h9V6h4v12h8.867v4H75v12h-4z" mask="url(&#39;#Grimace-mask1&#39;)"></path></g></g>', 1)];
const At = {
        render: function(a, e) {
            return r(), t("svg", null, [...Ot])
        }
    },
    Nt = [e('<g transform="translate(76 82)"><g id="Mouth/Scream-Open" transform="translate(2 52)"><defs><path id="ScreamOpen-path1" d="M34.008 15.136C35.128 29.124 38.235 40.993 53.996 41c15.762.007 18.92-11.943 19.998-25.994.087-1.13-.82-2.006-1.957-2.006-6.686 0-9.367 1.994-18.048 2s-13.232-2-17.897-2c-1.143 0-2.196.737-2.084 2.136"></path></defs><mask id="ScreamOpen-mask1" fill="#fff"><use href="#ScreamOpen-path1" transform="matrix(1 0 0 -1 0 54)"></use></mask><use id="Mouth" fill="#000" href="#ScreamOpen-path1" opacity=".7" transform="matrix(1 0 0 -1 0 54)"></use><rect id="Teeth" width="31" height="16" x="39" y="2" fill="#FFF" mask="url(&#39;#ScreamOpen-mask1&#39;)" rx="5"></rect><g id="Tongue" fill="#FF4F6D" mask="url(&#39;#ScreamOpen-mask1&#39;)"><g id="Say-ahhhh" transform="translate(38 32)"><circle cx="11" cy="11" r="11"></circle><circle cx="21" cy="11" r="11"></circle></g></g></g></g>', 1)];
const Vt = {
        render: function(a, e) {
            return r(), t("svg", null, [...Nt])
        }
    },
    qt = [e('<g transform="translate(76 82)"><g id="Mouth/Smile" transform="translate(2 52)"><defs><path id="Smile-path1" d="M35.118 15.128C36.176 24.62 44.226 32 54 32c9.804 0 17.874-7.426 18.892-16.96.082-.767-.775-2.04-1.85-2.04H37.088c-1.08 0-2.075 1.178-1.97 2.128"></path></defs><mask id="Smile-mask1" fill="#fff"><use href="#Smile-path1"></use></mask><use id="Mouth" fill="#000" href="#Smile-path1" opacity=".7"></use><rect id="Teeth" width="31" height="16" x="39" y="2" fill="#FFF" mask="url(&#39;#Smile-mask1&#39;)" rx="5"></rect><g id="Tongue" fill="#FF4F6D" mask="url(&#39;#Smile-mask1&#39;)"><g transform="translate(38 24)"><circle cx="11" cy="11" r="11"></circle><circle cx="21" cy="11" r="11"></circle></g></g></g></g>', 1)];
const Dt = {
        render: function(a, e) {
            return r(), t("svg", null, [...qt])
        }
    },
    bt = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Mouth/Twinkle",
        fill: "#000",
        opacity: ".6",
        transform: "translate(2 52)"
    }, [i("path", {
        id: "Mouth",
        d: "M40 16c0 5.372 6.158 9 14 9s14-3.628 14-9c0-1.105-.95-2-2-2-1.293 0-1.87.905-2 2-1.242 2.938-4.317 4.716-10 5-5.683-.284-8.758-2.062-10-5-.13-1.095-.707-2-2-2-1.05 0-2 .895-2 2"
    })])], -1)];
const Wt = {
        render: function(a, e) {
            return r(), t("svg", null, [...bt])
        }
    },
    Gt = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Mouth/Default",
        opacity: ".7",
        transform: "translate(2 52)"
    }, [i("path", {
        id: "Mouth",
        d: "M40 15c0 7.732 6.268 14 14 14s14-6.268 14-14"
    })])], -1)];
const Pt = {
        render: function(a, e) {
            return r(), t("svg", null, [...Gt])
        }
    },
    jt = [e('<g transform="translate(76 82)"><g id="Mouth/Eating" transform="translate(2 52)"><g id="Om-Nom-Nom" fill="#000" opacity=".6" transform="translate(28 6)"><path id="Delicious" d="M16.19 10.106C16.019 4.996 11.793.797 6.295 0 9.66 1.959 11.98 5.495 11.98 9.677c0 5.668-5.473 10.568-11.803 10.568H0A13 13 0 0 0 4.392 21c5.322 0 9.821-3.153 11.294-7.486 2.475 2.156 6.177 3.525 10.314 3.525s7.84-1.37 10.314-3.525C37.787 17.847 42.286 21 47.608 21c1.552 0 3.034-.268 4.392-.756l-.177.001c-6.33 0-11.803-4.9-11.803-10.568 0-4.182 2.32-7.718 5.686-9.677-5.498.797-9.724 4.996-9.897 10.106-2.564 1.736-6.014 2.8-9.809 2.8s-7.245-1.064-9.81-2.8"></path></g><circle id="Redish" cx="17" cy="15" r="9" fill="#FF4646" opacity=".2"></circle><circle id="Redish" cx="91" cy="15" r="9" fill="#FF4646" opacity=".2"></circle></g></g>', 1)];
const Rt = {
        render: function(a, e) {
            return r(), t("svg", null, [...jt])
        }
    },
    Zt = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Mouth/Sad",
        fill: "#000",
        opacity: ".7",
        transform: "translate(2 52)"
    }, [i("path", {
        id: "Mouth",
        d: "M40.058 16.654c.65 7.03 6.644 11.723 13.942 11.723 7.342 0 13.363-4.75 13.953-11.848.031-.378-.876-.676-1.324-.452q-8.308 4.16-12.629 4.16-4.266 0-12.446-4.069c-.507-.252-1.534.068-1.496.486",
        transform: "matrix(1 0 0 -1 0 44.377)"
    })])], -1)];
const Ut = {
        render: function(a, e) {
            return r(), t("svg", null, [...Zt])
        }
    },
    Qt = [i("g", {
        transform: "translate(76 82)"
    }, [i("g", {
        id: "Mouth/Serious",
        fill: "#000",
        opacity: ".7",
        transform: "translate(2 52)"
    }, [i("rect", {
        id: "Why-so-serious?",
        width: "24",
        height: "6",
        x: "42",
        y: "18",
        rx: "3"
    })])], -1)];
const _t = {
        render: function(a, e) {
            return r(), t("svg", null, [...Qt])
        }
    },
    It = [e('<g transform="translate(76 82)"><g id="Mouth/Tongue" transform="translate(2 52)"><defs><path id="Tongue-path1" d="M29 15.609C30.41 25.23 41.062 33 54 33c12.968 0 23.646-7.817 25-18.26.101-.4-.225-1.74-2.174-1.74H31.174c-1.79 0-2.304 1.24-2.174 2.609"></path></defs><mask id="Tongue-mask1" fill="#fff"><use href="#Tongue-path1"></use></mask><use id="Mouth" fill="#000" href="#Tongue-path1" opacity=".7"></use><rect id="Teeth" width="31" height="16" x="39" y="2" fill="#FFF" mask="url(&#39;#Tongue-mask1&#39;)" rx="5"></rect><path id="Tongue" fill="#FF4F6D" d="M65.984 23.747Q66 23.871 66 24v9c0 6.075-4.925 11-11 11h-1c-6.075 0-11-4.925-11-11v-9q0-.129.016-.253A2 2 0 0 1 43 23.5c0-1.933 2.91-3.5 6.5-3.5 2.01 0 3.808.491 5 1.263 1.192-.772 2.99-1.263 5-1.263 3.59 0 6.5 1.567 6.5 3.5q0 .124-.016.247"></path></g></g>', 1)];
const Kt = {
        render: function(a, e) {
            return r(), t("svg", null, [...It])
        }
    },
    Yt = [e('<g transform="translate(76 82)"><g id="Mouth/Vomit" transform="translate(2 52)"><defs><path id="Vomit-path1" d="M34.008 12.602c1.12 10.49 4.227 19.392 19.988 19.398 15.762.006 18.92-8.958 19.998-19.495.087-.848-.82-1.505-1.957-1.505-6.686 0-9.367 1.495-18.048 1.5S40.757 11 36.092 11c-1.143 0-2.196.552-2.084 1.602"></path><path id="Vomit-path2" d="M59.917 36H60a6 6 0 1 0 12 0v-5a6 6 0 0 0-6-6H42a6 6 0 0 0-6 6v7a6 6 0 1 0 12 0v-2h.083a6.002 6.002 0 0 1 11.834 0"></path><filter id="filter1" width="102.8%" height="105.3%" x="-1.4%" y="-2.6%" filterUnits="objectBoundingBox"><feOffset dy="-1" in="SourceAlpha" result="shadowOffsetInner1"></feOffset><feComposite in="shadowOffsetInner1" in2="SourceAlpha" k2="-1" k3="1" operator="arithmetic" result="shadowInnerInner1"></feComposite><feColorMatrix in="shadowInnerInner1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0"></feColorMatrix></filter></defs><mask id="Vomit-mask1" fill="#fff"><use href="#Vomit-path1" transform="matrix(1 0 0 -1 0 43)"></use></mask><use id="Mouth" fill="#000" href="#Vomit-path1" opacity=".7" transform="matrix(1 0 0 -1 0 43)"></use><rect id="Teeth" width="31" height="16" x="39" y="0" fill="#FFF" mask="url(&#39;#Vomit-mask1&#39;)" rx="5"></rect><g id="Vomit-Stuff"><use fill="#88C553" href="#Vomit-path2"></use><use filter="url(&#39;#filter1&#39;)" href="#Vomit-path2"></use></g></g></g>', 1)];
const Jt = {
        Concerned: zt,
        Disbelief: Et,
        Grimace: At,
        ScreamOpen: Vt,
        Smile: Dt,
        Twinkle: Wt,
        Default: Pt,
        Eating: Rt,
        Sad: Ut,
        Serious: _t,
        Tongue: Kt,
        Vomit: {
            render: function(a, e) {
                return r(), t("svg", null, [...Yt])
            }
        }
    },
    Xt = (r = "#6fb8e0") => [a("g", {
        id: "Circle",
        "stroke-width": "1",
        "fill-rule": "evenodd",
        transform: "translate(12.000000, 40.000000)"
    }, [a("mask", {
        id: "mask-1",
        fill: "white"
    }, [a("use", {
        href: "#path-1"
    })]), a("use", {
        id: "Circle-Background",
        fill: "#E6E6E6",
        href: "#path-1"
    }), a("g", {
        id: "Color/Palette/Blue-01",
        mask: "url(#mask-1)",
        fill: r
    }, [a("rect", {
        id: "Color",
        x: "0",
        y: "0",
        width: "240",
        height: "240"
    })])]), a("mask", {
        id: "mask-2",
        fill: "white"
    }, [a("use", {
        href: "#path-2"
    })])],
    $t = r => {
        const t = {
            "--avataaar-hair-color": r.hairColor,
            "--avataaar-facial-hair-color": r.facialHairColor,
            "--avataaar-top-color": r.topColor,
            "--avataaar-shirt-color": r.clothesColor
        };
        return a("svg", {
            viewBox: "0 0 264 280",
            version: "1.1",
            xmlns: "http://www.w3.org/2000/svg",
            "xmlns:xlink": "http://www.w3.org/1999/xlink"
        }, [a("desc", "vue3-avataaars"), a("defs", [a("circle", {
            id: "path-1",
            cx: "120",
            cy: "120",
            r: "120"
        }), a("path", {
            id: "path-2",
            d: "M12,160 C12,226.27417 65.72583,280 132,280 C198.27417,280 252,226.27417 252,160 L264,160 L264,-1.42108547e-14 L-3.19744231e-14,-1.42108547e-14 L-3.19744231e-14,160 L12,160 Z"
        }), a("path", {
            id: "path-silhouette",
            d: "M124,144.610951 L124,163 L128,163 L128,163 C167.764502,163 200,195.235498 200,235 L200,244 L0,244 L0,235 C-4.86974701e-15,195.235498 32.235498,163 72,163 L72,163 L76,163 L76,144.610951 C58.7626345,136.422372 46.3722246,119.687011 44.3051388,99.8812385 C38.4803105,99.0577866 34,94.0521096 34,88 L34,74 C34,68.0540074 38.3245733,63.1180731 44,62.1659169 L44,56 L44,56 C44,25.072054 69.072054,5.68137151e-15 100,0 L100,0 L100,0 C130.927946,-5.68137151e-15 156,25.072054 156,56 L156,62.1659169 C161.675427,63.1180731 166,68.0540074 166,74 L166,88 C166,94.0521096 161.51969,99.0577866 155.694861,99.8812385 C153.627775,119.687011 141.237365,136.422372 124,144.610951 Z"
        })]), a("g", {
            id: "Avataaar",
            stroke: "none",
            "stroke-width": "1",
            fill: "none",
            "fill-rule": "evenodd"
        }, [a("g", {
            id: "Avataaar/Circle",
            transform: "translate(-825.000000, -1100.000000)"
        }, [a("g", {
            transform: "translate(825.000000, 1100.000000)"
        }, [r.isCircle ? Xt(r.circleColor) : null, a("g", {
            id: "Mask"
        }), a("g", {
            id: "Avataaar",
            "stroke-width": "1",
            "fill-rule": "evenodd",
            fill: "black",
            mask: "url(#mask-2)",
            style: t
        }, [a("g", {
            id: "Body",
            transform: "translate(32.000000, 36.000000)"
        }, [a("mask", {
            id: "mask-silhouette",
            fill: "white"
        }, [a("use", {
            href: "#path-silhouette"
        })]), a("use", {
            fill: r.skinColor,
            href: "#path-silhouette"
        }), a("path", {
            id: "Neck-Shadow",
            d: "M156,79 L156,102 C156,132.927946 130.927946,158 100,158 C69.072054,158 44,132.927946 44,102 L44,79 L44,94 C44,124.927946 69.072054,150 100,150 C130.927946,150 156,124.927946 156,94 L156,79 Z",
            "fill-opacity": "0.100000001",
            fill: "#000000",
            mask: "url(#mask-silhouette)"
        })]), a(V[r.clothes]), "GraphicShirt" === r.clothes ? a(Er[r.graphicShirt]) : null, a(rt[r.eyes]), a(xt[r.eyebrows]), a(Jt[r.mouth]), a("svg", [a("g", {
            fill: "black",
            transform: "translate(76.000000, 82.000000)"
        }, [a("g", {
            id: "Nose/Default",
            transform: "translate(28.000000, 40.000000)",
            opacity: "0.16"
        }, [a("path", {
            id: "Nose",
            d: "M16,8 C16,12.418278 21.372583,16 28,16 L28,16 C34.627417,16 40,12.418278 40,8"
        })])])]), a(Xa[r.top]), a(cr[r.facialHair]), a(C[r.accessories])])])])])])
    },
    ae = Object.freeze(Object.defineProperty({
        __proto__: null,
        HatAndShirtColors: {
            Black: "#262E33",
            Blue01: "#65C9FF",
            Blue02: "#5199E4",
            Blue03: "#25557C",
            Gray01: "#E6E6E6",
            Gray02: "#929598",
            Heather: "#3C4F5C",
            PastelBlue: "#B1E2FF",
            PastelGreen: "#A7FFC4",
            PastelOrange: "#FFBC69",
            PastelRed: "#FFAFB9",
            PastelYellow: "#FFFFB1",
            Pink: "#FF488E",
            Red: "#FF5C5C",
            White: "#FFFFFF"
        },
        HairColors: {
            Auburn: "#A55728",
            Black: "#2C1B18",
            Blonde: "#B58143",
            BlondeGolden: "#D6B370",
            Brown: "#724133",
            BrownDark: "#4A312C",
            PastelPink: "#F59797",
            Platinum: "#ECDCBF",
            Red: "#C93305",
            SilverGray: "#E8E1E1"
        },
        SkinColors: {
            Tanned: "#FD9841",
            Yellow: "#F8D25C",
            Pale: "#FFDBB4",
            Light: "#EDB98A",
            Brown: "#D08B5B",
            DarkBrown: "#AE5D29",
            Black: "#614335"
        }
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    re = Object.freeze(Object.defineProperty({
        __proto__: null,
        Accessories: ["Blank", "Prescription01", "Round", "Wayfarers", "Kurt", "Prescription02", "Sunglasses"],
        Eyes: ["Close", "Default", "EyeRoll", "Hearts", "Squint", "Wink", "Cry", "Dizzy", "Happy", "Side", "Surprised", "WinkWacky"],
        Eyebrows: ["Angry", "FlatNatural", "SadConcerned", "UpDownNatural", "AngryNatural", "FrownNatural", "SadConcernedNatural", "Default", "RaisedExcited", "UnibrowNatural", "DefaultNatural", "RaisedExcitedNatural", "UpDown"],
        FacialHair: ["BeardMajestic", "BeardLight", "MoustacheFancy", "BeardMedium", "Blank", "MoustacheMagnum"],
        Mouths: ["Concerned", "Disbelief", "Grimace", "ScreamOpen", "Smile", "Twinkle", "Default", "Eating", "Sad", "Serious", "Tongue", "Vomit"],
        Tops: ["Eyepatch", "Hat", "Hijab", "LongHairBigHair", "LongHairBob", "LongHairBun", "LongHairCurly", "LongHairCurvy", "LongHairDreads", "LongHairFrida", "LongHairFro", "LongHairFroBand", "LongHairMiaWallace", "LongHairNotTooLong", "LongHairShavedSides", "LongHairStraight", "LongHairStraight2", "LongHairStraightStrand", "NoHair", "ShortHairDreads01", "ShortHairDreads02", "ShortHairFrizzle", "ShortHairShaggy", "ShortHairShaggyMullet", "ShortHairShortCurly", "ShortHairShortFlat", "ShortHairShortRound", "ShortHairShortWaved", "ShortHairSides", "ShortHairTheCaesar", "ShortHairTheCaesarSidePart", "Turban", "WinterHat1", "WinterHat2", "WinterHat3", "WinterHat4"],
        Clothes: ["BlazerShirt", "CollarSweater", "BlazerSweater", "Hoodie", "GraphicShirt", "Overall", "ShirtCrewNeck", "ShirtVNeck", "ShirtScoopNeck"],
        GraphicShirt: ["Bat", "Cumbia", "Diamond", "Pizza", "Selena", "SkullOutline", "Bear", "Deer", "Hola", "Resist", "Skull"]
    }, Symbol.toStringTag, {
        value: "Module"
    }));
export {
    re as I, ae as U, $t as j
};