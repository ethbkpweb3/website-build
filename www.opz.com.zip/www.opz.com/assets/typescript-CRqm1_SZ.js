const o = o => o;
export {
    o as m
};