import {
    A as e,
    a as t,
    b as a,
    c as s
} from "./AiTradeItems2-CNJNdsPE.js";
import {
    f as i,
    _ as l
} from "./index-B_Hz-fzE.js";
import {
    _ as n
} from "./SectionTitle.vue_vue_type_script_setup_true_lang-BWlX4763.js";
import {
    _ as o
} from "./CaseStudy-2bmZBwD0.js";
import {
    _ as r
} from "./ButtonGR-BF9zAU5B.js";
import {
    _ as d
} from "./Subtitle-ytb6lg8s.js";
import {
    _ as c
} from "./_plugin-vue_export-helper-BCo6x5W8.js";
import {
    cD as p,
    o as u,
    j as m,
    l as v,
    P as f,
    cB as g,
    dg as y,
    ck as h,
    t as b,
    bh as w,
    H as x,
    m as _,
    h as j,
    y as k,
    I as z,
    N as O,
    cC as A,
    p as C,
    n as S,
    w as T,
    q as I,
    s as B,
    X as P,
    v as V,
    r as N,
    u as E,
    Y as L,
    dm as D,
    a as W,
    G as Z,
    dp as M,
    dn as F,
    k as G,
    dD as $,
    K as q
} from "./index-jdACH0Rc.js";
import {
    _ as H
} from "./Title-ChmnbwlA.js";
import {
    P as Y,
    S as X,
    C as J
} from "./carousel.es-cLcmNbI1.js";
import {
    _ as U
} from "./VPlaceload-jGgmcTFZ.js";
import {
    a as R,
    _ as K
} from "./Navbar2-DVEXcHRs.js";
import {
    _ as Q,
    a as ee
} from "./google-play-0W6tGWt8.js";
import "./index-Dwv4qbXN.js";
import {
    E as te
} from "./index-DBFvTDaE.js";
import {
    E as ae
} from "./index-C8W9xb4z.js";
import {
    _ as se
} from "./Section-fdq8wkjz.js";
import {
    _ as ie
} from "./Hero.vue_vue_type_style_index_0_lang-BzZhUp93.js";
import {
    _ as le,
    a as ne
} from "./google-play-BbEUCb8h.js";
import {
    E as oe,
    a as re
} from "./index-BZssNWJT.js";
import {
    c as de
} from "./index-BSBG2tux.js";
import {
    V as ce
} from "./vue3-lottie.es-S_sZ807A.js";
import {
    M as pe
} from "./vue3-markdown-it.umd.min--TOU0B4Y.js";
import {
    s as ue
} from "./sleep-MiAo3PcT.js";
import {
    b as me
} from "./index-cRGdv3RN.js";
import {
    E as ve
} from "./index-CSGGFzQh.js";
import {
    m as fe
} from "./index-CaRD-WAZ.js";
import {
    b as ge
} from "./route-block-B_A1xBdJ.js";
import "./Collapse.vue_vue_type_style_index_0_lang-KeWOc8fH.js";
import "./AppPop-C6dVPDH2.js";
import "./browser-B3Bvmjnq.js";
import "./index-DPTDKB4o.js";
import "./index-D4R9Vjdp.js";
import "./index-Citk0ABi.js";
import "./index-DtPnfIe2.js";
import "./Button-BbTMX0Dh.js";
import "./AvatarSimple-CfXnZ0K8.js";
import "./via-placeholder-csI6CdwS.js";
import "./user-qMNVzsWD.js";
import "./sett-Dbwu6PJ1.js";
import "./avatarSettings-Daanxsoo.js";
import "./vue3-avataaars-C_k_hIh4.js";
import "./logo-DqlCWKKL.js";
import "./index-DWTvrBdo.js";
import "./aria-C-hsWcn7.js";
import "./index-Cg9BJciP.js";
import "./typescript-CRqm1_SZ.js";
import "./index-B1yvdImc.js";
import "./use-dialog-CmZNE833.js";
import "./use-global-config-Dm8LyY4T.js";
import "./index-BWeq1WY3.js";
import "./index-BahOysPn.js";
import "./vue.runtime.esm-bundler-DZHlI3Nq.js";
const ye = {
        class: "right dappsboards-gallery-wrapper"
    },
    he = {
        class: "gallery-wrapper"
    },
    be = {
        class: "dappsboards-gallery"
    },
    we = {
        rows: "3",
        class: "dappsboards-gallery-grid"
    },
    xe = ["visible"],
    _e = {
        class: "card-img-wrap"
    },
    je = ["src"],
    ke = ["enter"],
    ze = {
        class: "card-title"
    };
const Oe = c({
    data: () => ({
        links: [{
            cardNum: 1,
            imgSrc: "/assets/dapps/stargate.png",
            title: "Stargate"
        }, {
            cardNum: 2,
            imgSrc: "/assets/dapps/pancakeswap.png",
            title: "PancakeSwap"
        }, {
            cardNum: 3,
            imgSrc: "/assets/dapps/lido.png",
            title: "Lido"
        }, {
            cardNum: 4,
            imgSrc: "/assets/dapps/ens.png",
            title: "ENS"
        }, {
            cardNum: 5,
            imgSrc: "/assets/dapps/uniswapv3.png",
            title: "Uniswap"
        }, {
            cardNum: 6,
            imgSrc: "/assets/dapps/dodo.png",
            title: "DODO"
        }, {
            cardNum: 7,
            imgSrc: "/assets/dapps/opensea.png",
            title: "OpenSea"
        }, {
            cardNum: 8,
            imgSrc: "/assets/dapps/looksrare.webp",
            title: "LooksRare"
        }, {
            cardNum: 9,
            imgSrc: "/assets/dapps/aave.png",
            title: "AAVE"
        }, {
            cardNum: 10,
            imgSrc: "/assets/dapps/curve.png",
            title: "Curve"
        }, {
            cardNum: 11,
            imgSrc: "/assets/dapps/instadapp.png",
            title: "Instadapp"
        }, {
            cardNum: 12,
            imgSrc: "/assets/dapps/1inch.png",
            title: "1inch.io"
        }, {
            cardNum: 13,
            imgSrc: "/assets/dapps/sushiswap.png",
            title: "SushiSwap"
        }, {
            cardNum: 14,
            imgSrc: "/assets/dapps/yearn.png",
            title: "yearn.finance"
        }, {
            cardNum: 15,
            imgSrc: "/assets/dapps/balancer.png",
            title: "Balancer"
        }]
    }),
    props: {
        size: {
            type: Number,
            default: 150
        }
    }
}, [
    ["render", function(e, t, a, s, i, l) {
        const n = p("motion");
        return u(), m("div", ye, [v("div", he, [v("div", be, [v("div", we, [(u(!0), m(f, null, g(i.links, ((e, t) => y((u(), m("div", {
            key: t,
            class: "dappboard-card-link",
            initial: {
                x: -30,
                opacity: 0
            },
            visible: {
                x: 0,
                opacity: 1,
                transition: {
                    delay: 100 + 33 * t
                }
            }
        }, [v("div", _e, [v("img", {
            src: e.imgSrc,
            alt: "DappBoard",
            class: "card-img",
            style: h({
                width: `${this.size}px`,
                height: `${this.size}px`
            })
        }, null, 12, je)]), y((u(), m("div", {
            class: "card-bottom",
            initial: {
                opacity: 0
            },
            enter: {
                opacity: 1,
                transition: {
                    delay: 666 + 33 * t
                }
            }
        }, [v("div", null, [v("span", ze, b(e.title), 1)])], 8, ke)), [
            [n]
        ])], 8, xe)), [
            [n]
        ]))), 128))])])])])
    }]
]);
var Ae = function(e) {
        var t = typeof e;
        return null != e && ("object" == t || "function" == t)
    },
    Ce = "object" == typeof w && w && w.Object === Object && w,
    Se = "object" == typeof self && self && self.Object === Object && self,
    Te = Ce || Se || Function("return this")(),
    Ie = Te,
    Be = function() {
        return Ie.Date.now()
    },
    Pe = /\s/;
var Ve = function(e) {
        for (var t = e.length; t-- && Pe.test(e.charAt(t)););
        return t
    },
    Ne = /^\s+/;
var Ee = function(e) {
        return e ? e.slice(0, Ve(e) + 1).replace(Ne, "") : e
    },
    Le = Te.Symbol,
    De = Le,
    We = Object.prototype,
    Ze = We.hasOwnProperty,
    Me = We.toString,
    Fe = De ? De.toStringTag : void 0;
var Ge = function(e) {
        var t = Ze.call(e, Fe),
            a = e[Fe];
        try {
            e[Fe] = void 0;
            var s = !0
        } catch (l) {}
        var i = Me.call(e);
        return s && (t ? e[Fe] = a : delete e[Fe]), i
    },
    $e = Object.prototype.toString;
var qe = Ge,
    He = function(e) {
        return $e.call(e)
    },
    Ye = Le ? Le.toStringTag : void 0;
var Xe = function(e) {
        return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : Ye && Ye in Object(e) ? qe(e) : He(e)
    },
    Je = function(e) {
        return null != e && "object" == typeof e
    };
var Ue = Ee,
    Re = Ae,
    Ke = function(e) {
        return "symbol" == typeof e || Je(e) && "[object Symbol]" == Xe(e)
    },
    Qe = /^[-+]0x[0-9a-f]+$/i,
    et = /^0b[01]+$/i,
    tt = /^0o[0-7]+$/i,
    at = parseInt;
var st = Ae,
    it = Be,
    lt = function(e) {
        if ("number" == typeof e) return e;
        if (Ke(e)) return NaN;
        if (Re(e)) {
            var t = "function" == typeof e.valueOf ? e.valueOf() : e;
            e = Re(t) ? t + "" : t
        }
        if ("string" != typeof e) return 0 === e ? e : +e;
        e = Ue(e);
        var a = et.test(e);
        return a || tt.test(e) ? at(e.slice(2), a ? 2 : 8) : Qe.test(e) ? NaN : +e
    },
    nt = Math.max,
    ot = Math.min;
var rt = function(e, t, a) {
        var s, i, l, n, o, r, d = 0,
            c = !1,
            p = !1,
            u = !0;
        if ("function" != typeof e) throw new TypeError("Expected a function");

        function m(t) {
            var a = s,
                l = i;
            return s = i = void 0, d = t, n = e.apply(l, a)
        }

        function v(e) {
            var a = e - r;
            return void 0 === r || a >= t || a < 0 || p && e - d >= l
        }

        function f() {
            var e = it();
            if (v(e)) return g(e);
            o = setTimeout(f, function(e) {
                var a = t - (e - r);
                return p ? ot(a, l - (e - d)) : a
            }(e))
        }

        function g(e) {
            return o = void 0, u && s ? m(e) : (s = i = void 0, n)
        }

        function y() {
            var e = it(),
                a = v(e);
            if (s = arguments, i = this, r = e, a) {
                if (void 0 === o) return function(e) {
                    return d = e, o = setTimeout(f, t), c ? m(e) : n
                }(r);
                if (p) return clearTimeout(o), o = setTimeout(f, t), m(r)
            }
            return void 0 === o && (o = setTimeout(f, t)), n
        }
        return t = lt(t) || 0, st(a) && (c = !!a.leading, l = (p = "maxWait" in a) ? nt(lt(a.maxWait) || 0, t) : l, u = "trailing" in a ? !!a.trailing : u), y.cancel = function() {
            void 0 !== o && clearTimeout(o), d = 0, s = r = i = o = void 0
        }, y.flush = function() {
            return void 0 === o ? n : g(it())
        }, y
    },
    dt = Ae;
const ct = x((function(e, t, a) {
        var s = !0,
            i = !0;
        if ("function" != typeof e) throw new TypeError("Expected a function");
        return dt(a) && (s = "leading" in a ? !!a.leading : s, i = "trailing" in a ? !!a.trailing : i), rt(e, t, {
            leading: s,
            maxWait: t,
            trailing: i
        })
    })),
    pt = {
        class: "columns is-vcentered"
    },
    ut = {
        class: "column is-6"
    },
    mt = {
        class: "text-gradient"
    },
    vt = c(_({
        __name: "SideSectionMpc",
        props: {
            title: {},
            subtitle: {},
            content: {},
            to: {
                default: void 0
            },
            cta: {
                default: void 0
            },
            image: {},
            darkImage: {
                default: void 0
            },
            imageWidth: {
                default: "800"
            },
            imageHeight: {
                default: "600"
            },
            legend: {
                default: void 0
            },
            bordered: {
                type: Boolean,
                default: !1
            },
            inverted: {
                type: Boolean,
                default: !1
            },
            blob: {
                type: Boolean,
                default: !1
            },
            reverse: {
                type: Boolean,
                default: !1
            },
            opacity: {},
            isAppOn: {
                type: Boolean
            }
        },
        setup(e) {
            const t = e,
                a = j((() => [t.bordered && "is-bordered", t.inverted && "is-inverted", t.reverse && "is-reverse"])),
                s = j((() => [t.inverted && "is-inverted"])),
                i = k(!1),
                l = ct((() => {
                    i.value = window.innerWidth <= 500
                }), 100);
            z((() => {
                l(), window.addEventListener("resize", l)
            })), O((() => {
                window.removeEventListener("resize", l)
            }));
            return (e, l) => {
                const n = H,
                    o = Oe,
                    c = d,
                    p = r,
                    f = A("RouterLink");
                return u(), m("div", {
                    class: C(["side-section mobile:py-0 small:py-6 z-1", a.value])
                }, [v("div", pt, [v("div", {
                    class: C(["column is-6 has-text-centered is-relative", i.value ? "pb-4 pt-0" : ""])
                }, [t.legend ? (u(), S(n, {
                    key: 0,
                    tag: "h3",
                    size: 5,
                    weight: "bold",
                    inverted: t.inverted
                }, {
                    default: T((() => [I(b(t.legend), 1)])),
                    _: 1
                }, 8, ["inverted"])) : B("", !0), P(false) ? B("", !0) : (u(), S(o, {
                    key: 1,
                    size: i.value ? 60 : 90,
                    class: "dapp-scroll"
                }, null, 8, ["size"]))], 2), v("div", ut, [V(c, {
                    tag: "h2",
                    size: 6,
                    weight: "bold",
                    class: "pb-4",
                    leading: ""
                }, {
                    default: T((() => [v("span", mt, b(e.subtitle), 1)])),
                    _: 1
                }), V(n, {
                    tag: "h2",
                    size: 2,
                    weight: "bold",
                    inverted: t.inverted
                }, {
                    default: T((() => [I(b(e.title), 1)])),
                    _: 1
                }, 8, ["inverted"]), v("p", {
                    class: C(["paragraph rem-115 mb-4", s.value])
                }, b(t.content), 3), !e.isAppOn && e.cta ? (u(), S(f, {
                    key: 0,
                    to: t.to
                }, {
                    default: T((() => [V(p, {
                        style: {
                            "max-width": "200px"
                        }
                    }, {
                        default: T((() => [I(b(t.cta) + " ", 1), l[0] || (l[0] = v("i", {
                            class: "iconify pl-4",
                            "data-icon": "feather:arrow-right"
                        }, null, -1))])),
                        _: 1
                    })])),
                    _: 1
                }, 8, ["to"])) : B("", !0), N(e.$slots, "content", {}, void 0, !0)])])], 2)
            }
        }
    }), [
        ["__scopeId", "data-v-03ed6eb9"]
    ]),
    ft = {
        id: "seed-sale",
        class: "flex flex-col items-center justify-center token-detail-card relative my-8 py-8 px-2 space-y-8 bg-card-light"
    },
    gt = {
        id: "",
        class: "flex flex-col items-center justify-normal z-20 space-y-4",
        style: {
            "z-index": "11111"
        }
    },
    yt = {
        key: 0
    },
    ht = {
        key: 1,
        style: {
            width: "100%"
        }
    },
    bt = {
        class: "form-control-wrap flex justify-between flex-col mt-1"
    },
    wt = {
        key: 2
    },
    xt = {
        class: "flex justify-center text-center mx-auto items-center mt-3",
        style: {
            position: "relative",
            "z-index": "11111111"
        }
    },
    _t = c(_({
        __name: "WaitingList",
        props: {
            btn: {
                type: Boolean,
                default: !1
            },
            modelValue: {
                type: Boolean,
                default: !0
            }
        },
        emits: ["update:modelValue", "close"],
        setup(e, {
            emit: t
        }) {
            const a = E(),
                {
                    t: s
                } = L();
            D(), k();
            const i = t,
                l = e,
                n = j({
                    get: () => l.modelValue,
                    set: e => i("update:modelValue", e)
                }),
                o = W(),
                d = k(""),
                c = k(""),
                p = () => {
                    d.value = "", c.value = "", i("update:modelValue", !1)
                },
                g = Z();
            M();
            const y = () => {
                    _(), i("update:modelValue", !0);
                    const e = `${window.location.pathname}`;
                    window.history.replaceState({}, "", e)
                },
                h = k(a.isLoggedIn ? "https://www.opz.com/?ref=" + a.userData.id : s("inx.please-login")),
                w = k(!1),
                x = k(!a.isLoggedIn),
                _ = () => {
                    a.isLoggedIn ? (w.value = !0, x.value = !1) : (w.value = !1, x.value = !1)
                },
                z = e => {
                    e ? window.open("https://play.google.com/store/apps/details?id=com.opz.dev") : window.open("https://testflight.apple.com/join/Oxsd9WMO")
                },
                O = F();
            return (e, t) => {
                const i = r,
                    d = U;
                return u(), m(f, null, [P(O).isAppOn ? B("", !0) : (u(), S(i, {
                    key: 0,
                    class: "btn-buy-card",
                    onClick: t[0] || (t[0] = e => y())
                }, {
                    default: T((() => t[8] || (t[8] = [I("Join Waitinglist")]))),
                    _: 1
                })), l.btn ? (u(), S(P(ae), {
                    key: 1,
                    modelValue: n.value,
                    "onUpdate:modelValue": t[6] || (t[6] = e => n.value = e),
                    "append-to": "#app",
                    class: "dialogw cdetail buy-card-pop heads2 rass",
                    "destroy-on-close": "",
                    onClose: p,
                    onOpen: t[7] || (t[7] = e => y())
                }, {
                    header: T((() => t[9] || (t[9] = []))),
                    default: T((() => [v("div", null, [v("div", ft, [t[19] || (t[19] = v("div", {
                        class: "pattern left"
                    }, null, -1)), v("div", gt, [t[16] || (t[16] = v("p", {
                        class: "mt-3 head-title"
                    }, "The OPZ NFC Experience", -1)), t[17] || (t[17] = v("p", {
                        class: "mt-3 title-nw mb-4"
                    }, [I(" Connect to WEB3 and unlock the full potential"), v("br"), I(" of Dapps with a simple tap. ")], -1)), t[18] || (t[18] = v("img", {
                        alt: "OPZ LOGO",
                        draggable: "false",
                        loading: "lazy",
                        width: "74",
                        height: "74",
                        class: "max-w-full h-auto my-4",
                        src: R,
                        style: {
                            color: "transparent",
                            "box-shadow": "0 0 0.5rem rgba(115, 3, 252, 0.3)"
                        }
                    }, null, -1)), !0 === x.value ? (u(), m("div", yt, [V(d, {
                        width: "330px",
                        height: "120px"
                    })])) : P(a).isLoggedIn && w.value ? (u(), m("div", ht, [v("div", bt, [t[11] || (t[11] = v("p", {
                        class: "help mb-2"
                    }, "Share your referral link to boost your position on the waitlist.", -1)), V(P(te), {
                        modelValue: h.value,
                        "onUpdate:modelValue": t[2] || (t[2] = e => h.value = e),
                        class: "addressInput text-medium btnChain mb-3",
                        placeholder: h.value,
                        readonly: !0
                    }, {
                        prefix: T((() => t[10] || (t[10] = [v("i", {
                            class: "fas fa-link"
                        }, null, -1)]))),
                        suffix: T((() => [v("i", {
                            class: "copy-link fas fa-copy",
                            onClick: t[1] || (t[1] = e => (e => {
                                try {
                                    navigator.clipboard.writeText(e), o.success(s("depwi.copied-successfully"))
                                } catch (t) {
                                    o.error(s("depwi.error"))
                                }
                            })(h.value))
                        })])),
                        _: 1
                    }, 8, ["modelValue", "placeholder"]), V(i, {
                        onClick: t[3] || (t[3] = e => P(g).push({
                            name: "referral"
                        })),
                        size: "small"
                    }, {
                        default: T((() => [I(b(P(s)("pga.referrals")), 1)])),
                        _: 1
                    })])])) : (u(), m("div", wt, [t[14] || (t[14] = v("p", {
                        class: "title-nw mt-2",
                        style: {
                            color: "white"
                        }
                    }, "JOIN THE WAITINGLIST", -1)), v("div", xt, [v("div", {
                        onClick: t[4] || (t[4] = e => z()),
                        class: "cursor-pointer mr-2"
                    }, t[12] || (t[12] = [v("img", {
                        src: Q,
                        alt: "Download OPZ Beta",
                        width: "120"
                    }, null, -1)])), v("div", {
                        onClick: t[5] || (t[5] = e => z(!0)),
                        class: "cursor-pointer"
                    }, t[13] || (t[13] = [v("img", {
                        src: ee,
                        alt: "Download on Google Play",
                        width: "120"
                    }, null, -1)]))]), t[15] || (t[15] = v("p", {
                        class: "mt-2 title-nw"
                    }, [I(" Download the app and create your MPC wallet"), v("br"), I(" to join the waitinglist. ")], -1))]))]), t[20] || (t[20] = v("div", {
                        class: "pattern right"
                    }, null, -1))])])])),
                    _: 1
                }, 8, ["modelValue"])) : B("", !0)], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-78e11d12"]
    ]),
    jt = {
        class: "columns is-vcentered mb-6"
    },
    kt = {
        class: "column is-5"
    },
    zt = {
        class: "text-gradient text-bold"
    },
    Ot = {
        class: "is-weight-500 pl-2 pr-4 text-white"
    },
    At = {
        class: "mt-4"
    },
    Ct = {
        class: "column is-7 has-text-centered is-relative"
    },
    St = {
        class: "featured-image-container"
    },
    Tt = c(_({
        __name: "SideBenefits2",
        props: {
            title: {},
            subtitle: {},
            content: {},
            benefits: {
                default: () => []
            },
            image: {},
            darkImage: {
                default: void 0
            },
            imageWidth: {
                default: "300"
            },
            imageHeight: {
                default: "300"
            },
            bordered: {
                type: Boolean,
                default: !1
            },
            inverted: {
                type: Boolean,
                default: !1
            },
            reverse: {
                type: Boolean,
                default: !1
            }
        },
        setup(e) {
            const t = M(),
                a = t.query.open,
                s = k(!(!a || "true" !== a)),
                i = e,
                l = j((() => [i.bordered && "is-bordered", i.inverted && "is-inverted", i.reverse && "is-reverse"])),
                n = j((() => [i.inverted && "is-inverted"])),
                o = F(),
                r = Z();
            if (z((() => {
                    if (t.query.open) {
                        const e = { ...t.query
                        };
                        delete e.open, r.replace({
                            query: e
                        })
                    }
                })), o.isAppOn) {
                const e = e => {
                    var t, a;
                    (null == (a = null == (t = null == e ? void 0 : e.data) ? void 0 : t.toString()) ? void 0 : a.includes("OpenOPZBuyCard")) && (s.value = !s.value)
                };
                navigator.userAgent.includes("Android") ? document.addEventListener("message", e, !1) : window.addEventListener("message", e, !1)
            }
            return (e, t) => {
                const a = d,
                    o = H;
                return u(), m("div", {
                    class: C(["side-benefits mobile:py-0 small:py-6 z-1", l.value])
                }, [v("div", jt, [v("div", kt, [V(a, {
                    tag: "h3",
                    size: 5,
                    weight: "bold",
                    class: "pb-2"
                }, {
                    default: T((() => [v("span", zt, b(e.subtitle), 1)])),
                    _: 1
                }), V(o, {
                    tag: "h1",
                    size: 2,
                    weight: "bold",
                    inverted: i.inverted,
                    leading: ""
                }, {
                    default: T((() => [I(b(e.title), 1)])),
                    _: 1
                }, 8, ["inverted"]), v("p", {
                    class: C(["paragraph rem-115 mb-4 text-white", n.value])
                }, b(i.content), 3), v("hr", {
                    class: C(i.inverted && "is-inverted")
                }, null, 2), (u(!0), m(f, null, g(i.benefits, ((e, a) => (u(), m("div", {
                    key: a,
                    class: "benefit mb-2"
                }, [t[1] || (t[1] = v("i", {
                    class: "iconify",
                    "data-icon": "feather:check"
                }, null, -1)), v("span", Ot, b(e), 1)])))), 128)), v("div", At, [V(_t, {
                    modelValue: s.value,
                    "onUpdate:modelValue": t[0] || (t[0] = e => s.value = e),
                    btn: !0
                }, null, 8, ["modelValue"])])]), v("div", Ct, [v("div", St, [t[4] || (t[4] = v("div", {
                    class: "spinning-background"
                }, [v("div", {
                    class: "background-wrapper"
                }, [v("div", {
                    class: "circle green-circle"
                }), v("div", {
                    class: "circle blue-circle"
                })])], -1)), V(P(J), {
                    "items-to-show": 1,
                    autoplay: 5e3
                }, {
                    addons: T((() => [V(P(Y))])),
                    default: T((() => [(u(), S(P(X), {
                        key: 1
                    }, {
                        default: T((() => t[2] || (t[2] = [v("img", {
                            class: "is-relative mx-auto mpc-card",
                            src: "/images/illustrations/MPC-Card2.png",
                            alt: "MPC Card"
                        }, null, -1)]))),
                        _: 1
                    })), (u(), S(P(X), {
                        key: 2
                    }, {
                        default: T((() => t[3] || (t[3] = [v("img", {
                            class: "is-relative mx-auto mpc-card p-2",
                            src: "/images/illustrations/MPC-Card-Metallic.png",
                            alt: "MPC Card 2"
                        }, null, -1)]))),
                        _: 1
                    }))])),
                    _: 1
                })])])])], 2)
            }
        }
    }), [
        ["__scopeId", "data-v-27009814"]
    ]),
    It = {
        class: "py-3 mx-auto"
    },
    Bt = {
        class: "columns is-multiline b-columns-half-tablet-p fblock-z"
    },
    Pt = ["initial", "visibleOnce"],
    Vt = {
        class: "cardFlow fbz-body card"
    },
    Nt = ["src"],
    Et = {
        class: "fbz-img"
    },
    Lt = {
        class: "fbz-content"
    },
    Dt = {
        class: "fbz-content-head"
    },
    Wt = ["src", "alt"],
    Zt = {
        class: "fbz-title"
    },
    Mt = {
        class: "fbz-content-data"
    },
    Ft = {
        class: "fbz-text"
    },
    Gt = c(_({
        __name: "FeatureBlockZ2",
        props: {
            features: {},
            limit: {
                default: 3
            },
            size: {
                default: void 0
            },
            links: {
                type: Boolean,
                default: !1
            },
            animated: {
                type: Boolean,
                default: !1
            },
            horizontal: {
                type: Boolean,
                default: !1
            }
        },
        setup(e) {
            const t = e,
                a = j((() => [t.horizontal ? "is-6" : "is-4"]));
            return j((() => [t.animated && "animated", !t.horizontal && "has-text-centered p-4 large:p-10"])), j((() => [t.size && `is-${t.size}`])), j((() => ["small" === t.size && "rem-90", t.links && "mb-4", !t.horizontal && "mx-auto max-w-2"])), (e, s) => {
                const i = p("motion");
                return u(), m("div", It, [v("div", Bt, [(u(!0), m(f, null, g(t.features.slice(0, t.limit), ((e, t) => y((u(), m("div", {
                    key: t,
                    class: C(["column flex justify-center", a.value]),
                    initial: {
                        opacity: 0,
                        transition: {
                            delay: 100 + 333 * t
                        }
                    },
                    visibleOnce: {
                        opacity: 1,
                        transition: {
                            type: "spring",
                            stiffness: 90,
                            damping: 9,
                            delay: 100 + 333 * t
                        }
                    }
                }, [v("div", Vt, [v("img", {
                    src: e.bgimg,
                    alt: "Feature Background",
                    style: {
                        position: "absolute"
                    }
                }, null, 8, Nt), v("div", Et, [v("div", Lt, [v("div", Dt, [v("img", {
                    class: "mr-2",
                    width: "16",
                    src: e.imageSmall,
                    alt: e.title
                }, null, 8, Wt), v("p", Zt, b(e.title), 1)]), v("div", Mt, [v("p", Ft, b(e.text), 1)])])]), s[0] || (s[0] = G('<div class="card-arrow" data-v-b3d2654a><div class="card-arrow-top-left" data-v-b3d2654a></div><div class="card-arrow-top-right" data-v-b3d2654a></div><div class="card-arrow-bottom-left" data-v-b3d2654a></div><div class="card-arrow-bottom-right" data-v-b3d2654a></div></div>', 1))])], 10, Pt)), [
                    [i]
                ]))), 128))])])
            }
        }
    }), [
        ["__scopeId", "data-v-b3d2654a"]
    ]),
    $t = {
        class: "columns is-vcentered main-two"
    },
    qt = {
        class: "column is-relative"
    },
    Ht = {
        class: "hero-caption mx-auto mb-4"
    },
    Yt = {
        initial: {
            y: -30,
            opacity: 0
        },
        enter: {
            y: 0,
            opacity: 1,
            transition: {
                type: "spring",
                stiffness: 150,
                damping: 12,
                delay: 400
            }
        },
        tag: "p",
        size: 5,
        class: "mx-auto max-w-6 text-medium b-centered-tablet-p pt-2 subtitle is-5 text-white"
    },
    Xt = {
        key: 0,
        initial: {
            y: -60,
            opacity: 0
        },
        enter: {
            y: -0,
            opacity: 1,
            transition: {
                type: "spring",
                stiffness: 150,
                damping: 12,
                delay: 600
            }
        },
        class: "buttons is-relative z-1 btn-lnd"
    },
    Jt = {
        class: "btn-app-tri"
    },
    Ut = {
        class: "column is-relative"
    },
    Rt = {
        class: "hero-caption mx-auto mb-4"
    },
    Kt = {
        key: 0,
        class: "buttons is-relative z-1 btn-lnd"
    },
    Qt = {
        class: "btn-app-tri"
    },
    ea = "gradient-opaque",
    ta = c(_({
        __name: "HeroT2",
        setup(e) {
            const t = k(0);
            let a;
            const s = setInterval((() => {
                a && clearTimeout(a), a = setTimeout((() => {
                    t.value < 2 ? t.value++ : t.value = 0
                }), 1500)
            }), 3e3);
            O((() => {
                clearInterval(s), a && clearTimeout(a)
            }));
            const i = F(),
                l = Z(),
                n = e => {
                    e ? window.open("https://play.google.com/store/apps/details?id=com.opz.dev") : window.open("https://testflight.apple.com/join/Oxsd9WMO")
                };
            return k(window.innerWidth <= 767), (e, a) => {
                const s = H,
                    o = ie,
                    r = p("motion");
                return u(), S(o, {
                    class: "illustration-hero",
                    alignment: "center",
                    size: "fullheight",
                    color: "grey",
                    style: {
                        "z-index": "1",
                        position: "relative",
                        background: "transparent"
                    }
                }, {
                    body: T((() => [v("div", $t, [V(P(oe), {
                        autoplay: !0,
                        class: "opz-cara",
                        "motion-blur": "",
                        "indicator-position": "none",
                        loop: !1,
                        interval: 4500
                    }, {
                        default: T((() => [(u(), S(P(re), {
                            class: "opz-cara-item",
                            key: 1
                        }, {
                            default: T((() => [v("div", qt, [v("div", Ht, [V(s, {
                                tag: "h1",
                                size: 1,
                                weight: "bold"
                            }, {
                                default: T((() => [y((u(), m("span", {
                                    initial: {
                                        opacity: 0
                                    },
                                    enter: {
                                        opacity: 1,
                                        transition: {
                                            type: "spring",
                                            stiffness: 50,
                                            damping: 25,
                                            mass: 5,
                                            delay: 100
                                        }
                                    },
                                    class: C(["text-gradient-primary-pseudo px-2", 0 === t.value && ea]),
                                    "data-content": "Trade."
                                }, a[3] || (a[3] = [I(" Trade. ")]), 2)), [
                                    [r]
                                ]), y((u(), m("span", {
                                    initial: {
                                        opacity: 0
                                    },
                                    enter: {
                                        opacity: 1,
                                        transition: {
                                            type: "spring",
                                            stiffness: 50,
                                            damping: 25,
                                            mass: 5,
                                            delay: 200
                                        }
                                    },
                                    class: C(["text-gradient-secondary-pseudo px-2", 1 === t.value && ea]),
                                    "data-content": "Connect."
                                }, a[4] || (a[4] = [I(" Connect. ")]), 2)), [
                                    [r]
                                ]), y((u(), m("span", {
                                    initial: {
                                        opacity: 0
                                    },
                                    enter: {
                                        opacity: 1,
                                        transition: {
                                            type: "spring",
                                            stiffness: 50,
                                            damping: 25,
                                            mass: 5,
                                            delay: 300
                                        }
                                    },
                                    class: C(["text-gradient-accent-pseudo px-2", 2 === t.value && ea]),
                                    "data-content": "Secure."
                                }, a[5] || (a[5] = [I(" Secure. ")]), 2)), [
                                    [r]
                                ])])),
                                _: 1
                            }), y((u(), m("h2", Yt, a[6] || (a[6] = [I(" Revolutionizing Self-Custody with Advanced AI Technology ")]))), [
                                [r]
                            ])]), a[9] || (a[9] = v("div", {
                                style: {
                                    position: "absolute",
                                    inset: "0",
                                    "z-index": "0",
                                    overflow: "hidden"
                                }
                            }, null, -1)), a[10] || (a[10] = v("div", {
                                class: "hero-image-composition mb-5"
                            }, [v("div", {
                                style: {
                                    width: "100%"
                                },
                                class: "flex items-center justify-center mb-2 pt-1"
                            })], -1)), P(i).isAppOn ? B("", !0) : y((u(), m("div", Xt, [v("div", Jt, [v("div", {
                                onClick: a[0] || (a[0] = e => n()),
                                class: "btn-left btn-add1"
                            }, a[7] || (a[7] = [v("div", {
                                class: "btn-left-body"
                            }, [v("img", {
                                width: "20",
                                class: "mr-2",
                                src: le,
                                alt: "Apple Store Download Link"
                            }), v("div", {
                                class: "btn-txt",
                                style: {
                                    color: "#fafafa !important"
                                }
                            }, " OPZ BETA ")], -1)])), v("div", {
                                onClick: a[1] || (a[1] = e => n(!0)),
                                class: "btn-right btn-add1"
                            }, a[8] || (a[8] = [v("div", {
                                class: "btn-right-body"
                            }, [v("img", {
                                width: "20",
                                class: "mr-2",
                                src: ne,
                                alt: "Google Play Download Link"
                            }), v("div", {
                                class: "btn-txt",
                                style: {
                                    color: "#fafafa !important"
                                }
                            }, " GOOGLE PLAY ")], -1)]))])])), [
                                [r]
                            ])])])),
                            _: 1
                        })), (u(), S(P(re), {
                            class: "opz-cara-item",
                            key: 2
                        }, {
                            default: T((() => [v("div", Ut, [v("div", Rt, [V(s, {
                                tag: "h1",
                                size: 1,
                                weight: "bold",
                                class: "flex items-center justify-center"
                            }, {
                                default: T((() => a[11] || (a[11] = [v("span", {
                                    class: "px-2 txt-pr-o1",
                                    "data-content": "Join The OPZ Presale"
                                }, " Join The OPZ Presale ", -1)]))),
                                _: 1
                            }), a[12] || (a[12] = v("h2", {
                                tag: "p",
                                size: 5,
                                class: "mx-auto max-w-6 text-medium b-centered-tablet-p pt-2 subtitle is-5 text-white"
                            }, " Last Chance to Join the OPZ Presale Revolution! ", -1))]), a[15] || (a[15] = v("div", {
                                style: {
                                    position: "absolute",
                                    inset: "0",
                                    "z-index": "0",
                                    overflow: "hidden"
                                }
                            }, null, -1)), a[16] || (a[16] = v("div", {
                                class: "hero-image-composition mb-5"
                            }, [v("div", {
                                style: {
                                    width: "100%"
                                },
                                class: "flex items-center justify-center mb-2 pt-1"
                            })], -1)), P(i).isAppOn ? B("", !0) : (u(), m("div", Kt, [v("div", Qt, [a[14] || (a[14] = v("a", {
                                target: "_blank",
                                href: "https://whitepaper.opz.com/",
                                class: "btn-left btn-add1"
                            }, [v("div", {
                                class: "btn-left-body"
                            }, [v("img", {
                                width: "20",
                                class: "mr-2",
                                src: "/images/svg/open-book.svg",
                                alt: "Apple Store Download Link"
                            }), v("div", {
                                class: "btn-txt",
                                style: {
                                    color: "#fafafa !important"
                                }
                            }, " Whitepaper ")])], -1)), v("div", {
                                onClick: a[2] || (a[2] = e => P(l).push({
                                    name: "presale"
                                })),
                                class: "btn-right btn-add1"
                            }, a[13] || (a[13] = [v("div", {
                                class: "btn-right-body"
                            }, [v("img", {
                                width: "20",
                                class: "mr-2",
                                src: "/images/svg/join.svg",
                                alt: "Google Play Download Link"
                            }), v("div", {
                                class: "btn-txt",
                                style: {
                                    color: "#fafafa !important"
                                }
                            }, " Join Presale ")], -1)]))])]))])])),
                            _: 1
                        }))])),
                        _: 1
                    })])])),
                    _: 1
                })
            }
        }
    }), [
        ["__scopeId", "data-v-62471a17"]
    ]),
    aa = {
        id: "seed-sale",
        class: "flex flex-col items-center justify-center token-detail-card relative mt-2 pb-5 px-2 space-y-8 bg-card-light"
    },
    sa = {
        id: "",
        class: "flex flex-col items-center justify-normal z-20 space-y-4",
        style: {
            "z-index": "11111"
        }
    },
    ia = {
        class: "flex mt-3 items-center justify-center"
    },
    la = {
        class: "flex mb-4 mt-1 items-center justify-center"
    },
    na = ["src"],
    oa = {
        class: "ml-1 title-nw"
    },
    ra = {
        key: 0
    },
    da = {
        width: "330px",
        height: "180px",
        style: {
            top: "126px",
            display: "flex",
            "flex-direction": "column",
            "align-items": "center",
            "justify-content": "center",
            width: "330px",
            height: "180px"
        },
        class: "items-center justify-center",
        initial: {
            opacity: 0,
            y: 0,
            scale: .5
        },
        enter: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                type: "spring",
                stiffness: 25,
                damping: 10,
                mass: 1,
                delay: 100
            }
        }
    },
    ca = {
        style: {
            width: "210px"
        }
    },
    pa = {
        class: "title-nw mt-2 text-gray4",
        style: {
            display: "flex",
            position: "relative",
            "justify-content": "start",
            "padding-left": "36px",
            top: "-33px",
            "font-size": "12px"
        }
    },
    ua = {
        key: 1,
        style: {
            width: "100%"
        },
        class: "box-ai"
    },
    ma = {
        class: "container"
    },
    va = {
        class: "content"
    },
    fa = c(_({
        __name: "OPZAI",
        props: {
            btn: {
                type: Boolean,
                default: !1
            },
            modelValue: {
                type: Boolean,
                default: !0
            },
            symbol: {
                default: ""
            }
        },
        emits: ["update:modelValue", "close"],
        setup(e, {
            emit: t
        }) {
            L();
            const {
                Api: a
            } = D(), s = t, i = e, l = j({
                get: () => i.modelValue,
                set: e => s("update:modelValue", e)
            }), n = k("Generating " + i.symbol + " Analysis");
            let o;
            const d = () => {
                o && clearInterval(o)
            };
            O((() => {
                d()
            }));
            const c = () => {
                    s("update:modelValue", !1)
                },
                g = k(!0),
                h = k(""),
                w = W(),
                x = () => {
                    h.value = "", g.value = !0, (() => {
                        const e = [".", "..", "..."];
                        let t = 0;
                        o = setInterval((() => {
                            n.value = "Generating " + i.symbol + `  Analysis${e[t%e.length]}`, t++
                        }), 500)
                    })(), (async () => {
                        const e = Date.now();
                        "BTC" === i.symbol ? a.getBTCQuery().then((async ({
                            data: t
                        }) => {
                            if (500 == t.code) w.error(t.message), l.value = !1;
                            else if (0 == t.code) {
                                if ("" === h.value) {
                                    const a = Date.now() - e;
                                    a < 2e3 && await ue(2e3 - a), h.value = t.data, g.value = !1
                                } else h.value != t.data && (h.value = t.data, g.value = !1);
                                d()
                            }
                        })) : a.getETHQuery().then((async ({
                            data: t
                        }) => {
                            if (500 == t.code) w.error(t.message), l.value = !1;
                            else if (0 == t.code) {
                                if ("" === h.value) {
                                    const a = Date.now() - e;
                                    a < 2e3 && await ue(2e3 - a), h.value = t.data, g.value = !1
                                } else h.value != t.data && (h.value = t.data, g.value = !1);
                                d()
                            }
                        }))
                    })(), s("update:modelValue", !0);
                    const e = `${window.location.pathname}`;
                    window.history.replaceState({}, "", e)
                },
                _ = e => {
                    e ? window.open("https://play.google.com/store/apps/details?id=com.opz.dev") : window.open("https://testflight.apple.com/join/Oxsd9WMO")
                },
                z = F(),
                A = () => {
                    window.open("https://www.app.opz.com")
                };
            return (e, t) => {
                const a = r,
                    s = U,
                    o = p("motion");
                return u(), m(f, null, [!P(z).isAppOn && i.btn ? (u(), S(a, {
                    key: 0,
                    class: "btn-opz-ai",
                    style: {
                        "min-width": "inherit"
                    },
                    size: "small",
                    onClick: t[0] || (t[0] = e => x())
                }, {
                    default: T((() => t[5] || (t[5] = [I("AI")]))),
                    _: 1
                })) : B("", !0), V(P(ae), {
                    modelValue: l.value,
                    "onUpdate:modelValue": t[3] || (t[3] = e => l.value = e),
                    "append-to": "#app",
                    class: "dialogw cdetail buy-card-pop heads2 rass",
                    "destroy-on-close": "",
                    onClose: c,
                    onOpen: t[4] || (t[4] = e => x())
                }, {
                    header: T((() => t[6] || (t[6] = []))),
                    default: T((() => [v("div", null, [v("div", aa, [t[13] || (t[13] = v("div", {
                        class: "pattern left"
                    }, null, -1)), v("div", sa, [v("div", ia, [t[8] || (t[8] = v("p", {
                        class: "head-title mr-2"
                    }, "OPZ-AI", -1)), V(P(me), {
                        color: "#000",
                        hit: "",
                        class: "text-medium",
                        style: {
                            color: "var(--gray-03)",
                            "border-color": "#7303fc"
                        }
                    }, {
                        default: T((() => t[7] || (t[7] = [I("BETA")]))),
                        _: 1
                    })]), v("div", la, [v("img", {
                        src: "/images/icons/coin/" + i.symbol.toLowerCase() + ".svg",
                        style: {
                            "padding-top": "2px"
                        },
                        width: "21"
                    }, null, 8, na), v("p", oa, b("BTC" === i.symbol ? "Bitcoin" : "Ethereum") + " Technical Analysis Demo: ", 1)]), g.value ? (u(), m("div", ra, [y((u(), m("div", da, [V(P(ce), {
                        class: "fbz-img-lt",
                        animationLink: "/assets/animated/ai5.json",
                        height: 90,
                        width: 90
                    }), V(s, {
                        width: "210px",
                        height: "30px",
                        style: {
                            "border-radius": "3px",
                            "margin-top": "12px"
                        }
                    }), v("div", ca, [v("p", pa, b(n.value), 1)])])), [
                        [o]
                    ])])) : (u(), m("div", ua, [v("div", ma, [v("div", va, [V(P(pe), {
                        source: h.value,
                        breaks: !0,
                        style: {
                            "padding-bottom": "18px"
                        }
                    }, null, 8, ["source"])])])])), v("div", {
                        class: C(["flex justify-center text-center mx-auto items-center", g.value ? "mt-0" : "mt-5"]),
                        style: {
                            position: "relative",
                            "z-index": "11111111"
                        }
                    }, [v("div", {
                        onClick: t[1] || (t[1] = e => _()),
                        class: "cursor-pointer mr-2"
                    }, t[9] || (t[9] = [v("img", {
                        src: Q,
                        alt: "Download OPZ Beta",
                        width: "120"
                    }, null, -1)])), v("div", {
                        onClick: t[2] || (t[2] = e => _(!0)),
                        class: "cursor-pointer"
                    }, t[10] || (t[10] = [v("img", {
                        src: ee,
                        alt: "Download on Google Play",
                        width: "120"
                    }, null, -1)]))], 2), t[12] || (t[12] = v("p", {
                        class: "mt-2 title-nw"
                    }, [I(" Download the app and unlock the full"), v("br"), I(" potential of OPZ-AI ")], -1)), V(P(ve), {
                        "border-style": "double"
                    }), V(a, {
                        size: "medium",
                        onClick: A,
                        class: "web-button mt-2 mb-0",
                        style: {
                            width: "144px"
                        }
                    }, {
                        default: T((() => t[11] || (t[11] = [I("Visit Web App")]))),
                        _: 1
                    })]), t[14] || (t[14] = v("div", {
                        class: "pattern right"
                    }, null, -1))])])])),
                    _: 1
                }, 8, ["modelValue"])], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-cb2956ec"]
    ]),
    ga = {
        class: "container"
    },
    ya = {
        class: "columns is-vcentered pb-3"
    },
    ha = {
        class: "column is-4 hero-caption mt-4"
    },
    ba = {
        class: "container"
    },
    wa = {
        class: "columns is-vcentered pb-3 ai-trd flex column-reverse"
    },
    xa = {
        class: "column is-9 hero-caption mt-4 trd-ai-items"
    },
    _a = {
        class: "column is-4 hero-caption mt-4"
    },
    ja = {
        class: "container pt-4"
    },
    ka = {
        class: "container",
        style: {
            position: "relative",
            bottom: "-42px",
            "padding-top": "0"
        }
    },
    za = _({
        __name: "mpc",
        setup(c) {
            const g = k(!1),
                h = $(),
                b = q({
                    initial: {
                        opacity: 0,
                        y: 30
                    },
                    visibleOnce: {
                        opacity: 1,
                        y: 0,
                        transition: {
                            type: "spring",
                            stiffness: 25,
                            damping: 10,
                            mass: 1,
                            delay: 333
                        }
                    }
                }),
                w = F(),
                x = k(null),
                _ = q({
                    targetX: 0,
                    targetY: 0,
                    currentX: 0,
                    currentY: 0
                }),
                j = e => {
                    _.targetX = e.clientX / window.innerWidth - .5, _.targetY = e.clientY / window.innerHeight - .5
                },
                A = (e, t, a) => (1 - a) * e + a * t,
                C = () => {
                    _.currentX = A(_.currentX, _.targetX, .1), _.currentY = A(_.currentY, _.targetY, .1), (() => {
                        if (x.value) {
                            const e = 20;
                            x.value.style.transform = `translate(${_.currentX*e}px, ${_.currentY*e}px)`
                        }
                    })(), requestAnimationFrame(C)
                };
            return z((() => {
                window.fbq2opz("trackCustom", "VisitHome"), h.event("VisitHome"), requestAnimationFrame(C)
            })), z((() => {
                document.addEventListener("mousemove", j)
            })), O((() => {
                document.removeEventListener("mousemove", j)
            })), k(window.innerWidth <= 767), (c, h) => {
                const _ = K,
                    k = t,
                    z = ta,
                    O = d,
                    A = H,
                    C = r,
                    B = Gt,
                    N = se,
                    E = Tt,
                    L = vt,
                    D = o,
                    W = n,
                    Z = a,
                    M = l,
                    F = s,
                    G = p("motion");
                return u(), m(f, null, [V(_), v("div", {
                    onMousemove: j
                }, [y(v("img", {
                    ref_key: "container",
                    ref: x,
                    src: "/images/infographics/all-dapps4.jpg",
                    alt: "Inforgraphics Background",
                    initial: {
                        y: 100,
                        opacity: 0
                    },
                    enter: {
                        y: 0,
                        opacity: 1,
                        transition: {
                            duration: 600,
                            type: "keyframes",
                            ease: "easeIn"
                        }
                    },
                    style: {
                        position: "absolute",
                        transition: "transform 0.2s ease-out",
                        display: "block",
                        left: "0",
                        top: "0",
                        width: "100%",
                        height: "100%",
                        "object-fit": "cover",
                        "min-height": "100vh",
                        opacity: "1"
                    }
                }, null, 512), [
                    [G]
                ]), V(k)], 32), v("div", null, [V(z), V(N, {
                    color: "grey",
                    "bottom-narrow": "",
                    "bottom-narrow-mobile": ""
                }, {
                    default: T((() => [v("div", ga, [y((u(), m("div", ya, [v("div", ha, [V(O, {
                        tag: "h3",
                        size: 5,
                        weight: "bold",
                        class: "pb-3",
                        leading: ""
                    }, {
                        default: T((() => h[2] || (h[2] = [v("span", {
                            class: "text-gradient text-bold"
                        }, " OPZ-AI ", -1)]))),
                        _: 1
                    }), V(A, {
                        tag: "h3",
                        size: 4,
                        weight: "bold",
                        class: "pt-2",
                        leading: ""
                    }, {
                        default: T((() => h[3] || (h[3] = [I(" Your Advanced AI Crypto Analyst ")]))),
                        _: 1
                    }), h[5] || (h[5] = v("p", {
                        class: "paragraph rem-115 mb-4 text-white"
                    }, " Welcome to OPZ-AI, where the future of crypto analysis means staying ahead, covering over 10,000 coins with real-time, actionable insights. ", -1)), V(C, {
                        onClick: h[0] || (h[0] = e => g.value = !0),
                        size: "small",
                        style: {
                            width: "100px"
                        }
                    }, {
                        default: T((() => h[4] || (h[4] = [I(" Try OPZ-AI ")]))),
                        _: 1
                    })]), V(B, {
                        features: P(de),
                        class: "features-block",
                        limit: 3,
                        size: "medium",
                        links: "",
                        animated: ""
                    }, null, 8, ["features"])])), [
                        [G, b]
                    ])])])),
                    _: 1
                }), V(N, {
                    color: "grey",
                    "bottom-narrow": "",
                    "bottom-narrow-mobile": "",
                    "top-narrow": "",
                    "top-narrow-mobile": ""
                }, {
                    default: T((() => [v("div", ba, [y((u(), m("div", wa, [v("div", xa, [V(e, {
                        maxItems: 3
                    })]), v("div", _a, [V(O, {
                        tag: "h3",
                        size: 5,
                        weight: "bold",
                        class: "pb-3",
                        leading: ""
                    }, {
                        default: T((() => h[6] || (h[6] = [v("span", {
                            class: "text-gradient text-bold"
                        }, " Superintelligence Trader ", -1)]))),
                        _: 1
                    }), V(A, {
                        tag: "h3",
                        size: 4,
                        weight: "bold",
                        class: "pt-2",
                        leading: ""
                    }, {
                        default: T((() => h[7] || (h[7] = [I(" The Future of Trading ")]))),
                        _: 1
                    }), h[8] || (h[8] = v("p", {
                        class: "paragraph rem-115 mb-4 text-white"
                    }, " Superintelligence Trader is an AI-driven system that automates crypto trades, optimizing strategies with real-time analysis. ", -1))])])), [
                        [G, b]
                    ])])])),
                    _: 1
                }), V(N, {
                    class: "section-mpc pb-6",
                    color: "grey",
                    wave: "wave-2",
                    "shape-color": "white",
                    overflown: "",
                    "bottom-narrow": "",
                    "top-narrow-mobile": ""
                }, {
                    default: T((() => [v("div", ja, [y(V(E, {
                        subtitle: "OPZ-NFC",
                        title: "The OPZ NFC Experience",
                        content: "Store your encrypted MPC key on any NFC devices like rings, watches, tags, stickers and more. Connect to WEB3 and unlock the full potential of dApps with a simple tap. ",
                        image: "/assets/animated/nft-spin3.json",
                        "dark-image": "/images/infographics/nft-sign.jpg",
                        benefits: ["Our KeyFusion technology with MFA ensures no single entity accesses the private key.", "KeyFusion enables self-custody of your wallet without worrying about losing access."]
                    }, null, 512), [
                        [G, b]
                    ]), y((u(), S(D, {
                        background: "/assets/shapes/backshape2.jpg",
                        opacity: 0
                    }, {
                        default: T((() => [V(L, {
                            "is-app-on": P(w).isAppOn,
                            subtitle: "Connect to Dapps Like Never Before",
                            title: "The safest way to connect to dApps",
                            content: "Our Multi-Chain Web3 browser featuring real-time dApp security scanning establishes itself as the safest way to interact with dApps.",
                            cta: "Visit Apps Dasboard",
                            inverted: "",
                            to: "apps"
                        }, null, 8, ["is-app-on"])])),
                        _: 1
                    })), [
                        [G, b]
                    ])])])),
                    _: 1
                }), V(N, {
                    "shape-color": "grey",
                    "bottom-narrow": "",
                    style: {
                        "padding-top": "0"
                    }
                }, {
                    default: T((() => [v("div", ka, [V(W, {
                        title: "Take the time to read our FAQs",
                        subtitle: "Frequently Asked"
                    }), V(Z, {
                        left: P(fe).slice(0, 3),
                        right: P(fe).slice(3, 6),
                        chevrons: ""
                    }, null, 8, ["left", "right"])])])),
                    _: 1
                }), h[9] || (h[9] = v("img", {
                    style: {
                        "z-index": "1",
                        width: "100%",
                        height: "270px",
                        "background-color": "var(--section-bg-color)"
                    },
                    src: "/assets/shapes/bottom-line.png",
                    alt: "Circle shape"
                }, null, -1))]), V(fa, {
                    symbol: "BTC",
                    btn: !1,
                    modelValue: g.value,
                    "onUpdate:modelValue": h[1] || (h[1] = e => g.value = e)
                }, null, 8, ["modelValue"]), V(M, {
                    class: "footer-mpc",
                    content: P(i),
                    color: "dark",
                    cta: !0
                }, null, 8, ["content"]), V(F)], 64)
            }
        }
    });
"function" == typeof ge && ge(za);
const Oa = c(za, [
    ["__scopeId", "data-v-4f3299d6"]
]);
export {
    Oa as
    default
};