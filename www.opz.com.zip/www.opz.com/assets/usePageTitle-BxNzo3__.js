import {
    u as e
} from "./vue.8fc199ce-D3bCrqKA.js";
import {
    u as t
} from "./viewWrapper-Dh8gOQC5.js";
import {
    Y as s,
    B as a
} from "./index-jdACH0Rc.js";

function i(i, o) {
    const {
        t: r,
        locale: m
    } = s(), c = t();
    c.setPageTitle(r(i));
    a((() => m.value), (() => {
        const t = r(i);
        c.setPageTitle(t), e({
            title: "OPZ | " + t
        })
    }), {
        immediate: !0
    })
}
export {
    i as u
};