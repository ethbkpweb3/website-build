import {
    g as e,
    y as s
} from "./index-jdACH0Rc.js";
const t = e("viewWrapper", (() => {
    const e = s(!1),
        t = s(!1),
        u = s("Welcome");
    return {
        isPushed: e,
        isPushedBlock: t,
        pageTitle: u,
        setPushed: function(s) {
            e.value = s
        },
        setPushedBlock: function(e) {
            t.value = e
        },
        setPageTitle: function(e) {
            u.value = e
        }
    }
}));
export {
    t as u
};