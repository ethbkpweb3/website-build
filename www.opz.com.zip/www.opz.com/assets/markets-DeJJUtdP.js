import {
    f as e,
    _ as l
} from "./index-B_Hz-fzE.js";
import {
    C as s,
    S as a,
    _ as o
} from "./sockjs.min-CWulKIFY.js";
import {
    _ as i
} from "./Navbar2-DVEXcHRs.js";
import {
    m as t,
    dm as n,
    y as r,
    Y as c,
    a as d,
    G as m,
    u,
    K as g,
    h as p,
    I as v,
    N as h,
    j as b,
    v as k,
    l as y,
    t as w,
    X as f,
    p as x,
    ck as C,
    P as j,
    cB as S,
    s as _,
    n as L,
    w as F,
    dg as D,
    o as T,
    q as U
} from "./index-jdACH0Rc.js";
import {
    _ as E
} from "./lodash-Bck59wt3.js";
import {
    F as R
} from "./browser-B3Bvmjnq.js";
import "./index-Dwv4qbXN.js";
import {
    l as B
} from "./loadingSvg-B2DNNGSL.js";
import {
    u as V
} from "./useSeoMeta-CRPJPIvz.js";
import {
    E as G,
    v as z,
    a as N
} from "./directive-LFHXp42y.js";
import {
    E as P
} from "./index-D4R9Vjdp.js";
import {
    E as I,
    a as O
} from "./index-DZsnwgZr.js";
import {
    E as W
} from "./index-DBFvTDaE.js";
import {
    E as A
} from "./index-CYOIannN.js";
import {
    _ as M
} from "./_plugin-vue_export-helper-BCo6x5W8.js";
import "./Subtitle-ytb6lg8s.js";
import "./ButtonGR-BF9zAU5B.js";
import "./Title-ChmnbwlA.js";
import "./AppPop-C6dVPDH2.js";
import "./index-DPTDKB4o.js";
import "./index-DtPnfIe2.js";
import "./index-Citk0ABi.js";
import "./google-play-0W6tGWt8.js";
import "./VPlaceload-jGgmcTFZ.js";
import "./index-C8W9xb4z.js";
import "./index-B1yvdImc.js";
import "./index-Cg9BJciP.js";
import "./use-dialog-CmZNE833.js";
import "./use-global-config-Dm8LyY4T.js";
import "./index-BWeq1WY3.js";
import "./_commonjs-dynamic-modules-BHR_E30J.js";
import "./Button-BbTMX0Dh.js";
import "./AvatarSimple-CfXnZ0K8.js";
import "./via-placeholder-csI6CdwS.js";
import "./user-qMNVzsWD.js";
import "./sett-Dbwu6PJ1.js";
import "./avatarSettings-Daanxsoo.js";
import "./vue3-avataaars-C_k_hIh4.js";
import "./index-cRGdv3RN.js";
import "./logo-DqlCWKKL.js";
import "./index-DWTvrBdo.js";
import "./aria-C-hsWcn7.js";
import "./typescript-CRqm1_SZ.js";
import "./vue.8fc199ce-D3bCrqKA.js";
import "./index-BahOysPn.js";
import "./_initCloneObject-CyvZF8uk.js";
import "./isPlainObject--3V5F7Ei.js";
const H = {
        class: "markets all-sym"
    },
    q = {
        class: "markets-inner"
    },
    K = {
        class: "markets-header"
    },
    J = {
        class: "markets-top"
    },
    X = {
        class: "markets-top-body"
    },
    Y = {
        class: "markets-top-left"
    },
    Z = {
        key: 0,
        class: "markets-under"
    },
    Q = {
        class: "markets-under-body"
    },
    $ = {
        class: "markets-under-item top-gainer"
    },
    ee = {
        class: "leaderboard"
    },
    le = {
        class: "coin-unit"
    },
    se = {
        class: "coin-price"
    },
    ae = {
        class: "coin-chg"
    },
    oe = ["onClick"],
    ie = {
        class: "rank"
    },
    te = {
        class: "sym"
    },
    ne = ["src"],
    re = {
        class: "coin-unit"
    },
    ce = {
        class: "coin-price"
    },
    de = {
        class: "coin-chg"
    },
    me = {
        class: "markets-under-item populair"
    },
    ue = {
        class: "leaderboard"
    },
    ge = {
        class: "coin-unit"
    },
    pe = {
        class: "coin-price"
    },
    ve = {
        class: "coin-chg"
    },
    he = ["onClick"],
    be = {
        class: "rank"
    },
    ke = {
        class: "sym"
    },
    ye = ["src"],
    we = {
        class: "coin-unit"
    },
    fe = {
        class: "coin-price"
    },
    xe = {
        class: "coin-chg"
    },
    Ce = {
        class: "markets-under-item new-listing"
    },
    je = {
        class: "leaderboard"
    },
    Se = {
        class: "coin-unit"
    },
    _e = {
        class: "coin-price"
    },
    Le = {
        class: "coin-chg"
    },
    Fe = ["onClick"],
    De = {
        class: "rank"
    },
    Te = {
        class: "sym"
    },
    Ue = ["src"],
    Ee = {
        class: "coin-unit"
    },
    Re = {
        class: "coin-price"
    },
    Be = {
        class: "coin-chg"
    },
    Ve = {
        class: "markets-body"
    },
    Ge = {
        class: "markets-body-inner"
    },
    ze = {
        class: "tab-sort mt-0 mb-3"
    },
    Ne = {
        class: "custom-tabs-label"
    },
    Pe = {
        class: "custom-tabs-label"
    },
    Ie = {
        class: "custom-tabs-label"
    },
    Oe = {
        key: 1,
        class: "column is-12 py-0"
    },
    We = {
        class: "asset-category"
    },
    Ae = {
        class: "asset-name"
    },
    Me = ["onClick"],
    He = {
        class: "asset"
    },
    qe = {
        class: "asset-logo"
    },
    Ke = ["src"],
    Je = {
        class: "asset-name"
    },
    Xe = {
        class: "table-coins px-3"
    },
    Ye = ["onClick"],
    Ze = {
        key: 0,
        width: "1.2em",
        height: "1.2em",
        viewBox: "0 0 24 24",
        style: {
            color: "#979797"
        },
        class: "icon-favored"
    },
    Qe = {
        key: 1,
        width: "1.2em",
        height: "1.2em",
        viewBox: "0 0 24 24",
        style: {
            color: "#f0a70a"
        },
        class: "icon-favored"
    },
    $e = ["onClick"],
    el = {
        class: "imgParent"
    },
    ll = ["src"],
    sl = {
        class: "text-medium"
    },
    al = ["onClick"],
    ol = ["onClick"],
    il = ["onClick"],
    tl = ["onClick"],
    nl = ["onClick"],
    rl = M(t({
        __name: "markets",
        setup(t) {
            const {
                Api: M
            } = n(), rl = r(!0), {
                t: cl
            } = c(), dl = r(!1), ml = r(window.innerWidth <= 767), ul = r(""), gl = r(!1), pl = r(!1), vl = r(null), hl = console, bl = d(), kl = m(), yl = u(), wl = r("spot"), fl = r(""), xl = r(""), Cl = e => {
                if (!yl.isLoggedIn) return void bl.error(cl("inx.please-login"));
                const l = new R;
                l.append("symbol", e.symbol), M.addFavor(l).then((l => {
                    0 == l.data.code && (_l(e.symbol).isFavor = !0, e.isFavor = !0, Sl.coins.favor.push(e))
                }))
            }, jl = e => {
                if (!yl.isLoggedIn) return void bl.error(cl("inx.please-login"));
                const l = new R;
                l.append("symbol", e.symbol), M.deleteFavor(l).then((l => {
                    if (0 == l.data.code) {
                        _l(e.symbol).isFavor = !1;
                        for (let l = 0; l < Sl.coins.favor.length; l++) {
                            if (Sl.coins.favor[l].symbol == e.symbol) {
                                Sl.coins.favor.splice(l, 1);
                                break
                            }
                        }
                    }
                }))
            }, Sl = g({
                topGainerCoins: [],
                symbol: "",
                categories: [],
                categoriesName: [],
                coins: {
                    _map: [],
                    USDT: [],
                    BTC: [],
                    ETH: [],
                    favor: []
                }
            }), _l = e => Sl.coins._map[e];
            M.getSiteData().then((e => {
                const l = e.data;
                0 == l.code && (Sl.categories = l.data, Object.keys(Sl.categories).forEach((e => {
                    const l = e,
                        s = Sl.categories[e];
                    l && "id" != l && "newlisting" != l && "popular" != l && s && Sl.categoriesName.push(l)
                })))
            }));
            M.getSymbol().then((e => {
                var l, s, a;
                let o = e.data;
                for (let i in o) o[i].base = o[i].symbol.split("/")[1], Sl.coins._map = [], Sl.coins.favor = [], Sl.coins.USDT = [], Sl.coins.BTC = [], Sl.coins.ETH = [];
                for (let i in o) {
                    let e = o[i];
                    e.rose = o[i].chg > 0 ? "+" + (100 * o[i].chg).toFixed(2) + "%" : (100 * o[i].chg).toFixed(2) + "%", e.coin = o[i].symbol.split("/")[0], e.base = o[i].symbol.split("/")[1], e.href = (e.coin + "_" + e.base).toLowerCase(), e.isFavor = !1, Sl.coins._map[e.symbol] = e, Sl.coins[e.base].push(e)
                }
                rl.value = !1, yl.isLoggedIn && M.getFavor().then((e => {
                    Sl.coins.favor = [];
                    const l = e.data;
                    for (const s in l) {
                        let e = _l(l[s].symbol);
                        null != e && (e.isFavor = !0, Sl.coins.favor.push(e))
                    }
                })), Sl.topGainerCoins = null == (a = null == (s = null == (l = Sl.coins) ? void 0 : l.USDT) ? void 0 : s.sort(((e, l) => l.chg - e.chg))) ? void 0 : a.slice(0, 3)
            }));
            const Ll = p((() => {
                var e;
                return null == (e = "spot" == wl.value ? Sl.coins.USDT : "favor" == wl.value ? Sl.coins.favor : Sl.coins.BTC) ? void 0 : e.filter((e => (!fl.value || e.symbol.toLowerCase().includes(fl.value.toLowerCase())) && (!xl.value || String(Sl.categories[xl.value]).includes(e.symbol.split("/")[0]))))
            }));
            let Fl;
            v((async () => {
                var e;
                Fl = E.throttle((() => {
                    ml.value = window.innerWidth <= 767
                }), 100), window.addEventListener("resize", Fl), e = M.wsMarket, vl.value && vl.value.deactivate(), hl.log("Connecting..."), vl.value = null, vl.value = new s({
                    brokerURL: e,
                    logRawCommunication: !1,
                    webSocketFactory: () => (hl.log("webSocketFactory"), a(e)),
                    onStompError: e => {
                        hl.log("Stomp Error", e)
                    },
                    onConnect: e => {
                        hl.log("Stomp Connect", e), pl.value = !0, vl.value.subscribe("/topic/market/thumb", (e => {
                            let l = JSON.parse(e.body),
                                s = _l(l.symbol);
                            null != s && (s.price = l.close, s.rose = l.chg > 0 ? "+" + (100 * l.chg).toFixed(2) + "%" : (100 * l.chg).toFixed(2) + "%", s.close = l.close, s.high = l.high, s.low = l.low, s.change = l.change, s.chg = l.chg, s.turnover = parseInt(l.volume), s.volume = l.volume, s.usdRate = l.usdRate)
                        }))
                    },
                    onDisconnect: e => {
                        hl.log("Stomp Disconnect", e)
                    },
                    onWebSocketClose: e => {
                        hl.log("Stomp WebSocket Closed", e)
                    },
                    onWebSocketError: e => {
                        hl.log("Stomp WebSocket Error", e)
                    }
                })
            })), h((() => {
                window.removeEventListener("resize", Fl), vl.value && (vl.value.deactivate(), vl.value = null)
            }));
            const Dl = e => {
                kl.push({
                    name: "trade-slug",
                    params: {
                        slug: e.symbol.replace("/", "-")
                    }
                })
            };
            return V(cl("inx.markets") + " | Crypto Market Overview", "Browse all trading pairs and market data on OPZ."), (s, a) => {
                var t, n, r, c, d, m, u, g, p, v, h, E, R;
                const V = i,
                    M = o,
                    pl = l;
                return T(), b(j, null, [k(V, {
                    notfixed: !0
                }), y("div", H, [y("div", q, [y("div", K, [y("div", J, [y("div", X, [y("div", Y, w(f(cl)("inx.markets")), 1), a[4] || (a[4] = y("div", {
                    class: "markets-top-right"
                }, null, -1))])]), rl.value ? _("", !0) : (T(), b("div", Z, [y("div", Q, [y("div", $, [y("div", ee, [y("div", {
                    class: x(["bg-leader", (null == (t = Sl.topGainerCoins) ? void 0 : t.length) < 3 && "small-leader"]),
                    style: C("background-image: url(/images/icons/coin/" + (null == (n = Sl.topGainerCoins[0]) ? void 0 : n.coin.toLowerCase()) + ".svg);")
                }, null, 6), a[7] || (a[7] = y("header", null, [y("h1", null, "Top Gainer")], -1)), y("table", null, [y("thead", null, [y("tr", null, [a[5] || (a[5] = y("th", {
                    class: "rank"
                }, null, -1)), a[6] || (a[6] = y("th", {
                    class: "sym"
                }, null, -1)), y("th", le, w(f(cl)("depwi.coin")), 1), y("th", se, w(f(cl)("exh.price")), 1), y("th", ae, w(f(cl)("exh.24h-change")), 1)])]), y("tbody", null, [(T(!0), b(j, null, S(Sl.topGainerCoins, ((e, l) => {
                    var s, a;
                    return T(), b("tr", {
                        key: l,
                        onClick: l => {
                            var s;
                            return f(kl).push({
                                name: "trade-slug",
                                params: {
                                    slug: null == (s = e.symbol) ? void 0 : s.replace("/", "-")
                                }
                            })
                        }
                    }, [y("td", ie, w(l + 1), 1), y("td", te, [y("img", {
                        width: "18",
                        height: "18",
                        alt: "",
                        src: "/images/icons/coin/" + (null == (a = null == (s = e.symbol) ? void 0 : s.split("/")[0]) ? void 0 : a.toLowerCase()) + ".svg"
                    }, null, 8, ne)]), y("td", re, w(e.symbol.split("/")[0]), 1), y("td", ce, w(e.usdRate.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })), 1), y("td", de, [y("span", {
                        class: x(e.change > 0 ? "text-green-500" : e.change < 0 ? "text-red-500" : "")
                    }, w((e.change > 0 ? "+" : "") + (100 * e.chg).toFixed(2)) + "% ", 3)])], 8, oe)
                })), 128))])])])]), y("div", me, [y("div", ue, [y("div", {
                    class: x(["bg-leader", (null == (r = Sl.categories.popular) ? void 0 : r.split(",").length) < 3 && "small-leader"]),
                    style: C("background-image: url(/images/icons/coin/" + (null == (d = null == (c = Sl.categories.popular) ? void 0 : c.split(",")[0]) ? void 0 : d.toLowerCase()) + ".svg);")
                }, null, 6), a[10] || (a[10] = y("header", null, [y("h1", null, "Populair")], -1)), y("table", null, [y("thead", null, [y("tr", null, [a[8] || (a[8] = y("th", {
                    class: "rank"
                }, null, -1)), a[9] || (a[9] = y("th", {
                    class: "sym"
                }, null, -1)), y("th", ge, w(f(cl)("depwi.coin")), 1), y("th", pe, w(f(cl)("exh.price")), 1), y("th", ve, w(f(cl)("exh.24h-change")), 1)])]), y("tbody", null, [(T(!0), b(j, null, S(null == (u = null == (m = Sl.categories.popular) ? void 0 : m.split(",")) ? void 0 : u.slice(0, 3), ((e, l) => {
                    var s, a, o, i, t, n;
                    return T(), b("tr", {
                        key: l,
                        onClick: l => f(kl).push({
                            name: "trade-slug",
                            params: {
                                slug: e + "-USDT"
                            }
                        })
                    }, [y("td", be, w(l + 1), 1), y("td", ke, [y("img", {
                        width: "18",
                        height: "18",
                        alt: "",
                        src: "/images/icons/coin/" + (null == e ? void 0 : e.toLowerCase()) + ".svg"
                    }, null, 8, ye)]), y("td", we, w(e), 1), y("td", fe, w(null == (a = null == (s = Sl.coins._map[e + "/USDT"]) ? void 0 : s.usdRate) ? void 0 : a.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })), 1), y("td", xe, [y("span", {
                        class: x((null == (o = Sl.coins._map[e + "/USDT"]) ? void 0 : o.change) > 0 ? "text-green-500" : (null == (i = Sl.coins._map[e + "/USDT"]) ? void 0 : i.change) < 0 ? "text-red-500" : "")
                    }, w(((null == (t = Sl.coins._map[e + "/USDT"]) ? void 0 : t.change) > 0 ? "+" : "") + (100 * (null == (n = Sl.coins._map[e + "/USDT"]) ? void 0 : n.chg)).toFixed(2)) + "% ", 3)])], 8, he)
                })), 128))])])])]), y("div", Ce, [y("div", je, [y("div", {
                    class: x(["bg-leader", (null == (p = null == (g = Sl.categories.newlisting) ? void 0 : g.split(",")) ? void 0 : p.length) < 3 && "small-leader"]),
                    style: C("background-image: url(/images/icons/coin/" + (null == (h = null == (v = Sl.categories.newlisting) ? void 0 : v.split(",")[0]) ? void 0 : h.toLowerCase()) + ".svg);")
                }, null, 6), y("header", null, [y("h1", null, w(f(cl)("inx.new-listing")), 1)]), y("table", null, [y("thead", null, [y("tr", null, [a[11] || (a[11] = y("th", {
                    class: "rank"
                }, null, -1)), a[12] || (a[12] = y("th", {
                    class: "sym"
                }, null, -1)), y("th", Se, w(f(cl)("depwi.coin")), 1), y("th", _e, w(f(cl)("exh.price")), 1), y("th", Le, w(f(cl)("exh.24h-change")), 1)])]), y("tbody", null, [(T(!0), b(j, null, S(null == (R = null == (E = Sl.categories.newlisting) ? void 0 : E.split(",")) ? void 0 : R.slice(0, 3), ((e, l) => {
                    var s, a, o, i, t, n;
                    return T(), b("tr", {
                        key: l,
                        onClick: l => f(kl).push({
                            name: "trade-slug",
                            params: {
                                slug: e + "-USDT"
                            }
                        })
                    }, [y("td", De, w(l + 1), 1), y("td", Te, [y("img", {
                        width: "18",
                        height: "18",
                        alt: "",
                        src: "/images/icons/coin/" + (null == e ? void 0 : e.toLowerCase()) + ".svg"
                    }, null, 8, Ue)]), y("td", Ee, w(e), 1), y("td", Re, w(null == (a = null == (s = Sl.coins._map[e + "/USDT"]) ? void 0 : s.usdRate) ? void 0 : a.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })), 1), y("td", Be, [y("span", {
                        class: x((null == (o = Sl.coins._map[e + "/USDT"]) ? void 0 : o.change) > 0 ? "text-green-500" : (null == (i = Sl.coins._map[e + "/USDT"]) ? void 0 : i.change) < 0 ? "text-red-500" : "")
                    }, w(((null == (t = Sl.coins._map[e + "/USDT"]) ? void 0 : t.change) > 0 ? "+" : "") + (100 * (null == (n = Sl.coins._map[e + "/USDT"]) ? void 0 : n.chg)).toFixed(2)) + "% ", 3)])], 8, Fe)
                })), 128))])])])])])]))]), y("div", Ve, [y("div", Ge, [y("div", ze, [null != Sl.coins.USDT ? (T(), L(f(G), {
                    key: 0,
                    modelValue: wl.value,
                    "onUpdate:modelValue": a[1] || (a[1] = e => wl.value = e),
                    class: "markets-tabs text-medium"
                }, {
                    default: F((() => [k(f(N), {
                        name: "favor",
                        class: ""
                    }, {
                        label: F((() => [y("span", Ne, [a[13] || (a[13] = y("i", {
                            class: "mr-2 iconStar fas fa-star"
                        }, null, -1)), y("span", null, w(f(cl)("wall.favorites")), 1)])])),
                        _: 1
                    }), k(f(N), {
                        name: "spot"
                    }, {
                        label: F((() => [y("span", Pe, [y("span", null, w(f(cl)("dash.spot")), 1)])])),
                        _: 1
                    }), k(f(N), {
                        name: "perpetual"
                    }, {
                        label: F((() => [y("span", Ie, [y("span", null, w(f(cl)("inx.futures")), 1)])])),
                        _: 1
                    }), k(f(N), {
                        disabled: ""
                    }, {
                        label: F((() => [k(f(W), {
                            modelValue: fl.value,
                            "onUpdate:modelValue": a[0] || (a[0] = e => fl.value = e),
                            class: "searchCoin",
                            placeholder: f(cl)("dash.search")
                        }, {
                            prefix: F((() => a[14] || (a[14] = [y("i", {
                                class: "el-input__icon fas fa-search"
                            }, null, -1)]))),
                            _: 1
                        }, 8, ["modelValue", "placeholder"])])),
                        _: 1
                    })])),
                    _: 1
                }, 8, ["modelValue"])) : _("", !0), rl.value ? _("", !0) : (T(), b("div", Oe, [k(f(P), null, {
                    default: F((() => [y("div", We, [y("div", {
                        class: x(["category", "" == xl.value && "active-cat"]),
                        onClick: a[2] || (a[2] = e => xl.value = "")
                    }, [a[15] || (a[15] = y("div", {
                        class: "asset"
                    }, [y("div", {
                        class: "asset-logo"
                    }, [y("img", {
                        src: "/images/icons/cat/all.svg",
                        class: "img-asset"
                    })])], -1)), y("div", Ae, w(f(cl)("dash.all")), 1)], 2), (T(!0), b(j, null, S(Sl.categoriesName, ((e, l) => (T(), b("div", {
                        key: l,
                        class: x(["category", xl.value == e && "active-cat"]),
                        onClick: l => xl.value = e
                    }, [y("div", He, [y("div", qe, [y("img", {
                        src: "/images/icons/cat/" + e + ".svg",
                        class: "img-asset"
                    }, null, 8, Ke)])]), y("div", Je, w(f(cl)("ctm." + e)), 1)], 10, Me)))), 128))])])),
                    _: 1
                })]))]), y("div", Xe, [D((T(), L(f(I), {
                    "element-loading-background": "rgba(122, 122, 122, 0.8)",
                    "element-loading-text": f(cl)("pga.loading"),
                    "element-loading-spinner": f(B),
                    "element-loading-svg-view-box": "-10, -10, 50, 50",
                    data: Ll.value,
                    "tooltip-effect": "dark",
                    class: "slim-table",
                    "table-layout": "fixed",
                    style: {
                        width: "100%",
                        "min-height": "150px"
                    }
                }, {
                    default: F((() => [k(f(O), {
                        label: f(cl)("wall.symbol"),
                        width: "165",
                        "label-class-name": "coinName"
                    }, {
                        default: F((e => {
                            var l;
                            return [y("button", {
                                class: "btnRate",
                                onClick: l => {
                                    var s;
                                    1 == (s = e.row).isFavor ? jl(s) : 0 == s.isFavor && Cl(s)
                                }
                            }, [e.row.isFavor ? _("", !0) : (T(), b("svg", Ze, a[16] || (a[16] = [y("g", {
                                fill: "none",
                                stroke: "currentColor",
                                "stroke-width": "2",
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round"
                            }, [y("path", {
                                d: "M12 2l3.09 6.26L22 9.27l-5 4.87l1.18 6.88L12 17.77l-6.18 3.25L7 14.14L2 9.27l6.91-1.01L12 2z"
                            })], -1)]))), e.row.isFavor ? (T(), b("svg", Qe, a[17] || (a[17] = [y("g", {
                                fill: "none",
                                stroke: "currentColor",
                                "stroke-width": "2",
                                "stroke-linecap": "round",
                                "stroke-linejoin": "round"
                            }, [y("path", {
                                d: "M12 2l3.09 6.26L22 9.27l-5 4.87l1.18 6.88L12 17.77l-6.18 3.25L7 14.14L2 9.27l6.91-1.01L12 2z",
                                style: {
                                    fill: "#f0a70a"
                                }
                            })], -1)]))) : _("", !0)], 8, Ye), y("div", {
                                class: x(e.row.symbol == Sl.symbol ? "" : "cursor-pointer"),
                                onClick: () => {
                                    Dl(e.row)
                                }
                            }, [y("span", el, [y("img", {
                                class: "imgSelect",
                                src: "/images/icons/coin/" + (null == (l = e.row.coin) ? void 0 : l.toLowerCase()) + ".svg"
                            }, null, 8, ll)]), y("span", sl, w(e.row.symbol), 1)], 10, $e)]
                        })),
                        _: 1
                    }, 8, ["label"]), k(f(O), {
                        label: f(cl)("exh.price"),
                        prop: "usdRate",
                        align: "right",
                        sortable: ""
                    }, {
                        default: F((e => [y("div", {
                            onClick: () => {
                                Dl(e.row)
                            }
                        }, w(e.row.usdRate.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 9, al)])),
                        _: 1
                    }, 8, ["label"]), ml.value ? _("", !0) : (T(), L(f(O), {
                        key: 0,
                        label: f(cl)("exh.24h-high"),
                        align: "right",
                        sortable: ""
                    }, {
                        default: F((e => [y("div", {
                            onClick: () => {
                                Dl(e.row)
                            }
                        }, w(e.row.high.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 9, ol)])),
                        _: 1
                    }, 8, ["label"])), ml.value ? _("", !0) : (T(), L(f(O), {
                        key: 1,
                        label: f(cl)("exh.24h-low"),
                        align: "right",
                        sortable: ""
                    }, {
                        default: F((e => [y("div", {
                            onClick: () => {
                                Dl(e.row)
                            }
                        }, w(e.row.low.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 9, il)])),
                        _: 1
                    }, 8, ["label"])), ml.value ? _("", !0) : (T(), L(f(O), {
                        key: 2,
                        label: f(cl)("exh.24h-volume"),
                        align: "right",
                        sortable: ""
                    }, {
                        default: F((e => [y("div", {
                            onClick: () => {
                                Dl(e.row)
                            }
                        }, w(e.row.volume.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 9, tl)])),
                        _: 1
                    }, 8, ["label"])), k(f(O), {
                        label: ml.value ? "24H" : f(cl)("exh.24h-change"),
                        prop: "change",
                        align: "right",
                        sortable: ""
                    }, {
                        default: F((e => [y("div", {
                            class: x(e.row.symbol == Sl.symbol ? "" : "cursor-pointer"),
                            onClick: () => {
                                Dl(e.row)
                            }
                        }, [y("span", {
                            class: x(e.row.change > 0 ? "text-green-500" : e.row.change < 0 ? "text-red-500" : "")
                        }, w((e.row.change > 0 ? "+" : "") + (100 * e.row.chg).toFixed(2)) + "% ", 3)], 10, nl)])),
                        _: 1
                    }, 8, ["label"]), ml.value ? _("", !0) : (T(), L(f(O), {
                        key: 3,
                        align: "right"
                    }, {
                        header: F((() => a[18] || (a[18] = []))),
                        default: F((e => [k(f(A), {
                            text: "",
                            size: "small",
                            class: "text-10 text-medium",
                            onClick: l => (e => {
                                ul.value = e.row.symbol.split("/")[0], dl.value = !0, gl.value = !0
                            })(e)
                        }, {
                            default: F((() => [U(w(f(cl)("sett.details")), 1)])),
                            _: 2
                        }, 1032, ["onClick"]), k(f(A), {
                            text: "",
                            size: "small",
                            class: "text-10 text-medium",
                            onClick: l => (e => {
                                kl.push({
                                    name: "trade-slug",
                                    params: {
                                        slug: e.row.symbol.replace("/", "-")
                                    }
                                })
                            })(e)
                        }, {
                            default: F((() => [U(w(f(cl)("sett.trade")), 1)])),
                            _: 2
                        }, 1032, ["onClick"])])),
                        _: 1
                    }))])),
                    _: 1
                }, 8, ["element-loading-text", "element-loading-spinner", "data"])), [
                    [f(z), rl.value]
                ])])])])])]), dl.value ? (T(), L(M, {
                    key: 0,
                    single: !1,
                    coinname: ul.value,
                    modelValue: gl.value,
                    "onUpdate:modelValue": a[3] || (a[3] = e => gl.value = e)
                }, null, 8, ["coinname", "modelValue"])) : _("", !0), k(pl, {
                    content: f(e),
                    cta: !1,
                    color: "dark"
                }, null, 8, ["content"])], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-864f5e8e"]
    ]);
export {
    rl as
    default
};