import {
    f as l,
    _ as e
} from "./index-B_Hz-fzE.js";
import {
    C as s,
    S as a,
    _ as o
} from "./sockjs.min-CWulKIFY.js";
import {
    _ as i
} from "./Navbar2-DVEXcHRs.js";
import {
    m as t,
    dm as n,
    y as r,
    Y as c,
    a as d,
    G as u,
    u as m,
    K as g,
    h as p,
    I as v,
    N as h,
    cC as b,
    j as k,
    v as y,
    l as w,
    w as x,
    X as C,
    p as f,
    ck as j,
    t as S,
    P as _,
    cB as D,
    s as T,
    n as F,
    dg as L,
    o as U,
    q as E
} from "./index-jdACH0Rc.js";
import {
    _ as G
} from "./lodash-Bck59wt3.js";
import "./index-Dwv4qbXN.js";
import {
    l as P
} from "./loadingSvg-B2DNNGSL.js";
import {
    u as R
} from "./useSeoMeta-CRPJPIvz.js";
import {
    E as V
} from "./index-CYOIannN.js";
import {
    E as B,
    v as z,
    a as N
} from "./directive-LFHXp42y.js";
import {
    E as O
} from "./index-D4R9Vjdp.js";
import {
    E as W,
    a as A
} from "./index-DZsnwgZr.js";
import {
    E as I
} from "./index-DBFvTDaE.js";
import {
    _ as M
} from "./_plugin-vue_export-helper-BCo6x5W8.js";
import "./Subtitle-ytb6lg8s.js";
import "./ButtonGR-BF9zAU5B.js";
import "./Title-ChmnbwlA.js";
import "./AppPop-C6dVPDH2.js";
import "./browser-B3Bvmjnq.js";
import "./index-DPTDKB4o.js";
import "./index-DtPnfIe2.js";
import "./index-Citk0ABi.js";
import "./google-play-0W6tGWt8.js";
import "./VPlaceload-jGgmcTFZ.js";
import "./index-C8W9xb4z.js";
import "./index-B1yvdImc.js";
import "./index-Cg9BJciP.js";
import "./use-dialog-CmZNE833.js";
import "./use-global-config-Dm8LyY4T.js";
import "./index-BWeq1WY3.js";
import "./_commonjs-dynamic-modules-BHR_E30J.js";
import "./Button-BbTMX0Dh.js";
import "./AvatarSimple-CfXnZ0K8.js";
import "./via-placeholder-csI6CdwS.js";
import "./user-qMNVzsWD.js";
import "./sett-Dbwu6PJ1.js";
import "./avatarSettings-Daanxsoo.js";
import "./vue3-avataaars-C_k_hIh4.js";
import "./index-cRGdv3RN.js";
import "./logo-DqlCWKKL.js";
import "./index-DWTvrBdo.js";
import "./aria-C-hsWcn7.js";
import "./typescript-CRqm1_SZ.js";
import "./vue.8fc199ce-D3bCrqKA.js";
import "./index-BahOysPn.js";
import "./_initCloneObject-CyvZF8uk.js";
import "./isPlainObject--3V5F7Ei.js";
const H = {
        class: "markets all-sym"
    },
    q = {
        class: "markets-inner"
    },
    K = {
        class: "markets-header"
    },
    Z = {
        class: "markets-top"
    },
    J = {
        class: "markets-top-body"
    },
    X = {
        class: "markets-top-right"
    },
    Y = {
        key: 0,
        class: "markets-under"
    },
    Q = {
        class: "markets-under-body"
    },
    $ = {
        class: "markets-under-item top-gainer"
    },
    ll = {
        class: "leaderboard"
    },
    el = {
        class: "coin-unit"
    },
    sl = {
        class: "coin-price"
    },
    al = {
        class: "coin-chg"
    },
    ol = ["onClick"],
    il = {
        class: "rank"
    },
    tl = {
        class: "sym"
    },
    nl = ["src"],
    rl = {
        class: "coin-unit"
    },
    cl = {
        class: "coin-price"
    },
    dl = {
        class: "coin-chg"
    },
    ul = {
        class: "markets-under-item populair"
    },
    ml = {
        class: "leaderboard"
    },
    gl = {
        class: "coin-unit"
    },
    pl = {
        class: "coin-price"
    },
    vl = {
        class: "coin-chg"
    },
    hl = ["onClick"],
    bl = {
        class: "rank"
    },
    kl = {
        class: "sym"
    },
    yl = ["src"],
    wl = {
        class: "coin-unit"
    },
    xl = {
        class: "coin-price"
    },
    Cl = {
        class: "coin-chg"
    },
    fl = {
        class: "markets-under-item new-listing"
    },
    jl = {
        class: "leaderboard"
    },
    Sl = {
        class: "coin-unit"
    },
    _l = {
        class: "coin-price"
    },
    Dl = {
        class: "coin-chg"
    },
    Tl = ["onClick"],
    Fl = {
        class: "rank"
    },
    Ll = {
        class: "sym"
    },
    Ul = ["src"],
    El = {
        class: "coin-unit"
    },
    Gl = {
        class: "coin-price"
    },
    Pl = {
        class: "coin-chg"
    },
    Rl = {
        class: "markets-body"
    },
    Vl = {
        class: "markets-body-inner"
    },
    Bl = {
        class: "tab-sort mt-0 mb-3"
    },
    zl = {
        class: "custom-tabs-label"
    },
    Nl = {
        key: 1,
        class: "column is-12 py-0"
    },
    Ol = {
        class: "asset-category"
    },
    Wl = {
        class: "asset-name"
    },
    Al = ["onClick"],
    Il = {
        class: "asset"
    },
    Ml = {
        class: "asset-logo"
    },
    Hl = ["src"],
    ql = {
        class: "asset-name"
    },
    Kl = {
        class: "table-coins px-3"
    },
    Zl = ["onClick"],
    Jl = {
        class: "imgParent"
    },
    Xl = ["src"],
    Yl = {
        class: "text-medium"
    },
    Ql = ["onClick"],
    $l = ["onClick"],
    le = ["onClick"],
    ee = ["onClick"],
    se = ["onClick"],
    ae = M(t({
        __name: "overview",
        setup(t) {
            const {
                Api: M
            } = n(), ae = r(!0), {
                t: oe
            } = c(), ie = r(!1), te = r(window.innerWidth <= 767), ne = r(""), re = r(!1), ce = r(!1), de = r(null), ue = console;
            d();
            const me = u(),
                ge = m(),
                pe = r("spot"),
                ve = r(""),
                he = r(""),
                be = g({
                    topGainerCoins: [],
                    symbol: "",
                    categories: [],
                    categoriesName: [],
                    coins: {
                        _map: [],
                        USDT: [],
                        BTC: [],
                        ETH: [],
                        favor: []
                    }
                }),
                ke = l => be.coins._map[l];
            M.getSiteData().then((l => {
                const e = l.data;
                0 == e.code && (be.categories = e.data, Object.keys(be.categories).forEach((l => {
                    const e = l,
                        s = be.categories[l];
                    e && "id" != e && "newlisting" != e && "popular" != e && s && be.categoriesName.push(e)
                })))
            }));
            M.getSymbol().then((l => {
                var e, s, a;
                let o = l.data;
                for (let i in o) o[i].base = o[i].symbol.split("/")[1], be.coins._map = [], be.coins.favor = [], be.coins.USDT = [], be.coins.BTC = [], be.coins.ETH = [];
                for (let i in o) {
                    let l = o[i];
                    l.rose = o[i].chg > 0 ? "+" + (100 * o[i].chg).toFixed(2) + "%" : (100 * o[i].chg).toFixed(2) + "%", l.coin = o[i].symbol.split("/")[0], l.base = o[i].symbol.split("/")[1], l.href = (l.coin + "_" + l.base).toLowerCase(), l.isFavor = !1, be.coins._map[l.symbol] = l, be.coins[l.base].push(l)
                }
                ae.value = !1, ge.isLoggedIn && M.getFavor().then((l => {
                    be.coins.favor = [];
                    const e = l.data;
                    for (const s in e) {
                        let l = ke(e[s].symbol);
                        null != l && (l.isFavor = !0, be.coins.favor.push(l))
                    }
                })), be.topGainerCoins = null == (a = null == (s = null == (e = be.coins) ? void 0 : e.USDT) ? void 0 : s.sort(((l, e) => e.chg - l.chg))) ? void 0 : a.slice(0, 3)
            }));
            const ye = p((() => {
                var l;
                return null == (l = "spot" == pe.value ? be.coins.USDT : "favor" == pe.value ? be.coins.favor : be.coins.BTC) ? void 0 : l.filter((l => (!ve.value || l.symbol.toLowerCase().includes(ve.value.toLowerCase())) && (!he.value || String(be.categories[he.value]).includes(l.symbol.split("/")[0]))))
            }));
            let we;
            v((async () => {
                var l;
                we = G.throttle((() => {
                    te.value = window.innerWidth <= 767
                }), 100), window.addEventListener("resize", we), l = M.wsMarket, de.value && de.value.deactivate(), ue.log("Connecting..."), de.value = null, de.value = new s({
                    brokerURL: l,
                    logRawCommunication: !1,
                    webSocketFactory: () => (ue.log("webSocketFactory"), a(l)),
                    onStompError: l => {
                        ue.log("Stomp Error", l)
                    },
                    onConnect: l => {
                        ue.log("Stomp Connect", l), ce.value = !0, de.value.subscribe("/topic/market/thumb", (l => {
                            let e = JSON.parse(l.body),
                                s = ke(e.symbol);
                            null != s && (s.price = e.close, s.rose = e.chg > 0 ? "+" + (100 * e.chg).toFixed(2) + "%" : (100 * e.chg).toFixed(2) + "%", s.close = e.close, s.high = e.high, s.low = e.low, s.change = e.change, s.chg = e.chg, s.turnover = parseInt(e.volume), s.volume = e.volume, s.usdRate = e.usdRate)
                        }))
                    },
                    onDisconnect: l => {
                        ue.log("Stomp Disconnect", l)
                    },
                    onWebSocketClose: l => {
                        ue.log("Stomp WebSocket Closed", l)
                    },
                    onWebSocketError: l => {
                        ue.log("Stomp WebSocket Error", l)
                    }
                })
            })), h((() => {
                window.removeEventListener("resize", we), de.value && (de.value.deactivate(), de.value = null)
            }));
            const xe = l => {
                me.push({
                    name: "trade-slug",
                    params: {
                        slug: l.symbol.replace("/", "-")
                    }
                })
            };
            return R(oe("inx.markets") + " | Crypto Market Overview", "Browse all trading pairs and market data on OPZ."), (s, a) => {
                var t, n, r, c, d, u, m, g, p, v, h, G, R;
                const M = i,
                    ce = b("ss"),
                    de = o,
                    ue = e;
                return U(), k(_, null, [y(M, {
                    notfixed: !0
                }), w("div", H, [w("div", q, [w("div", K, [w("div", Z, [w("div", J, [a[5] || (a[5] = w("div", {
                    class: "markets-top-left"
                }, "OPZ GPTs", -1)), w("div", X, [y(C(V), {
                    size: "small",
                    text: "",
                    class: "text-10 text-medium"
                }, {
                    default: x((() => a[4] || (a[4] = [w("i", {
                        class: "fas fa-plus mr-1"
                    }, null, -1), E(" Create GPT")]))),
                    _: 1
                })])])]), ae.value ? T("", !0) : (U(), k("div", Y, [w("div", Q, [w("div", $, [w("div", ll, [w("div", {
                    class: f(["bg-leader", (null == (t = be.topGainerCoins) ? void 0 : t.length) < 3 && "small-leader"]),
                    style: j("background-image: url(/images/icons/coin/" + (null == (n = be.topGainerCoins[0]) ? void 0 : n.coin.toLowerCase()) + ".svg);")
                }, null, 6), a[8] || (a[8] = w("header", null, [w("h1", null, "Top Gainer")], -1)), w("table", null, [w("thead", null, [w("tr", null, [a[6] || (a[6] = w("th", {
                    class: "rank"
                }, null, -1)), a[7] || (a[7] = w("th", {
                    class: "sym"
                }, null, -1)), w("th", el, S(C(oe)("depwi.coin")), 1), w("th", sl, S(C(oe)("exh.price")), 1), w("th", al, S(C(oe)("exh.24h-change")), 1)])]), w("tbody", null, [(U(!0), k(_, null, D(be.topGainerCoins, ((l, e) => {
                    var s, a;
                    return U(), k("tr", {
                        key: e,
                        onClick: e => {
                            var s;
                            return C(me).push({
                                name: "trade-slug",
                                params: {
                                    slug: null == (s = l.symbol) ? void 0 : s.replace("/", "-")
                                }
                            })
                        }
                    }, [w("td", il, S(e + 1), 1), w("td", tl, [w("img", {
                        width: "18",
                        height: "18",
                        alt: "",
                        src: "/images/icons/coin/" + (null == (a = null == (s = l.symbol) ? void 0 : s.split("/")[0]) ? void 0 : a.toLowerCase()) + ".svg"
                    }, null, 8, nl)]), w("td", rl, S(l.symbol.split("/")[0]), 1), w("td", cl, S(l.usdRate.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })), 1), w("td", dl, [w("span", {
                        class: f(l.change > 0 ? "text-green-500" : l.change < 0 ? "text-red-500" : "")
                    }, S((l.change > 0 ? "+" : "") + (100 * l.chg).toFixed(2)) + "% ", 3)])], 8, ol)
                })), 128))])])])]), w("div", ul, [w("div", ml, [w("div", {
                    class: f(["bg-leader", (null == (r = be.categories.popular) ? void 0 : r.split(",").length) < 3 && "small-leader"]),
                    style: j("background-image: url(/images/icons/coin/" + (null == (d = null == (c = be.categories.popular) ? void 0 : c.split(",")[0]) ? void 0 : d.toLowerCase()) + ".svg);")
                }, null, 6), a[11] || (a[11] = w("header", null, [w("h1", null, "Populair")], -1)), w("table", null, [w("thead", null, [w("tr", null, [a[9] || (a[9] = w("th", {
                    class: "rank"
                }, null, -1)), a[10] || (a[10] = w("th", {
                    class: "sym"
                }, null, -1)), w("th", gl, S(C(oe)("depwi.coin")), 1), w("th", pl, S(C(oe)("exh.price")), 1), w("th", vl, S(C(oe)("exh.24h-change")), 1)])]), w("tbody", null, [(U(!0), k(_, null, D(null == (m = null == (u = be.categories.popular) ? void 0 : u.split(",")) ? void 0 : m.slice(0, 3), ((l, e) => {
                    var s, a, o, i, t, n;
                    return U(), k("tr", {
                        key: e,
                        onClick: e => C(me).push({
                            name: "trade-slug",
                            params: {
                                slug: l + "-USDT"
                            }
                        })
                    }, [w("td", bl, S(e + 1), 1), w("td", kl, [w("img", {
                        width: "18",
                        height: "18",
                        alt: "",
                        src: "/images/icons/coin/" + (null == l ? void 0 : l.toLowerCase()) + ".svg"
                    }, null, 8, yl)]), w("td", wl, S(l), 1), w("td", xl, S(null == (a = null == (s = be.coins._map[l + "/USDT"]) ? void 0 : s.usdRate) ? void 0 : a.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })), 1), w("td", Cl, [w("span", {
                        class: f((null == (o = be.coins._map[l + "/USDT"]) ? void 0 : o.change) > 0 ? "text-green-500" : (null == (i = be.coins._map[l + "/USDT"]) ? void 0 : i.change) < 0 ? "text-red-500" : "")
                    }, S(((null == (t = be.coins._map[l + "/USDT"]) ? void 0 : t.change) > 0 ? "+" : "") + (100 * (null == (n = be.coins._map[l + "/USDT"]) ? void 0 : n.chg)).toFixed(2)) + "% ", 3)])], 8, hl)
                })), 128))])])])]), w("div", fl, [w("div", jl, [w("div", {
                    class: f(["bg-leader", (null == (p = null == (g = be.categories.newlisting) ? void 0 : g.split(",")) ? void 0 : p.length) < 3 && "small-leader"]),
                    style: j("background-image: url(/images/icons/coin/" + (null == (h = null == (v = be.categories.newlisting) ? void 0 : v.split(",")[0]) ? void 0 : h.toLowerCase()) + ".svg);")
                }, null, 6), w("header", null, [w("h1", null, S(C(oe)("inx.new-listing")), 1)]), w("table", null, [w("thead", null, [w("tr", null, [a[12] || (a[12] = w("th", {
                    class: "rank"
                }, null, -1)), a[13] || (a[13] = w("th", {
                    class: "sym"
                }, null, -1)), w("th", Sl, S(C(oe)("depwi.coin")), 1), w("th", _l, S(C(oe)("exh.price")), 1), w("th", Dl, S(C(oe)("exh.24h-change")), 1)])]), w("tbody", null, [(U(!0), k(_, null, D(null == (R = null == (G = be.categories.newlisting) ? void 0 : G.split(",")) ? void 0 : R.slice(0, 3), ((l, e) => {
                    var s, a, o, i, t, n;
                    return U(), k("tr", {
                        key: e,
                        onClick: e => C(me).push({
                            name: "trade-slug",
                            params: {
                                slug: l + "-USDT"
                            }
                        })
                    }, [w("td", Fl, S(e + 1), 1), w("td", Ll, [w("img", {
                        width: "18",
                        height: "18",
                        alt: "",
                        src: "/images/icons/coin/" + (null == l ? void 0 : l.toLowerCase()) + ".svg"
                    }, null, 8, Ul)]), w("td", El, S(l), 1), w("td", Gl, S(null == (a = null == (s = be.coins._map[l + "/USDT"]) ? void 0 : s.usdRate) ? void 0 : a.toLocaleString(void 0, {
                        minimumFractionDigits: 2
                    })), 1), w("td", Pl, [w("span", {
                        class: f((null == (o = be.coins._map[l + "/USDT"]) ? void 0 : o.change) > 0 ? "text-green-500" : (null == (i = be.coins._map[l + "/USDT"]) ? void 0 : i.change) < 0 ? "text-red-500" : "")
                    }, S(((null == (t = be.coins._map[l + "/USDT"]) ? void 0 : t.change) > 0 ? "+" : "") + (100 * (null == (n = be.coins._map[l + "/USDT"]) ? void 0 : n.chg)).toFixed(2)) + "% ", 3)])], 8, Tl)
                })), 128))])])])])])]))]), w("div", Rl, [w("div", Vl, [w("div", Bl, [null != be.coins.USDT ? (U(), F(C(B), {
                    key: 0,
                    modelValue: pe.value,
                    "onUpdate:modelValue": a[1] || (a[1] = l => pe.value = l),
                    class: "markets-tabs text-medium"
                }, {
                    default: x((() => [y(C(N), {
                        name: "spot"
                    }, {
                        label: x((() => [w("span", zl, [w("span", null, S(C(oe)("dash.all")), 1)])])),
                        _: 1
                    }), y(C(N), {
                        name: "perpetual"
                    }, {
                        label: x((() => a[14] || (a[14] = [w("span", {
                            class: "custom-tabs-label"
                        }, [w("span", null, S("My GPTs"))], -1)]))),
                        _: 1
                    }), y(C(N), {
                        disabled: ""
                    }, {
                        label: x((() => [y(C(I), {
                            modelValue: ve.value,
                            "onUpdate:modelValue": a[0] || (a[0] = l => ve.value = l),
                            class: "searchCoin",
                            placeholder: C(oe)("dash.search")
                        }, {
                            prefix: x((() => a[15] || (a[15] = [w("i", {
                                class: "el-input__icon fas fa-search"
                            }, null, -1)]))),
                            _: 1
                        }, 8, ["modelValue", "placeholder"])])),
                        _: 1
                    })])),
                    _: 1
                }, 8, ["modelValue"])) : T("", !0), ae.value ? T("", !0) : (U(), k("div", Nl, [y(C(O), null, {
                    default: x((() => [w("div", Ol, [w("div", {
                        class: f(["category", "" == he.value && "active-cat"]),
                        onClick: a[2] || (a[2] = l => he.value = "")
                    }, [a[16] || (a[16] = w("div", {
                        class: "asset"
                    }, [w("div", {
                        class: "asset-logo"
                    }, [w("img", {
                        src: "/images/icons/cat/all.svg",
                        class: "img-asset"
                    })])], -1)), w("div", Wl, S(C(oe)("dash.all")), 1)], 2), (U(!0), k(_, null, D(be.categoriesName, ((l, e) => (U(), k("div", {
                        key: e,
                        class: f(["category", he.value == l && "active-cat"]),
                        onClick: e => he.value = l
                    }, [w("div", Il, [w("div", Ml, [w("img", {
                        src: "/images/icons/cat/" + l + ".svg",
                        class: "img-asset"
                    }, null, 8, Hl)])]), w("div", ql, S(C(oe)("ctm." + l)), 1)], 10, Al)))), 128))])])),
                    _: 1
                })]))]), w("div", Kl, [L((U(), F(C(W), {
                    "element-loading-background": "rgba(122, 122, 122, 0.8)",
                    "element-loading-text": C(oe)("pga.loading"),
                    "element-loading-spinner": C(P),
                    "element-loading-svg-view-box": "-10, -10, 50, 50",
                    data: ye.value,
                    "tooltip-effect": "dark",
                    class: "slim-table",
                    "table-layout": "fixed",
                    style: {
                        width: "100%",
                        "min-height": "150px"
                    }
                }, {
                    default: x((() => [y(C(A), {
                        label: C(oe)("wall.symbol"),
                        width: "165",
                        "label-class-name": "coinName"
                    }, {
                        default: x((l => {
                            var e;
                            return [y(ce), w("div", {
                                class: f(l.row.symbol == be.symbol ? "" : "cursor-pointer"),
                                onClick: () => {
                                    xe(l.row)
                                }
                            }, [w("span", Jl, [w("img", {
                                class: "imgSelect",
                                src: "/images/icons/coin/" + (null == (e = l.row.coin) ? void 0 : e.toLowerCase()) + ".svg"
                            }, null, 8, Xl)]), w("span", Yl, S(l.row.symbol), 1)], 10, Zl)]
                        })),
                        _: 1
                    }, 8, ["label"]), y(C(A), {
                        label: C(oe)("exh.price"),
                        prop: "usdRate",
                        align: "right",
                        sortable: ""
                    }, {
                        default: x((l => [w("div", {
                            onClick: () => {
                                xe(l.row)
                            }
                        }, S(l.row.usdRate.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 9, Ql)])),
                        _: 1
                    }, 8, ["label"]), te.value ? T("", !0) : (U(), F(C(A), {
                        key: 0,
                        label: C(oe)("exh.24h-high"),
                        align: "right",
                        sortable: ""
                    }, {
                        default: x((l => [w("div", {
                            onClick: () => {
                                xe(l.row)
                            }
                        }, S(l.row.high.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 9, $l)])),
                        _: 1
                    }, 8, ["label"])), te.value ? T("", !0) : (U(), F(C(A), {
                        key: 1,
                        label: C(oe)("exh.24h-low"),
                        align: "right",
                        sortable: ""
                    }, {
                        default: x((l => [w("div", {
                            onClick: () => {
                                xe(l.row)
                            }
                        }, S(l.row.low.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 9, le)])),
                        _: 1
                    }, 8, ["label"])), te.value ? T("", !0) : (U(), F(C(A), {
                        key: 2,
                        label: C(oe)("exh.24h-volume"),
                        align: "right",
                        sortable: ""
                    }, {
                        default: x((l => [w("div", {
                            onClick: () => {
                                xe(l.row)
                            }
                        }, S(l.row.volume.toLocaleString(void 0, {
                            minimumFractionDigits: 2
                        })), 9, ee)])),
                        _: 1
                    }, 8, ["label"])), y(C(A), {
                        label: te.value ? "24H" : C(oe)("exh.24h-change"),
                        prop: "change",
                        align: "right",
                        sortable: ""
                    }, {
                        default: x((l => [w("div", {
                            class: f(l.row.symbol == be.symbol ? "" : "cursor-pointer"),
                            onClick: () => {
                                xe(l.row)
                            }
                        }, [w("span", {
                            class: f(l.row.change > 0 ? "text-green-500" : l.row.change < 0 ? "text-red-500" : "")
                        }, S((l.row.change > 0 ? "+" : "") + (100 * l.row.chg).toFixed(2)) + "% ", 3)], 10, se)])),
                        _: 1
                    }, 8, ["label"]), te.value ? T("", !0) : (U(), F(C(A), {
                        key: 3,
                        align: "right"
                    }, {
                        header: x((() => a[17] || (a[17] = []))),
                        default: x((l => [y(C(V), {
                            text: "",
                            size: "small",
                            class: "text-10 text-medium",
                            onClick: e => (l => {
                                ne.value = l.row.symbol.split("/")[0], ie.value = !0, re.value = !0
                            })(l)
                        }, {
                            default: x((() => [E(S(C(oe)("sett.details")), 1)])),
                            _: 2
                        }, 1032, ["onClick"]), y(C(V), {
                            text: "",
                            size: "small",
                            class: "text-10 text-medium",
                            onClick: e => (l => {
                                me.push({
                                    name: "trade-slug",
                                    params: {
                                        slug: l.row.symbol.replace("/", "-")
                                    }
                                })
                            })(l)
                        }, {
                            default: x((() => [E(S(C(oe)("sett.trade")), 1)])),
                            _: 2
                        }, 1032, ["onClick"])])),
                        _: 1
                    }))])),
                    _: 1
                }, 8, ["element-loading-text", "element-loading-spinner", "data"])), [
                    [C(z), ae.value]
                ])])])])])]), ie.value ? (U(), F(de, {
                    key: 0,
                    single: !1,
                    coinname: ne.value,
                    modelValue: re.value,
                    "onUpdate:modelValue": a[3] || (a[3] = l => re.value = l)
                }, null, 8, ["coinname", "modelValue"])) : T("", !0), y(ue, {
                    content: C(l),
                    cta: !1,
                    color: "dark"
                }, null, 8, ["content"])], 64)
            }
        }
    }), [
        ["__scopeId", "data-v-5fcc8d75"]
    ]);
export {
    ae as
    default
};