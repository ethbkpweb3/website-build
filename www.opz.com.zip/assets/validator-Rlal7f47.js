import {c as s} from "./index-D4R9Vjdp.js";
const i = i => ["", ...s].includes(i);
export {i};
