function e(e=1e3){return new Promise((t=>{setTimeout(t,e)}))}export{e as s};
