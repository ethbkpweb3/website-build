function t(t,o){t.target.src=`https://via.placeholder.com/${o}`}export{t as o};
