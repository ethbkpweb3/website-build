const o=(o,r)=>Math.floor(o*10**r)/10**r;export{o as r};
