const o={};export{o as b};
